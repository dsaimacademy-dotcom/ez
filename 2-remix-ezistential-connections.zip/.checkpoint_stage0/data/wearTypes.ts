import { WearType, ColorItem, MasterSizeItem } from '../types';

export const DEFAULT_MASTER_SIZES: MasterSizeItem[] = [
  { id: 'size-xs', name: 'XS', label: 'Extra Small', category: 'Standard Adult', chestInch: '34-36"', lengthInch: '27"', active: true, sortOrder: 1 },
  { id: 'size-s', name: 'S', label: 'Small', category: 'Standard Adult', chestInch: '36-38"', lengthInch: '28"', active: true, sortOrder: 2 },
  { id: 'size-m', name: 'M', label: 'Medium', category: 'Standard Adult', chestInch: '40-42"', lengthInch: '29"', active: true, sortOrder: 3 },
  { id: 'size-l', name: 'L', label: 'Large', category: 'Standard Adult', chestInch: '44-46"', lengthInch: '30"', active: true, sortOrder: 4 },
  { id: 'size-xl', name: 'XL', label: 'Extra Large', category: 'Standard Adult', chestInch: '48-50"', lengthInch: '31"', active: true, sortOrder: 5 },
  { id: 'size-2xl', name: '2XL', label: 'Double Extra Large', category: 'Standard Adult', chestInch: '52-54"', lengthInch: '32"', active: true, sortOrder: 6 },
  { id: 'size-3xl', name: '3XL', label: 'Triple Extra Large', category: 'Standard Adult', chestInch: '56-58"', lengthInch: '33"', active: true, sortOrder: 7 },
  { id: 'size-os', name: 'OS', label: 'One Size / Universal', category: 'Unisex / Accessories', chestInch: 'Universal', lengthInch: 'Universal', active: true, sortOrder: 8 },
];

export const DEFAULT_WEAR_TYPES: WearType[] = [
  {
    id: 'wt-heavyweight-tee',
    name: '6.5oz Heavyweight Boxy Tee',
    category: 'tee',
    baseCost: 18.5,
    defaultRetailPrice: 48,
    fabric: '100% Organic Combed Ringspun Cotton',
    weight: '6.5 oz / 220 GSM Heavyweight Jersey',
    fit: 'Relaxed drop-shoulder boxy architectural silhouette with 1.25" reinforced rib collar',
    origin: 'Ethically crafted in Los Angeles, CA',
    printTechnique: 'Direct-to-Film (DTF) Soft-Hand Archival Pigment',
    supplierSku: 'APL-TEE-6500',
    active: true,
  },
  {
    id: 'wt-boxy-hoodie',
    name: '14oz Architectural Boxy Hoodie',
    category: 'hoodie',
    baseCost: 34.0,
    defaultRetailPrice: 88,
    fabric: '100% Heavyweight French Terry Cotton',
    weight: '14 oz / 460 GSM Heavyweight Fleece',
    fit: 'Oversized boxy drape, seamless drop-shoulder, double-lined structural hood',
    origin: 'Ethically crafted in Los Angeles, CA',
    printTechnique: 'Direct-to-Film (DTF) Archival Discharge Print',
    supplierSku: 'APL-HD-1400',
    active: true,
  },
  {
    id: 'wt-drop-crewneck',
    name: '12oz Drop-Shoulder Crewneck',
    category: 'crewneck',
    baseCost: 28.5,
    defaultRetailPrice: 74,
    fabric: '100% Brushed Fleece Cotton',
    weight: '12 oz / 380 GSM Heavyweight',
    fit: 'Classic relaxed boxy cut with reinforced collar and storm cuffs',
    origin: 'Ethically crafted in Los Angeles, CA',
    printTechnique: 'Direct-to-Film (DTF) Archival Print',
    supplierSku: 'APL-CRW-1200',
    active: true,
  },
  {
    id: 'wt-ribbed-longsleeve',
    name: '7oz Ribbed Long Sleeve Tee',
    category: 'tee',
    baseCost: 21.0,
    defaultRetailPrice: 56,
    fabric: '100% Combed Ringspun Cotton',
    weight: '7.0 oz / 240 GSM Mid-Heavy',
    fit: 'Relaxed body silhouette with architectural ribbed wrist cuffs',
    origin: 'Ethically crafted in Los Angeles, CA',
    printTechnique: 'Direct-to-Film (DTF) Soft-Hand Pigment',
    supplierSku: 'APL-LS-7000',
    active: true,
  },
  {
    id: 'wt-canvas-tote',
    name: '16oz Heavyweight Canvas Dialogue Tote',
    category: 'accessory',
    baseCost: 14.0,
    defaultRetailPrice: 38,
    fabric: '100% Heavyweight Cotton Duck Canvas',
    weight: '16 oz Rugged Canvas',
    fit: 'Architectural structured tote with reinforced webbed handles and interior zip pocket',
    origin: 'Ethically crafted in Los Angeles, CA',
    printTechnique: 'High-density pigment screenprint',
    supplierSku: 'APL-TOTE-160',
    active: true,
  },
];

export const MASTER_COLOR_LIBRARY: ColorItem[] = [
  { id: 'col-obsidian-black', name: 'Obsidian Black', hex: '#0f0f0f', category: 'Monochrome', active: true },
  { id: 'col-raw-ecru', name: 'Raw Ecru', hex: '#f4f1ea', category: 'Earth / Neutral', active: true },
  { id: 'col-heather-grey', name: 'Heather Grey', hex: '#d1d5db', category: 'Monochrome', active: true },
  { id: 'col-washed-navy', name: 'Washed Navy', hex: '#1e293b', category: 'Deep Tone', active: true },
  { id: 'col-forest-moss', name: 'Forest Moss', hex: '#1c2826', category: 'Earth / Neutral', active: true },
  { id: 'col-terracotta-rust', name: 'Terracotta Rust', hex: '#7c2d12', category: 'Warm Tone', active: true },
  { id: 'col-vintage-bone', name: 'Vintage Bone', hex: '#e7e5e4', category: 'Earth / Neutral', active: true },
  { id: 'col-washed-charcoal', name: 'Washed Charcoal', hex: '#262626', category: 'Monochrome', active: true },
];

/**
 * Calculates POD estimated gross profit margin percentage
 */
export function calculatePodMargin(retailPrice: number, baseCost: number): {
  profit: number;
  marginPercent: number;
} {
  const profit = Math.max(0, retailPrice - baseCost);
  const marginPercent = retailPrice > 0 ? Math.round((profit / retailPrice) * 100) : 0;
  return { profit, marginPercent };
}
