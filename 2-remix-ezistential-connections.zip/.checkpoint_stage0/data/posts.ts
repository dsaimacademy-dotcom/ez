import { BlogPost } from '../types';

export const INITIAL_BLOG_POSTS: BlogPost[] = [
  {
    id: 'post-001',
    slug: 'the-distance-between-us-is-man-made',
    title: 'The Distance Between Us Is Man-Made',
    excerpt: 'Examining why physical proximity in modern cities often coincides with emotional isolation, and how wearable prompts spark genuine human connection.',
    category: 'Essay & Philosophy',
    authorName: 'Ezistential Editorial',
    authorRole: 'Founding Collective',
    publishedAt: '2026-09-15T08:00:00.000Z',
    isPublished: true,
    isFeatured: true,
    readTimeMinutes: 5,
    coverImage: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=1200&auto=format&fit=crop',
    tags: ['Human Connection', 'Philosophy', 'Garment Design', 'Public Space'],
    content: `
We share the same sidewalk, ride the same trains, and order coffee at the same counters, yet we move through public space encased in noise-canceling armor. 

When we founded **Ezistential Connections**, we asked a fundamental question: *Can a garment serve as a quiet inquiry rather than a billboard?*

### Clothing as a Conversation Surface

Fast fashion relies on aggressive branding—huge logos, artificial urgency, and status signaling. We rejected that model entirely. Instead, each heavy 6.5oz organic cotton tee carries a quiet question or thesis embroidered in low-contrast thread.

> "Difference is not a defect to be eliminated. Somewhere between you and me, there is an us worth discovering."

When someone reads your shirt on the street, the barrier of anonymity momentarily softens. You are no longer two strangers avoiding eye contact; you are two minds contemplating the same reflection.

### What Comes Next

In the coming months, we will publish archived reflections submitted by wearers across Chicago, New York, London, and Tokyo. Every order includes a reflection prompt card where you can contribute your voice to the central archive.
    `,
  },
  {
    id: 'post-002',
    slug: 'heavyweight-cotton-and-digital-dignity',
    title: '6.5oz Heavyweight Cotton & Digital Dignity',
    excerpt: 'Inside our Chicago studio: selecting 100% combed cotton, zero-waste on-demand printing, and rejecting aggressive ad tracking.',
    category: 'Craft & Process',
    authorName: 'Studio Director',
    authorRole: 'Production & Textile Lead',
    publishedAt: '2026-09-22T10:30:00.000Z',
    isPublished: true,
    isFeatured: false,
    readTimeMinutes: 4,
    coverImage: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=1200&auto=format&fit=crop',
    tags: ['Fabric Craft', 'Made to Order', 'Digital Dignity', 'Sustainability'],
    content: `
A garment must feel substantial before it can mean anything intellectually. If a t-shirt feels flimsy or loses its shape after three washes, the message carried on it feels equally ephemeral.

### The 6.5oz Standard

Our inaugural collection uses custom-milled 6.5oz/yd² (220 GSM) 100% combed ring-spun cotton. 

* **Pre-shrunk integrity:** Zero surprise shrinkage in domestic wash cycles.
* **Relaxed editorial fit:** Structured shoulders with a natural drape.
* **Water-based inks:** Soft-hand feel where the ink binds into the fiber rather than sitting on top like plastic film.

### Rejecting Surveillance Commerce

Digital Dignity means we do not track you across the internet with retargeting pixels or sell your browsing history. Your attention is yours. When you order from Ezistential Connections, your transaction is encrypted, fulfilled on-demand, and stored in our central private cloud.
    `,
  },
  {
    id: 'post-003',
    slug: 'reflections-from-the-archival-community',
    title: 'Reflections from the Archival Community',
    excerpt: 'A curated selection of customer contributions answering "What does human connection mean to you in 2026?"',
    category: 'Community Journal',
    authorName: 'Archival Curator',
    authorRole: 'Community Lead',
    publishedAt: '2026-09-28T14:15:00.000Z',
    isPublished: true,
    isFeatured: false,
    readTimeMinutes: 3,
    coverImage: 'https://images.unsplash.com/photo-1499209974431-9dddcece7f88?q=80&w=1200&auto=format&fit=crop',
    tags: ['Community', 'Reflections', 'Archive', 'Humanity'],
    content: `
Last week, we opened the **Reflections Archive** inside the online store. We asked a simple question: *When was the last time a stranger changed your perspective?*

Here are three entries selected by our moderation team for this week’s journal update:

> **"I was sitting on the Damen blue line platform when someone commented on my shirt's embroidery. We ended up talking for twenty minutes about moving to a new city alone."**  
> — *Elena M., Chicago*

> **"In a world where everything is automated, holding a garment that asks a thoughtful question feels like a deliberate pause button."**  
> — *Marcus T., Brooklyn*

You can submit your own reflection anytime via the Reflection prompt on any garment page or directly in the Connection Archive.
    `,
  },
];
