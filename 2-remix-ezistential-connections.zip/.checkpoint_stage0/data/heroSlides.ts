import { HeroSlide } from '../types';

export const DEFAULT_HERO_SLIDES: HeroSlide[] = [
  // SLIDE 1: The Iconic Black (Noir Luxury Archival)
  {
    id: 'slide-noir-beginning',
    chapterNumber: '01',
    chapterLabel: 'The Threshold',
    tagline: 'The Medium Is Clothing. The Subject Is Connection.',
    headline: 'We share the same world, yet we experience each other at a distance.',
    subheadline:
      'Ezistential Connections examines the space between people. Our garments carry quiet questions into public space, interrupting assumptions, honoring difference, and opening the possibility of discovery.',
    primaryCtaText: 'Explore Garments',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'Why We Exist',
    secondaryCtaTarget: 'why-we-exist',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'noir-black',
    overlayOpacity: 0.62,
    accentHex: '#d4d4d4',
    overlayColor: '#0a0a0a',
    gradientStyle: 'cinematic',
    active: true,
  },
  // SLIDE 2: Golden Hour Connection (Contrast as Catalyst)
  {
    id: 'slide-golden-contrast',
    chapterNumber: '02',
    chapterLabel: 'Contrast as Catalyst',
    tagline: 'Difference Is Not A Defect. It Is The Threshold.',
    headline: 'We are not the same. That is the entire point.',
    subheadline:
      'Without difference, curiosity is impossible. Contrast is where human consciousness awakens. Our heavyweight combed cotton pieces are cut with architectural restraint to prompt recognition where casual assumptions once reigned.',
    primaryCtaText: 'View Inaugural Collection',
    primaryCtaTarget: 'collections',
    secondaryCtaText: 'Read The Manifesto',
    secondaryCtaTarget: 'manifesto',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'golden-amber',
    overlayOpacity: 0.50,
    accentHex: '#f59e0b',
    overlayColor: '#0a0a0a',
    gradientStyle: 'soft',
    active: true,
  },
  // SLIDE 3: Terracotta Sunset (Ideas in Public Space)
  {
    id: 'slide-terracotta-public',
    chapterNumber: '03',
    chapterLabel: 'Ideas in Motion',
    tagline: 'Ideas Pinned To Screens Fade. Worn Ideas Walk.',
    headline: 'A garment moves through the world and introduces a pause.',
    subheadline:
      'Every screen confines us inside algorithmic mirrors. A physical garment worn on a crowded sidewalk crosses physical thresholds, interrupts the gaze of a stranger, and asks a question without raising its voice.',
    primaryCtaText: 'Explore Garment Catalog',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'Public Encounters',
    secondaryCtaTarget: 'connection',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'terracotta-sunset',
    overlayOpacity: 0.48,
    accentHex: '#ea580c',
    overlayColor: '#1a0f0a',
    gradientStyle: 'cinematic',
    active: true,
  },
  // SLIDE 4: Twilight Indigo (The Man-Made Chasm)
  {
    id: 'slide-twilight-silence',
    chapterNumber: '04',
    chapterLabel: 'The Man-Made Chasm',
    tagline: 'The Distance Between Us Is Man-Made.',
    headline: 'If distance is built by human silence, it can be dismantled by curiosity.',
    subheadline:
      '6.5oz on-demand heavyweight garments crafted with tactile permanence. Conceived in Chicago for thoughtful individuals who refuse to replace living human beings with shallow labels.',
    primaryCtaText: 'Contemplate Garments',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'Human Connection Archive',
    secondaryCtaTarget: 'connection',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'twilight-indigo',
    overlayOpacity: 0.52,
    accentHex: '#6366f1',
    overlayColor: '#090d16',
    gradientStyle: 'soft',
    active: true,
  },
  // SLIDE 5: Architectural Earth (The Space Between Us)
  {
    id: 'slide-earth-recognition',
    chapterNumber: '05',
    chapterLabel: 'The Space Between',
    tagline: 'Somewhere Between You And Me, There Is An Us.',
    headline: 'Clothing created not to impress, but to invite recognition.',
    subheadline:
      'Ethically cut, sustainably finished on-demand, and stamped with philosophical theses that transform ordinary urban transit into an authentic human threshold.',
    primaryCtaText: 'Discover The Range',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'Our Origin Story',
    secondaryCtaTarget: 'our-story',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'golden-amber',
    overlayOpacity: 0.50,
    accentHex: '#d97706',
    overlayColor: '#0a0a0a',
    gradientStyle: 'minimal',
    active: true,
  },
];
