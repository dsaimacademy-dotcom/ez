import { SizeMeasurement } from '../types';

export const SIZE_GUIDE_DATA: SizeMeasurement[] = [
  {
    size: 'XS',
    chestInches: '36 - 38"',
    lengthInches: '27"',
    sleeveInches: '8.0"',
    chestCm: '91 - 96 cm',
    lengthCm: '68 cm',
    sleeveCm: '20 cm',
  },
  {
    size: 'S',
    chestInches: '38 - 40"',
    lengthInches: '28"',
    sleeveInches: '8.5"',
    chestCm: '96 - 101 cm',
    lengthCm: '71 cm',
    sleeveCm: '21 cm',
  },
  {
    size: 'M',
    chestInches: '40 - 42"',
    lengthInches: '29"',
    sleeveInches: '9.0"',
    chestCm: '101 - 106 cm',
    lengthCm: '73 cm',
    sleeveCm: '23 cm',
  },
  {
    size: 'L',
    chestInches: '42 - 44"',
    lengthInches: '30"',
    sleeveInches: '9.5"',
    chestCm: '106 - 111 cm',
    lengthCm: '76 cm',
    sleeveCm: '24 cm',
  },
  {
    size: 'XL',
    chestInches: '46 - 48"',
    lengthInches: '31"',
    sleeveInches: '10.0"',
    chestCm: '116 - 121 cm',
    lengthCm: '78 cm',
    sleeveCm: '25 cm',
  },
  {
    size: '2XL',
    chestInches: '50 - 52"',
    lengthInches: '32"',
    sleeveInches: '10.5"',
    chestCm: '127 - 132 cm',
    lengthCm: '81 cm',
    sleeveCm: '26 cm',
  },
  {
    size: '3XL',
    chestInches: '54 - 56"',
    lengthInches: '33"',
    sleeveInches: '11.0"',
    chestCm: '137 - 142 cm',
    lengthCm: '83 cm',
    sleeveCm: '28 cm',
  },
];

export const SIZE_MEASURING_TIPS = [
  {
    title: 'Chest Width',
    instruction: 'Measure across the fullest part of your chest, keeping the tape horizontal under your arms.',
  },
  {
    title: 'Body Length',
    instruction: 'Measure from the highest point of the shoulder seam straight down to the bottom hem.',
  },
  {
    title: 'Cut & Fit',
    instruction: 'Our garments feature a relaxed drop-shoulder cut. If you prefer a fitted traditional aesthetic, consider sizing down one size.',
  },
];
