import { CustomerResponse } from '../types';

export const MANIFESTO_BRIEF = {
  title: 'We Believe in the Space Between Us',
  subtitle: 'An interruption to assumptions, labels, and silence.',
  excerpt: 'We share the same world, yet we experience each other at a distance. Difference is not a defect to be eliminated, nor is it an excuse for division. Somewhere between you and me, there is an us worth discovering.',
};

export const MANIFESTO_FULL = {
  title: 'We Believe in the Space Between Us',
  sections: [
    {
      heading: 'The Presumption of Distance',
      body: 'Look across any public square, any transit car, any crowded sidewalk. We share the same physical air, yet the distance between two individuals can feel immense. We summarize each other in a microsecond, cataloging faces by clothes, age, skin, posture, and political assumptions. We replace the living person with a label.',
    },
    {
      heading: 'Difference Is the Point',
      body: 'We are told that unity requires sameness: that we must agree, adopt uniform slogans, or erase what makes us distinct. Ezistential Connections rejects this premise. We are not the same. That is the entire point. Contrast is where consciousness awakens. Without difference, curiosity is impossible.',
    },
    {
      heading: 'Clothing as Public Discourse',
      body: 'Why clothing? Because clothing moves. An idea pinned to a screen stays confined to an algorithmic echo chamber. But a garment worn by a human being walks through the world. It crosses thresholds. It introduces a pause in the gaze of a passerby. It asks a question without raising its voice.',
    },
    {
      heading: 'The Space Between',
      body: 'The first garment we conceived bore seven words: "THE DISTANCE BETWEEN US IS MAN-MADE." If distance is constructed by human hands and human silence, it can be dismantled by human curiosity. Somewhere between you and me, there is an us worth discovering.',
    },
  ],
};

export const WHY_WE_EXIST_CONTENT = {
  title: 'Why We Exist',
  subheading: 'Distance can become disconnection. Difference can become separation.',
  sections: [
    {
      lead: 'The Problem of Distance',
      paragraphs: [
        'People are often understood from a distance through assumptions, quick labels, and incomplete information. In a noisy society, the gap between what we see and who someone actually is widens every day.',
        'When distance goes unexamined, it quietly turns into estrangement. We cease seeing individuals; we see caricatures, adversaries, or invisible silhouettes passing on the street.',
      ],
    },
    {
      lead: 'Our Role in the Threshold',
      paragraphs: [
        'Ezistential Connections exists precisely in that space between people. Not to offer grandiose solutions or dogmatic answers, but to plant quiet questions in public view.',
        'We believe a simple pause, whether a double take on a sidewalk or an honest reflection across a counter, is where the architecture of empathy begins.',
      ],
    },
  ],
};

export const OUR_STORY_CONTENT = {
  title: 'Our Story',
  subheading: 'From a cold night in November 2008 to ideas walking through the world.',
  timeline: [
    {
      year: 'November 2008',
      title: 'The Observation',
      description: 'On election night in 2008, as crowds gathered in public spaces across the country, our founders observed a profound paradox: despite shared civic space, people looked at one another across deep chasms of unspoken tension and mutual assumptions.',
    },
    {
      year: 'The Realization',
      title: 'The Medium of the Public',
      description: 'Books and speeches are chosen by those who already agree. But clothing moves through neutral territory. A shirt enters the subway, the supermarket, the coffee shop. It can make someone look twice. It carries an idea beyond the person wearing it.',
    },
    {
      year: 'The First Print',
      title: '"THE DISTANCE BETWEEN US IS MAN-MADE"',
      description: 'The inaugural phrase was printed with intentional simplicity. It became the bedrock of Ezistential Connections, serving as a tactile inquiry into how we treat difference.',
    },
    {
      year: 'Today',
      title: 'An Open Invitation',
      description: 'Today, each garment we release is designed as an open inquiry. The wearer is not a walking billboard; the wearer is an active participant in an ongoing human question.',
    },
  ],
};

export const INITIAL_CUSTOMER_RESPONSES: CustomerResponse[] = [
  {
    id: 'resp-001',
    productId: 'prod-distance-01',
    productName: 'The Distance Tee',
    authorName: 'Marcus V.',
    authorLocation: 'Chicago, IL',
    response: 'I wore this on the Blue Line train. A woman sitting across from me read the chest print twice, met my eyes, and simply nodded with a warmth that completely changed my morning commute.',
    photoUrl: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
    garmentOnBodySize: 'L',
    status: 'Approved',
    permissionGranted: true,
    featuredQuote: true,
    createdAt: '2026-02-10T14:32:00Z',
  },
  {
    id: 'resp-002',
    productId: 'prod-difference-02',
    productName: 'The Difference Tee',
    authorName: 'Elena R.',
    authorLocation: 'Austin, TX',
    response: 'Saying "We are not the same, that’s the point" stopped a heated conversation with my family and turned it into an actual exchange. We spent two hours talking about how our backgrounds shaped us instead of arguing about headlines.',
    photoUrl: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80',
    garmentOnBodySize: 'M',
    status: 'Approved',
    permissionGranted: true,
    featuredQuote: true,
    createdAt: '2026-02-14T09:15:00Z',
  },
  {
    id: 'resp-003',
    productId: 'prod-connection-03',
    productName: 'The Connection Tee',
    authorName: 'David K.',
    authorLocation: 'Philadelphia, PA',
    response: 'The fabric weight is substantial, but what I appreciate most is that it doesn’t scream at people. It feels like an authentic thought rather than corporate apparel.',
    photoUrl: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=800&q=80',
    garmentOnBodySize: 'XL',
    status: 'Approved',
    permissionGranted: true,
    featuredQuote: true,
    createdAt: '2026-02-22T18:40:00Z',
  },
  {
    id: 'resp-004',
    productId: 'prod-discovery-04',
    productName: 'The Discovery Long Sleeve',
    authorName: 'Amara S.',
    authorLocation: 'Brooklyn, NY',
    response: 'The 6.5oz cotton has an architectural drape that feels protective without being stiff. A stranger at my neighborhood bakery tapped my shoulder to ask what the back statement meant. We stood by the counter sharing stories for twenty minutes. When does clothing ever do that?',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
    garmentOnBodySize: 'S',
    status: 'Approved',
    permissionGranted: true,
    featuredQuote: true,
    createdAt: '2026-02-26T11:20:00Z',
  },
  {
    id: 'resp-005',
    productId: 'prod-space-05',
    productName: 'The Space Between Crewneck',
    authorName: 'Julian T.',
    authorLocation: 'Seattle, WA',
    response: 'Most modern streetwear is loud graphic noise designed to flex status. Ezistential Connections is the exact opposite: it’s quiet, heavyweight, and intellectually generous. You wear it and realize you are carrying an invitation for curiosity into the room.',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80',
    garmentOnBodySize: 'XL',
    status: 'Approved',
    permissionGranted: true,
    featuredQuote: true,
    createdAt: '2026-03-02T16:15:00Z',
  },
  {
    id: 'resp-006',
    productId: 'prod-threshold-06',
    productName: 'The Threshold Heavyweight Tee',
    authorName: 'Nadia H.',
    authorLocation: 'Montreal, QC',
    response: 'After months of wear and washes, the collar remains crisp and the cotton has only softened into a rich, lived-in patina. People constantly double-take at the words. It creates moments of mutual vulnerability in a city where everyone usually looks down at their phones.',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80',
    garmentOnBodySize: 'M',
    status: 'Approved',
    permissionGranted: true,
    featuredQuote: true,
    createdAt: '2026-03-05T09:45:00Z',
  },
];
