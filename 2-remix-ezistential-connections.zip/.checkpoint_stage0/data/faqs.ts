import { FAQItem } from '../types';

export const FAQ_DATA: FAQItem[] = [
  {
    id: 'faq-brand-1',
    category: 'Brand & Meaning',
    question: 'What does "Ezistential Connections" mean?',
    answer: 'Ezistential Connections explores the subtle space between people. We share the same world, yet we often encounter each other through assumptions, distance, and labels. Ezistential Connections creates garments that act as gentle interruptions to that distance, prompting people to pause and reconsider how we relate.',
  },
  {
    id: 'faq-brand-2',
    category: 'Brand & Meaning',
    question: 'Is Ezistential Connections a political brand or campaign?',
    answer: 'No. While our origin was sparked by observing public dynamics during election night in November 2008, Ezistential Connections is not affiliated with any political party, candidate, or policy agenda. We do not engage in political persuasion. We ask timeless human questions about identity, difference, and the limits of understanding someone from afar.',
  },
  {
    id: 'faq-brand-3',
    category: 'Brand & Meaning',
    question: 'Why chose clothing as the medium for ideas?',
    answer: 'Clothing moves through public space. A sentence in a book stays on a shelf; a shirt walks through a grocery store, a subway station, a cafe, and a street corner. A garment can make a stranger look twice, reflect, and perhaps start an unexpected conversation.',
  },
  {
    id: 'faq-prod-1',
    category: 'Products & Sizing',
    question: 'How do your shirts fit?',
    answer: 'Our tees are designed with a relaxed, modern drop-shoulder silhouette and a substantial 6.0–6.5 oz heavyweight cotton jersey. They drape naturally without clinging. If you prefer a closer, traditional fit, we recommend sizing down. Detailed chest and length measurements are available in our interactive Size Guide on every product page.',
  },
  {
    id: 'faq-prod-2',
    category: 'Products & Sizing',
    question: 'Where and how are your garments produced?',
    answer: 'We partner with vetted production facilities including Apliiq for on-demand direct-to-garment and direct-to-film printing using OEKO-TEX certified, eco-conscious water-based inks. We print on demand to eliminate unnecessary apparel waste and overproduction.',
  },
  {
    id: 'faq-ship-1',
    category: 'Shipping & Delivery',
    question: 'Where do you ship?',
    answer: 'At initial launch, Ezistential Connections ships exclusively within the United States. We plan to expand to international destinations in future phases once our logistical partners meet our quality standards.',
  },
  {
    id: 'faq-ship-2',
    category: 'Shipping & Delivery',
    question: 'How is shipping calculated?',
    answer: 'All orders of $75 or more automatically receive Free Standard US Shipping. For orders under $75, a flat shipping rate of $7.50 is applied at checkout.',
  },
  {
    id: 'faq-ship-3',
    category: 'Shipping & Delivery',
    question: 'How long does production and delivery take?',
    answer: 'Because each garment is prepared on demand, production typically takes 2–4 business days. Once handed over to the carrier (USPS or UPS), delivery takes an additional 3–5 business days. You will receive an email with your tracking number the moment your order departs the facility.',
  },
  {
    id: 'faq-ret-1',
    category: 'Returns & Care',
    question: 'What is your return and exchange policy?',
    answer: 'Because our garments are printed specifically for you upon ordering, we do not support casual returns. However, if your garment arrives damaged, defective, or misprinted, we offer a 100% replacement or refund within 30 days of delivery. Reach out via our Contact page with your order number and photos of the issue.',
  },
  {
    id: 'faq-ret-2',
    category: 'Returns & Care',
    question: 'How should I care for my garment?',
    answer: 'Wash cold inside-out with like colors on a gentle cycle. We recommend line drying or hanging to dry to preserve the heavyweight cotton drape and protect the print over years of wear. If using a machine dryer, tumble dry on low.',
  },
];
