import React, { useState, useEffect } from 'react';
import { Product, ProductVariant, Size, WearType, ColorItem, DesignDraft } from '../../types';
import { useProducts } from '../../context/ProductContext';
import { calculatePodMargin } from '../../data/wearTypes';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import {
  Sparkles,
  Layers,
  ArrowRight,
  Plus,
  Trash2,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Info,
  Package,
  TrendingUp,
  Image as ImageIcon,
  Sliders,
  Filter,
  Check,
  RefreshCw
} from 'lucide-react';

interface ProductStudioProps {
  initialProduct?: Product | null;
  initialFromDesign?: { design: DesignDraft; versionNumber: number } | null;
  onClose: () => void;
  onSuccess: (savedProduct: Product) => void;
  showToast: (msg: string) => void;
}

const ALL_SIZES: Size[] = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];

export const ProductStudio: React.FC<ProductStudioProps> = ({
  initialProduct,
  initialFromDesign,
  onClose,
  onSuccess,
  showToast,
}) => {
  const { wearTypes, colors, designs, addProduct, updateProduct } = useProducts();

  // Active Stage Tab
  const [activeStage, setActiveStage] = useState<'info' | 'media' | 'story' | 'wear' | 'matrix' | 'fulfillment'>('info');

  // Stage 01: Commercial Info
  const [prodName, setProdName] = useState(initialProduct?.name || '');
  const [prodSlug, setProdSlug] = useState(initialProduct?.slug || '');
  const [prodTagline, setProdTagline] = useState(initialProduct?.tagline || '');
  const [prodPrice, setProdPrice] = useState(initialProduct?.price || 48);
  const [prodCollectionId, setProdCollectionId] = useState(initialProduct?.collectionId || 'core-concepts');
  const [prodAvailable, setProdAvailable] = useState(initialProduct?.isAvailable !== undefined ? initialProduct.isAvailable : true);
  const [prodSourceDesignId, setProdSourceDesignId] = useState<string | undefined>(initialProduct?.sourceDesignId);
  const [prodSourceDesignVersionId, setProdSourceDesignVersionId] = useState<string | undefined>(initialProduct?.sourceDesignVersionId);

  // Stage 02: Media
  const [prodPrimaryImage, setProdPrimaryImage] = useState(
    initialProduct?.primaryImage ||
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85'
  );
  const [prodGallery, setProdGallery] = useState<
    Array<{ url: string; alt: string; viewType: 'front' | 'rear' | 'detail' | 'fabric' | 'editorial' | 'on-body' }>
  >(initialProduct?.galleryImages || []);

  // Stage 03: Story & Philosophical Specifications
  const [prodThesis, setProdThesis] = useState(initialProduct?.storyA?.thesis || '');
  const [prodQuestion, setProdQuestion] = useState(initialProduct?.storyA?.question || '');
  const [prodWearerRole, setProdWearerRole] = useState(initialProduct?.storyA?.wearerRole || '');
  const [prodFabric, setProdFabric] = useState(initialProduct?.storyB?.fabric || '100% Organic Combed Ringspun Cotton');
  const [prodWeight, setProdWeight] = useState(initialProduct?.storyB?.weight || '6.5 oz / 220 GSM Heavyweight Jersey');
  const [prodFit, setProdFit] = useState(initialProduct?.storyB?.fit || 'Relaxed drop-shoulder boxy architectural drape');
  const [prodOrigin, setProdOrigin] = useState(initialProduct?.storyB?.origin || 'Ethically crafted in Los Angeles, CA');
  const [prodPrintTech, setProdPrintTech] = useState(initialProduct?.storyB?.printTechnique || 'Direct-to-Film (DTF) Soft-Hand Archival Pigment');
  const [prodProductionNotes, setProdProductionNotes] = useState(initialProduct?.storyB?.productionNotes || 'Printed on demand with eco-friendly water-based discharge inks.');
  const [prodDeliveryDays, setProdDeliveryDays] = useState(initialProduct?.storyB?.estimatedDeliveryDays || 'Production: 2–4 business days. Standard US delivery: 3–5 business days.');

  // Stage 04: Wear Types, Colors, Sizes
  const [selectedWearTypes, setSelectedWearTypes] = useState<string[]>(() => {
    if (initialProduct?.availableWearTypes && initialProduct.availableWearTypes.length > 0) {
      return initialProduct.availableWearTypes;
    }
    return ['6.5oz Heavyweight Boxy Tee'];
  });

  const [selectedColors, setSelectedColors] = useState<Array<{ name: string; hex: string }>>(() => {
    if (initialProduct?.availableColors && initialProduct.availableColors.length > 0) {
      return initialProduct.availableColors;
    }
    return [
      { name: 'Obsidian Black', hex: '#0f0f0f' },
      { name: 'Raw Ecru', hex: '#f4f1ea' },
    ];
  });

  const [selectedSizes, setSelectedSizes] = useState<Size[]>(() => {
    if (initialProduct?.availableSizes && initialProduct.availableSizes.length > 0) {
      return initialProduct.availableSizes;
    }
    return ['S', 'M', 'L', 'XL'];
  });

  // Stage 05: Variant Matrix & POD Fulfillment
  const [variants, setVariants] = useState<ProductVariant[]>(() => {
    if (initialProduct?.variants && initialProduct.variants.length > 0) {
      return initialProduct.variants;
    }
    return [];
  });

  const [podProvider, setPodProvider] = useState<'apliiq' | 'printful' | 'custom'>('apliiq');
  const [designPickerOpen, setDesignPickerOpen] = useState(false);

  // Matrix Filter State
  const [matrixFilterWearType, setMatrixFilterWearType] = useState<string>('all');
  const [matrixFilterColor, setMatrixFilterColor] = useState<string>('all');

  // Matrix Bulk Edit Inputs
  const [bulkPriceInput, setBulkPriceInput] = useState<string>('');
  const [bulkInventoryMode, setBulkInventoryMode] = useState<'pod' | 'stocked' | 'made_to_order'>('pod');

  // Auto-fill from incoming design draft if provided
  useEffect(() => {
    if (initialFromDesign) {
      const { design, versionNumber } = initialFromDesign;
      const ver = design.versions.find((v) => v.versionNumber === versionNumber) || design.versions[design.versions.length - 1];
      
      setProdName(design.name);
      setProdSlug(design.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
      setProdTagline(design.thesis);
      setProdThesis(design.thesis);
      setProdQuestion('What happens when we translate this inquiry into physical form?');
      setProdWearerRole('Carrying creative inquiry into public spaces.');
      setProdSourceDesignId(design.id);
      setProdSourceDesignVersionId(ver?.id || `ver-${versionNumber}`);

      if (ver?.artworkUrl) {
        setProdPrimaryImage(ver.artworkUrl);
        setProdGallery([
          { url: ver.artworkUrl, alt: `${design.name} Primary View`, viewType: 'front' },
          ...(ver.mockupUrl ? [{ url: ver.mockupUrl, alt: `${design.name} Mockup`, viewType: 'editorial' as const }] : []),
        ]);
      }

      if (ver?.suggestedWearTypes && ver.suggestedWearTypes.length > 0) {
        setSelectedWearTypes(ver.suggestedWearTypes);
      }

      if (ver?.suggestedColors && ver.suggestedColors.length > 0) {
        const mapped = ver.suggestedColors.map((cn) => {
          const found = colors.find((c) => c.name.toLowerCase() === cn.toLowerCase());
          return found ? { name: found.name, hex: found.hex } : { name: cn, hex: '#0f0f0f' };
        });
        setSelectedColors(mapped);
      }

      if (ver?.suggestedSizes && ver.suggestedSizes.length > 0) {
        setSelectedSizes(ver.suggestedSizes);
      }

      showToast(`Imported design "${design.name}" (v${versionNumber}) from Design Factory.`);
    }
  }, [initialFromDesign]);

  // Handler to import any design concept directly from modal
  const handleImportDesign = (design: DesignDraft, verNum: number) => {
    const ver = design.versions.find((v) => v.versionNumber === verNum) || design.versions[design.versions.length - 1];
    setProdName(design.name);
    setProdSlug(design.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
    setProdTagline(design.thesis);
    setProdThesis(design.thesis);
    setProdQuestion('What becomes possible when this inquiry is carried into public space?');
    setProdWearerRole('Observing boundaries and sparking authentic dialogue.');
    setProdSourceDesignId(design.id);
    setProdSourceDesignVersionId(ver?.id || `ver-${verNum}`);

    if (ver?.artworkUrl) {
      setProdPrimaryImage(ver.artworkUrl);
      setProdGallery([
        { url: ver.artworkUrl, alt: `${design.name} Artwork`, viewType: 'front' },
        ...(ver.mockupUrl ? [{ url: ver.mockupUrl, alt: `${design.name} Mockup`, viewType: 'editorial' as const }] : []),
      ]);
    }

    if (ver?.suggestedWearTypes && ver.suggestedWearTypes.length > 0) {
      setSelectedWearTypes(ver.suggestedWearTypes);
    }
    if (ver?.suggestedColors && ver.suggestedColors.length > 0) {
      const mapped = ver.suggestedColors.map((cn) => {
        const found = colors.find((c) => c.name.toLowerCase() === cn.toLowerCase());
        return found ? { name: found.name, hex: found.hex } : { name: cn, hex: '#0f0f0f' };
      });
      setSelectedColors(mapped);
    }
    if (ver?.suggestedSizes && ver.suggestedSizes.length > 0) {
      setSelectedSizes(ver.suggestedSizes);
    }

    setDesignPickerOpen(false);
    showToast(`Loaded Design Factory concept: "${design.name}".`);
  };

  // Synchronize / Generate Variant Matrix
  const handleGenerateMatrix = () => {
    if (selectedWearTypes.length === 0 || selectedColors.length === 0 || selectedSizes.length === 0) {
      showToast('Please select at least 1 wear type, 1 color, and 1 size first.');
      return;
    }

    const cleanSlug = prodSlug.trim() || prodName.toLowerCase().replace(/[^a-z0-9]+/g, '-').substring(0, 8);
    const generated: ProductVariant[] = [];

    selectedWearTypes.forEach((wtName) => {
      const wtObj = wearTypes.find((w) => w.name === wtName);
      const wtId = wtObj?.id || `wt-${wtName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
      const defaultRetail = wtObj?.defaultRetailPrice || prodPrice || 48;
      const isHoodie = wtName.toLowerCase().includes('hoodie');
      const isCrew = wtName.toLowerCase().includes('crewneck');
      const wearPrice = wtObj?.defaultRetailPrice || (isHoodie ? 88 : isCrew ? 74 : prodPrice || 48);

      selectedColors.forEach((color) => {
        selectedSizes.forEach((size) => {
          const existing = variants.find(
            (v) => (v.wearTypeName === wtName || v.wearTypeId === wtId) && v.size === size && v.colorName.toLowerCase() === color.name.toLowerCase()
          );

          if (existing) {
            generated.push({
              ...existing,
              wearTypeId: wtId,
              wearTypeName: wtName,
              colorHex: color.hex,
            });
          } else {
            const wtCode = wtName.split(' ')[0].toUpperCase();
            const colCode = color.name.replace(/[^a-zA-Z0-9]+/g, '-').toUpperCase().substring(0, 4);
            const sku = `EC-${cleanSlug.toUpperCase()}-${wtCode}-${size}-${colCode}`;

            generated.push({
              id: `var-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
              sku,
              wearTypeId: wtId,
              wearTypeName: wtName,
              size,
              colorName: color.name,
              colorHex: color.hex,
              priceOverride: wearPrice !== prodPrice ? wearPrice : undefined,
              inStock: true,
              inventoryMode: 'pod',
              quantity: 999,
              podProvider,
              podProductId: wtObj?.supplierSku || `APL-${wtCode}`,
              podVariantId: `APL-${cleanSlug.toUpperCase().substring(0, 4)}-${size}-${colCode}`,
            });
          }
        });
      });
    });

    setVariants(generated);
    showToast(`Generated ${generated.length} variants across ${selectedWearTypes.length} silhouettes.`);
  };

  // Save Commercial Garment
  const handleSaveGarment = () => {
    if (!prodName.trim()) {
      showToast('Please enter a garment name.');
      setActiveStage('info');
      return;
    }

    const finalSlug = prodSlug.trim() || prodName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    let finalVariants = variants;

    // If variants were not generated, generate them now
    if (finalVariants.length === 0) {
      const defaultWear = selectedWearTypes[0] || '6.5oz Heavyweight Boxy Tee';
      const wtObj = wearTypes.find((w) => w.name === defaultWear);
      finalVariants = selectedSizes.map((sz) => ({
        id: `var-${Date.now()}-${sz}`,
        sku: `EC-${finalSlug.toUpperCase()}-${sz}-${selectedColors[0]?.name.toUpperCase() || 'BLK'}`,
        wearTypeId: wtObj?.id || 'wt-heavyweight-tee',
        wearTypeName: defaultWear,
        size: sz,
        colorName: selectedColors[0]?.name || 'Obsidian Black',
        colorHex: selectedColors[0]?.hex || '#0f0f0f',
        inStock: true,
        inventoryMode: 'pod',
        quantity: 999,
        podProvider,
        podVariantId: `APL-${finalSlug.substring(0, 4).toUpperCase()}-${sz}`,
      }));
    }

    const productPayload: Product = {
      id: initialProduct?.id || `prod-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      slug: finalSlug,
      name: prodName.trim(),
      tagline: prodTagline.trim(),
      price: Number(prodPrice),
      collectionId: prodCollectionId,
      isFeatured: initialProduct?.isFeatured || false,
      isAvailable: prodAvailable,
      sourceDesignId: prodSourceDesignId,
      sourceDesignVersionId: prodSourceDesignVersionId,
      availableWearTypes: selectedWearTypes,
      availableColors: selectedColors,
      availableSizes: selectedSizes,
      primaryImage: prodPrimaryImage,
      galleryImages: prodGallery.length > 0 ? prodGallery : [
        { url: prodPrimaryImage, alt: `${prodName} Primary View`, viewType: 'front' }
      ],
      storyA: {
        headline: prodName,
        question: prodQuestion || 'How does this inquiry interrupt assumptions?',
        thesis: prodThesis || prodTagline,
        wearerRole: prodWearerRole || 'The Observer & Wayfarer',
      },
      storyB: {
        fabric: prodFabric,
        weight: prodWeight,
        fit: prodFit,
        origin: prodOrigin,
        printTechnique: prodPrintTech,
        careInstructions: [
          'Machine wash cold inside out with like colors',
          'Hang dry recommended to preserve structural drape',
          'Tumble dry low if necessary; do not iron directly on print',
        ],
        productionNotes: prodProductionNotes,
        estimatedDeliveryDays: prodDeliveryDays,
      },
      variants: finalVariants,
      createdAt: initialProduct?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (initialProduct?.id) {
      updateProduct(initialProduct.id, productPayload);
      showToast(`Updated commercial garment "${prodName}".`);
    } else {
      addProduct(productPayload);
      showToast(`Published new commercial garment "${prodName}" to store catalog.`);
    }

    onSuccess(productPayload);
  };

  // Calculations for Fulfillment Tab
  const totalVariants = variants.length;
  const avgRetailPrice = totalVariants > 0
    ? variants.reduce((acc, v) => acc + (v.priceOverride || prodPrice || 48), 0) / totalVariants
    : prodPrice;
  const avgBaseCost = totalVariants > 0
    ? variants.reduce((acc, v) => {
        const wtObj = wearTypes.find((w) => w.id === v.wearTypeId || w.name === v.wearTypeName);
        return acc + (wtObj?.baseCost || (v.wearTypeName?.toLowerCase().includes('hood') ? 34.0 : 18.5));
      }, 0) / totalVariants
    : 18.5;
  const avgProfit = Math.max(0, avgRetailPrice - avgBaseCost);
  const avgMargin = avgRetailPrice > 0 ? Math.round((avgProfit / avgRetailPrice) * 100) : 0;
  const lowMarginCount = variants.filter((v) => {
    const wtObj = wearTypes.find((w) => w.id === v.wearTypeId || w.name === v.wearTypeName);
    const cost = wtObj?.baseCost || 18.5;
    const price = v.priceOverride || prodPrice || 48;
    return price > 0 && ((price - cost) / price) < 0.40;
  }).length;

  // Filtered variants for matrix spreadsheet
  const filteredVariants = variants.filter((v) => {
    const matchesWear = matrixFilterWearType === 'all' || v.wearTypeName === matrixFilterWearType;
    const matchesCol = matrixFilterColor === 'all' || v.colorName === matrixFilterColor;
    return matchesWear && matchesCol;
  });

  return (
    <div className="bg-white border border-neutral-300 shadow-xl space-y-6 p-6 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="border-b border-neutral-200 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <button
            type="button"
            onClick={onClose}
            className="text-xs font-mono text-neutral-500 hover:text-black mb-1 flex items-center gap-1 cursor-pointer"
          >
            ← Back to Garment Catalog
          </button>
          <div className="flex flex-wrap items-center gap-2.5">
            <h3 className="font-serif text-2xl font-bold text-neutral-900">
              Product Studio: {initialProduct ? `Edit Garment — ${initialProduct.name}` : 'Create Commercial Garment'}
            </h3>
            {prodSourceDesignId && (
              <span className="px-2.5 py-0.5 text-[10px] font-mono bg-purple-100 text-purple-900 border border-purple-300 rounded-xs flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-purple-700" />
                Linked to Design Factory: #{prodSourceDesignId}
              </span>
            )}
          </div>
          <p className="text-xs text-neutral-500 mt-1 font-sans">
            Convert creative concepts into sellable garments with multi-silhouette variants, Apliiq POD fulfillment, and automated profit margins.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setDesignPickerOpen(true)}
            className="text-xs font-mono bg-purple-50 hover:bg-purple-100 text-purple-900 border-purple-300 flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-700" />
            <span>+ Create from Design</span>
          </Button>
          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={handleSaveGarment}
            className="text-xs font-mono bg-black text-white hover:bg-neutral-800 cursor-pointer"
          >
            Save & Publish Garment
          </Button>
        </div>
      </div>

      {/* 5-Stage Navigation Tab Bar */}
      <div className="flex flex-wrap gap-2 border-b border-neutral-200 pb-3">
        {[
          { id: 'info', label: '01 — PRODUCT', detail: prodName || 'Identity & Pricing' },
          { id: 'media', label: '02 — MEDIA', detail: `${prodGallery.length + 1} Angles` },
          { id: 'story', label: '03 — STORY & SPECS', detail: 'Thesis & Philosophy' },
          { id: 'wear', label: '04 — WEAR & SILHOUETTES', detail: `${selectedWearTypes.length} Wear · ${selectedColors.length} Col` },
          { id: 'matrix', label: '05 — VARIANT MATRIX', detail: `${variants.length} SKUs` },
          { id: 'fulfillment', label: '06 — FULFILLMENT & MARGINS', detail: `${avgMargin}% Gross Margin` },
        ].map((tab) => {
          const isActive = activeStage === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveStage(tab.id as any)}
              className={`px-3.5 py-2 text-left border transition-all cursor-pointer ${
                isActive
                  ? 'bg-black text-white border-black shadow-xs'
                  : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
              }`}
            >
              <div className="text-[10px] font-mono uppercase tracking-wider">{tab.label}</div>
              <div className={`text-xs font-sans font-medium truncate max-w-44 ${isActive ? 'text-neutral-200' : 'text-neutral-900'}`}>
                {tab.detail}
              </div>
            </button>
          );
        })}
      </div>

      {/* STAGE 01: COMMERCIAL PRODUCT INFO */}
      {activeStage === 'info' && (
        <div className="space-y-6 animate-in fade-in duration-150 max-w-4xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Commercial Garment Name</label>
              <input
                type="text"
                required
                value={prodName}
                onChange={(e) => {
                  setProdName(e.target.value);
                  if (!initialProduct && !prodSlug) {
                    setProdSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
                  }
                }}
                placeholder="e.g. The Distance Tee — Edition I"
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Store URL Slug</label>
              <input
                type="text"
                value={prodSlug}
                onChange={(e) => setProdSlug(e.target.value)}
                placeholder="e.g. the-distance-tee"
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Tagline / Short Statement</label>
            <input
              type="text"
              value={prodTagline}
              onChange={(e) => setProdTagline(e.target.value)}
              placeholder="e.g. WE ARE NOT THE SAME. THAT’S THE POINT."
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif italic"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Base Retail Price ($ USD)</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-neutral-400 font-mono text-xs">$</span>
                <input
                  type="number"
                  min="1"
                  step="1"
                  required
                  value={prodPrice}
                  onChange={(e) => setProdPrice(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 pl-7 pr-3 py-2 text-xs font-mono font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Collection</label>
              <select
                value={prodCollectionId}
                onChange={(e) => setProdCollectionId(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono"
              >
                <option value="core-concepts">Core Concepts (Foundational)</option>
                <option value="dialogue-series">Dialogue Series (Typographic Interventions)</option>
                <option value="limited-edition">Limited Edition (Numbered Batch)</option>
              </select>
            </div>

            <div className="flex items-center pt-6">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={prodAvailable}
                  onChange={(e) => setProdAvailable(e.target.checked)}
                  className="w-4 h-4 text-black border-neutral-300 rounded-xs cursor-pointer"
                />
                <span className="text-xs font-mono text-neutral-800">
                  Active & Available in Store
                </span>
              </label>
            </div>
          </div>

          {/* Quick Summary Bridge */}
          <div className="p-4 bg-neutral-50 border border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <div className="text-xs font-mono font-bold text-neutral-900">Configured Silhouettes & Options</div>
              <p className="text-[11px] text-neutral-500 font-sans">
                {selectedWearTypes.length} Wear Types · {selectedColors.length} Colors · {selectedSizes.length} Sizes · {variants.length} Variants.
              </p>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setActiveStage('media')}
              className="text-xs font-mono"
            >
              Next: Media & Gallery →
            </Button>
          </div>
        </div>
      )}

      {/* STAGE 02: MEDIA GALLERY */}
      {activeStage === 'media' && (
        <div className="space-y-6 animate-in fade-in duration-150 max-w-4xl">
          <div>
            <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Primary Garment Image URL</label>
            <div className="flex gap-3">
              <input
                type="text"
                value={prodPrimaryImage}
                onChange={(e) => setProdPrimaryImage(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className="flex-1 bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
              />
              <button
                type="button"
                onClick={() => {
                  setProdPrimaryImage('https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85');
                }}
                className="px-3 py-1 bg-neutral-100 border border-neutral-300 text-xs font-mono text-neutral-700 hover:text-black cursor-pointer"
              >
                Use Clean Studio Tee
              </button>
              <button
                type="button"
                onClick={() => {
                  setProdPrimaryImage('https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=900&q=85');
                }}
                className="px-3 py-1 bg-neutral-100 border border-neutral-300 text-xs font-mono text-neutral-700 hover:text-black cursor-pointer"
              >
                Use Clean Studio Hoodie
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mt-1 font-sans">
              Stores live cloud URLs or server-hosted media paths (/uploads/products/...). Zero base64 payload bloat.
            </p>
          </div>

          {/* Primary Image Preview */}
          <div className="w-48 aspect-4/3 bg-neutral-100 border border-neutral-300 overflow-hidden relative shadow-inner">
            <img src={prodPrimaryImage} alt="Primary Preview" className="w-full h-full object-cover" />
            <span className="absolute bottom-1 left-1 bg-black/70 text-white text-[9px] font-mono px-1 py-0.5">
              Primary Hero
            </span>
          </div>

          {/* Additional Gallery Angles */}
          <div className="border-t border-neutral-200 pt-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-serif text-sm font-bold text-neutral-900">Garment Angles & Perspectives ({prodGallery.length})</h4>
                <p className="text-xs text-neutral-500 font-sans">
                  Front, rear typography, fabric detail shots, editorial portraits, and on-body drape.
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  setProdGallery([
                    ...prodGallery,
                    {
                      url: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=900&q=85',
                      alt: `${prodName} Detail View`,
                      viewType: 'detail',
                    },
                  ]);
                }}
                className="text-xs font-mono"
              >
                <Plus className="w-3.5 h-3.5 mr-1" />
                <span>Add Gallery Shot</span>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {prodGallery.map((img, idx) => (
                <div key={idx} className="bg-neutral-50 border border-neutral-200 p-3.5 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase bg-neutral-200 text-neutral-800 px-2 py-0.5">
                      Angle #{idx + 1} • {img.viewType.toUpperCase()}
                    </span>
                    <button
                      type="button"
                      onClick={() => setProdGallery(prodGallery.filter((_, i) => i !== idx))}
                      className="text-neutral-400 hover:text-red-600 text-xs cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="aspect-16/9 bg-neutral-200 overflow-hidden relative border border-neutral-300">
                    <img src={img.url} alt={img.alt} className="w-full h-full object-cover" />
                  </div>

                  <input
                    type="text"
                    value={img.url}
                    onChange={(e) => {
                      const val = e.target.value;
                      setProdGallery((prev) => prev.map((item, i) => (i === idx ? { ...item, url: val } : item)));
                    }}
                    placeholder="Image URL"
                    className="w-full bg-white border border-neutral-300 p-1.5 text-xs font-mono"
                  />

                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={img.alt}
                      onChange={(e) => {
                        const val = e.target.value;
                        setProdGallery((prev) => prev.map((item, i) => (i === idx ? { ...item, alt: val } : item)));
                      }}
                      placeholder="Alt label"
                      className="w-full bg-white border border-neutral-300 p-1 text-xs"
                    />
                    <select
                      value={img.viewType}
                      onChange={(e) => {
                        const val = e.target.value as any;
                        setProdGallery((prev) => prev.map((item, i) => (i === idx ? { ...item, viewType: val } : item)));
                      }}
                      className="w-full bg-white border border-neutral-300 p-1 text-xs font-mono"
                    >
                      <option value="front">Front</option>
                      <option value="rear">Rear</option>
                      <option value="detail">Detail</option>
                      <option value="fabric">Fabric</option>
                      <option value="editorial">Editorial</option>
                      <option value="on-body">On-Body</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* STAGE 03: STORY & SPECIFICATIONS */}
      {activeStage === 'story' && (
        <div className="space-y-6 animate-in fade-in duration-150 max-w-3xl">
          <div className="space-y-4">
            <h4 className="font-serif text-sm font-bold text-neutral-900 uppercase tracking-wider">
              Story A: Philosophical Thesis & Public Space Inquiry
            </h4>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Core Philosophical Thesis</label>
              <textarea
                rows={3}
                value={prodThesis}
                onChange={(e) => setProdThesis(e.target.value)}
                placeholder="The core philosophical statement behind this garment..."
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif leading-relaxed"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Engagement Question</label>
              <input
                type="text"
                value={prodQuestion}
                onChange={(e) => setProdQuestion(e.target.value)}
                placeholder="e.g. What does this mean to you?"
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Wearer Role / Persona</label>
              <input
                type="text"
                value={prodWearerRole}
                onChange={(e) => setProdWearerRole(e.target.value)}
                placeholder="e.g. The Observer & Wayfarer"
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs"
              />
            </div>
          </div>

          <div className="border-t border-neutral-200 pt-5 space-y-4">
            <h4 className="font-serif text-sm font-bold text-neutral-900 uppercase tracking-wider">
              Story B: Craft & Manufacturing Specifications
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Fabric Composition</label>
                <input
                  type="text"
                  value={prodFabric}
                  onChange={(e) => setProdFabric(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Fabric Weight / GSM</label>
                <input
                  type="text"
                  value={prodWeight}
                  onChange={(e) => setProdWeight(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Fit & Drape</label>
                <input
                  type="text"
                  value={prodFit}
                  onChange={(e) => setProdFit(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Print Technique</label>
                <input
                  type="text"
                  value={prodPrintTech}
                  onChange={(e) => setProdPrintTech(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STAGE 04: WEAR TYPES & SILHOUETTES LIBRARY SELECTION */}
      {activeStage === 'wear' && (
        <div className="space-y-6 animate-in fade-in duration-150 max-w-4xl">
          {/* Silhouettes / Wear Type Selection */}
          <div className="bg-neutral-50 p-5 border border-neutral-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-serif text-sm font-bold text-neutral-900">
                  Select Garment Silhouettes (Wear Type Library)
                </h4>
                <p className="text-xs text-neutral-500 font-sans">
                  Choose which base garment blanks this design will be available on. (e.g. Tee vs Hoodie).
                </p>
              </div>
              <span className="text-xs font-mono bg-white px-2 py-1 border border-neutral-300 font-bold">
                {selectedWearTypes.length} / {wearTypes.length} Selected
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {wearTypes.map((wt) => {
                const isSelected = selectedWearTypes.includes(wt.name);
                return (
                  <div
                    key={wt.id}
                    onClick={() => {
                      if (isSelected) {
                        setSelectedWearTypes(selectedWearTypes.filter((w) => w !== wt.name));
                      } else {
                        setSelectedWearTypes([...selectedWearTypes, wt.name]);
                      }
                    }}
                    className={`p-3.5 border transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                      isSelected
                        ? 'bg-white border-black ring-1 ring-black shadow-xs'
                        : 'bg-white/70 border-neutral-300 hover:border-neutral-400 opacity-80'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-mono text-xs font-bold text-neutral-900">{wt.name}</div>
                        <div className="text-[11px] text-neutral-500 font-sans">{wt.weight} · {wt.fabric}</div>
                      </div>
                      <span className={`w-4 h-4 rounded-xs border flex items-center justify-center text-[10px] ${
                        isSelected ? 'bg-black text-white border-black' : 'border-neutral-300'
                      }`}>
                        {isSelected && '✓'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-mono pt-2 border-t border-neutral-100">
                      <span className="text-neutral-500">Base Cost: ${wt.baseCost.toFixed(2)}</span>
                      <span className="text-emerald-700 font-bold">Rec. Retail: ${wt.defaultRetailPrice}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Colorway Selection */}
          <div className="bg-neutral-50 p-5 border border-neutral-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-serif text-sm font-bold text-neutral-900">
                  Select Master Colorways ({selectedColors.length} Active)
                </h4>
                <p className="text-xs text-neutral-500 font-sans">
                  Uniform colors shared with Design Factory and Storefront.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
              {colors.map((col) => {
                const isSelected = selectedColors.some((c) => c.name.toLowerCase() === col.name.toLowerCase());
                return (
                  <button
                    key={col.id || col.name}
                    type="button"
                    onClick={() => {
                      if (isSelected) {
                        setSelectedColors(selectedColors.filter((c) => c.name.toLowerCase() !== col.name.toLowerCase()));
                      } else {
                        setSelectedColors([...selectedColors, { name: col.name, hex: col.hex }]);
                      }
                    }}
                    className={`flex items-center space-x-2.5 p-2.5 border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-white border-black ring-1 ring-black shadow-xs'
                        : 'bg-white/60 border-neutral-200 hover:border-neutral-300 opacity-75'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-full border border-neutral-300 shrink-0 shadow-inner"
                      style={{ backgroundColor: col.hex }}
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-mono font-medium text-neutral-900 truncate">{col.name}</div>
                      <div className="text-[10px] font-mono text-neutral-400">{col.hex}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sizes Selection */}
          <div className="bg-neutral-50 p-5 border border-neutral-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-serif text-sm font-bold text-neutral-900">
                  Available Sizes ({selectedSizes.length}/7 Selected)
                </h4>
                <p className="text-xs text-neutral-500 font-sans">
                  Active size scale enabled for customer purchase.
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedSizes([...ALL_SIZES])}
                  className="px-2 py-1 bg-white border border-neutral-300 text-[10px] font-mono hover:text-black cursor-pointer"
                >
                  All
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedSizes(['S', 'M', 'L', 'XL'])}
                  className="px-2 py-1 bg-white border border-neutral-300 text-[10px] font-mono hover:text-black cursor-pointer"
                >
                  Standard 4
                </button>
              </div>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {ALL_SIZES.map((sz) => {
                const isSelected = selectedSizes.includes(sz);
                return (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => {
                      if (isSelected) {
                        setSelectedSizes(selectedSizes.filter((s) => s !== sz));
                      } else {
                        setSelectedSizes([...selectedSizes, sz]);
                      }
                    }}
                    className={`py-2 text-center font-mono text-xs font-bold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-black text-white border-black shadow-xs'
                        : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-400'
                    }`}
                  >
                    {sz}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Generate Matrix CTA */}
          <div className="bg-white p-5 border border-neutral-300 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <div className="flex items-center space-x-2 text-sm font-mono font-bold text-neutral-900">
                <Layers className="w-4 h-4 text-emerald-600" />
                <span>Build Commercial Matrix</span>
              </div>
              <p className="text-xs text-neutral-500 font-sans">
                {selectedWearTypes.length} Silhouettes × {selectedColors.length} Colors × {selectedSizes.length} Sizes ={' '}
                <strong className="text-neutral-900 font-mono">
                  {selectedWearTypes.length * selectedColors.length * selectedSizes.length} Total SKUs
                </strong>
              </p>
            </div>
            <Button
              type="button"
              variant="primary"
              size="md"
              onClick={() => {
                handleGenerateMatrix();
                setActiveStage('matrix');
              }}
              className="bg-black text-white hover:bg-neutral-800 text-xs font-mono uppercase tracking-wider cursor-pointer"
            >
              Generate Matrix & Go to Stage 05 →
            </Button>
          </div>
        </div>
      )}

      {/* STAGE 05: COMMERCIAL VARIANT MATRIX SPREADSHEET */}
      {activeStage === 'matrix' && (
        <div className="space-y-5 animate-in fade-in duration-150">
          {/* Controls Bar */}
          <div className="bg-neutral-50 p-4 border border-neutral-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono text-neutral-500 uppercase">Filters:</span>
              <select
                value={matrixFilterWearType}
                onChange={(e) => setMatrixFilterWearType(e.target.value)}
                className="bg-white border border-neutral-300 p-1.5 text-xs font-mono"
              >
                <option value="all">All Silhouettes ({selectedWearTypes.length})</option>
                {selectedWearTypes.map((wt) => (
                  <option key={wt} value={wt}>{wt}</option>
                ))}
              </select>

              <select
                value={matrixFilterColor}
                onChange={(e) => setMatrixFilterColor(e.target.value)}
                className="bg-white border border-neutral-300 p-1.5 text-xs font-mono"
              >
                <option value="all">All Colors ({selectedColors.length})</option>
                {selectedColors.map((col) => (
                  <option key={col.name} value={col.name}>{col.name}</option>
                ))}
              </select>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Bulk Price Input */}
              <div className="flex items-center space-x-1">
                <input
                  type="number"
                  placeholder="Set all $"
                  value={bulkPriceInput}
                  onChange={(e) => setBulkPriceInput(e.target.value)}
                  className="w-20 bg-white border border-neutral-300 p-1.5 text-xs font-mono text-right"
                />
                <button
                  type="button"
                  onClick={() => {
                    const num = Number(bulkPriceInput);
                    if (num > 0) {
                      setVariants(variants.map((v) => ({ ...v, priceOverride: num })));
                      showToast(`Bulk set retail price to $${num} on all variants.`);
                      setBulkPriceInput('');
                    }
                  }}
                  className="px-2 py-1.5 bg-neutral-200 hover:bg-neutral-300 text-xs font-mono cursor-pointer"
                >
                  Apply $
                </button>
              </div>

              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleGenerateMatrix}
                className="text-xs font-mono"
              >
                Re-Generate Matrix
              </Button>
            </div>
          </div>

          {/* Spreadsheet Table */}
          <div className="border border-neutral-200 overflow-x-auto shadow-xs">
            <table className="w-full text-left text-xs bg-white">
              <thead className="bg-neutral-100 border-b border-neutral-200 text-neutral-600 uppercase font-mono text-[10px]">
                <tr>
                  <th className="py-3 px-3">Silhouette (Wear Type)</th>
                  <th className="py-3 px-3">Colorway</th>
                  <th className="py-3 px-2 text-center">Size</th>
                  <th className="py-3 px-3">SKU Identifier</th>
                  <th className="py-3 px-3">Retail Price</th>
                  <th className="py-3 px-3">POD Base Cost & Margin</th>
                  <th className="py-3 px-3">Inventory Mode</th>
                  <th className="py-3 px-2 text-center">In Stock</th>
                  <th className="py-3 px-3">POD Mapping ID</th>
                  <th className="py-3 px-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 font-mono text-xs">
                {filteredVariants.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-12 text-center text-neutral-500 font-sans">
                      No variants generated. Go to Stage 04 ("Wear & Silhouettes") and click "Build Commercial Matrix".
                    </td>
                  </tr>
                ) : (
                  filteredVariants.map((v, idx) => {
                    const originalIndex = variants.findIndex((item) => item.id === v.id);
                    const effectivePrice = v.priceOverride || prodPrice || 48;
                    const wtObj = wearTypes.find((w) => w.id === v.wearTypeId || w.name === v.wearTypeName);
                    const cost = wtObj?.baseCost || (v.wearTypeName?.toLowerCase().includes('hood') ? 34.0 : 18.5);
                    const { profit, marginPercent } = calculatePodMargin(effectivePrice, cost);

                    return (
                      <tr key={v.id || idx} className="hover:bg-neutral-50/70 transition-colors">
                        {/* Silhouette */}
                        <td className="py-2.5 px-3">
                          <span className="font-sans font-medium text-neutral-900 block truncate max-w-40">
                            {v.wearTypeName}
                          </span>
                        </td>

                        {/* Color */}
                        <td className="py-2.5 px-3">
                          <div className="flex items-center space-x-1.5">
                            <span
                              className="w-3.5 h-3.5 rounded-full border border-neutral-300 shrink-0"
                              style={{ backgroundColor: v.colorHex }}
                            />
                            <span className="text-neutral-800 truncate">{v.colorName}</span>
                          </div>
                        </td>

                        {/* Size */}
                        <td className="py-2.5 px-2 text-center font-bold">
                          {v.size}
                        </td>

                        {/* SKU */}
                        <td className="py-2.5 px-3">
                          <input
                            type="text"
                            value={v.sku}
                            onChange={(e) => {
                              const updated = [...variants];
                              updated[originalIndex].sku = e.target.value;
                              setVariants(updated);
                            }}
                            className="bg-neutral-50 border border-neutral-200 p-1 text-[11px] font-mono w-44"
                          />
                        </td>

                        {/* Retail Price Override */}
                        <td className="py-2.5 px-3">
                          <div className="flex items-center space-x-1">
                            <span className="text-neutral-400">$</span>
                            <input
                              type="number"
                              value={v.priceOverride ?? ''}
                              onChange={(e) => {
                                const updated = [...variants];
                                updated[originalIndex].priceOverride = e.target.value ? Number(e.target.value) : undefined;
                                setVariants(updated);
                              }}
                              placeholder={String(prodPrice || 48)}
                              className="bg-neutral-50 border border-neutral-200 p-1 text-xs font-mono font-bold w-16"
                            />
                          </div>
                        </td>

                        {/* POD Cost & Margin */}
                        <td className="py-2.5 px-3">
                          <div className="text-[11px] leading-tight">
                            <span className="text-neutral-500">Cost: ${cost.toFixed(2)}</span>
                            <div className={`font-semibold ${marginPercent < 40 ? 'text-amber-700' : 'text-emerald-700'}`}>
                              +${profit.toFixed(2)} ({marginPercent}%)
                            </div>
                          </div>
                        </td>

                        {/* Inventory Mode */}
                        <td className="py-2.5 px-3">
                          <select
                            value={v.inventoryMode || 'pod'}
                            onChange={(e) => {
                              const updated = [...variants];
                              updated[originalIndex].inventoryMode = e.target.value as any;
                              setVariants(updated);
                            }}
                            className="bg-neutral-50 border border-neutral-200 p-1 text-[11px]"
                          >
                            <option value="pod">POD On-Demand</option>
                            <option value="stocked">Stocked Warehouse</option>
                            <option value="made_to_order">Made to Order</option>
                          </select>
                        </td>

                        {/* In Stock */}
                        <td className="py-2.5 px-2 text-center">
                          <input
                            type="checkbox"
                            checked={v.inStock}
                            onChange={(e) => {
                              const updated = [...variants];
                              updated[originalIndex].inStock = e.target.checked;
                              setVariants(updated);
                            }}
                            className="w-4 h-4 accent-black cursor-pointer"
                          />
                        </td>

                        {/* POD Variant ID */}
                        <td className="py-2.5 px-3">
                          <input
                            type="text"
                            value={v.podVariantId || ''}
                            onChange={(e) => {
                              const updated = [...variants];
                              updated[originalIndex].podVariantId = e.target.value;
                              setVariants(updated);
                            }}
                            placeholder="e.g. APL-1029"
                            className="bg-neutral-50 border border-neutral-200 p-1 text-[11px] font-mono w-28"
                          />
                        </td>

                        {/* Delete */}
                        <td className="py-2.5 px-2 text-right">
                          <button
                            type="button"
                            onClick={() => setVariants(variants.filter((_, i) => i !== originalIndex))}
                            className="p-1 text-neutral-400 hover:text-red-600 cursor-pointer"
                            title="Delete SKU"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* STAGE 06: FULFILLMENT & POD MARGINS CALCULATOR */}
      {activeStage === 'fulfillment' && (
        <div className="space-y-6 animate-in fade-in duration-150 max-w-4xl">
          {/* Provider Selection */}
          <div className="bg-neutral-50 p-5 border border-neutral-200 space-y-3">
            <h4 className="font-serif text-sm font-bold text-neutral-900 uppercase tracking-wider">
              Primary On-Demand Fulfillment Provider
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { id: 'apliiq', name: 'Apliiq DTF (Los Angeles, CA)', desc: 'High-end streetwear blanks, woven branding labels, soft-hand discharge.' },
                { id: 'printful', name: 'Printful Direct Fulfillment', desc: 'Global multi-facility direct fulfillment with standardized blanks.' },
                { id: 'custom', name: 'In-House Studio Workshop', desc: 'Hand-printed artisan micro-batches in Chicago studio.' },
              ].map((p) => (
                <div
                  key={p.id}
                  onClick={() => setPodProvider(p.id as any)}
                  className={`p-3.5 border transition-all cursor-pointer ${
                    podProvider === p.id
                      ? 'bg-white border-black ring-1 ring-black shadow-xs'
                      : 'bg-white/60 border-neutral-200 hover:border-neutral-300 opacity-75'
                  }`}
                >
                  <div className="font-mono text-xs font-bold text-neutral-900">{p.name}</div>
                  <p className="text-[11px] text-neutral-500 mt-1 font-sans">{p.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Margin Guardrail & Economics Dashboard */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white border border-neutral-200 p-4">
              <span className="text-[10px] font-mono uppercase text-neutral-500">Total Variants</span>
              <div className="font-mono text-2xl font-bold text-neutral-900 mt-1">{totalVariants}</div>
              <span className="text-[11px] text-neutral-400 font-sans">Active commercial SKUs</span>
            </div>

            <div className="bg-white border border-neutral-200 p-4">
              <span className="text-[10px] font-mono uppercase text-neutral-500">Avg. Retail Price</span>
              <div className="font-mono text-2xl font-bold text-neutral-900 mt-1">${avgRetailPrice.toFixed(2)}</div>
              <span className="text-[11px] text-neutral-400 font-sans">USD per garment</span>
            </div>

            <div className="bg-white border border-neutral-200 p-4">
              <span className="text-[10px] font-mono uppercase text-neutral-500">Avg. POD Base Cost</span>
              <div className="font-mono text-2xl font-bold text-neutral-900 mt-1">${avgBaseCost.toFixed(2)}</div>
              <span className="text-[11px] text-neutral-400 font-sans">Wholesale blank + print</span>
            </div>

            <div className="bg-white border border-neutral-200 p-4">
              <span className="text-[10px] font-mono uppercase text-neutral-500">Est. Gross Margin</span>
              <div className="font-mono text-2xl font-bold text-emerald-700 mt-1">{avgMargin}%</div>
              <span className="text-[11px] text-emerald-600 font-sans font-medium">+${avgProfit.toFixed(2)} profit / unit</span>
            </div>
          </div>

          {lowMarginCount > 0 && (
            <div className="p-4 bg-amber-50 border border-amber-300 text-amber-900 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <strong className="text-xs font-mono">Profit Margin Warning:</strong>
                <p className="text-xs font-sans mt-0.5">
                  {lowMarginCount} variant(s) have estimated gross profit margins below 40%. Consider adjusting retail prices or hoodie price overrides in Stage 05.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Sticky Bottom Action Bar */}
      <div className="sticky bottom-0 bg-white/95 backdrop-blur-sm border-t border-neutral-200 p-4 -mx-6 -mb-6 mt-8 flex items-center justify-between z-20 shadow-lg">
        <div className="text-xs font-mono text-neutral-500">
          Garment: <strong className="text-neutral-900">{prodName || 'Unnamed Garment'}</strong> · {variants.length} SKUs configured
        </div>
        <div className="flex items-center space-x-2">
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={handleSaveGarment}
            className="bg-black text-white hover:bg-neutral-800"
          >
            Save & Publish Commercial Garment
          </Button>
        </div>
      </div>

      {/* Design Picker Modal */}
      {designPickerOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-neutral-300 max-w-2xl w-full p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <div>
                <h4 className="font-serif text-lg font-bold text-neutral-900">Select Design Factory Concept</h4>
                <p className="text-xs text-neutral-500 font-sans">
                  Approved creative designs ready to be turned into sellable commercial garments.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDesignPickerOpen(false)}
                className="text-neutral-400 hover:text-black font-mono text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              {designs.length === 0 ? (
                <div className="text-center py-8 text-neutral-500 text-xs font-sans">
                  No designs found in Design Factory.
                </div>
              ) : (
                designs.map((d) => (
                  <div key={d.id} className="border border-neutral-200 p-4 bg-neutral-50 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                    <div className="space-y-1 max-w-md">
                      <div className="flex items-center space-x-2">
                        <span className="font-serif text-base font-bold text-neutral-900">{d.name}</span>
                        <Badge variant={d.status === 'approved' ? 'success' : 'neutral'} size="sm">
                          {d.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-xs text-neutral-600 font-serif italic">"{d.thesis}"</p>
                      <p className="text-[11px] text-neutral-500 font-sans">
                        {d.versions?.length || 1} iterations · Active Version: v{d.activeVersionNumber}
                      </p>
                    </div>

                    <Button
                      type="button"
                      variant="primary"
                      size="sm"
                      onClick={() => handleImportDesign(d, d.activeVersionNumber)}
                      className="text-xs font-mono shrink-0 cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 mr-1.5" />
                      <span>Use This Concept</span>
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
