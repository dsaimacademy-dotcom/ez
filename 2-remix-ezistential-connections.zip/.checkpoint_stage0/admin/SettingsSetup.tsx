import React, { useState } from 'react';
import {
  Settings,
  SlidersHorizontal,
  ShieldCheck,
  Bell,
  Database,
  CheckCircle2,
  Lock,
  Download,
  Upload,
  RefreshCw,
  AlertTriangle,
  Server,
  Key,
  Truck,
  Eye,
  Mail,
  Zap,
  Check,
  Save,
  Send,
  FileText,
  Smartphone,
  Tag,
  ExternalLink
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { useProducts } from '../../context/ProductContext';
import { useOrders } from '../../context/OrderContext';
import { usePosts } from '../../context/PostContext';
import { Button } from '../ui/Button';

export type SettingsSubTab = 'ux' | 'security' | 'notifications' | 'email_templates' | 'backup';
export type EmailTemplateKey = 'signup' | 'password' | 'order_status' | 'order_confirm';

export const SettingsSetup: React.FC<{
  initialSubTab?: SettingsSubTab;
  onOpenDataBackupModal?: () => void;
}> = ({ initialSubTab = 'ux', onOpenDataBackupModal }) => {
  const { content, updateContent, faqs } = useContent();
  const { products } = useProducts();
  const { orders } = useOrders();
  const { posts } = usePosts();

  const [activeSubTab, setActiveSubTab] = useState<SettingsSubTab>(initialSubTab);
  const [activeEmailKey, setActiveEmailKey] = useState<EmailTemplateKey>('signup');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Storefront & UX States
  const [freeShippingThreshold, setFreeShippingThreshold] = useState(content.freeShippingThreshold ?? 150);
  const [standardShippingRate, setStandardShippingRate] = useState(content.standardShippingRate ?? 12);
  const [enableCookieConsentBanner, setEnableCookieConsentBanner] = useState(content.enableCookieConsentBanner ?? true);
  const [cookieBannerHeadline, setCookieBannerHeadline] = useState(content.cookieBannerHeadline || 'Digital Dignity & Data Respect');
  const [cookieBannerDescription, setCookieBannerDescription] = useState(
    content.cookieBannerDescription || 'We process minimal telemetry required for order logistics. No third-party data tracking.'
  );

  // Security & System States
  const [sessionTimeoutMinutes, setSessionTimeoutMinutes] = useState(60);
  const [requireTwoFactor, setRequireTwoFactor] = useState(false);
  const [apiLoggingEnabled, setApiLoggingEnabled] = useState(true);

  // Notifications & Maintenance States
  const [adminNotifyEmails, setAdminNotifyEmails] = useState(content.ordersEmail || 'orders@ezistential.com');
  const [lowStockAlertThreshold, setLowStockAlertThreshold] = useState(5);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [maintenanceMessage, setMaintenanceMessage] = useState(
    'Storefront is undergoing scheduled maintenance. Please check back shortly.'
  );

  // Email Template States (Sign Up, Password Reset, Order Status, Order Confirm)
  const [signUpSubject, setSignUpSubject] = useState(
    content.smtpSignUpSubject || 'Welcome to Ezistential Connections — Space Between People'
  );
  const [signUpBody, setSignUpBody] = useState(
    content.smtpSignUpTemplate ||
      'Dear {customer_name},\n\nWelcome to Ezistential Connections. Your account has been initialized.\n\nExplore our connection garments at https://ezistential.com\n\nWarm regards,\nEzistential Connections Studio'
  );

  const [passwordSubject, setPasswordSubject] = useState(
    content.smtpPasswordResetSubject || 'Reset Your Ezistential Connections Password'
  );
  const [passwordBody, setPasswordBody] = useState(
    content.smtpPasswordResetTemplate ||
      'Hello {customer_name},\n\nWe received a request to reset your password. Click the link below to verify:\n{reset_link}\n\nIf you did not request this, please ignore this message.\n\nEzistential Care Team'
  );

  const [orderStatusSubject, setOrderStatusSubject] = useState(
    content.smtpOrderStatusSubject || 'Shipment Update for Order #{order_id} — In Transit'
  );
  const [orderStatusBody, setOrderStatusBody] = useState(
    content.smtpOrderStatusTemplate ||
      'Dear {customer_name},\n\nYour order #{order_id} status has been updated to: {order_status}.\n\nTracking Reference: {tracking_number}\n\nThank you for journeying with us,\nEzistential Connections'
  );

  const [orderConfirmSubject, setOrderConfirmSubject] = useState(
    content.smtpOrderConfirmSubject || 'Order Confirmation #{order_id} — Ezistential Connections'
  );
  const [orderConfirmBody, setOrderConfirmBody] = useState(
    content.smtpOrderConfirmTemplate ||
      'Dear {customer_name},\n\nThank you for your order #{order_id} totaling ${total_amount}.\n\nItems Ordered:\n{items_summary}\n\nWe are preparing your garments for print-on-demand fulfillment.\n\nEzistential Fulfillment'
  );

  const [testDispatchState, setTestDispatchState] = useState<{ testing: boolean; msg?: string }>({ testing: false });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      freeShippingThreshold: Number(freeShippingThreshold) || 0,
      standardShippingRate: Number(standardShippingRate) || 0,
      enableCookieConsentBanner,
      cookieBannerHeadline: cookieBannerHeadline.trim(),
      cookieBannerDescription: cookieBannerDescription.trim(),
      ordersEmail: adminNotifyEmails.trim(),

      smtpSignUpSubject: signUpSubject.trim(),
      smtpSignUpTemplate: signUpBody.trim(),
      smtpPasswordResetSubject: passwordSubject.trim(),
      smtpPasswordResetTemplate: passwordBody.trim(),
      smtpOrderStatusSubject: orderStatusSubject.trim(),
      smtpOrderStatusTemplate: orderStatusBody.trim(),
      smtpOrderConfirmSubject: orderConfirmSubject.trim(),
      smtpOrderConfirmTemplate: orderConfirmBody.trim(),
    });
    showToast('All System & Email Template settings saved successfully!');
  };

  const handleTestEmailDispatch = () => {
    setTestDispatchState({ testing: true });
    setTimeout(() => {
      setTestDispatchState({
        testing: false,
        msg: `Test dispatch simulation rendered for '${activeEmailKey}' template. Check live preview on right pane.`,
      });
      showToast('Simulated email dispatch rendered!');
    }, 400);
  };

  // Live Template Sample Filler for Live Email Previewer
  const renderSamplePreviewText = (text: string) => {
    return text
      .replace(/{customer_name}/g, 'Alex Morgan')
      .replace(/{brand_name}/g, content.brandName || 'Ezistential Connections')
      .replace(/{order_id}/g, 'EZ-9402')
      .replace(/{total_amount}/g, '148.00')
      .replace(/{items_summary}/g, '1x Heavyweight Hooded Sweatshirt (L / Charcoal) — $148.00')
      .replace(/{reset_link}/g, 'https://ezistential.com/auth/reset?token=e8a9f2')
      .replace(/{tracking_number}/g, '9400111899562100843211 (USPS Priority)')
      .replace(/{order_status}/g, 'In Transit / Shipped from Chicago Studio');
  };

  const getCurrentSubject = () => {
    if (activeEmailKey === 'signup') return signUpSubject;
    if (activeEmailKey === 'password') return passwordSubject;
    if (activeEmailKey === 'order_status') return orderStatusSubject;
    return orderConfirmSubject;
  };

  const getCurrentBody = () => {
    if (activeEmailKey === 'signup') return signUpBody;
    if (activeEmailKey === 'password') return passwordBody;
    if (activeEmailKey === 'order_status') return orderStatusBody;
    return orderConfirmBody;
  };

  const insertTag = (tag: string) => {
    if (activeEmailKey === 'signup') setSignUpBody((prev) => prev + ` ${tag}`);
    else if (activeEmailKey === 'password') setPasswordBody((prev) => prev + ` ${tag}`);
    else if (activeEmailKey === 'order_status') setOrderStatusBody((prev) => prev + ` ${tag}`);
    else if (activeEmailKey === 'order_confirm') setOrderConfirmBody((prev) => prev + ` ${tag}`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-neutral-200 gap-4">
        <div>
          <h2 className="font-serif text-2xl text-neutral-900">System Settings & Email Templates Manager</h2>
          <p className="text-xs text-neutral-500 mt-1">
            Configure logistics rules, administrative security, database backups, and manage & preview email templates.
          </p>
        </div>
        <Button onClick={handleSaveSettings} variant="primary" size="md">
          <Save className="w-3.5 h-3.5 mr-1.5" />
          <span>Save All Settings</span>
        </Button>
      </div>

      {/* Subtabs Bar */}
      <div className="flex border-b border-neutral-200 overflow-x-auto gap-1 text-xs font-mono">
        <button
          type="button"
          onClick={() => setActiveSubTab('ux')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'ux' ? 'border-black text-black font-bold bg-neutral-50' : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Truck className="w-3.5 h-3.5" />
          <span>1. Storefront UX & Shipping</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('security')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'security'
              ? 'border-black text-black font-bold bg-neutral-50'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>2. Security & Access</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('notifications')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'notifications'
              ? 'border-black text-black font-bold bg-neutral-50'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>3. Notifications & Maintenance</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('email_templates')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'email_templates'
              ? 'border-black text-black font-bold bg-neutral-50 text-purple-900'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Mail className="w-3.5 h-3.5 text-purple-600" />
          <span>4. Email Templates & Live Preview</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('backup')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'backup'
              ? 'border-black text-black font-bold bg-neutral-50'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>5. Database & Snapshots</span>
        </button>
      </div>

      {/* Main Form Body */}
      <form onSubmit={handleSaveSettings} className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
        {/* SUBTAB 1: STOREFRONT UX & LOGISTICS */}
        {activeSubTab === 'ux' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Storefront E-Commerce & Shipping Logistics</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Configure complimentary shipping thresholds, flat rate fees, and cookie banner parameters.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs font-mono">
              <div>
                <label className="block text-neutral-800 font-medium mb-1">
                  Complimentary Domestic Shipping Threshold ($)
                </label>
                <input
                  type="number"
                  value={freeShippingThreshold}
                  onChange={(e) => setFreeShippingThreshold(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-neutral-800 font-medium mb-1">Standard Flat Rate Shipping Fee ($)</label>
                <input
                  type="number"
                  value={standardShippingRate}
                  onChange={(e) => setStandardShippingRate(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                />
              </div>
            </div>

            <div className="p-5 bg-neutral-50 border border-neutral-200 space-y-4">
              <label className="flex items-center space-x-3 text-xs text-neutral-900 font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableCookieConsentBanner}
                  onChange={(e) => setEnableCookieConsentBanner(e.target.checked)}
                  className="accent-black w-4 h-4"
                />
                <span>Enable Privacy & Digital Dignity Consent Banner</span>
              </label>

              {enableCookieConsentBanner && (
                <div className="grid grid-cols-1 gap-4 pt-2">
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">Banner Heading</label>
                    <input
                      type="text"
                      value={cookieBannerHeadline}
                      onChange={(e) => setCookieBannerHeadline(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">Banner Policy Notice</label>
                    <textarea
                      rows={2}
                      value={cookieBannerDescription}
                      onChange={(e) => setCookieBannerDescription(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SUBTAB 2: SECURITY & ACCESS */}
        {activeSubTab === 'security' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Administrative Security & System Access</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Session timeout limits, two-factor authentication preferences, and CORS whitelist policies.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs font-mono">
              <div>
                <label className="block text-neutral-800 font-medium mb-1">Admin Session Timeout (Minutes)</label>
                <input
                  type="number"
                  value={sessionTimeoutMinutes}
                  onChange={(e) => setSessionTimeoutMinutes(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                />
              </div>

              <div className="flex items-center pt-4 sm:pt-6">
                <label className="flex items-center space-x-3 text-xs text-neutral-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={requireTwoFactor}
                    onChange={(e) => setRequireTwoFactor(e.target.checked)}
                    className="accent-black w-4 h-4"
                  />
                  <div>
                    <span className="font-bold block">Enforce 2FA for Admin Portal Access</span>
                    <span className="text-[11px] text-neutral-500 font-normal">
                      Requires authenticator app codes on login.
                    </span>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 3: NOTIFICATIONS & MAINTENANCE */}
        {activeSubTab === 'notifications' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Notifications Dispatch & Emergency Maintenance Mode</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Configure administrative dispatch emails and temporary storefront lockouts.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs font-mono">
              <div>
                <label className="block text-neutral-800 font-medium mb-1">Order Alert Dispatch Recipient Email</label>
                <input
                  type="email"
                  value={adminNotifyEmails}
                  onChange={(e) => setAdminNotifyEmails(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-neutral-800 font-medium mb-1">Low Inventory Alert Threshold (Units)</label>
                <input
                  type="number"
                  value={lowStockAlertThreshold}
                  onChange={(e) => setLowStockAlertThreshold(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 4: EMAIL TEMPLATES & LIVE PREVIEW (NEW!) */}
        {activeSubTab === 'email_templates' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center space-x-2">
                  <Mail className="w-5 h-5 text-purple-600" />
                  <h3 className="font-serif text-lg font-bold text-neutral-900">Transactional Email Template Manager & Live Preview</h3>
                </div>
                <p className="text-xs text-neutral-500 mt-0.5 font-sans">
                  Edit transactional email text and test real-time rendered previews for Sign Up, Password Reset, and Order Status.
                </p>
              </div>

              <Button type="button" variant="outline" size="sm" onClick={handleTestEmailDispatch}>
                <Send className="w-3.5 h-3.5 mr-1.5 text-purple-600" />
                <span>Simulate Dispatch Preview</span>
              </Button>
            </div>

            {/* Template Selection Pills */}
            <div className="flex border border-neutral-200 bg-neutral-100 p-1 rounded-xs overflow-x-auto text-xs font-mono">
              {[
                { id: 'signup', label: '1. User Sign Up / Welcome' },
                { id: 'password', label: '2. Password Reset Request' },
                { id: 'order_status', label: '3. Order Status & Shipping' },
                { id: 'order_confirm', label: '4. Order Confirmation' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setActiveEmailKey(t.id as EmailTemplateKey)}
                  className={`px-4 py-2 transition-all cursor-pointer font-medium whitespace-nowrap ${
                    activeEmailKey === t.id ? 'bg-black text-white font-bold shadow-xs' : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Dual Pane Editor & Live Inbox Preview */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-2">
              {/* Left Pane: Editable Text Area & Placeholders */}
              <div className="lg:col-span-6 space-y-5">
                <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-4">
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center justify-between">
                    <span>Editable Template Controls</span>
                    <span className="text-[10px] text-purple-700 bg-purple-100 px-2 py-0.5 border border-purple-200">
                      Live Editable
                    </span>
                  </h4>

                  {/* Subject Line Input */}
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1 font-bold">
                      Email Subject Line *
                    </label>
                    <input
                      type="text"
                      required
                      value={
                        activeEmailKey === 'signup'
                          ? signUpSubject
                          : activeEmailKey === 'password'
                          ? passwordSubject
                          : activeEmailKey === 'order_status'
                          ? orderStatusSubject
                          : orderConfirmSubject
                      }
                      onChange={(e) => {
                        const val = e.target.value;
                        if (activeEmailKey === 'signup') setSignUpSubject(val);
                        else if (activeEmailKey === 'password') setPasswordSubject(val);
                        else if (activeEmailKey === 'order_status') setOrderStatusSubject(val);
                        else setOrderConfirmSubject(val);
                      }}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900 focus:outline-hidden focus:border-black"
                    />
                  </div>

                  {/* Body Text Area */}
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1 font-bold">
                      Email Body Content Template *
                    </label>
                    <textarea
                      rows={8}
                      required
                      value={
                        activeEmailKey === 'signup'
                          ? signUpBody
                          : activeEmailKey === 'password'
                          ? passwordBody
                          : activeEmailKey === 'order_status'
                          ? orderStatusBody
                          : orderConfirmBody
                      }
                      onChange={(e) => {
                        const val = e.target.value;
                        if (activeEmailKey === 'signup') setSignUpBody(val);
                        else if (activeEmailKey === 'password') setPasswordBody(val);
                        else if (activeEmailKey === 'order_status') setOrderStatusBody(val);
                        else setOrderConfirmBody(val);
                      }}
                      className="w-full bg-white border border-neutral-300 p-3 text-xs font-mono text-neutral-900 leading-relaxed focus:outline-hidden focus:border-black"
                    />
                  </div>

                  {/* Placeholder Insert Pills */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[11px] font-mono font-bold text-neutral-700 flex items-center gap-1">
                      <Tag className="w-3 h-3 text-neutral-500" />
                      <span>Click to append placeholder tag:</span>
                    </span>
                    <div className="flex flex-wrap gap-1.5 text-[10px] font-mono">
                      {[
                        '{customer_name}',
                        '{brand_name}',
                        '{order_id}',
                        '{reset_link}',
                        '{total_amount}',
                        '{items_summary}',
                        '{tracking_number}',
                        '{order_status}',
                      ].map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => insertTag(tag)}
                          className="px-2 py-1 bg-white hover:bg-neutral-200 border border-neutral-300 text-neutral-800 cursor-pointer font-bold transition-all"
                        >
                          + {tag}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Pane: Live Email Inbox Preview Canvas */}
              <div className="lg:col-span-6 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-800 flex items-center gap-1.5">
                    <Eye className="w-4 h-4 text-emerald-600" />
                    <span>Real-Time Customer Inbox Render</span>
                  </h4>
                  <span className="text-[10px] font-mono text-neutral-500">Live Client View</span>
                </div>

                {/* Email Client Frame Simulation */}
                <div className="border border-neutral-300 bg-white shadow-md rounded-xs overflow-hidden">
                  {/* Inbox Title Bar */}
                  <div className="bg-neutral-900 text-white p-3 text-xs font-mono flex items-center justify-between border-b border-neutral-800">
                    <div className="flex items-center space-x-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" />
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                      <span className="text-[11px] font-bold text-neutral-300 ml-2">Inbox Preview</span>
                    </div>
                    <span className="text-[10px] opacity-75">care@ezistential.com</span>
                  </div>

                  {/* Header Meta Info */}
                  <div className="p-4 bg-neutral-50 border-b border-neutral-200 space-y-1 text-xs font-sans text-neutral-700">
                    <div className="flex items-center justify-between">
                      <div>
                        <strong>From:</strong> {content.brandName || 'Ezistential Connections Studio'} &lt;care@ezistential.com&gt;
                      </div>
                      <span className="text-[10px] font-mono text-neutral-400">18:20 PM</span>
                    </div>
                    <div>
                      <strong>To:</strong> Alex Morgan &lt;alex.morgan@client.com&gt;
                    </div>
                    <div className="pt-2 text-sm font-serif font-bold text-neutral-900 border-t border-neutral-200/60 mt-2">
                      Subject: {renderSamplePreviewText(getCurrentSubject())}
                    </div>
                  </div>

                  {/* Rendered Email Body Box */}
                  <div className="p-6 space-y-6 text-xs text-neutral-900 font-sans leading-relaxed bg-white min-h-[220px]">
                    {/* Brand Banner Inside Email */}
                    <div className="border-b border-neutral-200 pb-3 flex items-center justify-between">
                      <span className="font-serif font-bold tracking-wider text-sm uppercase">
                        {content.brandName || 'EZISTENTIAL CONNECTIONS'}
                      </span>
                      <span className="text-[9px] font-mono text-neutral-400 uppercase">STUDIO DIRECTIVE</span>
                    </div>

                    {/* Body Text with Live Variable Replacement */}
                    <div className="whitespace-pre-wrap font-sans text-neutral-800 text-xs leading-relaxed">
                      {renderSamplePreviewText(getCurrentBody())}
                    </div>

                    {/* Interactive Sample CTA inside email */}
                    {activeEmailKey === 'password' && (
                      <div className="pt-2">
                        <a
                          href="#preview"
                          onClick={(e) => e.preventDefault()}
                          className="inline-block bg-black text-white px-4 py-2 font-mono text-[11px] font-bold uppercase tracking-wider hover:bg-neutral-800"
                        >
                          Verify & Reset Password →
                        </a>
                      </div>
                    )}

                    {/* Email Footer Dignity Note */}
                    <div className="border-t border-neutral-100 pt-4 text-[10px] text-neutral-400 font-mono space-y-1">
                      <div>{content.legalBusinessName || 'Ezistential Connections LLC'} — Chicago, IL</div>
                      <div>Examining the space between people through intentional apparel.</div>
                    </div>
                  </div>
                </div>

                {testDispatchState.msg && (
                  <div className="p-3 bg-purple-50 text-purple-900 border border-purple-200 text-xs font-mono">
                    {testDispatchState.msg}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 5: DATABASE & SNAPSHOTS */}
        {activeSubTab === 'backup' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="font-serif text-lg text-neutral-900">Database Records & Backup Snapshots</h3>
              <p className="text-xs text-neutral-500 mt-0.5 font-sans">
                Export complete system backups, inspect database record counts, or restore state.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-neutral-50 border border-neutral-200 font-mono text-xs">
              <div className="p-3 bg-white border border-neutral-200">
                <div className="text-[10px] text-neutral-500 uppercase">Products</div>
                <div className="text-xl font-bold text-neutral-900 mt-1">{products.length}</div>
              </div>
              <div className="p-3 bg-white border border-neutral-200">
                <div className="text-[10px] text-neutral-500 uppercase">Orders</div>
                <div className="text-xl font-bold text-neutral-900 mt-1">{orders.length}</div>
              </div>
              <div className="p-3 bg-white border border-neutral-200">
                <div className="text-[10px] text-neutral-500 uppercase">Journal Posts</div>
                <div className="text-xl font-bold text-neutral-900 mt-1">{posts.length}</div>
              </div>
              <div className="p-3 bg-white border border-neutral-200">
                <div className="text-[10px] text-neutral-500 uppercase">FAQs</div>
                <div className="text-xl font-bold text-neutral-900 mt-1">{faqs.length}</div>
              </div>
            </div>

            <div className="p-6 bg-neutral-900 text-white space-y-4 border border-neutral-800">
              <div className="flex items-center space-x-2">
                <Database className="w-5 h-5 text-emerald-400" />
                <h4 className="font-serif text-base font-medium">Data Backup & Disaster Recovery</h4>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                Save a complete JSON snapshot of all products, order records, journal posts, and brand configuration to your local device.
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    if (onOpenDataBackupModal) {
                      onOpenDataBackupModal();
                    } else {
                      showToast('Opening Data Backup & Snapshot tool...');
                    }
                  }}
                >
                  <Download className="w-3.5 h-3.5 mr-1.5" />
                  <span>Open Snapshot & Restore Modal</span>
                </Button>
              </div>
            </div>
          </div>
        )}

        <div className="pt-6 border-t border-neutral-200 flex justify-end">
          <Button type="submit" variant="primary" size="md">
            <Check className="w-3.5 h-3.5 mr-1.5" />
            <span>Save All Settings & Templates</span>
          </Button>
        </div>
      </form>
    </div>
  );
};
