import React from 'react';
import { X, Printer, Check, MapPin, Phone, Mail } from 'lucide-react';
import { Order } from '../../types';
import { Button } from '../ui/Button';
import { Logo } from '../brand/Logo';
import { formatPrice } from '../../lib/utils';
import { useContent } from '../../context/ContentContext';

export interface PackingSlipModalProps {
  order: Order | null;
  onClose: () => void;
}

export const PackingSlipModal: React.FC<PackingSlipModalProps> = ({ order, onClose }) => {
  const { content } = useContent();
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs print:hidden"
        onClick={onClose}
      />

      {/* Modal / Printable Slip */}
      <div className="relative w-full max-w-2xl bg-white border border-neutral-300 p-8 sm:p-10 space-y-6 shadow-2xl z-10 max-h-[92vh] overflow-y-auto print:max-h-none print:shadow-none print:border-none print:p-0 print:m-0 animate-in fade-in duration-200">
        {/* Screen Toolbar */}
        <div className="flex items-center justify-between border-b border-neutral-200 pb-4 print:hidden">
          <div className="flex items-center space-x-2">
            <Printer className="w-4 h-4 text-neutral-700" />
            <span className="text-xs uppercase font-mono tracking-wider text-neutral-800 font-semibold">
              Commercial Packing Slip Preview
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <Button onClick={handlePrint} variant="primary" size="sm">
              <Printer className="w-3.5 h-3.5 mr-1.5" />
              <span>Print Packing Slip</span>
            </Button>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-black cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Content */}
        <div className="space-y-6 text-neutral-900 font-sans">
          {/* Slip Header */}
          <div className="flex justify-between items-start border-b border-neutral-900 pb-6">
            <div>
              <Logo variant="black" className="h-8 w-auto mb-2" />
              <p className="text-[11px] text-neutral-800 font-mono uppercase tracking-wider font-semibold">
                {content.legalBusinessName || content.brandName}
              </p>
              <p className="text-[11px] text-neutral-500">
                {content.businessAddressStreet}, {content.businessAddressCity}, {content.businessAddressState} {content.businessAddressZip}
              </p>
              <p className="text-[11px] text-neutral-500 font-mono">
                Support: {content.supportEmail} · Tel: {content.businessPhone}
              </p>
            </div>
            <div className="text-right">
              <div className="text-xs font-mono uppercase tracking-widest text-neutral-500">
                Packing Slip
              </div>
              <div className="font-mono text-lg font-bold text-neutral-900">
                {order.orderNumber}
              </div>
              <div className="text-xs text-neutral-600 font-mono mt-1">
                Date: {new Date(order.createdAt).toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </div>
            </div>
          </div>

          {/* Addresses & Dispatch Row */}
          <div className="grid grid-cols-2 gap-8 text-xs">
            <div className="space-y-1">
              <span className="font-mono text-[10px] uppercase tracking-wider text-neutral-500 block">
                Deliver To (Recipient):
              </span>
              <p className="font-bold text-neutral-900">{order.shippingAddress.fullName}</p>
              <p className="text-neutral-600">{order.shippingAddress.street}</p>
              {order.shippingAddress.apartment && (
                <p className="text-neutral-600">{order.shippingAddress.apartment}</p>
              )}
              <p className="text-neutral-600">
                {order.shippingAddress.city}, {order.shippingAddress.state}{' '}
                {order.shippingAddress.zipCode}
              </p>
              <p className="text-neutral-600 font-mono text-[11px]">
                {order.shippingAddress.country} · {order.shippingAddress.phone || order.customerEmail}
              </p>
            </div>

            <div className="space-y-1 text-right">
              <span className="font-mono text-[10px] uppercase tracking-wider text-neutral-500 block">
                Fulfillment & Carrier:
              </span>
              <p className="font-mono font-medium text-neutral-900">
                {order.carrier || 'USPS Ground Advantage'}
              </p>
              <p className="font-mono text-[11px] text-neutral-600">
                Tracking: {order.trackingNumber || 'Pending scan'}
              </p>
              <p className="font-mono text-[11px] text-neutral-500 pt-1">
                Batch: {order.podOrderId || 'APQ-DOMESTIC'}
              </p>
            </div>
          </div>

          {/* Garments Items Table */}
          <div className="border-t border-b border-neutral-200 py-4">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-neutral-200 text-neutral-400 font-mono text-[10px] uppercase">
                  <th className="py-2">Item / Garment Specification</th>
                  <th className="py-2">Size</th>
                  <th className="py-2">Color</th>
                  <th className="py-2 text-center">Qty</th>
                  <th className="py-2 text-right">Unit Price</th>
                  <th className="py-2 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {order.items.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-3 font-medium text-neutral-900">
                      {item.productName}
                      <span className="block text-[10px] text-neutral-500 font-mono">
                        {item.wearType || '6.5oz Heavyweight Cotton Blank'} • DTF Print
                      </span>
                    </td>
                    <td className="py-3 font-mono font-bold text-neutral-800">{item.size}</td>
                    <td className="py-3 text-neutral-700">{item.color}</td>
                    <td className="py-3 text-center font-mono font-bold">{item.quantity}</td>
                    <td className="py-3 text-right font-mono text-neutral-600">
                      {formatPrice(item.price)}
                    </td>
                    <td className="py-3 text-right font-mono font-bold text-neutral-900">
                      {formatPrice(item.subtotal)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Order Summary & Philosophy Note */}
          <div className="grid grid-cols-2 gap-8 text-xs pt-2">
            <div className="space-y-2 bg-[#f5f4f0] p-4 border border-neutral-200">
              <span className="font-mono text-[10px] uppercase tracking-widest text-neutral-500 block">
                Contemplation Covenant
              </span>
              <p className="font-serif italic text-xs text-neutral-800 leading-relaxed">
                "{content.foundingQuote}"
              </p>
              <p className="text-[11px] text-neutral-600">
                Thank you for bringing these questions into public space. Wear with intention.
              </p>
            </div>

            <div className="space-y-1.5 font-mono text-right text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-500">Subtotal:</span>
                <span>{formatPrice(order.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Domestic Shipping:</span>
                <span>{order.shippingCost === 0 ? 'Complimentary' : formatPrice(order.shippingCost)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Estimated Tax ({content.salesTaxRatePercent}%):</span>
                <span>{formatPrice(order.taxCost)}</span>
              </div>
              <div className="flex justify-between text-sm font-bold border-t border-neutral-300 pt-2 text-neutral-900">
                <span>Total Paid:</span>
                <span>{formatPrice(order.total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
