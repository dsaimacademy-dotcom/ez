import React, { useState } from 'react';
import { WearType, ColorItem, MasterSizeItem } from '../../types';
import { useProducts } from '../../context/ProductContext';
import { calculatePodMargin, DEFAULT_MASTER_SIZES, DEFAULT_WEAR_TYPES, MASTER_COLOR_LIBRARY } from '../../data/wearTypes';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import {
  Layers,
  Palette,
  Ruler,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Sparkles,
  Info,
  DollarSign,
  RotateCcw,
  Check,
  X,
  SlidersHorizontal
} from 'lucide-react';

interface WearTypeLibraryCMSProps {
  showToast: (msg: string) => void;
}

export const WearTypeLibraryCMS: React.FC<WearTypeLibraryCMSProps> = ({ showToast }) => {
  const {
    wearTypes,
    addWearType,
    updateWearTypes,
    deleteWearType,
    colors,
    addColor,
    updateColors,
    deleteColor,
    sizes,
    addSize,
    updateSize,
    updateSizes,
    deleteSize,
  } = useProducts();

  const [activeTab, setActiveTab] = useState<'weartypes' | 'colors' | 'sizes'>('weartypes');

  // New Wear Type State
  const [newWtName, setNewWtName] = useState('');
  const [newWtCategory, setNewWtCategory] = useState<'tee' | 'hoodie' | 'crewneck' | 'fleece' | 'accessory' | 'pant' | 'other'>('tee');
  const [newWtBaseCost, setNewWtBaseCost] = useState('18.50');
  const [newWtRetail, setNewWtRetail] = useState('48');
  const [newWtFabric, setNewWtFabric] = useState('100% Organic Combed Ringspun Cotton');
  const [newWtWeight, setNewWtWeight] = useState('6.5 oz / 220 GSM Heavyweight Jersey');
  const [newWtFit, setNewWtFit] = useState('Relaxed architectural drop-shoulder cut');
  const [newWtPrintTech, setNewWtPrintTech] = useState('Direct-to-Film (DTF) Soft-Hand Archival Pigment');
  const [newWtSku, setNewWtSku] = useState('APL-TEE-6500');

  // Edit Wear Type State
  const [editingWearType, setEditingWearType] = useState<WearType | null>(null);

  // New Color State
  const [newColorName, setNewColorName] = useState('');
  const [newColorHex, setNewColorHex] = useState('#0f0f0f');
  const [newColorCategory, setNewColorCategory] = useState('Monochrome');

  // New Size State
  const [newSizeName, setNewSizeName] = useState('');
  const [newSizeLabel, setNewSizeLabel] = useState('');
  const [newSizeCategory, setNewSizeCategory] = useState<string>('Standard Adult');
  const [newSizeChest, setNewSizeChest] = useState('');
  const [newSizeLength, setNewSizeLength] = useState('');

  // Edit Size Modal / State
  const [editingSize, setEditingSize] = useState<MasterSizeItem | null>(null);

  // Handlers
  const handleAddWearType = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWtName.trim()) return;

    const baseCostNum = parseFloat(newWtBaseCost) || 18.5;
    const retailNum = parseFloat(newWtRetail) || 48;
    const id = `wt-${newWtName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString(36).slice(-4)}`;

    const newWt: WearType = {
      id,
      name: newWtName.trim(),
      category: newWtCategory,
      baseCost: baseCostNum,
      defaultRetailPrice: retailNum,
      fabric: newWtFabric.trim(),
      weight: newWtWeight.trim(),
      fit: newWtFit.trim(),
      origin: 'Ethically crafted in Los Angeles, CA',
      printTechnique: newWtPrintTech.trim(),
      supplierSku: newWtSku.trim(),
      active: true,
    };

    addWearType(newWt);
    setNewWtName('');
    showToast(`Added "${newWt.name}" to Master Wear Type Library.`);
  };

  const handleSaveWearTypeEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWearType) return;

    const updated = wearTypes.map((wt) => (wt.id === editingWearType.id ? editingWearType : wt));
    updateWearTypes(updated);
    setEditingWearType(null);
    showToast(`Updated "${editingWearType.name}" specifications.`);
  };

  const handleAddColor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColorName.trim()) return;

    const newCol: ColorItem = {
      id: `col-${newColorName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
      name: newColorName.trim(),
      hex: newColorHex,
      category: newColorCategory,
      active: true,
    };

    addColor(newCol);
    setNewColorName('');
    showToast(`Added color "${newCol.name}" to Master Color Library.`);
  };

  const handleAddSize = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSizeName.trim()) return;

    const cleanName = newSizeName.trim().toUpperCase();
    const newSz: MasterSizeItem = {
      id: `size-${cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString(36).slice(-4)}`,
      name: cleanName,
      label: newSizeLabel.trim() || cleanName,
      category: newSizeCategory,
      chestInch: newSizeChest.trim() || undefined,
      lengthInch: newSizeLength.trim() || undefined,
      active: true,
      sortOrder: (sizes?.length || 0) + 1,
    };

    addSize(newSz);
    setNewSizeName('');
    setNewSizeLabel('');
    setNewSizeChest('');
    setNewSizeLength('');
    showToast(`Added size "${newSz.name}" (${newSz.label}) to Master Size Library.`);
  };

  const handleSaveSizeEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSize) return;

    updateSize(editingSize.id, editingSize);
    setEditingSize(null);
    showToast(`Updated size "${editingSize.name}" dimensions.`);
  };

  const handleRestoreDefaultSizes = () => {
    if (confirm('Restore standard defaults (XS, S, M, L, XL, 2XL, 3XL, OS) for the Master Size Library?')) {
      updateSizes(DEFAULT_MASTER_SIZES);
      showToast('Master Size Library restored to factory defaults.');
    }
  };

  const handleRestoreDefaultWearTypes = () => {
    if (confirm('Restore default 5 base blanks (Tee, Hoodie, Crewneck, Longsleeve, Tote)?')) {
      updateWearTypes(DEFAULT_WEAR_TYPES);
      showToast('Base Garments & Wear Types restored to defaults.');
    }
  };

  const handleRestoreDefaultColors = () => {
    if (confirm('Restore 8 master colorways?')) {
      updateColors(MASTER_COLOR_LIBRARY);
      showToast('Master Color Library restored to defaults.');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header & Sub-Tabs */}
      <div className="bg-white border border-neutral-200 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-serif text-xl font-bold text-neutral-900">
            Master Garment, Color & Size Libraries
          </h3>
          <p className="text-xs text-neutral-500 font-sans mt-0.5">
            Central real-world base blanks, color palettes, and size scales synchronized seamlessly across Design Factory and Product Studio.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 bg-neutral-100 p-1 border border-neutral-200 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('weartypes')}
            className={`px-3 py-2 text-xs font-mono font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'weartypes' ? 'bg-black text-white shadow-xs' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>1. Base Garments & Wear Types ({wearTypes.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('colors')}
            className={`px-3 py-2 text-xs font-mono font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'colors' ? 'bg-black text-white shadow-xs' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>2. Master Color Library ({colors.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('sizes')}
            className={`px-3 py-2 text-xs font-mono font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'sizes' ? 'bg-black text-white shadow-xs' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <Ruler className="w-3.5 h-3.5" />
            <span>3. Master Size Library ({(sizes || []).length})</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          TAB 1: BASE GARMENTS & WEAR TYPES
          ======================================================== */}
      {activeTab === 'weartypes' && (
        <div className="space-y-6">
          {/* Add New Wear Type Blank Form */}
          <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <h4 className="font-serif text-base font-bold text-neutral-900">Add New Base Blank / Wear Type Entity</h4>
              <button
                type="button"
                onClick={handleRestoreDefaultWearTypes}
                className="text-[11px] font-mono text-neutral-500 hover:text-black inline-flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Defaults</span>
              </button>
            </div>
            <form onSubmit={handleAddWearType} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Silhouette Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 10oz French Terry Crewneck"
                    value={newWtName}
                    onChange={(e) => setNewWtName(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-medium focus:outline-hidden focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Category</label>
                  <select
                    value={newWtCategory}
                    onChange={(e) => setNewWtCategory(e.target.value as any)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:outline-hidden focus:border-black"
                  >
                    <option value="tee">T-Shirt</option>
                    <option value="hoodie">Hoodie</option>
                    <option value="crewneck">Crewneck</option>
                    <option value="fleece">Fleece / Outerwear</option>
                    <option value="accessory">Accessory / Tote</option>
                    <option value="pant">Pant / Bottom</option>
                    <option value="other">Other Silhouette</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Supplier Blank SKU</label>
                  <input
                    type="text"
                    placeholder="e.g. APL-CRW-1000"
                    value={newWtSku}
                    onChange={(e) => setNewWtSku(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:outline-hidden focus:border-black"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">POD Base Wholesale Cost ($)</label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={newWtBaseCost}
                    onChange={(e) => setNewWtBaseCost(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono font-bold focus:outline-hidden focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Default Retail Price ($)</label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={newWtRetail}
                    onChange={(e) => setNewWtRetail(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono font-bold focus:outline-hidden focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Fabric Weight / GSM</label>
                  <input
                    type="text"
                    value={newWtWeight}
                    onChange={(e) => setNewWtWeight(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs focus:outline-hidden focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Fit Silhouette</label>
                  <input
                    type="text"
                    value={newWtFit}
                    onChange={(e) => setNewWtFit(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs focus:outline-hidden focus:border-black"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="submit" variant="primary" size="sm">
                  + Add Base Blank to Library
                </Button>
              </div>
            </form>
          </div>

          {/* Existing Blanks Table */}
          <div className="bg-white border border-neutral-200 overflow-x-auto shadow-xs">
            <table className="w-full text-left text-xs bg-white">
              <thead className="bg-neutral-100 border-b border-neutral-200 text-neutral-600 uppercase font-mono text-[10px]">
                <tr>
                  <th className="py-3 px-4">Base Silhouette Name</th>
                  <th className="py-3 px-3">Category</th>
                  <th className="py-3 px-3">Fabric & Weight</th>
                  <th className="py-3 px-3">POD Wholesale Cost</th>
                  <th className="py-3 px-3">Rec. Retail</th>
                  <th className="py-3 px-3">Gross Margin</th>
                  <th className="py-3 px-3">Supplier Blank SKU</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 font-mono text-xs">
                {wearTypes.map((wt, idx) => {
                  const { profit, marginPercent } = calculatePodMargin(wt.defaultRetailPrice, wt.baseCost);
                  return (
                    <tr key={wt.id || idx} className="hover:bg-neutral-50 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-sans font-bold text-neutral-900">{wt.name}</div>
                        <div className="text-[10px] text-neutral-400 font-mono">{wt.id}</div>
                      </td>
                      <td className="py-3 px-3">
                        <Badge variant="neutral" size="sm">{wt.category.toUpperCase()}</Badge>
                      </td>
                      <td className="py-3 px-3 font-sans text-neutral-600">
                        {wt.weight} · {wt.fabric}
                      </td>
                      <td className="py-3 px-3 font-bold text-neutral-900">
                        ${wt.baseCost.toFixed(2)}
                      </td>
                      <td className="py-3 px-3 font-bold text-neutral-900">
                        ${wt.defaultRetailPrice.toFixed(2)}
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-emerald-700">
                          +${profit.toFixed(2)} ({marginPercent}%)
                        </span>
                      </td>
                      <td className="py-3 px-3 text-neutral-500">
                        {wt.supplierSku || 'APL-GEN'}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => {
                            const updated = [...wearTypes];
                            updated[idx].active = !updated[idx].active;
                            updateWearTypes(updated);
                            showToast(`Toggled ${wt.name} status.`);
                          }}
                          className={`px-2 py-0.5 text-[10px] font-mono cursor-pointer border ${
                            wt.active
                              ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                              : 'bg-neutral-200 text-neutral-700 border-neutral-300'
                          }`}
                        >
                          {wt.active ? 'ACTIVE' : 'INACTIVE'}
                        </button>
                      </td>
                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          type="button"
                          onClick={() => setEditingWearType({ ...wt })}
                          className="p-1 text-neutral-400 hover:text-black cursor-pointer"
                          title="Edit Silhouette"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            deleteWearType(wt.id);
                            showToast(`Removed "${wt.name}" from library.`);
                          }}
                          className="p-1 text-neutral-400 hover:text-red-600 cursor-pointer"
                          title="Delete Silhouette"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 2: MASTER COLOR LIBRARY
          ======================================================== */}
      {activeTab === 'colors' && (
        <div className="space-y-6">
          {/* Add Color Form */}
          <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <h4 className="font-serif text-base font-bold text-neutral-900">Add New Master Brand Colorway</h4>
              <button
                type="button"
                onClick={handleRestoreDefaultColors}
                className="text-[11px] font-mono text-neutral-500 hover:text-black inline-flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Defaults</span>
              </button>
            </div>
            <form onSubmit={handleAddColor} className="flex flex-col sm:flex-row items-center gap-3">
              <input
                type="text"
                required
                placeholder="Color Name (e.g. Washed Sage)"
                value={newColorName}
                onChange={(e) => setNewColorName(e.target.value)}
                className="flex-1 bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono w-full focus:outline-hidden focus:border-black"
              />
              <div className="flex items-center gap-2 shrink-0">
                <input
                  type="color"
                  value={newColorHex}
                  onChange={(e) => setNewColorHex(e.target.value)}
                  className="w-10 h-8 bg-white border border-neutral-300 p-0.5 cursor-pointer"
                />
                <span className="font-mono text-xs text-neutral-600 uppercase">{newColorHex}</span>
              </div>
              <select
                value={newColorCategory}
                onChange={(e) => setNewColorCategory(e.target.value)}
                className="bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:outline-hidden focus:border-black"
              >
                <option value="Monochrome">Monochrome</option>
                <option value="Earth / Neutral">Earth / Neutral</option>
                <option value="Deep Tone">Deep Tone</option>
                <option value="Warm Tone">Warm Tone</option>
                <option value="Vibrant">Vibrant</option>
              </select>
              <Button type="submit" variant="primary" size="sm" className="shrink-0">
                + Add Color
              </Button>
            </form>
          </div>

          {/* Color Grid */}
          <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
            <h4 className="font-serif text-base font-bold text-neutral-900">
              Active Master Colors ({colors.length})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {colors.map((col, idx) => (
                <div
                  key={col.id || col.name}
                  className="bg-neutral-50 p-3.5 border border-neutral-200 flex items-center justify-between gap-3 shadow-xs hover:border-neutral-400 transition-colors"
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <span
                      className="w-8 h-8 rounded-full border border-neutral-300 shrink-0 shadow-inner"
                      style={{ backgroundColor: col.hex }}
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-mono font-bold text-neutral-900 truncate">{col.name}</div>
                      <div className="text-[10px] font-mono text-neutral-500 uppercase">{col.hex} · {col.category || 'Color'}</div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      deleteColor(col.id || col.name);
                      showToast(`Removed color "${col.name}".`);
                    }}
                    className="p-1 text-neutral-400 hover:text-red-600 cursor-pointer shrink-0"
                    title="Delete Color"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 3: MASTER SIZE LIBRARY (DYNAMIC SIZES CMS)
          ======================================================== */}
      {activeTab === 'sizes' && (
        <div className="space-y-6">
          {/* Add Size Form */}
          <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-serif text-base font-bold text-neutral-900">Add New Master Size Option</h4>
                <p className="text-xs text-neutral-500 font-sans mt-0.5">
                  Sizes are not hardcoded. Add custom size codes, descriptors, chest & length measurements, and categories.
                </p>
              </div>
              <button
                type="button"
                onClick={handleRestoreDefaultSizes}
                className="text-[11px] font-mono text-neutral-500 hover:text-black inline-flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Defaults</span>
              </button>
            </div>

            <form onSubmit={handleAddSize} className="space-y-4 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">
                    Size Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 4XL or BOXY-M"
                    value={newSizeName}
                    onChange={(e) => setNewSizeName(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono font-bold uppercase focus:outline-hidden focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Full Label / Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Quadruple Extra Large"
                    value={newSizeLabel}
                    onChange={(e) => setNewSizeLabel(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-medium focus:outline-hidden focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Category</label>
                  <select
                    value={newSizeCategory}
                    onChange={(e) => setNewSizeCategory(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:outline-hidden focus:border-black"
                  >
                    <option value="Standard Adult">Standard Adult</option>
                    <option value="Oversized / Boxy">Oversized / Boxy</option>
                    <option value="Unisex / Accessories">Unisex / Accessories</option>
                    <option value="Tall / Long">Tall / Long</option>
                    <option value="Custom">Custom</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Chest Width (in / cm)</label>
                  <input
                    type="text"
                    placeholder='e.g. 60-62"'
                    value={newSizeChest}
                    onChange={(e) => setNewSizeChest(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:outline-hidden focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Body Length (in / cm)</label>
                  <input
                    type="text"
                    placeholder='e.g. 34"'
                    value={newSizeLength}
                    onChange={(e) => setNewSizeLength(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:outline-hidden focus:border-black"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="submit" variant="primary" size="sm">
                  + Add Size to Master Library
                </Button>
              </div>
            </form>
          </div>

          {/* Sizes List & Grid */}
          <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <h4 className="font-serif text-base font-bold text-neutral-900">
                Configured Sizes ({(sizes || []).length})
              </h4>
              <span className="text-xs font-mono text-neutral-500">
                Available for selection during product publishing & customer sizing
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs bg-white">
                <thead className="bg-neutral-100 border-b border-neutral-200 text-neutral-600 uppercase font-mono text-[10px]">
                  <tr>
                    <th className="py-3 px-4 w-20">Size Code</th>
                    <th className="py-3 px-3">Descriptive Label</th>
                    <th className="py-3 px-3">Category</th>
                    <th className="py-3 px-3">Chest Width</th>
                    <th className="py-3 px-3">Body Length</th>
                    <th className="py-3 px-3 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 font-mono text-xs">
                  {(sizes || DEFAULT_MASTER_SIZES).map((sz, idx) => (
                    <tr key={sz.id || sz.name} className="hover:bg-neutral-50 transition-colors">
                      <td className="py-3 px-4">
                        <span className="inline-block px-2.5 py-1 bg-black text-white font-mono font-bold text-xs rounded-xs">
                          {sz.name}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-sans font-medium text-neutral-900">
                        {sz.label}
                      </td>
                      <td className="py-3 px-3">
                        <Badge variant="neutral" size="sm">
                          {sz.category || 'Standard'}
                        </Badge>
                      </td>
                      <td className="py-3 px-3 text-neutral-600 font-mono">
                        {sz.chestInch || '—'}
                      </td>
                      <td className="py-3 px-3 text-neutral-600 font-mono">
                        {sz.lengthInch || '—'}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => {
                            updateSize(sz.id, { active: !sz.active });
                            showToast(`Size ${sz.name} set to ${!sz.active ? 'ACTIVE' : 'INACTIVE'}.`);
                          }}
                          className={`px-2 py-0.5 text-[10px] font-mono cursor-pointer border ${
                            sz.active !== false
                              ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                              : 'bg-neutral-200 text-neutral-700 border-neutral-300'
                          }`}
                        >
                          {sz.active !== false ? 'ACTIVE' : 'INACTIVE'}
                        </button>
                      </td>
                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          type="button"
                          onClick={() => setEditingSize({ ...sz })}
                          className="p-1 text-neutral-400 hover:text-black cursor-pointer"
                          title="Edit Size Specs"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            deleteSize(sz.id || sz.name);
                            showToast(`Removed size "${sz.name}".`);
                          }}
                          className="p-1 text-neutral-400 hover:text-red-600 cursor-pointer"
                          title="Delete Size"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: EDIT WEAR TYPE
          ======================================================== */}
      {editingWearType && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-neutral-300 max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">
                Edit Wear Type: {editingWearType.name}
              </h3>
              <button
                type="button"
                onClick={() => setEditingWearType(null)}
                className="p-1 text-neutral-400 hover:text-black cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveWearTypeEdit} className="space-y-3 font-sans text-xs">
              <div>
                <label className="block font-mono uppercase text-neutral-600 mb-1">Silhouette Name</label>
                <input
                  type="text"
                  required
                  value={editingWearType.name}
                  onChange={(e) => setEditingWearType({ ...editingWearType, name: e.target.value })}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono uppercase text-neutral-600 mb-1">POD Base Cost ($)</label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={editingWearType.baseCost}
                    onChange={(e) => setEditingWearType({ ...editingWearType, baseCost: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-mono uppercase text-neutral-600 mb-1">Retail Price ($)</label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={editingWearType.defaultRetailPrice}
                    onChange={(e) => setEditingWearType({ ...editingWearType, defaultRetailPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-mono uppercase text-neutral-600 mb-1">Fabric & Weight</label>
                <input
                  type="text"
                  value={editingWearType.fabric}
                  onChange={(e) => setEditingWearType({ ...editingWearType, fabric: e.target.value })}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2"
                />
              </div>

              <div>
                <label className="block font-mono uppercase text-neutral-600 mb-1">Fit Silhouette</label>
                <input
                  type="text"
                  value={editingWearType.fit}
                  onChange={(e) => setEditingWearType({ ...editingWearType, fit: e.target.value })}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2"
                />
              </div>

              <div>
                <label className="block font-mono uppercase text-neutral-600 mb-1">Print Technique</label>
                <input
                  type="text"
                  value={editingWearType.printTechnique || ''}
                  onChange={(e) => setEditingWearType({ ...editingWearType, printTechnique: e.target.value })}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 font-mono"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-neutral-200">
                <Button type="button" variant="outline" size="sm" onClick={() => setEditingWearType(null)}>
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  Save Changes
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: EDIT SIZE
          ======================================================== */}
      {editingSize && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-neutral-300 max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">
                Edit Size: {editingSize.name}
              </h3>
              <button
                type="button"
                onClick={() => setEditingSize(null)}
                className="p-1 text-neutral-400 hover:text-black cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSizeEdit} className="space-y-3 font-sans text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono uppercase text-neutral-600 mb-1">Size Code</label>
                  <input
                    type="text"
                    required
                    value={editingSize.name}
                    onChange={(e) => setEditingSize({ ...editingSize, name: e.target.value.toUpperCase() })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 font-mono font-bold uppercase"
                  />
                </div>
                <div>
                  <label className="block font-mono uppercase text-neutral-600 mb-1">Category</label>
                  <select
                    value={editingSize.category || 'Standard Adult'}
                    onChange={(e) => setEditingSize({ ...editingSize, category: e.target.value })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 font-mono"
                  >
                    <option value="Standard Adult">Standard Adult</option>
                    <option value="Oversized / Boxy">Oversized / Boxy</option>
                    <option value="Unisex / Accessories">Unisex / Accessories</option>
                    <option value="Tall / Long">Tall / Long</option>
                    <option value="Custom">Custom</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-mono uppercase text-neutral-600 mb-1">Full Descriptive Label</label>
                <input
                  type="text"
                  required
                  value={editingSize.label}
                  onChange={(e) => setEditingSize({ ...editingSize, label: e.target.value })}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono uppercase text-neutral-600 mb-1">Chest Width</label>
                  <input
                    type="text"
                    value={editingSize.chestInch || ''}
                    onChange={(e) => setEditingSize({ ...editingSize, chestInch: e.target.value })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-mono uppercase text-neutral-600 mb-1">Body Length</label>
                  <input
                    type="text"
                    value={editingSize.lengthInch || ''}
                    onChange={(e) => setEditingSize({ ...editingSize, lengthInch: e.target.value })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-neutral-200">
                <Button type="button" variant="outline" size="sm" onClick={() => setEditingSize(null)}>
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  Save Size Changes
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
