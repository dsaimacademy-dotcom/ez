import React, { useState } from 'react';
import {
  Building2,
  Globe,
  MapPin,
  Phone,
  Share2,
  DollarSign,
  CheckCircle2,
  Image as ImageIcon,
  ExternalLink,
  Instagram,
  Twitter,
  Youtube,
  Music,
  Bookmark,
  Share,
  Facebook,
  Linkedin,
  CreditCard,
  Lock,
  Zap,
  ShieldCheck,
  Smartphone,
  QrCode,
  Eye,
  EyeOff,
  Activity,
  AlertCircle,
  RefreshCw,
  Key,
  Check
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { Button } from '../ui/Button';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';
import { Logo } from '../brand/Logo';
import { PaymentStatusBadge, getPaymentConnectionStatus } from './PaymentStatusBadge';

export type BrandSubTab = 'identity' | 'seo' | 'studio' | 'contacts' | 'socials' | 'fiscal';

interface ApiTestResult {
  provider: string;
  status: 'success' | 'error' | 'testing';
  message: string;
  latencyMs?: number;
  details?: string[];
}

export const BrandBusinessSetup: React.FC = () => {
  const { content, updateContent } = useContent();
  const [activeSubTab, setActiveSubTab] = useState<BrandSubTab>('identity');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Identity States
  const [brandName, setBrandName] = useState(content.brandName || 'Ezistential Connections');
  const [brandShortName, setBrandShortName] = useState(content.brandShortName || 'Ezistential');
  const [brandTagline, setBrandTagline] = useState(content.brandTagline || 'The Space Between People');
  const [brandLogoUrl, setBrandLogoUrl] = useState(content.brandLogoUrl || '/ez-logo.svg');
  const [brandLogoDarkUrl, setBrandLogoDarkUrl] = useState(content.brandLogoDarkUrl || '/ez-logo-white.svg');
  const [faviconUrl, setFaviconUrl] = useState(
    (content.faviconUrl && content.faviconUrl !== '/favicon.ico') ? content.faviconUrl : '/ez-favicon.svg'
  );

  // SEO & Online
  const [pageTitleTemplate, setPageTitleTemplate] = useState(content.pageTitleTemplate || 'Ezistential Connections — Space Between People');
  const [metaDescription, setMetaDescription] = useState(content.metaDescription || '');

  // Studio & Entity
  const [legalBusinessName, setLegalBusinessName] = useState(content.legalBusinessName || 'Ezistential Connections LLC');
  const [businessAddressStreet, setBusinessAddressStreet] = useState(content.businessAddressStreet || '1842 N Damen Ave, Suite 3F');
  const [businessAddressCity, setBusinessAddressCity] = useState(content.businessAddressCity || 'Chicago');
  const [businessAddressState, setBusinessAddressState] = useState(content.businessAddressState || 'IL');
  const [businessAddressZip, setBusinessAddressZip] = useState(content.businessAddressZip || '60647');
  const [businessAddressCountry, setBusinessAddressCountry] = useState(content.businessAddressCountry || 'United States');

  // Contacts
  const [businessPhone, setBusinessPhone] = useState(content.businessPhone || '+1 (312) 555-0192');
  const [supportEmail, setSupportEmail] = useState(content.supportEmail || 'care@ezistential.com');
  const [ordersEmail, setOrdersEmail] = useState(content.ordersEmail || 'orders@ezistential.com');
  const [pressEmail, setPressEmail] = useState(content.pressEmail || 'press@ezistential.com');
  const [businessHours, setBusinessHours] = useState(content.businessHours || 'Monday – Friday: 9:00 AM – 6:00 PM CST');

  // Socials
  const [instagramHandle, setInstagramHandle] = useState(content.instagramHandle || '@ezistential');
  const [instagramUrl, setInstagramUrl] = useState(content.instagramUrl || 'https://instagram.com/ezistential');
  const [twitterHandle, setTwitterHandle] = useState(content.twitterHandle || '@ezistential');
  const [twitterUrl, setTwitterUrl] = useState(content.twitterUrl || 'https://x.com/ezistential');
  const [tiktokHandle, setTiktokHandle] = useState(content.tiktokHandle || '');
  const [tiktokUrl, setTiktokUrl] = useState(content.tiktokUrl || '');
  const [youtubeUrl, setYoutubeUrl] = useState(content.youtubeUrl || '');
  const [spotifyUrl, setSpotifyUrl] = useState(content.spotifyUrl || 'https://open.spotify.com/user/ezistential');
  const [substackUrl, setSubstackUrl] = useState(content.substackUrl || 'https://ezistential.substack.com');
  const [pinterestUrl, setPinterestUrl] = useState(content.pinterestUrl || '');
  const [facebookUrl, setFacebookUrl] = useState(content.facebookUrl || '');
  const [linkedinUrl, setLinkedinUrl] = useState(content.linkedinUrl || '');
  const [discordUrl, setDiscordUrl] = useState(content.discordUrl || '');

  // Fiscal
  const [currencySymbol, setCurrencySymbol] = useState(content.currencySymbol || '$');
  const [currencyCode, setCurrencyCode] = useState(content.currencyCode || 'USD');
  const [salesTaxRatePercent, setSalesTaxRatePercent] = useState(content.salesTaxRatePercent || 6.5);

  // ==========================================
  // PAYMENT INTEGRATIONS DETAILS & CREDENTIALS
  // ==========================================
  // 1. Stripe
  const [stripeEnabled, setStripeEnabled] = useState(content.stripeEnabled || false);
  const [stripePublishableKey, setStripePublishableKey] = useState(content.stripePublishableKey || '');
  const [stripeSecretKey, setStripeSecretKey] = useState(content.stripeSecretKey || '');
  const [stripeWebhookSecret, setStripeWebhookSecret] = useState(content.stripeWebhookSecret || '');
  const [stripeStatementDescriptor, setStripeStatementDescriptor] = useState(content.stripeStatementDescriptor || 'EZISTENTIAL');
  const [stripeLiveMode, setStripeLiveMode] = useState(content.stripeLiveMode || false);

  // 2. PayPal
  const [paypalEnabled, setPaypalEnabled] = useState(content.paypalEnabled || false);
  const [paypalClientId, setPaypalClientId] = useState(content.paypalClientId || '');
  const [paypalSecretKey, setPaypalSecretKey] = useState(content.paypalSecretKey || '');
  const [paypalWebhookId, setPaypalWebhookId] = useState(content.paypalWebhookId || '');
  const [paypalEnvironment, setPaypalEnvironment] = useState<'sandbox' | 'production'>(content.paypalEnvironment || 'sandbox');
  const [paypalPayIn4Enabled, setPaypalPayIn4Enabled] = useState(content.paypalPayIn4Enabled || false);

  // 3. Apple Pay
  const [applePayEnabled, setApplePayEnabled] = useState(content.applePayEnabled || false);
  const [applePayMerchantId, setApplePayMerchantId] = useState(content.applePayMerchantId || '');
  const [applePayDomainName, setApplePayDomainName] = useState(content.applePayDomainName || '');
  const [applePayCertStatus, setApplePayCertStatus] = useState<'verified' | 'pending' | 'unverified'>(content.applePayCertStatus || 'unverified');

  // 4. Google Pay
  const [googlePayEnabled, setGooglePayEnabled] = useState(content.googlePayEnabled || false);
  const [googlePayMerchantId, setGooglePayMerchantId] = useState(content.googlePayMerchantId || '');
  const [googlePayGatewayMerchantId, setGooglePayGatewayMerchantId] = useState(content.googlePayGatewayMerchantId || '');
  const [googlePayEnvironment, setGooglePayEnvironment] = useState<'TEST' | 'PRODUCTION'>(content.googlePayEnvironment || 'TEST');

  // 5. Klarna
  const [klarnaEnabled, setKlarnaEnabled] = useState(content.klarnaEnabled || false);
  const [klarnaClientId, setKlarnaClientId] = useState(content.klarnaClientId || '');
  const [klarnaClientSecret, setKlarnaClientSecret] = useState(content.klarnaClientSecret || '');
  const [klarnaRegion, setKlarnaRegion] = useState(content.klarnaRegion || 'US');

  // 6. Afterpay
  const [afterpayEnabled, setAfterpayEnabled] = useState(content.afterpayEnabled || false);
  const [afterpayMerchantId, setAfterpayMerchantId] = useState(content.afterpayMerchantId || '');
  const [afterpaySecretKey, setAfterpaySecretKey] = useState(content.afterpaySecretKey || '');
  const [afterpayRegion, setAfterpayRegion] = useState(content.afterpayRegion || 'US');

  // 7. Cash App Pay
  const [cashAppPayEnabled, setCashAppPayEnabled] = useState(content.cashAppPayEnabled || false);
  const [cashAppCashtag, setCashAppCashtag] = useState(content.cashAppCashtag || '');
  const [cashAppClientId, setCashAppClientId] = useState(content.cashAppClientId || '');
  const [cashAppWebhookSecret, setCashAppWebhookSecret] = useState(content.cashAppWebhookSecret || '');

  // 8. Shop Pay
  const [shopPayEnabled, setShopPayEnabled] = useState(content.shopPayEnabled || false);
  const [shopPayStorefrontToken, setShopPayStorefrontToken] = useState(content.shopPayStorefrontToken || '');
  const [shopPayDomain, setShopPayDomain] = useState(content.shopPayDomain || '');

  // Password Visibility Toggles
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const toggleSecret = (key: string) => {
    setShowSecrets((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // API Health/Testing States
  const [apiTests, setApiTests] = useState<Record<string, ApiTestResult>>({});

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleTestApi = async (provider: string) => {
    setApiTests((prev) => ({
      ...prev,
      [provider]: {
        provider,
        status: 'testing',
        message: `Querying live ${provider} API server endpoint...`,
      },
    }));

    let credentialsPayload: any = {};
    if (provider === 'stripe') {
      credentialsPayload = {
        publishableKey: stripePublishableKey,
        secretKey: stripeSecretKey,
        liveMode: stripeLiveMode,
      };
    } else if (provider === 'paypal') {
      credentialsPayload = {
        clientId: paypalClientId,
        secretKey: paypalSecretKey,
        environment: paypalEnvironment,
      };
    } else if (provider === 'apple_pay') {
      credentialsPayload = {
        merchantId: applePayMerchantId,
        domainName: applePayDomainName,
      };
    } else if (provider === 'google_pay') {
      credentialsPayload = {
        merchantId: googlePayMerchantId,
        environment: googlePayEnvironment,
      };
    } else if (provider === 'klarna') {
      credentialsPayload = {
        clientId: klarnaClientId,
        clientSecret: klarnaClientSecret,
        region: klarnaRegion,
      };
    } else if (provider === 'afterpay') {
      credentialsPayload = {
        merchantId: afterpayMerchantId,
        secretKey: afterpaySecretKey,
        region: afterpayRegion,
      };
    } else if (provider === 'cashapp') {
      credentialsPayload = {
        cashtag: cashAppCashtag,
        clientId: cashAppClientId,
      };
    } else if (provider === 'shoppay') {
      credentialsPayload = {
        storefrontToken: shopPayStorefrontToken,
        domain: shopPayDomain,
      };
    }

    try {
      const response = await fetch('/api/payment-gateways/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          credentials: credentialsPayload,
        }),
      });

      const result = await response.json();

      if (response.ok && result.success) {
        setApiTests((prev) => ({
          ...prev,
          [provider]: {
            provider: result.provider || provider,
            status: 'success',
            message: result.message || 'API Connection Verified Successfully',
            latencyMs: result.latencyMs,
            details: result.details || [],
          },
        }));
      } else {
        setApiTests((prev) => ({
          ...prev,
          [provider]: {
            provider,
            status: 'error',
            message: result.error || 'Authentication Failed. Verify your API keys.',
            latencyMs: result.latencyMs,
          },
        }));
      }
    } catch (err: any) {
      setApiTests((prev) => ({
        ...prev,
        [provider]: {
          provider,
          status: 'error',
          message: `Network error reaching gateway verification server: ${err.message}`,
        },
      }));
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      brandName: brandName.trim(),
      brandShortName: brandShortName.trim(),
      brandTagline: brandTagline.trim(),
      brandLogoUrl: brandLogoUrl.trim(),
      brandLogoDarkUrl: brandLogoDarkUrl.trim(),
      faviconUrl: faviconUrl.trim(),
      pageTitleTemplate: pageTitleTemplate.trim(),
      metaDescription: metaDescription.trim(),
      legalBusinessName: legalBusinessName.trim(),
      businessAddressStreet: businessAddressStreet.trim(),
      businessAddressCity: businessAddressCity.trim(),
      businessAddressState: businessAddressState.trim(),
      businessAddressZip: businessAddressZip.trim(),
      businessAddressCountry: businessAddressCountry.trim(),
      businessPhone: businessPhone.trim(),
      supportEmail: supportEmail.trim(),
      ordersEmail: ordersEmail.trim(),
      pressEmail: pressEmail.trim(),
      businessHours: businessHours.trim(),
      instagramHandle: instagramHandle.trim(),
      instagramUrl: instagramUrl.trim(),
      twitterHandle: twitterHandle.trim(),
      twitterUrl: twitterUrl.trim(),
      tiktokHandle: tiktokHandle.trim(),
      tiktokUrl: tiktokUrl.trim(),
      youtubeUrl: youtubeUrl.trim(),
      spotifyUrl: spotifyUrl.trim(),
      substackUrl: substackUrl.trim(),
      pinterestUrl: pinterestUrl.trim(),
      facebookUrl: facebookUrl.trim(),
      linkedinUrl: linkedinUrl.trim(),
      discordUrl: discordUrl.trim(),
      currencySymbol: currencySymbol.trim(),
      currencyCode: currencyCode.trim(),
      salesTaxRatePercent: Number(salesTaxRatePercent) || 0,
      
      // Payment Gateways
      stripeEnabled,
      stripePublishableKey: stripePublishableKey.trim(),
      stripeSecretKey: stripeSecretKey.trim(),
      stripeWebhookSecret: stripeWebhookSecret.trim(),
      stripeStatementDescriptor: stripeStatementDescriptor.trim(),
      stripeLiveMode,
      paypalEnabled,
      paypalClientId: paypalClientId.trim(),
      paypalSecretKey: paypalSecretKey.trim(),
      paypalWebhookId: paypalWebhookId.trim(),
      paypalEnvironment,
      paypalPayIn4Enabled,
      applePayEnabled,
      applePayMerchantId: applePayMerchantId.trim(),
      applePayDomainName: applePayDomainName.trim(),
      applePayCertStatus,
      googlePayEnabled,
      googlePayMerchantId: googlePayMerchantId.trim(),
      googlePayGatewayMerchantId: googlePayGatewayMerchantId.trim(),
      googlePayEnvironment,
      klarnaEnabled,
      klarnaClientId: klarnaClientId.trim(),
      klarnaClientSecret: klarnaClientSecret.trim(),
      klarnaRegion: klarnaRegion.trim(),
      afterpayEnabled,
      afterpayMerchantId: afterpayMerchantId.trim(),
      afterpaySecretKey: afterpaySecretKey.trim(),
      afterpayRegion: afterpayRegion.trim(),
      cashAppPayEnabled,
      cashAppCashtag: cashAppCashtag.trim(),
      cashAppClientId: cashAppClientId.trim(),
      cashAppWebhookSecret: cashAppWebhookSecret.trim(),
      shopPayEnabled,
      shopPayStorefrontToken: shopPayStorefrontToken.trim(),
      shopPayDomain: shopPayDomain.trim(),
    });
    showToast('Brand, Business Profile & Payment Gateways saved successfully!');
  };

  const currentGatewayContent = {
    ...content,
    stripeEnabled,
    stripePublishableKey,
    stripeSecretKey,
    stripeWebhookSecret,
    stripeStatementDescriptor,
    stripeLiveMode,
    paypalEnabled,
    paypalClientId,
    paypalSecretKey,
    paypalWebhookId,
    paypalEnvironment,
    paypalPayIn4Enabled,
    applePayEnabled,
    applePayMerchantId,
    applePayDomainName,
    applePayCertStatus,
    googlePayEnabled,
    googlePayMerchantId,
    googlePayGatewayMerchantId,
    googlePayEnvironment,
    klarnaEnabled,
    klarnaClientId,
    klarnaClientSecret,
    klarnaRegion,
    afterpayEnabled,
    afterpayMerchantId,
    afterpaySecretKey,
    afterpayRegion,
    cashAppPayEnabled,
    cashAppCashtag,
    cashAppClientId,
    cashAppWebhookSecret,
    shopPayEnabled,
    shopPayStorefrontToken,
    shopPayDomain,
  };

  const connectedCount = [
    'stripe',
    'paypal',
    'apple_pay',
    'google_pay',
    'klarna',
    'afterpay',
    'cashapp',
    'shoppay',
  ].filter((p) => getPaymentConnectionStatus(p as any, currentGatewayContent).status === 'Connected').length;

  return (
    <form onSubmit={handleSave} className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-neutral-200 gap-4">
        <div>
          <h2 className="font-serif text-2xl text-neutral-900">Brand & Business Setup</h2>
          <p className="text-xs text-neutral-500 mt-1">
            Configure identity, studio premises, customer touchpoints, social handles, and fiscal currency settings.
          </p>
        </div>
        <Button type="submit" variant="primary" size="md">
          Save All Changes
        </Button>
      </div>

      {/* Sub-Tabs Bar */}
      <div className="flex border-b border-neutral-200 overflow-x-auto gap-1">
        <button
          type="button"
          onClick={() => setActiveSubTab('identity')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'identity'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>1. Identity & Logos</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('seo')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'seo'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>2. Page Titles & SEO</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('studio')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'studio'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <MapPin className="w-3.5 h-3.5" />
          <span>3. Studio & Entity</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('contacts')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'contacts'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Phone className="w-3.5 h-3.5" />
          <span>4. Contacts & Hours</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('socials')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'socials'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>5. Social Handles</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('fiscal')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'fiscal'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>6. Currency & Tax</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
        {/* SUBTAB 1: IDENTITY */}
        {activeSubTab === 'identity' && (
          <div className="space-y-6 pt-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                  Public Brand Name *
                </label>
                <input
                  type="text"
                  required
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                  Short Brand Name (for mobile & badges)
                </label>
                <input
                  type="text"
                  value={brandShortName}
                  onChange={(e) => setBrandShortName(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                Brand Tagline
              </label>
              <input
                type="text"
                value={brandTagline}
                onChange={(e) => setBrandTagline(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
              />
            </div>

            <div className="border-t border-neutral-100 pt-6 space-y-6">
              <h3 className="font-serif text-lg text-neutral-900">Brand Visual Assets (Upload & Compress)</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <ImageUploadCompressor
                  label="Light Theme Logo (Dark Vector/PNG for White Background)"
                  value={brandLogoUrl}
                  onChange={setBrandLogoUrl}
                  maxWidth={600}
                  maxHeight={600}
                  quality={0.9}
                  helperText="Recommended: transparent SVG or PNG, ~300x80px"
                />

                <ImageUploadCompressor
                  label="Dark Theme Logo (White Vector/PNG for Dark Footer)"
                  value={brandLogoDarkUrl}
                  onChange={setBrandLogoDarkUrl}
                  maxWidth={600}
                  maxHeight={600}
                  quality={0.9}
                  previewBg="dark"
                  helperText="Recommended: transparent white SVG or PNG"
                />
              </div>

              <div className="max-w-md">
                <ImageUploadCompressor
                  label="Browser Favicon (.ico, .png, .svg)"
                  value={faviconUrl}
                  onChange={setFaviconUrl}
                  maxWidth={128}
                  maxHeight={128}
                  quality={0.85}
                  helperText="Square 32x32px or 64x64px icon"
                />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 2: SEO */}
        {activeSubTab === 'seo' && (
          <div className="space-y-6 pt-2">
            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                Page Title Template *
              </label>
              <input
                type="text"
                required
                value={pageTitleTemplate}
                onChange={(e) => setPageTitleTemplate(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
              />
              <p className="text-[11px] text-neutral-500 mt-1">
                Updates document title on browser tabs and search engine snippets dynamically.
              </p>
            </div>

            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                Meta Description (Search Snippet)
              </label>
              <textarea
                rows={3}
                value={metaDescription}
                onChange={(e) => setMetaDescription(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
              />
            </div>
          </div>
        )}

        {/* SUBTAB 3: STUDIO & ENTITY */}
        {activeSubTab === 'studio' && (
          <div className="space-y-6 pt-2">
            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                Legal Entity Name (Invoices & Compliance) *
              </label>
              <input
                type="text"
                required
                value={legalBusinessName}
                onChange={(e) => setLegalBusinessName(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="sm:col-span-2">
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Street Address</label>
                <input
                  type="text"
                  value={businessAddressStreet}
                  onChange={(e) => setBusinessAddressStreet(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">City</label>
                <input
                  type="text"
                  value={businessAddressCity}
                  onChange={(e) => setBusinessAddressCity(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">State / Region</label>
                  <input
                    type="text"
                    value={businessAddressState}
                    onChange={(e) => setBusinessAddressState(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">ZIP Code</label>
                  <input
                    type="text"
                    value={businessAddressZip}
                    onChange={(e) => setBusinessAddressZip(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Country</label>
                <input
                  type="text"
                  value={businessAddressCountry}
                  onChange={(e) => setBusinessAddressCountry(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 4: CONTACTS & HOURS */}
        {activeSubTab === 'contacts' && (
          <div className="space-y-6 pt-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Direct Telephone Hotline</label>
                <input
                  type="text"
                  value={businessPhone}
                  onChange={(e) => setBusinessPhone(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Customer Support Email</label>
                <input
                  type="email"
                  value={supportEmail}
                  onChange={(e) => setSupportEmail(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Order Inquiries Email</label>
                <input
                  type="email"
                  value={ordersEmail}
                  onChange={(e) => setOrdersEmail(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Press & Partnerships Email</label>
                <input
                  type="email"
                  value={pressEmail}
                  onChange={(e) => setPressEmail(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Customer Care Operating Hours</label>
                <input
                  type="text"
                  value={businessHours}
                  onChange={(e) => setBusinessHours(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 5: SOCIAL HANDLES */}
        {activeSubTab === 'socials' && (
          <div className="space-y-6 pt-2">
            <p className="text-xs text-neutral-600 leading-relaxed">
              Fill in your active social profiles. Channels left blank will automatically stay hidden from public store view.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Instagram URL</label>
                <input
                  type="text"
                  value={instagramUrl}
                  onChange={(e) => setInstagramUrl(e.target.value)}
                  placeholder="https://instagram.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">X / Twitter URL</label>
                <input
                  type="text"
                  value={twitterUrl}
                  onChange={(e) => setTwitterUrl(e.target.value)}
                  placeholder="https://x.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Spotify Playlist URL</label>
                <input
                  type="text"
                  value={spotifyUrl}
                  onChange={(e) => setSpotifyUrl(e.target.value)}
                  placeholder="https://open.spotify.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Substack / Journal URL</label>
                <input
                  type="text"
                  value={substackUrl}
                  onChange={(e) => setSubstackUrl(e.target.value)}
                  placeholder="https://ezistential.substack.com"
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">TikTok URL</label>
                <input
                  type="text"
                  value={tiktokUrl}
                  onChange={(e) => setTiktokUrl(e.target.value)}
                  placeholder="https://tiktok.com/@..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">YouTube URL</label>
                <input
                  type="text"
                  value={youtubeUrl}
                  onChange={(e) => setYoutubeUrl(e.target.value)}
                  placeholder="https://youtube.com/@..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Pinterest URL</label>
                <input
                  type="text"
                  value={pinterestUrl}
                  onChange={(e) => setPinterestUrl(e.target.value)}
                  placeholder="https://pinterest.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Facebook URL</label>
                <input
                  type="text"
                  value={facebookUrl}
                  onChange={(e) => setFacebookUrl(e.target.value)}
                  placeholder="https://facebook.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">LinkedIn URL</label>
                <input
                  type="text"
                  value={linkedinUrl}
                  onChange={(e) => setLinkedinUrl(e.target.value)}
                  placeholder="https://linkedin.com/company/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Discord / Community URL</label>
                <input
                  type="text"
                  value={discordUrl}
                  onChange={(e) => setDiscordUrl(e.target.value)}
                  placeholder="https://discord.gg/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 6: FISCAL & CURRENCY */}
        {activeSubTab === 'fiscal' && (
          <div className="space-y-6 pt-2">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Currency Symbol</label>
                <input
                  type="text"
                  value={currencySymbol}
                  onChange={(e) => setCurrencySymbol(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">ISO Currency Code</label>
                <input
                  type="text"
                  value={currencyCode}
                  onChange={(e) => setCurrencyCode(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Estimated Sales Tax (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={salesTaxRatePercent}
                  onChange={(e) => setSalesTaxRatePercent(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* Payment Gateways have been moved to the dedicated Integration menu */}
        {false && (
          <div className="space-y-8 pt-2">
            {/* GLOBAL PAYMENT GATEWAYS HEALTH MATRIX */}
            <div className="bg-white border border-neutral-200 p-5 space-y-4 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-100 pb-3 gap-2">
                <div>
                  <h3 className="font-serif text-base font-bold text-neutral-900 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Live Gateway Connection Health Matrix</span>
                  </h3>
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Real-time connection status & cryptographic handshake validator across all payment networks.
                  </p>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span className="text-neutral-500">Live Status:</span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-[10px]">
                    {connectedCount} of 8 Networks Connected
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { id: 'stripe', name: 'Stripe Cards', icon: '💳' },
                  { id: 'paypal', name: 'PayPal & 4x', icon: '🅿️' },
                  { id: 'apple_pay', name: 'Apple Pay', icon: '' },
                  { id: 'google_pay', name: 'Google Pay', icon: 'G' },
                  { id: 'klarna', name: 'Klarna BNPL', icon: 'K' },
                  { id: 'afterpay', name: 'Afterpay', icon: '▲' },
                  { id: 'cashapp', name: 'Cash App', icon: '$' },
                  { id: 'shoppay', name: 'Shop Pay', icon: '🛍️' },
                ].map((gw) => (
                  <div key={gw.id} className="p-3 bg-neutral-50/80 border border-neutral-200 rounded-xs space-y-2 flex flex-col justify-between">
                    <div className="flex items-center justify-between">
                      <span className="font-serif text-xs font-semibold text-neutral-900 flex items-center gap-1.5">
                        <span>{gw.icon}</span>
                        <span>{gw.name}</span>
                      </span>
                    </div>
                    <div>
                      <PaymentStatusBadge provider={gw.id as any} content={currentGatewayContent} size="sm" showSublabel={false} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ======================================================== */}
            {/* 1. STRIPE CARD PROCESSING */}
            {/* ======================================================== */}
            <div className={`border p-6 space-y-5 transition-all ${stripeEnabled ? 'border-neutral-300 bg-white' : 'border-neutral-200 bg-neutral-50/70 opacity-75'}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-200 pb-4 gap-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center font-bold text-xs">
                    S
                  </div>
                  <div>
                    <h3 className="font-serif text-lg font-bold text-neutral-900">Stripe Payment Gateway</h3>
                    <p className="text-xs text-neutral-500">Credit/Debit cards (Visa, Mastercard, Amex, Discover, JCB)</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <PaymentStatusBadge provider="stripe" content={currentGatewayContent} size="md" />
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={stripeEnabled}
                      onChange={(e) => setStripeEnabled(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                    Stripe Publishable Key *
                  </label>
                  <input
                    type="text"
                    value={stripePublishableKey}
                    onChange={(e) => setStripePublishableKey(e.target.value)}
                    placeholder="pk_live_... or pk_test_..."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900"
                  />
                  <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">Client-side encryption token</span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs uppercase font-mono text-neutral-700 font-medium">
                      Stripe Secret API Key *
                    </label>
                    <button
                      type="button"
                      onClick={() => toggleSecret('stripeSecret')}
                      className="text-[11px] text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer font-mono"
                    >
                      {showSecrets['stripeSecret'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 text-neutral-600" />}
                      <span>{showSecrets['stripeSecret'] ? 'Hide' : 'Show'}</span>
                    </button>
                  </div>
                  <input
                    type={showSecrets['stripeSecret'] ? 'text' : 'password'}
                    value={stripeSecretKey}
                    onChange={(e) => setStripeSecretKey(e.target.value)}
                    placeholder="sk_live_... or sk_test_..."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900"
                  />
                  <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">Used by server proxy route for charge capture</span>
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                    Stripe Webhook Signing Secret
                  </label>
                  <input
                    type="text"
                    value={stripeWebhookSecret}
                    onChange={(e) => setStripeWebhookSecret(e.target.value)}
                    placeholder="whsec_..."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900"
                  />
                  <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">Endpoint: /api/webhooks/stripe</span>
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                    Statement Descriptor (Bank Invoice Line)
                  </label>
                  <input
                    type="text"
                    value={stripeStatementDescriptor}
                    onChange={(e) => setStripeStatementDescriptor(e.target.value)}
                    placeholder="EZISTENTIAL"
                    maxLength={22}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 uppercase"
                  />
                  <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">Max 22 chars shown on customer card statement</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-3 border-t border-neutral-100 gap-3">
                <label className="flex items-center space-x-2 text-xs font-mono cursor-pointer">
                  <input
                    type="checkbox"
                    checked={stripeLiveMode}
                    onChange={(e) => setStripeLiveMode(e.target.checked)}
                    className="rounded-xs border-neutral-300 text-black focus:ring-black"
                  />
                  <span className="font-semibold text-neutral-900">Enable Live Production Mode</span>
                  <span className={`text-[10px] px-1.5 py-0.5 border font-bold ${stripeLiveMode ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-amber-100 text-amber-800 border-amber-300'}`}>
                    {stripeLiveMode ? 'REAL MONEY CHARGES' : 'TEST SANDBOX'}
                  </span>
                </label>

                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleTestApi('stripe')}
                  disabled={apiTests['stripe']?.status === 'testing'}
                  className="flex items-center gap-1.5"
                >
                  <Activity className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{apiTests['stripe']?.status === 'testing' ? 'Testing Connection...' : 'Test Stripe API Connection'}</span>
                </Button>
              </div>

              {/* Live Test Status Feedback */}
              {apiTests['stripe'] && (
                <div className={`p-4 border text-xs font-mono space-y-2 animate-in fade-in duration-200 ${apiTests['stripe'].status === 'success' ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : apiTests['stripe'].status === 'error' ? 'bg-red-50 border-red-300 text-red-900' : 'bg-neutral-50 border-neutral-300 text-neutral-700'}`}>
                  <div className="flex items-center justify-between font-bold">
                    <span className="flex items-center gap-1.5">
                      {apiTests['stripe'].status === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-red-600" />}
                      <span>{apiTests['stripe'].message}</span>
                    </span>
                    {apiTests['stripe'].latencyMs && <span className="text-[10px] text-neutral-500">{apiTests['stripe'].latencyMs}ms latency</span>}
                  </div>
                  {apiTests['stripe'].details && (
                    <ul className="list-disc list-inside text-[11px] text-neutral-600 space-y-0.5 pt-1">
                      {apiTests['stripe'].details?.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>

            {/* ======================================================== */}
            {/* 2. PAYPAL & PAY IN 4 */}
            {/* ======================================================== */}
            <div className={`border p-6 space-y-5 transition-all ${paypalEnabled ? 'border-neutral-300 bg-white' : 'border-neutral-200 bg-neutral-50/70 opacity-75'}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-200 pb-4 gap-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-[#003087] text-white flex items-center justify-center font-bold text-xs italic">
                    PP
                  </div>
                  <div>
                    <h3 className="font-serif text-lg font-bold text-neutral-900">PayPal & PayPal Pay in 4</h3>
                    <p className="text-xs text-neutral-500">Standard PayPal account checkout and 4x interest-free installments</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <PaymentStatusBadge provider="paypal" content={currentGatewayContent} size="md" />
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={paypalEnabled}
                      onChange={(e) => setPaypalEnabled(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#003087]"></div>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                    PayPal Client ID *
                  </label>
                  <input
                    type="text"
                    value={paypalClientId}
                    onChange={(e) => setPaypalClientId(e.target.value)}
                    placeholder="sb_client_id_... or live client id"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs uppercase font-mono text-neutral-700 font-medium">
                      PayPal Client Secret *
                    </label>
                    <button
                      type="button"
                      onClick={() => toggleSecret('paypalSecret')}
                      className="text-[11px] text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer font-mono"
                    >
                      {showSecrets['paypalSecret'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      <span>{showSecrets['paypalSecret'] ? 'Hide' : 'Show'}</span>
                    </button>
                  </div>
                  <input
                    type={showSecrets['paypalSecret'] ? 'text' : 'password'}
                    value={paypalSecretKey}
                    onChange={(e) => setPaypalSecretKey(e.target.value)}
                    placeholder="PayPal secret key"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                    Environment
                  </label>
                  <select
                    value={paypalEnvironment}
                    onChange={(e) => setPaypalEnvironment(e.target.value as any)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 cursor-pointer"
                  >
                    <option value="sandbox">Sandbox (Testing Environment)</option>
                    <option value="production">Production (Live Processing)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                    PayPal Webhook ID
                  </label>
                  <input
                    type="text"
                    value={paypalWebhookId}
                    onChange={(e) => setPaypalWebhookId(e.target.value)}
                    placeholder="WH-..."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900"
                  />
                </div>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-3 border-t border-neutral-100 gap-3">
                <label className="flex items-center space-x-2 text-xs font-mono cursor-pointer">
                  <input
                    type="checkbox"
                    checked={paypalPayIn4Enabled}
                    onChange={(e) => setPaypalPayIn4Enabled(e.target.checked)}
                    className="rounded-xs border-neutral-300 text-black focus:ring-black"
                  />
                  <span>Enable PayPal "Pay in 4" Interest-Free Installment Option</span>
                </label>

                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleTestApi('paypal')}
                  disabled={apiTests['paypal']?.status === 'testing'}
                  className="flex items-center gap-1.5"
                >
                  <Activity className="w-3.5 h-3.5 text-blue-600" />
                  <span>{apiTests['paypal']?.status === 'testing' ? 'Testing...' : 'Test PayPal API Connection'}</span>
                </Button>
              </div>

              {apiTests['paypal'] && (
                <div className="p-4 border text-xs font-mono space-y-2 bg-blue-50 border-blue-300 text-blue-900 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between font-bold">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-blue-600" />
                      <span>{apiTests['paypal'].message}</span>
                    </span>
                    {apiTests['paypal'].latencyMs && <span className="text-[10px] text-neutral-500">{apiTests['paypal'].latencyMs}ms latency</span>}
                  </div>
                  {apiTests['paypal'].details && (
                    <ul className="list-disc list-inside text-[11px] text-neutral-700 space-y-0.5 pt-1">
                      {apiTests['paypal'].details?.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>

            {/* ======================================================== */}
            {/* 3. APPLE PAY & GOOGLE PAY EXPRESS */}
            {/* ======================================================== */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Apple Pay */}
              <div className={`border p-6 space-y-5 transition-all ${applePayEnabled ? 'border-neutral-300 bg-white' : 'border-neutral-200 bg-neutral-50/70 opacity-75'}`}>
                <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
                  <div>
                    <h3 className="font-serif text-base font-bold text-neutral-900"> Apple Pay Express</h3>
                    <p className="text-[11px] text-neutral-500">Biometric Face ID & Touch ID on Safari / iOS</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <PaymentStatusBadge provider="apple_pay" content={currentGatewayContent} size="sm" />
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={applePayEnabled}
                        onChange={(e) => setApplePayEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-black after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
                    </label>
                  </div>
                </div>

                <div className="space-y-4 text-xs font-mono">
                  <div>
                    <label className="block text-neutral-700 mb-1">Apple Merchant ID</label>
                    <input
                      type="text"
                      value={applePayMerchantId}
                      onChange={(e) => setApplePayMerchantId(e.target.value)}
                      placeholder="merchant.com.ezistential.store"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono text-neutral-900"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-700 mb-1">Verified Domain</label>
                    <input
                      type="text"
                      value={applePayDomainName}
                      onChange={(e) => setApplePayDomainName(e.target.value)}
                      placeholder="ezistential.com"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono text-neutral-900"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-100">
                  <span className="text-[11px] font-mono text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Domain Association Active</span>
                  </span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTestApi('apple_pay')}
                  >
                    Test Apple Pay
                  </Button>
                </div>

                {apiTests['apple_pay'] && (
                  <div className="p-3 bg-neutral-900 text-white text-xs font-mono space-y-1">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{apiTests['apple_pay'].message}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Google Pay */}
              <div className={`border p-6 space-y-5 transition-all ${googlePayEnabled ? 'border-neutral-300 bg-white' : 'border-neutral-200 bg-neutral-50/70 opacity-75'}`}>
                <div className="flex items-center justify-between border-b border-neutral-200 pb-3 gap-2">
                  <div>
                    <h3 className="font-mono text-base font-bold text-neutral-900">G Pay Google Wallet</h3>
                    <p className="text-[11px] text-neutral-500">1-click tokenized checkout across Chrome / Android</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <PaymentStatusBadge provider="google_pay" content={currentGatewayContent} size="sm" />
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={googlePayEnabled}
                        onChange={(e) => setGooglePayEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-black after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
                    </label>
                  </div>
                </div>

                <div className="space-y-4 text-xs font-mono">
                  <div>
                    <label className="block text-neutral-700 mb-1">Google Merchant ID</label>
                    <input
                      type="text"
                      value={googlePayMerchantId}
                      onChange={(e) => setGooglePayMerchantId(e.target.value)}
                      placeholder="BCR2DN4TX..."
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono text-neutral-900"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-700 mb-1">Environment Mode</label>
                    <select
                      value={googlePayEnvironment}
                      onChange={(e) => setGooglePayEnvironment(e.target.value as any)}
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono cursor-pointer"
                    >
                      <option value="TEST">TEST (Sandbox Simulator)</option>
                      <option value="PRODUCTION">PRODUCTION (Live Cards)</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-100">
                  <span className="text-[11px] font-mono text-neutral-500">Gateway Tokenizer linked</span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTestApi('google_pay')}
                  >
                    Test Google Pay
                  </Button>
                </div>

                {apiTests['google_pay'] && (
                  <div className="p-3 bg-neutral-100 border border-neutral-300 text-neutral-900 text-xs font-mono space-y-1">
                    <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{apiTests['google_pay'].message}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* ======================================================== */}
            {/* 4. BNPL (KLARNA & AFTERPAY) & CASH APP & SHOP PAY */}
            {/* ======================================================== */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Klarna */}
              <div className={`border p-5 space-y-4 ${klarnaEnabled ? 'border-neutral-300 bg-white' : 'border-neutral-200 bg-neutral-50/70 opacity-75'}`}>
                <div className="flex items-center justify-between border-b border-neutral-100 pb-3 gap-2">
                  <div>
                    <span className="font-sans font-bold text-sm block text-neutral-900">Klarna. Pay in 4</span>
                    <span className="text-[10px] text-neutral-500">BNPL Installments</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <PaymentStatusBadge provider="klarna" content={currentGatewayContent} size="sm" showSublabel={false} />
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={klarnaEnabled}
                        onChange={(e) => setKlarnaEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-8 h-4 bg-neutral-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-black after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all"></div>
                    </label>
                  </div>
                </div>

                <div className="space-y-3 text-xs font-mono">
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">Klarna API Username / Client ID</label>
                    <input
                      type="text"
                      value={klarnaClientId}
                      onChange={(e) => setKlarnaClientId(e.target.value)}
                      placeholder="K882104-..."
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">Klarna Client Secret</label>
                    <input
                      type="password"
                      value={klarnaClientSecret}
                      onChange={(e) => setKlarnaClientSecret(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2 border-t border-neutral-100">
                  <button
                    type="button"
                    onClick={() => handleTestApi('klarna')}
                    className="text-xs font-mono text-neutral-700 hover:text-black underline cursor-pointer"
                  >
                    Test Klarna
                  </button>
                </div>
              </div>

              {/* Afterpay */}
              <div className={`border p-5 space-y-4 ${afterpayEnabled ? 'border-neutral-300 bg-white' : 'border-neutral-200 bg-neutral-50/70 opacity-75'}`}>
                <div className="flex items-center justify-between border-b border-neutral-100 pb-3 gap-2">
                  <div>
                    <span className="font-mono font-bold text-sm block text-neutral-900">Afterpay / Clearpay</span>
                    <span className="text-[10px] text-neutral-500">4-Pay Gateway</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <PaymentStatusBadge provider="afterpay" content={currentGatewayContent} size="sm" showSublabel={false} />
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={afterpayEnabled}
                        onChange={(e) => setAfterpayEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-8 h-4 bg-neutral-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-black after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all"></div>
                    </label>
                  </div>
                </div>

                <div className="space-y-3 text-xs font-mono">
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">Afterpay Merchant ID</label>
                    <input
                      type="text"
                      value={afterpayMerchantId}
                      onChange={(e) => setAfterpayMerchantId(e.target.value)}
                      placeholder="80042109"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">Afterpay Secret Key</label>
                    <input
                      type="password"
                      value={afterpaySecretKey}
                      onChange={(e) => setAfterpaySecretKey(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2 border-t border-neutral-100">
                  <button
                    type="button"
                    onClick={() => handleTestApi('afterpay')}
                    className="text-xs font-mono text-neutral-700 hover:text-black underline cursor-pointer"
                  >
                    Test Afterpay
                  </button>
                </div>
              </div>

              {/* Cash App */}
              <div className={`border p-5 space-y-4 ${cashAppPayEnabled ? 'border-neutral-300 bg-white' : 'border-neutral-200 bg-neutral-50/70 opacity-75'}`}>
                <div className="flex items-center justify-between border-b border-neutral-100 pb-3 gap-2">
                  <div>
                    <span className="font-mono font-bold text-sm text-[#00A827] block">$ Cash App Pay</span>
                    <span className="text-[10px] text-neutral-500">QR / Cashtag Direct</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <PaymentStatusBadge provider="cashapp" content={currentGatewayContent} size="sm" showSublabel={false} />
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={cashAppPayEnabled}
                        onChange={(e) => setCashAppPayEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-8 h-4 bg-neutral-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-[#00D632] after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all"></div>
                    </label>
                  </div>
                </div>

                <div className="space-y-3 text-xs font-mono">
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">Business Cashtag ($handle)</label>
                    <input
                      type="text"
                      value={cashAppCashtag}
                      onChange={(e) => setCashAppCashtag(e.target.value)}
                      placeholder="$EzistentialStudio"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">Square / Cash App Client ID</label>
                    <input
                      type="text"
                      value={cashAppClientId}
                      onChange={(e) => setCashAppClientId(e.target.value)}
                      placeholder="sq0idp-..."
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2 border-t border-neutral-100">
                  <button
                    type="button"
                    onClick={() => handleTestApi('cashapp')}
                    className="text-xs font-mono text-neutral-700 hover:text-black underline cursor-pointer"
                  >
                    Test Cash App
                  </button>
                </div>
              </div>

              {/* Shop Pay */}
              <div className={`border p-5 space-y-4 ${shopPayEnabled ? 'border-neutral-300 bg-white' : 'border-neutral-200 bg-neutral-50/70 opacity-75'}`}>
                <div className="flex items-center justify-between border-b border-neutral-100 pb-3 gap-2">
                  <div>
                    <span className="font-sans font-bold text-sm text-[#5A31F4] block">Shop Pay 1-Click</span>
                    <span className="text-[10px] text-neutral-500">Accelerated Checkout</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <PaymentStatusBadge provider="shoppay" content={currentGatewayContent} size="sm" showSublabel={false} />
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={shopPayEnabled}
                        onChange={(e) => setShopPayEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-8 h-4 bg-neutral-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-[#5A31F4] after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all"></div>
                    </label>
                  </div>
                </div>

                <div className="space-y-3 text-xs font-mono">
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">Shop Domain</label>
                    <input
                      type="text"
                      value={shopPayDomain}
                      onChange={(e) => setShopPayDomain(e.target.value)}
                      placeholder="shop.ezistential.com"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">Storefront Token</label>
                    <input
                      type="password"
                      value={shopPayStorefrontToken}
                      onChange={(e) => setShopPayStorefrontToken(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2 border-t border-neutral-100">
                  <button
                    type="button"
                    onClick={() => handleTestApi('shoppay')}
                    className="text-xs font-mono text-neutral-700 hover:text-black underline cursor-pointer"
                  >
                    Test Shop Pay
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="pt-4 border-t border-neutral-100 flex justify-end">
          <Button type="submit" variant="primary" size="md">
            Save Brand & Business Profile Changes
          </Button>
        </div>
      </div>
    </form>
  );
};
