import React, { useState } from 'react';
import {
  ShieldCheck,
  Check,
  X,
  UserCheck,
  UserX,
  ShoppingBag,
  MessageSquare,
  Camera,
  MapPin,
  SlidersHorizontal,
  Info,
  Search,
  CheckCircle2,
  AlertCircle,
  Users,
  Download,
  Calendar,
  Package
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { MemberVerificationRules, UserProfile, Order, CustomerResponse } from '../../types';
import { DEFAULT_VERIFICATION_RULES, evaluateMemberVerification } from '../../lib/verification';

export interface UserVerificationCMSProps {
  contentRules?: MemberVerificationRules;
  onUpdateRules: (rules: MemberVerificationRules) => void;
  orders: Order[];
  responses: CustomerResponse[];
  currentUser: UserProfile | null;
  showToast: (msg: string) => void;
}

export const UserVerificationCMS: React.FC<UserVerificationCMSProps> = ({
  contentRules,
  onUpdateRules,
  orders,
  responses,
  currentUser,
  showToast,
}) => {
  const [activeTab, setActiveTab] = useState<'verification_engine' | 'member_directory' | 'customer_account_pool'>('verification_engine');
  const [rules, setRules] = useState<MemberVerificationRules>(
    contentRules || DEFAULT_VERIFICATION_RULES
  );

  // Initial registered users list combined with current logged-in user
  const [usersList, setUsersList] = useState<UserProfile[]>(() => {
    const defaultList: UserProfile[] = [
      {
        id: 'usr-001',
        email: 'marcus.v@example.com',
        fullName: 'Marcus Vance',
        location: 'Chicago, IL',
        role: 'customer',
        createdAt: '2026-01-15T10:00:00Z',
        updatedAt: '2026-02-10T14:32:00Z',
        addresses: [],
        savedGarments: [],
        isVerifiedManualOverride: true,
        verifiedAt: '2026-02-10T14:32:00Z',
        verificationNotes: 'Manually verified long-time Chicago customer',
        communicationPreferences: { orderUpdatesEmail: true, reflectionDigestsEmail: true, curatedEssaysEmail: true },
      },
      {
        id: 'usr-002',
        email: 'elena.r@example.com',
        fullName: 'Elena Rostova',
        location: 'Austin, TX',
        role: 'customer',
        createdAt: '2026-02-01T11:20:00Z',
        updatedAt: '2026-02-14T09:15:00Z',
        addresses: [],
        savedGarments: [],
        isVerifiedManualOverride: false,
        communicationPreferences: { orderUpdatesEmail: true, reflectionDigestsEmail: false, curatedEssaysEmail: true },
      },
      {
        id: 'usr-003',
        email: 'david.k@example.com',
        fullName: 'David Kim',
        location: 'Philadelphia, PA',
        role: 'customer',
        createdAt: '2026-02-05T08:12:00Z',
        updatedAt: '2026-02-22T18:40:00Z',
        addresses: [],
        savedGarments: [],
        isVerifiedManualOverride: false,
        communicationPreferences: { orderUpdatesEmail: true, reflectionDigestsEmail: true, curatedEssaysEmail: false },
      },
    ];

    if (currentUser && !defaultList.some((u) => u.email.toLowerCase() === currentUser.email.toLowerCase())) {
      defaultList.unshift(currentUser);
    }
    return defaultList;
  });

  const [searchQuery, setSearchQuery] = useState('');

  // Handle rule toggles
  const handleToggleRule = (key: keyof MemberVerificationRules) => {
    const updated = { ...rules, [key]: !rules[key] };
    setRules(updated);
    onUpdateRules(updated);
    showToast('Verification rules updated successfully');
  };

  const handleNumberRuleChange = (key: keyof MemberVerificationRules, val: number) => {
    const updated = { ...rules, [key]: val };
    setRules(updated);
    onUpdateRules(updated);
    showToast('Verification threshold updated');
  };

  // Toggle individual user manual verification
  const handleToggleUserVerification = (userId: string) => {
    setUsersList((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const nextVal = !u.isVerifiedManualOverride;
          return {
            ...u,
            isVerifiedManualOverride: nextVal,
            verifiedAt: nextVal ? new Date().toISOString() : undefined,
          };
        }
        return u;
      })
    );
    showToast('User verification override updated');
  };

  const filteredUsers = usersList.filter(
    (u) =>
      u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.location?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-[#121212] text-white p-6 sm:p-8 border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md">
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <span className="text-[10px] uppercase font-mono tracking-widest text-amber-300 bg-neutral-900 px-2 py-0.5 border border-neutral-800 font-bold">
              Customer Directory
            </span>
            <span className="text-[10px] font-mono text-neutral-400">• Core Operations</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl text-white tracking-tight">
            Customers & Member Verification
          </h2>
          <p className="text-xs text-neutral-400 max-w-xl leading-relaxed">
            Manage customer accounts, automated verification rules, saved garments, and verified wearer status.
          </p>
        </div>

        <div className="bg-neutral-900 border border-neutral-800 p-4 text-xs space-y-1 font-mono text-neutral-300 shrink-0">
          <p className="text-white font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{usersList.length} Accounts Registered</span>
          </p>
          <p className="text-[11px] text-neutral-400">
            {rules.requirePurchase ? 'Order Required' : 'No Order Required'} • {rules.requireReflection ? 'Reflection Required' : 'No Reflection Required'}
          </p>
        </div>
      </div>

      {/* 3 Explicit Navigation Tabs */}
      <div className="flex border-b border-neutral-200 bg-white p-2 space-x-2 shadow-2xs overflow-x-auto">
        <button
          onClick={() => setActiveTab('verification_engine')}
          className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center space-x-2 shrink-0 ${
            activeTab === 'verification_engine'
              ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
              : 'bg-[#fbfbf9] text-neutral-600 hover:text-black border-neutral-200'
          }`}
        >
          <ShieldCheck className={`w-4 h-4 ${activeTab === 'verification_engine' ? 'text-amber-300' : 'text-neutral-500'}`} />
          <span>1. Verification Rules</span>
        </button>

        <button
          onClick={() => setActiveTab('member_directory')}
          className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center space-x-2 shrink-0 ${
            activeTab === 'member_directory'
              ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
              : 'bg-[#fbfbf9] text-neutral-600 hover:text-black border-neutral-200'
          }`}
        >
          <UserCheck className={`w-4 h-4 ${activeTab === 'member_directory' ? 'text-amber-300' : 'text-neutral-500'}`} />
          <span>2. Customer Directory & Overrides</span>
        </button>

        <button
          onClick={() => setActiveTab('customer_account_pool')}
          className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center space-x-2 shrink-0 ${
            activeTab === 'customer_account_pool'
              ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
              : 'bg-[#fbfbf9] text-neutral-600 hover:text-black border-neutral-200'
          }`}
        >
          <ShoppingBag className={`w-4 h-4 ${activeTab === 'customer_account_pool' ? 'text-amber-300' : 'text-neutral-500'}`} />
          <span>3. Saved Garments & Activity</span>
        </button>
      </div>

      {/* TAB 1: MEMBER VERIFICATION ENGINE */}
      {activeTab === 'verification_engine' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs animate-in fade-in duration-150">
          <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-neutral-900">1. Member Verification Engine Rules</h3>
              <p className="text-xs text-neutral-500 font-sans mt-0.5">
                Set global criteria determining who unlocks the "Verified Wearer & Member" badge across the store.
              </p>
            </div>
            <Button
              onClick={() => {
                setRules(DEFAULT_VERIFICATION_RULES);
                onUpdateRules(DEFAULT_VERIFICATION_RULES);
                showToast('Reset to default verification rules');
              }}
              variant="outline"
              size="sm"
              className="text-xs font-mono"
            >
              Reset Defaults
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Rule 1: Product Purchase */}
            <div className="border border-neutral-200 p-5 bg-[#fcfcfb] space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 bg-neutral-100 border border-neutral-200">
                    <ShoppingBag className="w-4 h-4 text-neutral-800" />
                  </div>
                  <div>
                    <h4 className="font-serif text-sm font-bold text-neutral-900">Require Garment Purchase</h4>
                    <p className="text-[11px] text-neutral-500 font-mono">Full order checkout loop</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={rules.requirePurchase}
                  onChange={() => handleToggleRule('requirePurchase')}
                  className="w-4 h-4 accent-black cursor-pointer mt-1"
                />
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                User must complete at least 1 paid POD order to fulfill this criterion.
              </p>
              {rules.requirePurchase && (
                <div className="pt-2 border-t border-neutral-200 flex items-center justify-between text-xs">
                  <span className="text-neutral-500 font-mono">Min Orders Required:</span>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={rules.minPurchasesCount}
                    onChange={(e) => handleNumberRuleChange('minPurchasesCount', Number(e.target.value))}
                    className="w-16 bg-white border border-neutral-300 px-2 py-1 text-center font-mono text-xs"
                  />
                </div>
              )}
            </div>

            {/* Rule 2: Reflection Submission */}
            <div className="border border-neutral-200 p-5 bg-[#fcfcfb] space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 bg-neutral-100 border border-neutral-200">
                    <MessageSquare className="w-4 h-4 text-neutral-800" />
                  </div>
                  <div>
                    <h4 className="font-serif text-sm font-bold text-neutral-900">Require Field Reflection</h4>
                    <p className="text-[11px] text-neutral-500 font-mono">Connection Archive entry</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={rules.requireReflection}
                  onChange={() => handleToggleRule('requireReflection')}
                  className="w-4 h-4 accent-black cursor-pointer mt-1"
                />
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                User must contribute at least 1 reflection observation to the Connection Archive.
              </p>
            </div>

            {/* Rule 3: Profile Location */}
            <div className="border border-neutral-200 p-5 bg-[#fcfcfb] space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 bg-neutral-100 border border-neutral-200">
                    <MapPin className="w-4 h-4 text-neutral-800" />
                  </div>
                  <div>
                    <h4 className="font-serif text-sm font-bold text-neutral-900">Require City Location</h4>
                    <p className="text-[11px] text-neutral-500 font-mono">Archive attribution tag</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={rules.requireProfileLocation}
                  onChange={() => handleToggleRule('requireProfileLocation')}
                  className="w-4 h-4 accent-black cursor-pointer mt-1"
                />
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                User profile must specify their City/State for public archive attribution.
              </p>
            </div>

            {/* Rule 4: Manual Override */}
            <div className="border border-neutral-200 p-5 bg-[#fcfcfb] space-y-4 col-span-1 md:col-span-2 lg:col-span-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 bg-neutral-100 border border-neutral-200">
                    <UserCheck className="w-4 h-4 text-neutral-800" />
                  </div>
                  <div>
                    <h4 className="font-serif text-sm font-bold text-neutral-900">Allow Curator Manual Override</h4>
                    <p className="text-[11px] text-neutral-500 font-mono">Admin grant or revocation override</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={rules.allowManualOverride}
                  onChange={() => handleToggleRule('allowManualOverride')}
                  className="w-4 h-4 accent-black cursor-pointer mt-1"
                />
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Allows studio admins to manually grant or revoke Verified Member status for VIP wearers, press, or early supporters regardless of automated criteria.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MEMBER DIRECTORY & OVERRIDES */}
      {activeTab === 'member_directory' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-neutral-900">2. Member Directory & Manual Overrides</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Evaluate member verification criteria in real time and toggle manual verification overrides.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search member name or email..."
                className="w-full bg-[#fbfbf9] border border-neutral-300 pl-8 pr-3 py-2 text-xs focus:border-black focus:outline-hidden"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-neutral-200 text-[10px] font-mono uppercase tracking-wider text-neutral-500 bg-[#f5f4f0]">
                  <th className="py-3 px-4">Member Name & Email</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4 text-center">Orders Placed</th>
                  <th className="py-3 px-4 text-center">Reflections</th>
                  <th className="py-3 px-4 text-center">Auto Evaluated Status</th>
                  <th className="py-3 px-4 text-center">Manual Override</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200 text-xs font-sans">
                {filteredUsers.map((u) => {
                  const userOrders = orders.filter((o) => o.customerEmail.toLowerCase() === u.email.toLowerCase());
                  const userReflections = responses.filter((r) => r.email?.toLowerCase() === u.email.toLowerCase());
                  const evalResult = evaluateMemberVerification(u, userOrders, userReflections, rules);

                  return (
                    <tr key={u.id} className="hover:bg-neutral-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-medium text-neutral-900">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-full bg-neutral-900 text-white font-serif text-xs flex items-center justify-center shrink-0">
                            {u.fullName.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-bold text-neutral-900">{u.fullName}</p>
                            <p className="text-[11px] font-mono text-neutral-500">{u.email}</p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-neutral-600 font-mono text-[11px]">
                        {u.location || <span className="text-neutral-400 font-sans italic">Not Set</span>}
                      </td>

                      <td className="py-3.5 px-4 text-center font-mono font-medium">
                        <span className={userOrders.length > 0 ? 'text-black font-bold' : 'text-neutral-400'}>
                          {userOrders.length} Order{userOrders.length === 1 ? '' : 's'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center font-mono font-medium">
                        <span className={userReflections.length > 0 ? 'text-black font-bold' : 'text-neutral-400'}>
                          {userReflections.length}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        {evalResult.isVerified ? (
                          <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-mono uppercase tracking-wider font-bold">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Verified ({evalResult.percentage}%)</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-mono uppercase tracking-wider">
                            <AlertCircle className="w-3 h-3 text-amber-600" />
                            <span>In Progress ({evalResult.percentage}%)</span>
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        {u.isVerifiedManualOverride ? (
                          <span className="text-[10px] font-mono uppercase text-emerald-700 bg-emerald-100 px-2 py-0.5 border border-emerald-300">
                            Manual Verified
                          </span>
                        ) : (
                          <span className="text-[10px] font-mono text-neutral-400">Rules Auto</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => handleToggleUserVerification(u.id)}
                          className={`text-xs font-mono uppercase tracking-wider px-3 py-1 border transition-colors cursor-pointer ${
                            u.isVerifiedManualOverride
                              ? 'bg-neutral-100 hover:bg-neutral-200 text-neutral-800 border-neutral-300'
                              : 'bg-black hover:bg-neutral-800 text-white border-black'
                          }`}
                        >
                          {u.isVerifiedManualOverride ? 'Revoke Override' : 'Verify Member'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: CUSTOMER ACCOUNT POOL CONTENT */}
      {activeTab === 'customer_account_pool' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-neutral-900">3. Customer Account Pool Content & Activity</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Full historical log of registered account profiles, fulfillment statistics, and data exports.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredUsers.map((u) => {
              const uOrders = orders.filter((o) => o.customerEmail.toLowerCase() === u.email.toLowerCase());
              const uReflections = responses.filter((r) => r.email?.toLowerCase() === u.email.toLowerCase());

              return (
                <div key={u.id} className="border border-neutral-200 p-5 bg-[#fcfcfb] space-y-4">
                  <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-9 h-9 rounded-full bg-black text-white font-serif text-xs flex items-center justify-center shrink-0">
                        {u.fullName.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h4 className="font-serif text-sm font-bold text-neutral-900">{u.fullName}</h4>
                        <p className="text-[11px] font-mono text-neutral-500">{u.email}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono uppercase bg-neutral-100 px-2 py-0.5 border border-neutral-300">
                      {u.role}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs font-mono">
                    <div className="flex justify-between text-neutral-600">
                      <span>Location Tag:</span>
                      <span className="text-black font-semibold">{u.location || 'Not Specified'}</span>
                    </div>
                    <div className="flex justify-between text-neutral-600">
                      <span>Total POD Orders:</span>
                      <span className="text-black font-semibold">{uOrders.length}</span>
                    </div>
                    <div className="flex justify-between text-neutral-600">
                      <span>Reflections Submitted:</span>
                      <span className="text-black font-semibold">{uReflections.length}</span>
                    </div>
                    <div className="flex justify-between text-neutral-600">
                      <span>Account Created:</span>
                      <span className="text-neutral-500">{new Date(u.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-neutral-200 flex justify-between items-center text-xs">
                    <span className={`px-2 py-0.5 font-mono text-[10px] uppercase border ${
                      u.isVerifiedManualOverride ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : 'bg-neutral-100 text-neutral-600 border-neutral-200'
                    }`}>
                      {u.isVerifiedManualOverride ? 'Verified Member' : 'Standard Member'}
                    </span>
                    <button
                      type="button"
                      onClick={() => showToast(`Exported user profile data for ${u.fullName}`)}
                      className="text-[11px] font-mono text-black hover:underline cursor-pointer"
                    >
                      Export Profile →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
