import React, { useState } from 'react';
import {
  Palette,
  CheckCircle2,
  Eye,
  Check,
  Zap,
  Layers,
  ArrowRight,
  Layout,
  Type,
  Maximize2
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { ShapeDividerVariant } from '../../types';
import { Button } from '../ui/Button';
import { ShapeDivider } from '../ui/ShapeDivider';

export interface ThemePreset {
  id: string;
  name: string;
  subtitle: string;
  primaryColor: string;
  fontStyle: 'serif-editorial' | 'sans-modern' | 'mono-stark';
  bgPreview: string;
  borderPreview: string;
  active: boolean;
}

export const THEME_PRESETS: ThemePreset[] = [
  {
    id: 'editorial-noir',
    name: 'Theme 1: Editorial Noir',
    subtitle: 'High-Contrast Monochrome & Serif Typography (Current Studio Default)',
    primaryColor: '#0a0a0a',
    fontStyle: 'serif-editorial',
    bgPreview: 'bg-black text-white',
    borderPreview: 'border-black',
    active: true,
  },
  {
    id: 'warm-parchment',
    name: 'Theme 2: Warm Parchment',
    subtitle: 'Earthy Studio Tones, Soft Beige Canvas & Editorial Serifs',
    primaryColor: '#2d2b2a',
    fontStyle: 'serif-editorial',
    bgPreview: 'bg-[#f7f5f0] text-[#1c1a18]',
    borderPreview: 'border-[#3d3835]',
    active: false,
  },
  {
    id: 'raw-canvas',
    name: 'Theme 3: Raw Canvas',
    subtitle: 'Industrial Slate, Unbleached Textiles & Stark Spatial Grid',
    primaryColor: '#1a1f2c',
    fontStyle: 'sans-modern',
    bgPreview: 'bg-[#eef1f5] text-[#0f172a]',
    borderPreview: 'border-[#1e293b]',
    active: false,
  },
  {
    id: 'cyber-minimalist',
    name: 'Theme 4: Cyber Minimalist',
    subtitle: 'Deep Obsidian Matte, Monospace Accents & High-Tech Directives',
    primaryColor: '#121212',
    fontStyle: 'mono-stark',
    bgPreview: 'bg-[#050505] text-[#e2e8f0]',
    borderPreview: 'border-neutral-700',
    active: false,
  },
];

export const DesignSetup: React.FC = () => {
  const { content, updateContent } = useContent();
  const [activeTab, setActiveTab] = useState<'theme' | 'divider'>('theme');
  const [toast, setToast] = useState<string | null>(null);

  // Theme States
  const [selectedThemeId, setSelectedThemeId] = useState<string>(content.selectedThemeId || 'editorial-noir');
  const [primaryThemeColor, setPrimaryThemeColor] = useState(content.primaryThemeColor || '#0a0a0a');
  const [enableImageZoom, setEnableImageZoom] = useState(content.enableImageZoom !== false);

  // Shape Divider States
  const [shapeDividerEnabled, setShapeDividerEnabled] = useState(content.shapeDividerEnabled !== false);
  const [shapeDividerVariant, setShapeDividerVariant] = useState<ShapeDividerVariant>(
    content.shapeDividerVariant || 'editorial-notch'
  );
  const [shapeDividerHeight, setShapeDividerHeight] = useState<number>(content.shapeDividerHeight || 64);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleApplyPreset = (preset: ThemePreset) => {
    setSelectedThemeId(preset.id);
    setPrimaryThemeColor(preset.primaryColor);
    updateContent({
      selectedThemeId: preset.id,
      primaryThemeColor: preset.primaryColor,
    });
    showToast(`Applied ${preset.name}! Storefront theme updated.`);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      selectedThemeId,
      primaryThemeColor: primaryThemeColor.trim(),
      enableImageZoom,
      shapeDividerEnabled,
      shapeDividerVariant,
      shapeDividerHeight,
    });
    showToast('UX/UI Design Theme & Shape Divider settings updated and published!');
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 animate-in fade-in duration-200">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{toast}</span>
        </div>
      )}

      {/* Sub-tab Switcher Header */}
      <div className="bg-white border border-neutral-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between shadow-xs gap-3">
        <div className="flex items-center space-x-2">
          <Palette className="w-5 h-5 text-neutral-800" />
          <div>
            <h2 className="font-serif text-lg font-bold text-neutral-900">Frontend Design & UX/UI Controls</h2>
            <p className="text-xs text-neutral-500 font-sans">
              Manage storefront aesthetic theme presets, primary accent colors, and custom shape divider geometries.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 bg-neutral-100 p-1 rounded-sm text-xs font-mono shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('theme')}
            className={`px-4 py-1.5 transition-all cursor-pointer ${
              activeTab === 'theme' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
            }`}
          >
            UX/UI Theme
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('divider')}
            className={`px-4 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'divider' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <span>Shape Divider</span>
          </button>
        </div>
      </div>

      {/* TAB 1: UX/UI THEME PRESETS */}
      {activeTab === 'theme' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
          <div className="space-y-1 border-b border-neutral-100 pb-4">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-lg font-bold text-neutral-900">UX/UI Theme Presets</h3>
              <span className="text-[10px] font-mono uppercase bg-neutral-100 px-2 py-0.5 text-neutral-600 border border-neutral-300">
                Logos managed under Business Setup
              </span>
            </div>
            <p className="text-xs text-neutral-500 font-sans">
              Select or customize the public storefront interface theme. Theme 1 is active; click to switch presets.
            </p>
          </div>

          {/* Theme Preset Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {THEME_PRESETS.map((preset) => {
              const isSelected = selectedThemeId === preset.id;
              return (
                <div
                  key={preset.id}
                  onClick={() => handleApplyPreset(preset)}
                  className={`border-2 p-5 transition-all cursor-pointer relative flex flex-col justify-between space-y-4 ${
                    isSelected ? 'border-black bg-neutral-50 shadow-md' : 'border-neutral-200 bg-white hover:border-neutral-400'
                  }`}
                >
                  {isSelected && (
                    <span className="absolute top-3 right-3 px-2 py-0.5 bg-black text-white text-[10px] font-mono uppercase font-bold tracking-wider flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span>Active Selection</span>
                    </span>
                  )}

                  <div className="space-y-1.5">
                    <h4 className="font-serif text-base font-bold text-neutral-900">{preset.name}</h4>
                    <p className="text-xs text-neutral-600 leading-relaxed font-sans">{preset.subtitle}</p>
                  </div>

                  {/* UI Theme Visual Preview Block */}
                  <div className={`p-4 rounded-xs border ${preset.borderPreview} ${preset.bgPreview} space-y-2 text-xs font-mono`}>
                    <div className="flex items-center justify-between border-b border-current/20 pb-2">
                      <span className="font-bold uppercase tracking-wider text-[10px]">EZISTENTIAL CONNECTIONS</span>
                      <span className="text-[9px] opacity-75">STOREFRONT PREVIEW</span>
                    </div>
                    <div className="font-serif italic text-sm pt-1">
                      "The space between people is where identity forms."
                    </div>
                    <div className="flex items-center space-x-2 pt-2 text-[10px]">
                      <span className="px-2 py-0.5 bg-current/10 rounded-xs font-semibold uppercase">Garment Collection</span>
                      <span className="px-2 py-0.5 border border-current/30 rounded-xs font-semibold uppercase">Lookbook</span>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between text-xs font-mono text-neutral-500 border-t border-neutral-100">
                    <span>Accent: <strong className="text-neutral-900">{preset.primaryColor}</strong></span>
                    <span className="underline font-medium text-black">Select Theme →</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Theme Color & Zoom Controls */}
          <div className="p-6 bg-neutral-50 border border-neutral-200 space-y-6">
            <h4 className="text-xs uppercase font-mono tracking-wider text-neutral-700 font-bold">
              Theme Customization & Interactive Controls
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs font-mono">
              <div>
                <label className="block text-neutral-800 font-medium mb-1.5">Primary Theme Accent Hex Color</label>
                <div className="flex items-center space-x-3">
                  <input
                    type="color"
                    value={primaryThemeColor}
                    onChange={(e) => setPrimaryThemeColor(e.target.value)}
                    className="w-10 h-10 border border-neutral-300 rounded-xs cursor-pointer p-0.5 bg-white"
                  />
                  <input
                    type="text"
                    value={primaryThemeColor}
                    onChange={(e) => setPrimaryThemeColor(e.target.value)}
                    className="flex-1 bg-white border border-neutral-300 p-2.5 text-xs font-mono uppercase font-bold text-neutral-900 focus:outline-hidden focus:border-black"
                  />
                </div>
              </div>

              <div className="flex items-center pt-4 sm:pt-6">
                <label className="flex items-center space-x-3 text-xs text-neutral-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableImageZoom}
                    onChange={(e) => setEnableImageZoom(e.target.checked)}
                    className="accent-black w-4 h-4"
                  />
                  <div>
                    <span className="font-bold block">Interactive Garment Image Magnifier</span>
                    <span className="text-[11px] text-neutral-500 font-normal">
                      Enables high-resolution zoom hover on product detail pages.
                    </span>
                  </div>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SHAPE DIVIDER */}
      {activeTab === 'divider' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
          <div className="space-y-1 border-b border-neutral-100 pb-4">
            <h3 className="font-serif text-lg font-bold text-neutral-900">Custom Section Shape Divider Geometries</h3>
            <p className="text-xs text-neutral-500 font-sans">
              Choose the architectural divider cut applied between editorial sections and garment displays on the public homepage.
            </p>
          </div>

          <div className="space-y-4">
            <label className="flex items-center space-x-3 text-xs text-neutral-800 cursor-pointer">
              <input
                type="checkbox"
                checked={shapeDividerEnabled}
                onChange={(e) => setShapeDividerEnabled(e.target.checked)}
                className="accent-black w-4 h-4"
              />
              <span className="font-bold text-sm">Enable Architectural Shape Divider on Homepage</span>
            </label>

            {shapeDividerEnabled && (
              <div className="space-y-6 pt-4 border-t border-neutral-100">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    { id: 'editorial-notch', title: 'Editorial Notch', desc: 'Symmetrical geometric notch cut out' },
                    { id: 'zebra-contour', title: 'Zebra Contour', desc: 'Asymmetric diagonal rhythm wave' },
                    { id: 'textile-seam', title: 'Textile Seam', desc: 'Tactile stitched apparel seam divide' },
                    { id: 'horizon-converge', title: 'Horizon Converge', desc: 'Deep subtle parabolic dip' },
                    { id: 'asymmetric-slash', title: 'Asymmetric Slash', desc: 'Sharp angular architectural edge' },
                  ].map((variant) => (
                    <button
                      key={variant.id}
                      type="button"
                      onClick={() => setShapeDividerVariant(variant.id as ShapeDividerVariant)}
                      className={`p-4 text-left border rounded-xs transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                        shapeDividerVariant === variant.id
                          ? 'border-black bg-neutral-900 text-white shadow-md'
                          : 'border-neutral-200 bg-white text-neutral-900 hover:border-neutral-400'
                      }`}
                    >
                      <div>
                        <span className="text-[10px] font-mono uppercase tracking-widest block opacity-60">Variant</span>
                        <h4 className="font-serif text-sm font-bold mt-0.5">{variant.title}</h4>
                        <p className="text-[11px] font-sans opacity-80 mt-1">{variant.desc}</p>
                      </div>

                      {/* Live Mini Preview of Shape Divider */}
                      <div className="bg-neutral-800 h-10 relative overflow-hidden rounded-xs">
                        <ShapeDivider variant={variant.id as ShapeDividerVariant} fillColor="#ffffff" height={32} />
                      </div>
                    </button>
                  ))}
                </div>

                <div className="p-4 bg-neutral-50 border border-neutral-200">
                  <label className="block text-xs font-mono uppercase font-bold text-neutral-800 mb-2">
                    Divider Geometric Height: {shapeDividerHeight}px
                  </label>
                  <input
                    type="range"
                    min="32"
                    max="120"
                    step="8"
                    value={shapeDividerHeight}
                    onChange={(e) => setShapeDividerHeight(Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Save Button */}
      <div className="bg-white border border-neutral-200 p-4 flex justify-end">
        <Button type="submit" variant="primary" size="md">
          <Check className="w-3.5 h-3.5 mr-1.5" />
          <span>Save All Design Changes</span>
        </Button>
      </div>
    </form>
  );
};
