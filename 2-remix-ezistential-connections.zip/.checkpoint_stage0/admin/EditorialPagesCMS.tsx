import React, { useState } from 'react';
import {
  FileText,
  CheckCircle2,
  BookOpen,
  Compass,
  Heart,
  HelpCircle,
  Phone,
  Truck,
  Save,
  Check,
  Globe,
  Layout,
  ShoppingBag,
  Shield,
  Send,
  MessageSquare
} from 'lucide-react';
import { useContent, SpotlightSlide } from '../../context/ContentContext';
import { Button } from '../ui/Button';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';

export type PageCmsTab =
  | 'home'
  | 'why_we_exist'
  | 'our_story'
  | 'manifesto'
  | 'connection'
  | 'care_shipping'
  | 'contact'
  | 'faq'
  | 'journal'
  | 'footer_legal';

export const EditorialPagesCMS: React.FC = () => {
  const { content, updateContent } = useContent();
  const [activeTab, setActiveTab] = useState<PageCmsTab>('home');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // 1. Homepage & Hero & Garments Catalog
  const [announcementText, setAnnouncementText] = useState(content.announcementText || '');
  const [announcementActive, setAnnouncementActive] = useState(content.announcementActive !== false);
  const [announcementLinkText, setAnnouncementLinkText] = useState(content.announcementLinkText || 'Explore Garments');
  const [heroHeadline, setHeroHeadline] = useState(content.heroHeadline || '');
  const [heroSubheadline, setHeroSubheadline] = useState(content.heroSubheadline || '');
  const [heroTagline, setHeroTagline] = useState(content.heroTagline || '');
  const [heroButtonText, setHeroButtonText] = useState(content.heroButtonText || 'Explore Connection Garments');
  const [heroImageUrl, setHeroImageUrl] = useState(content.heroImageUrl || 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=2000&q=85');
  const [heroImageOverlayOpacity, setHeroImageOverlayOpacity] = useState(
    typeof content.heroImageOverlayOpacity === 'number' ? content.heroImageOverlayOpacity : 0.52
  );
  const [heroColorMood, setHeroColorMood] = useState(content.heroColorMood || 'golden-amber');
  const [catalogSectionTitle, setCatalogSectionTitle] = useState(
    content.catalogSectionTitle || 'On-Demand Heavyweight Garments'
  );
  const [catalogSectionSubtitle, setCatalogSectionSubtitle] = useState(
    content.catalogSectionSubtitle || 'Heavyweight 6.5oz combed cotton garments designed to provoke quiet recognition.'
  );
  const [spotlightSlides, setSpotlightSlides] = useState<SpotlightSlide[]>(
    content.spotlightSlides || [
      {
        id: 'slide-1',
        url: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=1200&q=85',
        subtitle: 'Diverse Age Showcase · Park Series',
        caption: 'The Distance Between Us Is Man-Made',
      },
      {
        id: 'slide-2',
        url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1200&q=85',
        subtitle: 'Editorial Campaign · 02',
        caption: 'Interrupted Typography in Public Space',
      },
      {
        id: 'slide-3',
        url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=85',
        subtitle: 'Community & Connection',
        caption: 'Inaugural Statement — Est. Nov 2008',
      },
    ]
  );

  // 2. Why We Exist
  const [whyWeExistHeadline, setWhyWeExistHeadline] = useState(content.whyWeExistHeadline || 'Why We Exist');
  const [whyWeExistSubtitle, setWhyWeExistSubtitle] = useState(
    content.whyWeExistSubtitle || 'A garment is not merely fabric; it is an artifact of presence.'
  );
  const [whyWeExistBody, setWhyWeExistBody] = useState(content.whyWeExistBody || '');
  const [foundingQuote, setFoundingQuote] = useState(content.foundingQuote || '');

  // 3. Our Story
  const [storyHeadline, setStoryHeadline] = useState(content.storyHeadline || 'From Chicago to the World: The Story of Ezistential');
  const [storyBody, setStoryBody] = useState(content.storyBody || '');

  // 4. Manifesto
  const [manifestoTitle, setManifestoTitle] = useState(content.manifestoTitle || 'The Ezistential Manifesto');
  const [manifestoExcerpt, setManifestoExcerpt] = useState(content.manifestoExcerpt || '');
  const [pillar1, setPillar1] = useState(content.manifestoPillars?.[0] || '1. Design with intention and physical weight.');
  const [pillar2, setPillar2] = useState(
    content.manifestoPillars?.[1] || '2. Honor the dignity of human presence over digital distraction.'
  );
  const [pillar3, setPillar3] = useState(content.manifestoPillars?.[2] || '3. Create clothing that serves as a bridge, not a barrier.');
  const [pillar4, setPillar4] = useState(
    content.manifestoPillars?.[3] || '4. Practice ethical print-on-demand zero-waste manufacturing.'
  );

  // 5. Connection Archive
  const [connectionPromptTitle, setConnectionPromptTitle] = useState(content.connectionPromptTitle || 'The Connection Archive');
  const [connectionPromptSubtitle, setConnectionPromptSubtitle] = useState(
    content.connectionPromptSubtitle || 'Anonymous reflections on distance, human connection, and presence.'
  );
  const [connectionSubmitPromptTitle, setConnectionSubmitPromptTitle] = useState(
    content.connectionSubmitPromptTitle || 'Submit an Anonymous Reflection'
  );
  const [connectionSubmitPromptGuide, setConnectionSubmitPromptGuide] = useState(
    content.connectionSubmitPromptGuide || 'Reflections are moderated by studio stewards before publication in the Connection Archive.'
  );
  const [connectionEmptyStateNotice, setConnectionEmptyStateNotice] = useState(
    content.connectionEmptyStateNotice || 'No published reflections in this category yet. Be the first to share an entry.'
  );

  // 6. Care & Garment Specs & Shipping
  const [careDirectivesTitle, setCareDirectivesTitle] = useState(
    content.careDirectivesTitle || 'Garment Care & Fabric Integrity Directives'
  );
  const [careDirectivesNotice, setCareDirectivesNotice] = useState(content.careDirectivesNotice || '');
  const [garmentFabricNotice, setGarmentFabricNotice] = useState(
    content.garmentFabricNotice || '100% Combed Ring-Spun Cotton, 6.5oz Heavyweight Custom Blank.'
  );
  const [garmentFulfillmentNotice, setGarmentFulfillmentNotice] = useState(
    content.garmentFulfillmentNotice || 'Printed on-demand with zero-waste manufacturing. 3–5 business days fulfillment.'
  );
  const [shippingReturnsHeadline, setShippingReturnsHeadline] = useState(
    content.shippingReturnsHeadline || 'Logistics, Domestic Delivery & Returns Covenant'
  );
  const [shippingReturnsBody, setShippingReturnsBody] = useState(content.shippingReturnsBody || '');

  // 7. Contact Page
  const [contactPageTitle, setContactPageTitle] = useState(content.contactPageTitle || 'Studio Premises & Inquiries');
  const [contactPageSubtitle, setContactPageSubtitle] = useState(content.contactPageSubtitle || '');

  // 8. FAQ Page
  const [faqPageTitle, setFaqPageTitle] = useState(
    content.faqPageTitle || 'Frequently Asked Questions & Care Directives'
  );
  const [faqPageSubtitle, setFaqPageSubtitle] = useState(
    content.faqPageSubtitle || 'Answers regarding garment care, custom heavyweight sizing, and domestic shipping.'
  );

  // 9. Journal & Updates Page
  const [journalPageTitle, setJournalPageTitle] = useState(content.journalPageTitle || 'Journal & Studio Updates');
  const [journalPageSubtitle, setJournalPageSubtitle] = useState(
    content.journalPageSubtitle || 'Articles, design manifestos, and studio notes from Ezistential Connections.'
  );

  // 10. Footer & Legal Pages
  const [footerSlogan, setFooterSlogan] = useState(
    content.footerSlogan || 'Examining the space between people through intentional apparel.'
  );
  const [newsletterHeading, setNewsletterHeading] = useState(content.newsletterHeading || 'Receive Studio Dispatches');
  const [newsletterSubtitle, setNewsletterSubtitle] = useState(
    content.newsletterSubtitle || 'Occasional letters on connection, garment releases, and studio manifestos.'
  );
  const [termsPageTitle, setTermsPageTitle] = useState(content.termsPageTitle || 'Terms of Service & Usage Covenant');
  const [termsPageBody, setTermsPageBody] = useState(content.termsPageBody || '');
  const [privacyPageTitle, setPrivacyPageTitle] = useState(content.privacyPageTitle || 'Digital Dignity & Privacy Covenant');
  const [privacyPageBody, setPrivacyPageBody] = useState(content.privacyPageBody || '');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSavePageContent = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      announcementText: announcementText.trim(),
      announcementActive,
      announcementLinkText: announcementLinkText.trim(),
      heroHeadline: heroHeadline.trim(),
      heroSubheadline: heroSubheadline.trim(),
      heroTagline: heroTagline.trim(),
      heroButtonText: heroButtonText.trim(),
      heroImageUrl: heroImageUrl.trim(),
      heroImageOverlayOpacity: Number(heroImageOverlayOpacity),
      heroColorMood,
      catalogSectionTitle: catalogSectionTitle.trim(),
      catalogSectionSubtitle: catalogSectionSubtitle.trim(),
      spotlightSlides,

      whyWeExistHeadline: whyWeExistHeadline.trim(),
      whyWeExistSubtitle: whyWeExistSubtitle.trim(),
      whyWeExistBody: whyWeExistBody.trim(),
      foundingQuote: foundingQuote.trim(),

      storyHeadline: storyHeadline.trim(),
      storyBody: storyBody.trim(),

      manifestoTitle: manifestoTitle.trim(),
      manifestoExcerpt: manifestoExcerpt.trim(),
      manifestoPillars: [pillar1.trim(), pillar2.trim(), pillar3.trim(), pillar4.trim()],

      connectionPromptTitle: connectionPromptTitle.trim(),
      connectionPromptSubtitle: connectionPromptSubtitle.trim(),
      connectionSubmitPromptTitle: connectionSubmitPromptTitle.trim(),
      connectionSubmitPromptGuide: connectionSubmitPromptGuide.trim(),
      connectionEmptyStateNotice: connectionEmptyStateNotice.trim(),

      careDirectivesTitle: careDirectivesTitle.trim(),
      careDirectivesNotice: careDirectivesNotice.trim(),
      garmentFabricNotice: garmentFabricNotice.trim(),
      garmentFulfillmentNotice: garmentFulfillmentNotice.trim(),
      shippingReturnsHeadline: shippingReturnsHeadline.trim(),
      shippingReturnsBody: shippingReturnsBody.trim(),

      contactPageTitle: contactPageTitle.trim(),
      contactPageSubtitle: contactPageSubtitle.trim(),

      faqPageTitle: faqPageTitle.trim(),
      faqPageSubtitle: faqPageSubtitle.trim(),

      journalPageTitle: journalPageTitle.trim(),
      journalPageSubtitle: journalPageSubtitle.trim(),

      footerSlogan: footerSlogan.trim(),
      newsletterHeading: newsletterHeading.trim(),
      newsletterSubtitle: newsletterSubtitle.trim(),
      termsPageTitle: termsPageTitle.trim(),
      termsPageBody: termsPageBody.trim(),
      privacyPageTitle: privacyPageTitle.trim(),
      privacyPageBody: privacyPageBody.trim(),
    });
    showToast('Page CMS updated! All page content is synchronized live across the storefront.');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-neutral-200 gap-4">
        <div>
          <h2 className="font-serif text-2xl text-neutral-900">Page CMS — Storefront Copy Controller</h2>
          <p className="text-xs text-neutral-500 mt-1">
            Complete page content management. Every headline, paragraph, quote, and notice across the storefront is editable below.
          </p>
        </div>
        <Button onClick={handleSavePageContent} variant="primary" size="md">
          <Save className="w-3.5 h-3.5 mr-1.5" />
          <span>Publish Page Updates</span>
        </Button>
      </div>

      {/* Page Tabs Bar */}
      <div className="flex border-b border-neutral-200 overflow-x-auto gap-1 text-xs font-mono">
        {[
          { id: 'home', label: '1. Home & Hero', icon: Globe },
          { id: 'why_we_exist', label: '2. Why We Exist', icon: Compass },
          { id: 'our_story', label: '3. Our Story', icon: BookOpen },
          { id: 'manifesto', label: '4. Manifesto', icon: FileText },
          { id: 'connection', label: '5. Connection Archive', icon: Heart },
          { id: 'care_shipping', label: '6. Care & Shipping', icon: Truck },
          { id: 'contact', label: '7. Contact Page', icon: Phone },
          { id: 'faq', label: '8. FAQ Page', icon: HelpCircle },
          { id: 'journal', label: '9. Journal Page', icon: BookOpen },
          { id: 'footer_legal', label: '10. Footer & Legal', icon: Shield },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as PageCmsTab)}
              className={`py-2.5 px-3.5 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                isActive
                  ? 'border-black text-black font-bold bg-neutral-50'
                  : 'border-transparent text-neutral-500 hover:text-black'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Page CMS Form */}
      <form onSubmit={handleSavePageContent} className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
        {/* TAB 1: HOMEPAGE & HERO & CATALOG */}
        {activeTab === 'home' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Homepage, Hero & Garment Catalog Editor</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Edit top announcement bar, primary hero statement, subheadline, tagline, CTA button, and garment section titles.
              </p>
            </div>

            <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-4">
              <label className="flex items-center space-x-3 text-xs text-neutral-900 font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={announcementActive}
                  onChange={(e) => setAnnouncementActive(e.target.checked)}
                  className="accent-black w-4 h-4"
                />
                <span>Enable Top Announcement Bar</span>
              </label>

              {announcementActive && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Announcement Statement</label>
                    <input
                      type="text"
                      value={announcementText}
                      onChange={(e) => setAnnouncementText(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2 text-xs font-sans text-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Link Label</label>
                    <input
                      type="text"
                      value={announcementLinkText}
                      onChange={(e) => setAnnouncementLinkText(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2 text-xs font-sans text-neutral-900"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4 pt-2">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                  Main Hero Opening Statement (Headline) *
                </label>
                <textarea
                  rows={2}
                  required
                  value={heroHeadline}
                  onChange={(e) => setHeroHeadline(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-sm font-serif text-neutral-900 focus:outline-hidden focus:border-black leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                  Hero Subheadline Description
                </label>
                <textarea
                  rows={3}
                  value={heroSubheadline}
                  onChange={(e) => setHeroSubheadline(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 focus:outline-hidden focus:border-black leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Hero Tagline Pill</label>
                  <input
                    type="text"
                    value={heroTagline}
                    onChange={(e) => setHeroTagline(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Primary CTA Button Text</label>
                  <input
                    type="text"
                    value={heroButtonText}
                    onChange={(e) => setHeroButtonText(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden font-bold uppercase"
                  />
                </div>
              </div>

              {/* Hero Atmospheric Background Image & Color Mood */}
              <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-4 pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs uppercase font-mono font-bold text-neutral-800">
                      Hero Atmospheric Background Image &amp; Color Mood
                    </h4>
                    <p className="text-[11px] text-neutral-500 font-sans">
                      Add rich color and evocative editorial photography to the opening hero section.
                    </p>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-neutral-200 text-neutral-700">
                    Live Hero
                  </span>
                </div>

                <div className="space-y-3">
                  <ImageUploadCompressor
                    label="Hero Background Image (.jpg, .png, .webp)"
                    value={heroImageUrl}
                    onChange={setHeroImageUrl}
                    maxWidth={2000}
                    maxHeight={1400}
                    quality={0.88}
                    helperText="Recommended: 1920x1080 landscape editorial photo with rich lighting"
                  />

                  {/* Curated Presets */}
                  <div className="space-y-1.5 pt-1">
                    <label className="block text-[11px] uppercase font-mono text-neutral-600">
                      Or Choose a Curated Editorial Preset:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        {
                          name: 'Golden Hour',
                          url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=2000&q=85',
                          mood: 'golden-amber' as const,
                          color: '#f59e0b',
                        },
                        {
                          name: 'Terracotta Sunset',
                          url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=2000&q=85',
                          mood: 'terracotta-sunset' as const,
                          color: '#ea580c',
                        },
                        {
                          name: 'Architectural Light',
                          url: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=2000&q=85',
                          mood: 'golden-amber' as const,
                          color: '#d97706',
                        },
                        {
                          name: 'Twilight Dusk',
                          url: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=2000&q=85',
                          mood: 'twilight-indigo' as const,
                          color: '#6366f1',
                        },
                      ].map((preset) => (
                        <button
                          key={preset.name}
                          type="button"
                          onClick={() => {
                            setHeroImageUrl(preset.url);
                            setHeroColorMood(preset.mood);
                          }}
                          className={`p-2 border text-left flex items-center gap-2 transition-all cursor-pointer ${
                            heroImageUrl === preset.url
                              ? 'border-black bg-white shadow-xs font-semibold'
                              : 'border-neutral-300 bg-neutral-100 hover:border-neutral-400'
                          }`}
                        >
                          <span
                            className="w-3 h-3 rounded-full shrink-0"
                            style={{ backgroundColor: preset.color }}
                          />
                          <span className="text-[11px] font-sans truncate">{preset.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Color Mood & Opacity Sliders */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div>
                      <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">
                        Ambient Color Mood (Light Blooms)
                      </label>
                      <select
                        value={heroColorMood}
                        onChange={(e) => setHeroColorMood(e.target.value as any)}
                        className="w-full bg-white border border-neutral-300 p-2 text-xs font-sans text-neutral-900 cursor-pointer"
                      >
                        <option value="golden-amber">Golden Amber (Warm Sunlight &amp; Terracotta)</option>
                        <option value="terracotta-sunset">Terracotta Sunset (Sienna &amp; Rose Twilight)</option>
                        <option value="twilight-indigo">Twilight Indigo (Cosmic Indigo &amp; Cobalt)</option>
                        <option value="natural-monochrome">Natural Minimal (Subtle Candle Warmth)</option>
                      </select>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[11px] uppercase font-mono text-neutral-600">
                          Scrim Overlay Darkness
                        </label>
                        <span className="text-xs font-mono text-neutral-700">
                          {Math.round(heroImageOverlayOpacity * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0.2"
                        max="0.85"
                        step="0.05"
                        value={heroImageOverlayOpacity}
                        onChange={(e) => setHeroImageOverlayOpacity(parseFloat(e.target.value))}
                        className="w-full accent-black cursor-pointer"
                      />
                      <p className="text-[10px] text-neutral-500 font-sans mt-0.5">
                        Balances vivid image background colors with crisp white headline contrast
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-3 pt-4">
                <h4 className="text-xs uppercase font-mono font-bold text-neutral-800">Homepage Garments Section Title</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">Section Title</label>
                    <input
                      type="text"
                      value={catalogSectionTitle}
                      onChange={(e) => setCatalogSectionTitle(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">Section Subtitle</label>
                    <input
                      type="text"
                      value={catalogSectionSubtitle}
                      onChange={(e) => setCatalogSectionSubtitle(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                    />
                  </div>
                </div>
              </div>

              {/* Spotlight Carousel Slides Manager */}
              <div className="pt-6 border-t border-neutral-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-serif text-base font-bold text-neutral-900">Home Spotlight Carousel Slides</h4>
                    <p className="text-xs text-neutral-500 font-sans">
                      Manage marketing images, subtitles, and captions for the homepage spotlight carousel. Add, edit, or remove slides freely.
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="primary"
                    size="sm"
                    onClick={() => {
                      setSpotlightSlides((prev) => [
                        ...prev,
                        {
                          id: `slide-${Date.now()}`,
                          url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1200&q=85',
                          subtitle: 'New Slide Series',
                          caption: 'Enter slide caption',
                        },
                      ]);
                    }}
                  >
                    + Add New Slide
                  </Button>
                </div>

                <div className="space-y-4">
                  {spotlightSlides.map((slide, index) => (
                    <div key={slide.id} className="p-4 bg-white border border-neutral-300 space-y-3 relative shadow-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono font-bold text-neutral-700">Slide #{index + 1}</span>
                        {spotlightSlides.length > 1 && (
                          <button
                            type="button"
                            onClick={() => {
                              setSpotlightSlides((prev) => prev.filter((s) => s.id !== slide.id));
                            }}
                            className="text-xs text-red-600 hover:text-red-800 font-mono cursor-pointer"
                          >
                            Remove Slide
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="sm:col-span-3">
                          <ImageUploadCompressor
                            label="Slide Image (Upload & Compress or Paste URL)"
                            value={slide.url}
                            onChange={(url) => {
                              setSpotlightSlides((prev) => prev.map((s) => (s.id === slide.id ? { ...s, url } : s)));
                            }}
                            helperText="Optimizes uploaded imagery into WebP format for high performance storefront display."
                            previewBg="dark"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase font-mono text-neutral-600 mb-1">Subtitle / Series Tag</label>
                          <input
                            type="text"
                            value={slide.subtitle}
                            onChange={(e) => {
                              const val = e.target.value;
                              setSpotlightSlides((prev) => prev.map((s) => (s.id === slide.id ? { ...s, subtitle: val } : s)));
                            }}
                            className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-sans text-neutral-900"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] uppercase font-mono text-neutral-600 mb-1">Caption / Statement</label>
                          <input
                            type="text"
                            value={slide.caption}
                            onChange={(e) => {
                              const val = e.target.value;
                              setSpotlightSlides((prev) => prev.map((s) => (s.id === slide.id ? { ...s, caption: val } : s)));
                            }}
                            className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-serif text-neutral-900"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: WHY WE EXIST PAGE */}
        {activeTab === 'why_we_exist' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Why We Exist Page Content</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Configure philosophy copy, sub-titles, and core purpose narrative.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Page Title</label>
                <input
                  type="text"
                  value={whyWeExistHeadline}
                  onChange={(e) => setWhyWeExistHeadline(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Subtitle Quote</label>
                <input
                  type="text"
                  value={whyWeExistSubtitle}
                  onChange={(e) => setWhyWeExistSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif italic text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Philosophy Narrative Body</label>
                <textarea
                  rows={6}
                  value={whyWeExistBody}
                  onChange={(e) => setWhyWeExistBody(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed focus:outline-hidden focus:border-black"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Founding Philosophy Quote</label>
                <input
                  type="text"
                  value={foundingQuote}
                  onChange={(e) => setFoundingQuote(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif italic text-neutral-900"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: OUR STORY PAGE */}
        {activeTab === 'our_story' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Our Story & Brand Origin Page</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Narrative regarding studio origins, physical Chicago premises, and craftsmanship philosophy.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Story Headline</label>
                <input
                  type="text"
                  value={storyHeadline}
                  onChange={(e) => setStoryHeadline(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Story Body Narrative</label>
                <textarea
                  rows={8}
                  value={storyBody}
                  onChange={(e) => setStoryBody(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed focus:outline-hidden focus:border-black"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: MANIFESTO */}
        {activeTab === 'manifesto' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">The Ezistential Manifesto & Core Pillars</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Manage manifesto header, excerpt, and four founding tenets.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Manifesto Page Title</label>
                <input
                  type="text"
                  value={manifestoTitle}
                  onChange={(e) => setManifestoTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Primary Excerpt</label>
                <textarea
                  rows={3}
                  value={manifestoExcerpt}
                  onChange={(e) => setManifestoExcerpt(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-serif italic text-neutral-900 leading-relaxed"
                />
              </div>

              <div className="space-y-3 pt-2">
                <h4 className="text-xs uppercase font-mono font-bold text-neutral-700">4 Directives & Brand Pillars</h4>
                <input
                  type="text"
                  value={pillar1}
                  onChange={(e) => setPillar1(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
                <input
                  type="text"
                  value={pillar2}
                  onChange={(e) => setPillar2(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
                <input
                  type="text"
                  value={pillar3}
                  onChange={(e) => setPillar3(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
                <input
                  type="text"
                  value={pillar4}
                  onChange={(e) => setPillar4(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: CONNECTION ARCHIVE */}
        {activeTab === 'connection' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Connection Archive & Reflection Prompts</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Manage prompt headers, submission guidelines, and empty state notes for community reflections.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Archive Header Title</label>
                <input
                  type="text"
                  value={connectionPromptTitle}
                  onChange={(e) => setConnectionPromptTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Prompt Subtitle</label>
                <textarea
                  rows={2}
                  value={connectionPromptSubtitle}
                  onChange={(e) => setConnectionPromptSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Submit Box Title</label>
                  <input
                    type="text"
                    value={connectionSubmitPromptTitle}
                    onChange={(e) => setConnectionSubmitPromptTitle(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans font-bold text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Submit Box Guidelines</label>
                  <input
                    type="text"
                    value={connectionSubmitPromptGuide}
                    onChange={(e) => setConnectionSubmitPromptGuide(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Empty Reflection Notice</label>
                <input
                  type="text"
                  value={connectionEmptyStateNotice}
                  onChange={(e) => setConnectionEmptyStateNotice(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: CARE & GARMENT SPECS & SHIPPING */}
        {activeTab === 'care_shipping' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Garment Fabric Specs, Care & Shipping Policy</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Fabric care directives, cotton density notes, print-on-demand fulfillment notes, and domestic delivery covenants.
              </p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Garment Blank Specs Note</label>
                  <input
                    type="text"
                    value={garmentFabricNotice}
                    onChange={(e) => setGarmentFabricNotice(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans font-bold text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Print-on-Demand Fulfillment Notice</label>
                  <input
                    type="text"
                    value={garmentFulfillmentNotice}
                    onChange={(e) => setGarmentFulfillmentNotice(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Care Directives Title</label>
                <input
                  type="text"
                  value={careDirectivesTitle}
                  onChange={(e) => setCareDirectivesTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Fabric & Wash Instructions</label>
                <textarea
                  rows={3}
                  value={careDirectivesNotice}
                  onChange={(e) => setCareDirectivesNotice(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                />
              </div>

              <div className="pt-4 border-t border-neutral-100 space-y-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Shipping & Returns Headline</label>
                  <input
                    type="text"
                    value={shippingReturnsHeadline}
                    onChange={(e) => setShippingReturnsHeadline(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Shipping & Returns Policy Body</label>
                  <textarea
                    rows={4}
                    value={shippingReturnsBody}
                    onChange={(e) => setShippingReturnsBody(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: CONTACT PAGE */}
        {activeTab === 'contact' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Contact & Studio Premises Page</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Configure titles and contact introduction. Physical address and email addresses sync automatically from Business Setup.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Contact Page Header</label>
                <input
                  type="text"
                  value={contactPageTitle}
                  onChange={(e) => setContactPageTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Contact Intro Subtitle</label>
                <textarea
                  rows={3}
                  value={contactPageSubtitle}
                  onChange={(e) => setContactPageSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: FAQ PAGE */}
        {activeTab === 'faq' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">FAQ Page Header Copy</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Heading and subtext for the FAQ & Care directives page. (Manage individual question items under Content ➔ FAQ & Guideline).
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">FAQ Page Header Title</label>
                <input
                  type="text"
                  value={faqPageTitle}
                  onChange={(e) => setFaqPageTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">FAQ Page Subtitle</label>
                <textarea
                  rows={2}
                  value={faqPageSubtitle}
                  onChange={(e) => setFaqPageSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 9: JOURNAL & UPDATES PAGE */}
        {activeTab === 'journal' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Journal & Updates Page Headers</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Heading and subtext for the public Journal Updates blog page.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Journal Page Title</label>
                <input
                  type="text"
                  value={journalPageTitle}
                  onChange={(e) => setJournalPageTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Journal Subtitle Description</label>
                <textarea
                  rows={2}
                  value={journalPageSubtitle}
                  onChange={(e) => setJournalPageSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 10: FOOTER & LEGAL PAGES */}
        {activeTab === 'footer_legal' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Footer Slogan & Legal Covenant Pages</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Manage global footer slogan, newsletter invitation copy, Terms of Service, and Privacy Policy.
              </p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Footer Slogan Quote</label>
                  <input
                    type="text"
                    value={footerSlogan}
                    onChange={(e) => setFooterSlogan(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif italic text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Newsletter Box Heading</label>
                  <input
                    type="text"
                    value={newsletterHeading}
                    onChange={(e) => setNewsletterHeading(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Newsletter Subtitle Description</label>
                <input
                  type="text"
                  value={newsletterSubtitle}
                  onChange={(e) => setNewsletterSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
              </div>

              <div className="pt-4 border-t border-neutral-100 space-y-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Terms of Service Page Title</label>
                  <input
                    type="text"
                    value={termsPageTitle}
                    onChange={(e) => setTermsPageTitle(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Terms of Service Page Body</label>
                  <textarea
                    rows={4}
                    value={termsPageBody}
                    onChange={(e) => setTermsPageBody(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-100 space-y-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Privacy Policy Page Title</label>
                  <input
                    type="text"
                    value={privacyPageTitle}
                    onChange={(e) => setPrivacyPageTitle(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Privacy Policy Page Body</label>
                  <textarea
                    rows={4}
                    value={privacyPageBody}
                    onChange={(e) => setPrivacyPageBody(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="pt-4 border-t border-neutral-200 flex justify-end">
          <Button type="submit" variant="primary" size="md">
            <Check className="w-3.5 h-3.5 mr-1.5" />
            <span>Publish All Page CMS Updates</span>
          </Button>
        </div>
      </form>
    </div>
  );
};
