import React, { useState } from 'react';
import { usePosts } from '../../context/PostContext';
import { BlogPost } from '../../types';
import {
  FileText,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  CheckCircle2,
  Clock,
  Tag,
  User,
  Image as ImageIcon,
  X,
  Check,
  Globe,
  Lock,
  ArrowRight
} from 'lucide-react';
import { Button } from '../ui/Button';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';

export const BlogPostsCMS: React.FC = () => {
  const { posts, addPost, updatePost, deletePost } = usePosts();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Published' | 'Draft'>('All');
  const [toast, setToast] = useState<string | null>(null);

  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [previewPost, setPreviewPost] = useState<BlogPost | null>(null);

  // Form Fields
  const [formTitle, setFormTitle] = useState('');
  const [formSlug, setFormSlug] = useState('');
  const [formCategory, setFormCategory] = useState('Essay & Philosophy');
  const [formCoverImage, setFormCoverImage] = useState('https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=1200&auto=format&fit=crop');
  const [formExcerpt, setFormExcerpt] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formAuthorName, setFormAuthorName] = useState('Ezistential Studio');
  const [formAuthorRole, setFormAuthorRole] = useState('Editorial Collective');
  const [formReadTime, setFormReadTime] = useState(4);
  const [formTags, setFormTags] = useState('Human Connection, Philosophy');
  const [formIsPublished, setFormIsPublished] = useState(true);
  const [formIsFeatured, setFormIsFeatured] = useState(false);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const categories = ['Essay & Philosophy', 'Craft & Process', 'Community Journal', 'Brand Announcement'];

  const openCreateModal = () => {
    setEditingPost(null);
    setFormTitle('');
    setFormSlug('');
    setFormCategory('Essay & Philosophy');
    setFormCoverImage('https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=1200&auto=format&fit=crop');
    setFormExcerpt('');
    setFormContent('');
    setFormAuthorName('Ezistential Studio');
    setFormAuthorRole('Editorial Collective');
    setFormReadTime(4);
    setFormTags('Human Connection, Philosophy');
    setFormIsPublished(true);
    setFormIsFeatured(false);
    setIsModalOpen(true);
  };

  const openEditModal = (post: BlogPost) => {
    setEditingPost(post);
    setFormTitle(post.title);
    setFormSlug(post.slug);
    setFormCategory(post.category);
    setFormCoverImage(post.coverImage);
    setFormExcerpt(post.excerpt);
    setFormContent(post.content);
    setFormAuthorName(post.authorName);
    setFormAuthorRole(post.authorRole || '');
    setFormReadTime(post.readTimeMinutes);
    setFormTags(post.tags?.join(', ') || '');
    setFormIsPublished(post.isPublished);
    setFormIsFeatured(post.isFeatured || false);
    setIsModalOpen(true);
  };

  const handleTitleChange = (val: string) => {
    setFormTitle(val);
    if (!editingPost) {
      setFormSlug(val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
    }
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      showToast('Error: Title and article content are required');
      return;
    }

    const tagsArray = formTags.split(',').map((t) => t.trim()).filter(Boolean);

    if (editingPost) {
      await updatePost(editingPost.id, {
        title: formTitle.trim(),
        slug: formSlug.trim() || formTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        category: formCategory,
        coverImage: formCoverImage,
        excerpt: formExcerpt.trim(),
        content: formContent.trim(),
        authorName: formAuthorName.trim(),
        authorRole: formAuthorRole.trim(),
        readTimeMinutes: Number(formReadTime) || 4,
        tags: tagsArray,
        isPublished: formIsPublished,
        isFeatured: formIsFeatured,
      });
      showToast('Article update published successfully!');
    } else {
      await addPost({
        title: formTitle.trim(),
        slug: formSlug.trim() || formTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        category: formCategory,
        coverImage: formCoverImage,
        excerpt: formExcerpt.trim(),
        content: formContent.trim(),
        authorName: formAuthorName.trim(),
        authorRole: formAuthorRole.trim(),
        readTimeMinutes: Number(formReadTime) || 4,
        tags: tagsArray,
        publishedAt: new Date().toISOString(),
        isPublished: formIsPublished,
        isFeatured: formIsFeatured,
      });
      showToast('New update article created and published!');
    }

    setIsModalOpen(false);
  };

  const handleDelete = async (id: string, title: string) => {
    if (window.confirm(`Are you sure you want to permanently delete "${title}"?`)) {
      await deletePost(id);
      showToast('Article deleted successfully');
    }
  };

  const filteredPosts = posts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(search.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(search.toLowerCase()) ||
      post.authorName.toLowerCase().includes(search.toLowerCase());
    const matchesCat = categoryFilter === 'All' || post.category === categoryFilter;
    const matchesStatus =
      statusFilter === 'All' ||
      (statusFilter === 'Published' && post.isPublished) ||
      (statusFilter === 'Draft' && !post.isPublished);
    return matchesSearch && matchesCat && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{toast}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 border border-neutral-200 shadow-xs">
        <div>
          <h2 className="font-serif text-lg font-bold text-neutral-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-neutral-800" />
            <span>Updates & Blog Posts Management</span>
          </h2>
          <p className="text-xs text-neutral-500 font-sans">
            Create, edit, publish, and schedule editorial journal updates for the storefront.
          </p>
        </div>

        <Button variant="primary" size="md" onClick={openCreateModal} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          <span>New Update Article</span>
        </Button>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 border border-neutral-200 text-xs font-mono">
        <div className="relative flex-1 sm:max-w-md">
          <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search updates by title, excerpt, author..."
            className="w-full bg-neutral-50 border border-neutral-200 pl-9 pr-3 py-2 text-xs text-neutral-900 font-sans focus:outline-hidden focus:border-black"
          />
        </div>

        <div className="flex items-center space-x-3">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-neutral-50 border border-neutral-200 px-3 py-2 text-xs font-mono"
          >
            <option value="All">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="bg-neutral-50 border border-neutral-200 px-3 py-2 text-xs font-mono"
          >
            <option value="All">All Statuses</option>
            <option value="Published">Published</option>
            <option value="Draft">Drafts</option>
          </select>
        </div>
      </div>

      {/* Posts Table */}
      <div className="bg-white border border-neutral-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 uppercase font-mono text-[10px]">
              <tr>
                <th className="py-3 px-4">Article Title & Category</th>
                <th className="py-3 px-4">Author</th>
                <th className="py-3 px-4">Published Date</th>
                <th className="py-3 px-4">Read Time</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {filteredPosts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-neutral-500 font-serif text-sm">
                    No articles found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredPosts.map((post) => (
                  <tr key={post.id} className="hover:bg-neutral-50/70 transition-colors">
                    <td className="py-3.5 px-4 space-y-1">
                      <div className="flex items-center space-x-2">
                        {post.isFeatured && (
                          <span className="px-1.5 py-0.5 bg-amber-100 text-amber-800 text-[9px] font-mono font-bold uppercase border border-amber-300">
                            Featured
                          </span>
                        )}
                        <span className="font-serif font-bold text-neutral-900 text-sm">{post.title}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-[11px] text-neutral-500 font-mono">
                        <span className="text-neutral-700 font-medium">{post.category}</span>
                        <span>•</span>
                        <span className="text-neutral-400 font-mono">/{post.slug}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-neutral-700">
                      <div>{post.authorName}</div>
                      {post.authorRole && <div className="text-[10px] text-neutral-400">{post.authorRole}</div>}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-neutral-500 text-[11px]">
                      {new Date(post.publishedAt).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-neutral-600">
                      {post.readTimeMinutes} min
                    </td>
                    <td className="py-3.5 px-4">
                      {post.isPublished ? (
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-300 font-mono text-[10px] font-semibold">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Published</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-neutral-100 text-neutral-600 border border-neutral-300 font-mono text-[10px]">
                          <Lock className="w-3 h-3" />
                          <span>Draft</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-1">
                      <button
                        onClick={() => setPreviewPost(post)}
                        className="p-1.5 text-neutral-600 hover:text-black hover:bg-neutral-100 rounded-xs transition-colors cursor-pointer"
                        title="Preview Article"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => openEditModal(post)}
                        className="p-1.5 text-neutral-600 hover:text-black hover:bg-neutral-100 rounded-xs transition-colors cursor-pointer"
                        title="Edit Article"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(post.id, post.title)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded-xs transition-colors cursor-pointer"
                        title="Delete Article"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Article Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-neutral-300 w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
              <h3 className="font-serif text-xl font-bold text-neutral-900">
                {editingPost ? 'Edit Update Article' : 'Create New Update Article'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-neutral-400 hover:text-black cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-5 text-xs font-mono">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Article Title *</label>
                  <input
                    type="text"
                    required
                    value={formTitle}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    placeholder="e.g. The Distance Between Us Is Man-Made"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans font-bold text-neutral-900"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 font-medium mb-1">URL Slug</label>
                  <input
                    type="text"
                    value={formSlug}
                    onChange={(e) => setFormSlug(e.target.value)}
                    placeholder="the-distance-between-us"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono cursor-pointer"
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Author Name</label>
                  <input
                    type="text"
                    value={formAuthorName}
                    onChange={(e) => setFormAuthorName(e.target.value)}
                    placeholder="Ezistential Studio"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Read Time (Minutes)</label>
                  <input
                    type="number"
                    min="1"
                    value={formReadTime}
                    onChange={(e) => setFormReadTime(Number(e.target.value))}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900"
                  />
                </div>
              </div>

              <div>
                <ImageUploadCompressor
                  label="Cover Hero Image"
                  value={formCoverImage}
                  onChange={setFormCoverImage}
                  maxWidth={1200}
                  maxHeight={630}
                />
              </div>

              <div>
                <label className="block text-neutral-700 font-medium mb-1">Short Excerpt (Summary for Cards)</label>
                <textarea
                  rows={2}
                  value={formExcerpt}
                  onChange={(e) => setFormExcerpt(e.target.value)}
                  placeholder="A brief 1-2 sentence overview shown on blog post card previews..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-800"
                />
              </div>

              <div>
                <label className="block text-neutral-700 font-medium mb-1">
                  Article Body Content (Supports HTML, Clickable Links &lt;a href="..."&gt;, & YouTube Embeds &lt;iframe&gt; or YouTube links) *
                </label>
                <textarea
                  rows={10}
                  required
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="Write the full update article body here..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-mono text-neutral-900 leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-neutral-700 font-medium mb-1">Tags (Comma Separated)</label>
                <input
                  type="text"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="Human Connection, Craft, Philosophy"
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div className="flex items-center space-x-6 pt-2 border-t border-neutral-100">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsPublished}
                    onChange={(e) => setFormIsPublished(e.target.checked)}
                    className="rounded-xs border-neutral-300 text-black focus:ring-black"
                  />
                  <span className="font-bold text-neutral-900">Publish Immediately to Storefront</span>
                </label>

                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsFeatured}
                    onChange={(e) => setFormIsFeatured(e.target.checked)}
                    className="rounded-xs border-neutral-300 text-black focus:ring-black"
                  />
                  <span className="text-neutral-700">Set as Featured Hero Update</span>
                </label>
              </div>

              <div className="pt-4 border-t border-neutral-200 flex justify-end space-x-3">
                <Button type="button" variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="md">
                  {editingPost ? 'Save Update Article' : 'Publish Article'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Article Preview Modal */}
      {previewPost && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-neutral-300 w-full max-w-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <span className="text-xs font-mono uppercase text-neutral-500">Storefront Article Preview</span>
              <button onClick={() => setPreviewPost(null)} className="p-1 text-neutral-400 hover:text-black">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 font-serif">
              <span className="px-2 py-0.5 bg-neutral-100 text-neutral-800 text-[10px] font-mono font-bold uppercase">
                {previewPost.category}
              </span>
              <h1 className="text-2xl sm:text-3xl font-bold text-neutral-900">{previewPost.title}</h1>
              <p className="text-xs font-mono text-neutral-500">By {previewPost.authorName} • {previewPost.readTimeMinutes} min read</p>
              {previewPost.coverImage && (
                <img src={previewPost.coverImage} alt={previewPost.title} className="w-full max-h-64 object-cover border border-neutral-200" />
              )}
              <div className="text-sm font-sans leading-relaxed text-neutral-700 whitespace-pre-line">
                {previewPost.content}
              </div>
            </div>

            <div className="pt-4 border-t border-neutral-200 flex justify-end">
              <Button variant="primary" size="sm" onClick={() => setPreviewPost(null)}>
                Close Preview
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
