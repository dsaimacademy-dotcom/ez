import React, { useState } from 'react';
import { X, Download, Upload, RefreshCw, AlertTriangle, CheckCircle2, Database } from 'lucide-react';
import { Button } from '../ui/Button';

export interface DataBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataRestored: () => void;
}

export const DataBackupModal: React.FC<DataBackupModalProps> = ({
  isOpen,
  onClose,
  onDataRestored,
}) => {
  const [restoreStatus, setRestoreStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  if (!isOpen) return null;

  // 1. Export All Store Data to JSON
  const handleExport = () => {
    const backupData = {
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      orders: localStorage.getItem('ec_demo_orders_v2'),
      products: localStorage.getItem('ec_products_catalog_v2'),
      cmsContent: localStorage.getItem('ec_cms_content_v2'),
      faqs: localStorage.getItem('ec_cms_faqs_v2'),
      responses: localStorage.getItem('ec_user_responses_v1'),
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `ezistential-backup-${new Date().toISOString().split('T')[0]}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // 2. Import / Restore Store Data from JSON
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);

        if (!parsed.version && !parsed.orders && !parsed.products) {
          throw new Error('Invalid backup file format.');
        }

        if (parsed.orders) localStorage.setItem('ec_demo_orders_v2', typeof parsed.orders === 'string' ? parsed.orders : JSON.stringify(parsed.orders));
        if (parsed.products) localStorage.setItem('ec_products_catalog_v2', typeof parsed.products === 'string' ? parsed.products : JSON.stringify(parsed.products));
        if (parsed.cmsContent) localStorage.setItem('ec_cms_content_v2', typeof parsed.cmsContent === 'string' ? parsed.cmsContent : JSON.stringify(parsed.cmsContent));
        if (parsed.faqs) localStorage.setItem('ec_cms_faqs_v2', typeof parsed.faqs === 'string' ? parsed.faqs : JSON.stringify(parsed.faqs));
        if (parsed.responses) localStorage.setItem('ec_user_responses_v1', typeof parsed.responses === 'string' ? parsed.responses : JSON.stringify(parsed.responses));

        setRestoreStatus('success');
        setTimeout(() => {
          onDataRestored();
          onClose();
        }, 1200);
      } catch (err: any) {
        setRestoreStatus('error');
        setErrorMessage(err.message || 'Failed to parse backup JSON.');
      }
    };
    reader.readAsText(file);
  };

  // 3. Factory Reset All Data
  const handleFactoryReset = () => {
    localStorage.removeItem('ec_demo_orders_v2');
    localStorage.removeItem('ec_products_catalog_v2');
    localStorage.removeItem('ec_cms_content_v2');
    localStorage.removeItem('ec_cms_faqs_v2');
    localStorage.removeItem('ec_user_responses_v1');
    setConfirmResetOpen(false);
    onDataRestored();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-lg bg-white border border-neutral-300 p-6 sm:p-8 space-y-6 shadow-2xl z-10 animate-in fade-in duration-200">
        <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
          <div className="flex items-center space-x-2">
            <Database className="w-5 h-5 text-neutral-800" />
            <h2 className="font-serif text-2xl text-neutral-900 tracking-tight">
              Data Backup & Restore
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-black cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {restoreStatus === 'success' && (
          <div className="bg-emerald-50 border border-emerald-300 p-3 text-xs text-emerald-800 flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Store state successfully restored! Reloading data...</span>
          </div>
        )}

        {restoreStatus === 'error' && (
          <div className="bg-rose-50 border border-rose-300 p-3 text-xs text-rose-800 flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="space-y-4 text-xs text-neutral-700">
          {/* Export Section */}
          <div className="p-4 bg-[#fbfbf9] border border-neutral-200 space-y-2">
            <div className="font-semibold text-neutral-900 flex items-center justify-between">
              <span>Export Store Database</span>
              <span className="text-[10px] uppercase font-mono text-neutral-500">JSON Archive</span>
            </div>
            <p className="text-[11px] text-neutral-600 leading-relaxed font-sans">
              Download a complete JSON snapshot of all live orders, tracking statuses, product pricing, CMS copy, and community reflections.
            </p>
            <Button onClick={handleExport} variant="primary" size="sm" fullWidth className="mt-2">
              <Download className="w-3.5 h-3.5 mr-1.5" />
              <span>Download Backup JSON</span>
            </Button>
          </div>

          {/* Import Section */}
          <div className="p-4 bg-[#fbfbf9] border border-neutral-200 space-y-2">
            <div className="font-semibold text-neutral-900 flex items-center justify-between">
              <span>Restore from Backup</span>
              <span className="text-[10px] uppercase font-mono text-neutral-500">File Upload</span>
            </div>
            <p className="text-[11px] text-neutral-600 leading-relaxed font-sans">
              Upload a previously exported JSON backup file to restore complete store data.
            </p>
            <label className="flex items-center justify-center gap-2 border border-neutral-300 bg-white py-2 px-3 text-xs font-mono uppercase tracking-wider text-neutral-800 hover:border-black cursor-pointer transition-colors mt-2">
              <Upload className="w-3.5 h-3.5 text-neutral-600" />
              <span>Choose Backup File</span>
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* Factory Reset Section */}
          <div className="p-4 bg-rose-50/50 border border-rose-200 space-y-2">
            <div className="font-semibold text-rose-900 flex items-center justify-between">
              <span>Factory Demo Reset</span>
              <span className="text-[10px] uppercase font-mono text-rose-500">Dangerous</span>
            </div>
            <p className="text-[11px] text-rose-700 leading-relaxed font-sans">
              Clears local custom changes and reinstates standard demo orders, base pricing, and curated community reflections.
            </p>
            {confirmResetOpen ? (
              <div className="pt-2 flex items-center gap-2">
                <Button
                  onClick={handleFactoryReset}
                  variant="primary"
                  size="sm"
                  fullWidth
                  className="bg-rose-700 hover:bg-rose-800 text-white"
                >
                  Confirm Full Reset
                </Button>
                <Button onClick={() => setConfirmResetOpen(false)} variant="outline" size="sm">
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmResetOpen(true)}
                className="w-full text-center text-xs font-mono uppercase tracking-wider text-rose-700 hover:text-rose-900 border border-rose-300 py-1.5 bg-white transition-colors cursor-pointer mt-1"
              >
                Reset to Default Demo State
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
