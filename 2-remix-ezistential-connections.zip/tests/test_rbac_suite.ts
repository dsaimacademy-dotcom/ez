/**
 * Comprehensive Automated RBAC & Security Test Suite
 * Ezistential Connections
 */

import http from 'http';
import fs from 'fs';
import path from 'path';
import { normalizeUserProfile, normalizeAdminLog } from '../src/lib/api';
import { generateSecurePassword } from '../src/components/admin/UserManagementCMS';
import { evaluateModuleAccess, getDefaultTabForRole } from '../src/components/admin/AdminPortal';

const API_BASE = 'http://localhost:3000/api';

async function request(path: string, options: { method?: string; headers?: Record<string, string>; body?: any } = {}) {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, {
    method: options.method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const data = await res.json().catch(() => null);
  return { status: res.status, ok: res.ok, data };
}

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    console.log(`  [PASS] ${testName}`);
    passed++;
  } else {
    console.error(`  [FAIL] ${testName}${detail ? ` -> ${detail}` : ''}`);
    failed++;
  }
}

async function runTests() {
  console.log('\n--- 1. PUBLIC REGISTRATION & CUSTOMER ROLE ENFORCEMENT ---');
  const regEmail = `cust_${Date.now()}@example.com`;
  const regRes = await request('/auth/register', {
    method: 'POST',
    body: {
      email: regEmail,
      fullName: 'Test Customer',
      password: 'password123',
      role: 'superadmin' // Attempt privilege escalation during self-registration
    }
  });

  assert(regRes.status === 200 && regRes.data?.success, 'Customer registration succeeds');
  assert(regRes.data?.user?.role === 'customer', 'Role is strictly forced to customer (privilege escalation blocked)', `Got role: ${regRes.data?.user?.role}`);
  assert(regRes.data?.user?.status === 'active', 'Account status initialized to active');
  assert(regRes.data?.user?.tokenVersion === 1, 'Token version initialized to 1');

  console.log('\n--- 2. ADMIN AUTHENTICATION & PRIVILEGE ENFORCEMENT ---');
  // Admin login with wrong password
  const badLogin = await request('/auth/admin-login', {
    method: 'POST',
    body: { email: 'admin@ezistential.com', password: 'wrongpassword' }
  });
  assert(badLogin.status === 401, 'Invalid password rejected with 401');

  // Customer account trying to log into admin portal
  const customerAdminLogin = await request('/auth/admin-login', {
    method: 'POST',
    body: { email: regEmail, password: 'password123' }
  });
  assert(customerAdminLogin.status === 403, 'Customer account denied admin cockpit access with 403');

  // Legitimate Superadmin login
  const adminLogin = await request('/auth/admin-login', {
    method: 'POST',
    body: { email: 'admin@ezistential.com', password: 'adminpassword123' }
  });
  assert(adminLogin.status === 200 && adminLogin.data?.token, 'Superadmin login succeeds and returns token');
  const adminToken = adminLogin.data?.token;
  const adminCaps = adminLogin.data?.user?.effectiveCapabilities || [];
  assert(adminCaps.includes('users.create') && adminCaps.includes('settings.manage'), 'Superadmin possesses full capability suite');

  console.log('\n--- 3. STAFF PROVISIONING (LEAST-PRIVILEGE ROLES) ---');
  // Create Store Manager
  const mgrEmail = `mgr_${Date.now()}@ezistential.com`;
  const createMgr = await request('/admin/users', {
    method: 'POST',
    headers: { Authorization: `Bearer ${adminToken}` },
    body: {
      email: mgrEmail,
      fullName: 'Store Manager Alex',
      role: 'manager',
      password: 'managerpassword123'
    }
  });
  assert(createMgr.status === 200 && createMgr.data?.success, 'Superadmin creates Store Manager account');
  const mgrId = createMgr.data?.id;

  // Log in as Store Manager
  const mgrLogin = await request('/auth/admin-login', {
    method: 'POST',
    body: { email: mgrEmail, password: 'managerpassword123' }
  });
  assert(mgrLogin.status === 200 && mgrLogin.data?.token, 'Store Manager logs in successfully');
  const mgrToken = mgrLogin.data?.token;
  const mgrCaps = mgrLogin.data?.user?.effectiveCapabilities || [];
  assert(mgrCaps.includes('catalog.edit') && mgrCaps.includes('orders.view'), 'Store Manager has catalog and order capabilities');
  assert(!mgrCaps.includes('users.create') && !mgrCaps.includes('settings.manage'), 'Store Manager is restricted from staff management and settings');

  // Store Manager attempting to create a user (forbidden)
  const forbiddenCreate = await request('/admin/users', {
    method: 'POST',
    headers: { Authorization: `Bearer ${mgrToken}` },
    body: { email: 'hacker@example.com', fullName: 'Hacker', role: 'superadmin', password: 'password123' }
  });
  assert(forbiddenCreate.status === 403, 'Store Manager cannot create user accounts (403 Forbidden)');

  console.log('\n--- 4. SUPERADMIN LOCKOUT & DEMOTION SAFEGUARDS ---');
  // Find superadmin account
  const usersList = await request('/admin/users', {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  const superAdmin = usersList.data?.users?.find((u: any) => u.email === 'admin@ezistential.com');

  if (superAdmin) {
    // Attempt to suspend last Superadmin
    const suspendLast = await request(`/admin/users/${superAdmin.id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { status: 'suspended' }
    });
    assert(suspendLast.status === 400, 'Suspending the last Superadmin is blocked by system safeguard', suspendLast.data?.error);

    // Attempt to demote last Superadmin
    const demoteLast = await request(`/admin/users/${superAdmin.id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { role: 'customer' }
    });
    assert(demoteLast.status === 400, 'Demoting the last Superadmin is blocked by system safeguard', demoteLast.data?.error);

    // Attempt to delete last Superadmin
    const deleteLast = await request(`/admin/users/${superAdmin.id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(deleteLast.status === 400, 'Deleting the last Superadmin is blocked by system safeguard', deleteLast.data?.error);
  }

  console.log('\n--- 5. SESSION INVALIDATION & ACCOUNT SUSPENSION ---');
  // Suspend the store manager
  const suspendMgr = await request(`/admin/users/${mgrId}`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${adminToken}` },
    body: { status: 'suspended' }
  });
  assert(suspendMgr.status === 200 && suspendMgr.data?.success, 'Superadmin suspends Store Manager');

  // Verify old token is rejected because account is suspended
  const suspendedCheck = await request('/orders', {
    headers: { Authorization: `Bearer ${mgrToken}` }
  });
  assert(suspendedCheck.status === 403, 'Old session token of suspended user is immediately rejected (403)');

  // Suspended manager attempting login
  const suspendedLogin = await request('/auth/admin-login', {
    method: 'POST',
    body: { email: mgrEmail, password: 'managerpassword123' }
  });
  assert(suspendedLogin.status === 403 && suspendedLogin.data?.accountSuspended, 'Suspended user login rejected with descriptive message');

  console.log('\n--- 6. IDOR & CUSTOMER PRIVACY GUARDS ---');
  // Unauthenticated user querying orders
  const unauthOrders = await request('/orders');
  assert(unauthOrders.status === 403, 'Unauthenticated master order query rejected with 403');

  // Customer querying another customer email
  const idorOrders = await request('/orders?email=victim@example.com', {
    headers: { 'X-User-Email': regEmail }
  });
  assert(idorOrders.status === 403, 'Access denied when attempting to view another customer orders');

  // Single order lookup without authentication or matching email
  const unauthOrderLookup = await request('/orders?orderNumber=EC-94821-01');
  assert(unauthOrderLookup.status === 403, 'Anonymous single order lookup without customer email verification rejected');

  // Single order lookup with matching email
  const authOrderLookup = await request('/orders?orderNumber=EC-94821-01&email=marcus@example.com');
  assert(authOrderLookup.status === 200 && authOrderLookup.data?.order, 'Single order lookup succeeds when order number and email match');

  console.log('\n--- 7. AUDIT ACTIVITY LOG & FAILED LOGIN VERIFICATION ---');
  // Attempt failed login with a distinctive canary password
  const canaryPassword = 'SuperSecretCanaryPassword9981!';
  const failedAttemptRes = await request('/auth/admin-login', {
    method: 'POST',
    body: {
      email: 'admin@ezistential.com',
      password: canaryPassword
    }
  });
  assert(failedAttemptRes.status === 401, 'Failed staff login correctly returns 401');

  // Verify successful login still works
  const successLoginRes = await request('/auth/admin-login', {
    method: 'POST',
    body: {
      email: 'admin@ezistential.com',
      password: 'adminpassword123'
    }
  });
  assert(successLoginRes.status === 200 && successLoginRes.data?.token, 'Successful staff login continues to function properly');

  const logsRes = await request('/admin/logs', {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  assert(logsRes.status === 200 && Array.isArray(logsRes.data?.logs), 'Audit activity log retrieved successfully');
  const allLogs: any[] = logsRes.data?.logs || [];
  const actions = allLogs.map((l: any) => l.action);

  assert(actions.includes('user.create'), 'Activity log captured user creation');
  assert(actions.includes('user.edit'), 'Activity log captured user modification');

  // Check auth.login_failed entry
  const failedLog = allLogs.find((l: any) => l.action === 'auth.login_failed');
  assert(!!failedLog, 'Activity log captures auth.login_failed event');
  assert(failedLog?.details?.reason === 'invalid_credentials', 'Failed login log records failure reason (invalid_credentials)');
  assert(failedLog?.details?.attempted_email === 'admin@ezistential.com', 'Failed login log records attempted email');

  // Strict credential safety check: Ensure password was NOT saved in audit log
  const rawLogsString = JSON.stringify(allLogs);
  const passwordExposed = rawLogsString.includes(canaryPassword) || rawLogsString.includes('adminpassword123');
  assert(!passwordExposed, 'Security check: Passwords are never written to the audit log');

  console.log('\n--- 8. STAGE 2B-1: RBAC CONTRACT & ACCESS-CONTROL FIXES ---');
  // A. Effective capability normalization
  const normSuper = normalizeUserProfile({
    id: 'u-1',
    name: 'Super User',
    role: 'superadmin',
    effective_capabilities: ['users.view', 'users.create', 'users.edit', 'users.reset_pwd'],
  });
  assert(
    Array.isArray(normSuper?.effectiveCapabilities) &&
    normSuper?.effectiveCapabilities.includes('users.create') &&
    normSuper?.effectiveCapabilities.includes('users.reset_pwd'),
    'Effective capabilities normalized from effective_capabilities for superadmin'
  );

  const normMgr = normalizeUserProfile({
    id: 'u-2',
    name: 'Store Manager',
    role: 'manager',
    effective_capabilities: ['catalog.edit', 'orders.view'],
  });
  assert(
    Array.isArray(normMgr?.effectiveCapabilities) &&
    normMgr?.effectiveCapabilities.includes('catalog.edit') &&
    normMgr?.effectiveCapabilities.includes('orders.view') &&
    !normMgr?.effectiveCapabilities.includes('users.create'),
    'Effective capabilities normalized for manager without privilege leak'
  );

  // B. Audit log normalization (PHP shape & Node shape)
  const normPhpLog = normalizeAdminLog({
    id: 'log-php-01',
    user_id: 'usr-123',
    user_email: 'curator@ezistential.com',
    user_role: 'manager',
    target_entity: 'garment',
    target_id: 'prod-456',
    created_at: '2026-10-05T08:00:00.000Z',
    details: '{"action":"publish"}'
  });
  assert(
    normPhpLog.actorEmail === 'curator@ezistential.com' &&
    normPhpLog.actorRole === 'manager' &&
    normPhpLog.targetType === 'garment' &&
    normPhpLog.createdAt === '2026-10-05T08:00:00.000Z' &&
    normPhpLog.details?.action === 'publish',
    'Audit log normalization handles PHP-shaped attributes (user_email, user_role, target_entity, created_at)'
  );

  const normNodeLog = normalizeAdminLog({
    id: 'log-node-01',
    actorUserId: 'usr-789',
    actorEmail: 'admin@ezistential.com',
    actorRole: 'superadmin',
    targetType: 'session',
    targetId: 'usr-stf',
    createdAt: '2026-10-05T08:05:00.000Z',
    details: { reason: 'session_reset' }
  });
  assert(
    normNodeLog.actorEmail === 'admin@ezistential.com' &&
    normNodeLog.targetType === 'session' &&
    normNodeLog.details?.reason === 'session_reset',
    'Audit log normalization handles Node-shaped attributes (actorEmail, targetType)'
  );

  // C. Reset Password route & authorization
  const newStaffEmail = `staff_reset_${Date.now()}@ezistential.com`;
  const initialPassword = 'InitialPassword123!';
  const createTargetStaff = await request('/admin/users', {
    method: 'POST',
    headers: { Authorization: `Bearer ${adminToken}` },
    body: {
      email: newStaffEmail,
      fullName: 'Password Reset Target',
      role: 'fulfillment',
      password: initialPassword
    }
  });
  assert(createTargetStaff.status === 200 && createTargetStaff.data?.id, 'Created target staff member for password reset test');
  const targetStaffId = createTargetStaff.data?.id;

  // Non-privileged staff (Store Manager) attempting reset-password (forbidden)
  const forbiddenReset = await request(`/admin/users/${targetStaffId}/reset-password`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${mgrToken}` },
    body: { newPassword: 'HackedPassword123!' }
  });
  assert(forbiddenReset.status === 403, 'Reset password route rejects staff without users.reset_pwd (403 Forbidden)');

  // Superadmin calling with password < 8 characters (rejected)
  const shortReset = await request(`/admin/users/${targetStaffId}/reset-password`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${adminToken}` },
    body: { newPassword: 'short' }
  });
  assert(shortReset.status === 400, 'Reset password route rejects passwords shorter than 8 characters (400 Bad Request)');

  // Superadmin calling with valid password
  const newStaffPassword = 'BrandNewSecurePassword123!';
  const validReset = await request(`/admin/users/${targetStaffId}/reset-password`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${adminToken}` },
    body: { newPassword: newStaffPassword }
  });
  assert(validReset.status === 200 && validReset.data?.success, 'Superadmin resets staff password successfully (200 OK)');
  const newVersion = validReset.data?.tokenVersion;
  assert(typeof newVersion === 'number' && newVersion > 1, 'Password reset increments tokenVersion for session invalidation');

  // Old password fails login
  const oldLoginFail = await request('/auth/admin-login', {
    method: 'POST',
    body: { email: newStaffEmail, password: initialPassword }
  });
  assert(oldLoginFail.status === 401, 'Old password fails login after password reset');

  // New password succeeds login
  const newLoginSuccess = await request('/auth/admin-login', {
    method: 'POST',
    body: { email: newStaffEmail, password: newStaffPassword }
  });
  assert(newLoginSuccess.status === 200 && newLoginSuccess.data?.token, 'New password succeeds login after password reset');

  // Reset password audit event logged
  const postResetLogs = await request('/admin/logs', {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  const resetLog = (postResetLogs.data?.logs || []).find((l: any) => l.action === 'user.reset_pwd' && l.details?.target_email === newStaffEmail);
  assert(!!resetLog, 'Password reset audit event (user.reset_pwd) recorded in activity log');
  assert(!JSON.stringify(postResetLogs.data?.logs || []).includes(newStaffPassword), 'Security check: New plaintext password never enters activity log');

  // D. UI Permission Gating Logic
  function evaluateUiGates(user: any) {
    const isSuper = user?.role === 'superadmin' || user?.role === 'admin';
    const caps = user?.effectiveCapabilities || [];
    return {
      canCreateStaff: isSuper || caps.includes('users.create'),
      canEditStaff: isSuper || caps.includes('users.edit'),
      canResetPassword: isSuper || caps.includes('users.reset_pwd'),
      canViewUsers: isSuper || caps.includes('users.view'),
    };
  }

  const fulfillmentStaffProfile = { role: 'fulfillment', effectiveCapabilities: ['orders.view', 'orders.fulfill'] };
  const fulfillmentGates = evaluateUiGates(fulfillmentStaffProfile);
  assert(
    !fulfillmentGates.canCreateStaff &&
    !fulfillmentGates.canEditStaff &&
    !fulfillmentGates.canResetPassword &&
    !fulfillmentGates.canViewUsers,
    'UI gating: Fulfillment staff has all user management modification controls disabled'
  );

  const superadminProfile = { role: 'superadmin', effectiveCapabilities: ['users.view', 'users.create', 'users.edit', 'users.reset_pwd'] };
  const superadminGates = evaluateUiGates(superadminProfile);
  assert(
    superadminGates.canCreateStaff &&
    superadminGates.canEditStaff &&
    superadminGates.canResetPassword &&
    superadminGates.canViewUsers,
    'UI gating: Superadmin retains all active user management modification controls'
  );

  // E. Users-screen access boundary
  assert(fulfillmentGates.canViewUsers === false, 'Users screen access boundary triggers Access Restricted for unauthorized staff');
  assert(superadminGates.canViewUsers === true, 'Users screen access boundary allows authorized staff to render UserManagementCMS');

  console.log('\n--- 9. STAGE 2B-2: USER MANAGEMENT UX & VISUAL ENHANCEMENTS ---');
  // A. Password generator entropy & formatting
  const generatedPwd1 = generateSecurePassword();
  const generatedPwd2 = generateSecurePassword();
  assert(typeof generatedPwd1 === 'string' && generatedPwd1.length === 16, 'Password generator produces 16-character string');
  assert(generatedPwd1 !== generatedPwd2, 'Successive password generations produce distinct high-entropy strings');
  assert(/[A-Z]/.test(generatedPwd1), 'Generated password contains uppercase characters');
  assert(/[a-z]/.test(generatedPwd1), 'Generated password contains lowercase characters');
  assert(/[0-9]/.test(generatedPwd1), 'Generated password contains numeric digits');
  assert(/[!@#$%&*+=?]/.test(generatedPwd1), 'Generated password contains special symbols');

  // B. Directory segmentation & counts
  const mockDirectory = [
    { id: '1', role: 'superadmin', email: 's@ec.com', status: 'active' },
    { id: '2', role: 'manager', email: 'm@ec.com', status: 'active' },
    { id: '3', role: 'fulfillment', email: 'f@ec.com', status: 'active' },
    { id: '4', role: 'editor', email: 'e@ec.com', status: 'active' },
    { id: '5', role: 'moderator', email: 'mod@ec.com', status: 'active' },
    { id: '6', role: 'customer', email: 'c1@ec.com', status: 'active' },
    { id: '7', role: 'customer', email: 'c2@ec.com', status: 'suspended' },
  ];
  const staffRoleList = ['superadmin', 'admin', 'manager', 'fulfillment', 'editor', 'moderator'];
  const totalCnt = mockDirectory.length;
  const staffCnt = mockDirectory.filter(u => staffRoleList.includes(u.role)).length;
  const custCnt = mockDirectory.filter(u => u.role === 'customer').length;

  assert(totalCnt === 7, 'Segment count: Total directory accounts counted accurately (7)');
  assert(staffCnt === 5, 'Segment count: Staff members filtered and counted accurately (5)');
  assert(custCnt === 2, 'Segment count: Storefront customers filtered and counted accurately (2)');

  const staffSegmentFiltered = mockDirectory.filter(u => staffRoleList.includes(u.role));
  assert(
    staffSegmentFiltered.every(u => staffRoleList.includes(u.role)) &&
    !staffSegmentFiltered.some(u => u.role === 'customer'),
    'Directory segmentation: "Staff Members" view strictly excludes customer accounts'
  );

  const customerSegmentFiltered = mockDirectory.filter(u => u.role === 'customer');
  assert(
    customerSegmentFiltered.every(u => u.role === 'customer') &&
    !customerSegmentFiltered.some(u => staffRoleList.includes(u.role)),
    'Directory segmentation: "Customers" view strictly isolates customer shopper accounts'
  );

  // C. Proactive Sole Superadmin Safeguard
  const soleCheckMockSingle = [
    { id: 'adm-1', role: 'superadmin', status: 'active' },
    { id: 'mgr-1', role: 'manager', status: 'active' },
  ];
  const activeSupersSingle = soleCheckMockSingle.filter(u => u.role === 'superadmin' && u.status === 'active');
  const isSole1 = activeSupersSingle.length <= 1;
  assert(isSole1 === true, 'Sole superadmin detection: Single active superadmin flagged as protected');

  const soleCheckMockMultiple = [
    { id: 'adm-1', role: 'superadmin', status: 'active' },
    { id: 'adm-2', role: 'superadmin', status: 'active' },
  ];
  const activeSupersMulti = soleCheckMockMultiple.filter(u => u.role === 'superadmin' && u.status === 'active');
  const isSole2 = activeSupersMulti.length <= 1;
  assert(isSole2 === false, 'Sole superadmin detection: Multiple active superadmins allow regular editing');

  const soleCheckMockSuspended = [
    { id: 'adm-1', role: 'superadmin', status: 'active' },
    { id: 'adm-2', role: 'superadmin', status: 'suspended' },
  ];
  const activeSupersWithSuspended = soleCheckMockSuspended.filter(u => u.role === 'superadmin' && u.status === 'active');
  const isSole3 = activeSupersWithSuspended.length <= 1;
  assert(isSole3 === true, 'Sole superadmin detection: Suspended superadmin does not decrement protection threshold');

  // D. Capability Inspector source attribution
  const inspectUser = {
    role: 'manager',
    effectiveCapabilities: ['catalog.edit', 'orders.view', 'users.create'],
    customPermissions: ['users.create'],
  };
  const isCustomGrant = inspectUser.customPermissions.includes('users.create');
  const isRoleDefault = !inspectUser.customPermissions.includes('catalog.edit');
  assert(isCustomGrant === true, 'Capabilities inspector correctly attributes "users.create" as Custom Grant');
  assert(isRoleDefault === true, 'Capabilities inspector correctly attributes "catalog.edit" as Role Default');

  console.log('\n--- 10. STAGE 3: FULL-SPECTRUM ADMIN COCKPIT RBAC & ACTION GATING ---');
  // A. Superadmin full spectrum access
  const superActor = { role: 'superadmin', effectiveCapabilities: [] };
  const superPerms = evaluateModuleAccess(superActor);
  assert(superPerms.isSuperadminActor === true, 'Superadmin identified as unrestricted superadmin actor');
  assert(
    superPerms.canViewOverview &&
    superPerms.canViewOrders &&
    superPerms.canViewCatalog &&
    superPerms.canViewContent &&
    superPerms.canViewCommunity &&
    superPerms.canViewUsers &&
    superPerms.canViewIntegrations &&
    superPerms.canManageSettings &&
    superPerms.canManageSeo &&
    superPerms.canManageBackup,
    'Superadmin possesses unrestricted view access across all Cockpit workspaces'
  );
  assert(
    superPerms.canEditOrders &&
    superPerms.canFulfillOrders &&
    superPerms.canExportOrders &&
    superPerms.canEditCatalog &&
    superPerms.canEditContent &&
    superPerms.canModerateCommunity,
    'Superadmin retains all operational action capabilities across all subsystems'
  );

  // B. Least-privilege fulfillment staff profile
  const fulfillActor = {
    role: 'fulfillment',
    effectiveCapabilities: ['orders.view', 'orders.fulfill'],
  };
  const fulfillPerms = evaluateModuleAccess(fulfillActor);
  assert(fulfillPerms.canViewOrders === true, 'Fulfillment staff possesses orders workspace view access');
  assert(fulfillPerms.canFulfillOrders === true, 'Fulfillment staff possesses order dispatch and tracking modification');
  assert(fulfillPerms.canEditOrders === false, 'Fulfillment staff strictly blocked from deleting orders or creating test orders');
  assert(fulfillPerms.canViewCatalog === false, 'Fulfillment staff strictly blocked from Garments and Creative Lab catalog');
  assert(fulfillPerms.canEditCatalog === false, 'Fulfillment staff strictly blocked from Product Studio and price editing');
  assert(fulfillPerms.canViewUsers === false, 'Fulfillment staff strictly blocked from User & Staff Management');
  assert(fulfillPerms.canManageSettings === false, 'Fulfillment staff strictly blocked from Platform & Brand Settings');
  assert(fulfillPerms.canManageBackup === false, 'Fulfillment staff strictly blocked from Database Snapshot exports');

  // C. Content editor profile
  const editorActor = {
    role: 'editor',
    effectiveCapabilities: ['content.view', 'content.edit'],
  };
  const editorPerms = evaluateModuleAccess(editorActor);
  assert(editorPerms.canViewContent === true, 'Editor possesses content and editorial workspace view access');
  assert(editorPerms.canEditContent === true, 'Editor possesses article and FAQ editing capabilities');
  assert(editorPerms.canViewOrders === false, 'Editor strictly blocked from customer orders');
  assert(editorPerms.canEditCatalog === false, 'Editor strictly blocked from garment pricing and catalog mutations');

  // D. Community moderator profile
  const modActor = {
    role: 'moderator',
    effectiveCapabilities: ['community.view', 'community.moderate'],
  };
  const modPerms = evaluateModuleAccess(modActor);
  assert(modPerms.canViewCommunity === true, 'Moderator possesses human connection archive view access');
  assert(modPerms.canModerateCommunity === true, 'Moderator possesses reflection approve, reject, and feature capabilities');
  assert(modPerms.canViewOrders === false, 'Moderator strictly blocked from order records');
  assert(modPerms.canViewCatalog === false, 'Moderator strictly blocked from garment catalog');

  // E. Store manager profile
  const managerActor = {
    role: 'manager',
    effectiveCapabilities: ['catalog.view', 'catalog.edit', 'orders.view', 'orders.fulfill', 'community.view'],
  };
  const managerPerms = evaluateModuleAccess(managerActor);
  assert(managerPerms.canViewCatalog === true && managerPerms.canEditCatalog === true, 'Manager has full catalog view and edit rights');
  assert(managerPerms.canViewOrders === true && managerPerms.canFulfillOrders === true, 'Manager has order oversight and fulfillment rights');
  assert(managerPerms.canViewUsers === false, 'Manager without custom grant strictly blocked from Staff Directory');
  assert(managerPerms.canManageSettings === false, 'Manager strictly blocked from Platform Settings and API keys');

  // F. Storefront customer boundary check
  const customerActor = { role: 'customer', effectiveCapabilities: [] };
  const customerPerms = evaluateModuleAccess(customerActor);
  assert(
    !customerPerms.canViewOverview &&
    !customerPerms.canViewOrders &&
    !customerPerms.canViewCatalog &&
    !customerPerms.canViewUsers &&
    !customerPerms.canEditOrders &&
    !customerPerms.canEditCatalog,
    'Storefront customer is denied all admin cockpit views and operational actions'
  );

  // G. Default landing workspace resolver
  assert(getDefaultTabForRole(fulfillActor) === 'orders', 'Default workspace: Fulfillment staff lands directly on "orders" tab');
  assert(getDefaultTabForRole(editorActor) === 'content_updates', 'Default workspace: Editor lands directly on "content_updates" tab');
  assert(getDefaultTabForRole(modActor) === 'moderation', 'Default workspace: Moderator lands directly on "moderation" tab');
  assert(getDefaultTabForRole(managerActor) === 'overview', 'Default workspace: Manager lands on "overview" tab');
  assert(getDefaultTabForRole(superActor) === 'overview', 'Default workspace: Superadmin lands on "overview" tab');
  assert(getDefaultTabForRole(null) === 'overview', 'Default workspace: Unauthenticated / null user falls back gracefully to "overview"');
  assert(
    getDefaultTabForRole({ role: 'specialist', effectiveCapabilities: ['orders.view'] }) === 'orders',
    'Default workspace: Custom role with orders.view lands dynamically on "orders"'
  );
  assert(
    getDefaultTabForRole({ role: 'stylist', effectiveCapabilities: ['catalog.view'] }) === 'products',
    'Default workspace: Custom role with catalog.view lands dynamically on "products"'
  );

  console.log(`\n========================================`);
  console.log(`TEST SUITE COMPLETED: ${passed} passed, ${failed} failed.`);
  console.log(`========================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch(err => {
  console.error('Test execution failed with error:', err);
  process.exit(1);
});
