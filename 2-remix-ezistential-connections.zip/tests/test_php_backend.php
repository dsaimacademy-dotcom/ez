<?php
/**
 * Ezistential Connections — Comprehensive PHP Backend Test Suite
 * Executes end-to-end integration tests for backend/api.php, backend/db.php, and backend/config.php.
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

// Setup testing database using SQLite
$testDbFile = __DIR__ . '/test_database.sqlite';
if (file_exists($testDbFile)) {
    unlink($testDbFile);
}

putenv('DB_DRIVER=sqlite');
putenv("SQLITE_PATH={$testDbFile}");

// Load and initialize SQLite schema
$pdo = new PDO("sqlite:{$testDbFile}", null, null, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

// Create SQLite tables matching MySQL schema
$pdo->exec("
CREATE TABLE wear_types (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    wholesale_cost REAL DEFAULT 18.50,
    default_retail_price REAL DEFAULT 48.00,
    fabric_weight TEXT DEFAULT '6.5oz',
    fit_profile TEXT DEFAULT 'Boxy',
    primary_provider TEXT DEFAULT 'apliiq',
    base_garment_code TEXT DEFAULT 'APL-6500',
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE colors (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    hex TEXT NOT NULL,
    active INTEGER DEFAULT 1,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE sizes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    chest_inches REAL,
    length_inches REAL,
    sort_order INTEGER DEFAULT 0,
    active INTEGER DEFAULT 1
);

CREATE TABLE designs (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    thesis TEXT,
    status TEXT DEFAULT 'draft',
    approved_version_id TEXT,
    suggested_wear_types TEXT,
    suggested_colors TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE design_versions (
    id TEXT PRIMARY KEY,
    design_id TEXT NOT NULL,
    version_number INTEGER DEFAULT 1,
    artwork_front_url TEXT,
    artwork_back_url TEXT,
    artwork_sleeve_url TEXT,
    artwork_preview_url TEXT,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    category TEXT DEFAULT 'Tees',
    collection_name TEXT DEFAULT 'Core',
    base_price REAL DEFAULT 48.00,
    wholesale_cost REAL DEFAULT 18.50,
    status TEXT DEFAULT 'published',
    is_ready_for_pod INTEGER DEFAULT 1,
    story_a_thesis TEXT,
    story_a_meaning TEXT,
    story_a_wearer_role TEXT,
    story_b_fabric_spec TEXT,
    story_b_weight_gsm TEXT,
    story_b_fit_notes TEXT,
    primary_image_url TEXT,
    gallery_urls TEXT,
    source_design_id TEXT,
    source_design_version_id TEXT,
    source_design_version_number INTEGER,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE product_variants (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL,
    sku TEXT NOT NULL,
    wear_type_id TEXT,
    wear_type_name TEXT,
    size TEXT,
    color_id TEXT,
    color_name TEXT,
    color_hex TEXT,
    price_override REAL,
    in_stock INTEGER DEFAULT 1,
    is_available INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    pod_provider TEXT DEFAULT 'apliiq',
    pod_variant_id TEXT
);

CREATE TABLE orders (
    id TEXT PRIMARY KEY,
    order_number TEXT UNIQUE NOT NULL,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    shipping_address TEXT,
    subtotal REAL DEFAULT 0,
    tax_amount REAL DEFAULT 0,
    shipping_amount REAL DEFAULT 0,
    total_amount REAL DEFAULT 0,
    currency TEXT DEFAULT 'USD',
    payment_method TEXT DEFAULT 'card',
    payment_status TEXT DEFAULT 'Paid',
    payment_transaction_id TEXT,
    status TEXT DEFAULT 'Paid',
    pod_provider TEXT DEFAULT 'apliiq',
    pod_order_id TEXT,
    idempotency_key TEXT,
    tracking_number TEXT,
    tracking_carrier TEXT DEFAULT 'USPS',
    tracking_url TEXT,
    submitted_to_pod_at TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE order_items (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    product_id TEXT,
    product_name TEXT,
    sku TEXT,
    wear_type_name TEXT,
    color_name TEXT,
    color_hex TEXT,
    size TEXT,
    quantity INTEGER DEFAULT 1,
    unit_price REAL DEFAULT 48.00
);

CREATE TABLE reflections (
    id TEXT PRIMARY KEY,
    product_id TEXT,
    product_name TEXT DEFAULT 'The Distance Tee',
    author_name TEXT DEFAULT 'Anonymous',
    author_location TEXT DEFAULT 'Public Space',
    email TEXT,
    response TEXT NOT NULL,
    photo_url TEXT,
    photo_caption TEXT,
    garment_on_body_size TEXT DEFAULT 'L',
    permission_granted INTEGER DEFAULT 1,
    status TEXT DEFAULT 'Pending Review',
    featured_quote INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT,
    name TEXT NOT NULL,
    phone TEXT,
    saved_items TEXT,
    shipping_address TEXT,
    role TEXT DEFAULT 'customer',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE site_content (
    config_key TEXT PRIMARY KEY,
    config_value TEXT NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE faqs (
    id TEXT PRIMARY KEY,
    category TEXT DEFAULT 'General',
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE blog_posts (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    excerpt TEXT NOT NULL,
    content TEXT NOT NULL,
    author TEXT DEFAULT 'Ezistential Studio',
    published_at TEXT NOT NULL,
    read_time TEXT DEFAULT '3 min read',
    tags TEXT,
    status TEXT DEFAULT 'published',
    cover_image TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
");

// Seed default administrative curator user with secure bcrypt hash
$adminBcrypt = password_hash('adminpassword123', PASSWORD_BCRYPT);
$pdo->exec("
INSERT INTO users (id, email, password_hash, name, role, saved_items)
VALUES ('usr-admin-01', 'admin@ezistential.com', '{$adminBcrypt}', 'Ezistential Curator', 'admin', '{\"id\":\"usr-admin-01\",\"email\":\"admin@ezistential.com\",\"fullName\":\"Ezistential Curator\",\"role\":\"admin\"}');
");

echo "=== INITIALIZING EZISTENTIAL CONNECTIONS TEST SUITE ===\n\n";

$testsTotal = 0;
$testsPassed = 0;
$testsFailed = 0;

function runTest(string $description, callable $fn) {
    global $testsTotal, $testsPassed, $testsFailed;
    $testsTotal++;
    echo "[$testsTotal] Testing: $description ... ";
    try {
        $result = $fn();
        if ($result !== false) {
            $testsPassed++;
            echo "PASS\n";
        } else {
            $testsFailed++;
            echo "FAIL (Assertion returned false)\n";
        }
    } catch (Throwable $e) {
        $testsFailed++;
        echo "FAIL (Exception: " . $e->getMessage() . " at line " . $e->getLine() . ")\n";
    }
}

// Helper to simulate calling backend/api.php
function callApi(string $action, string $method = 'GET', array $input = [], array $headers = [], array $queryParams = []) {
    global $testDbFile;
    $_SERVER['REQUEST_METHOD'] = $method;
    $_SERVER['REQUEST_URI'] = '/api/' . $action;
    $_GET = array_merge(['action' => $action], $queryParams);
    $_POST = [];
    $_FILES = [];

    // Clear previous HTTP headers
    foreach (array_keys($_SERVER) as $k) {
        if (strpos($k, 'HTTP_') === 0) {
            unset($_SERVER[$k]);
        }
    }

    foreach ($headers as $k => $v) {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $k));
        $_SERVER[$key] = $v;
    }

    // Set php input
    $stdin = tmpfile();
    if (!empty($input)) {
        fwrite($stdin, json_encode($input));
        fseek($stdin, 0);
    }

    // Run in subshell or buffered require
    $cmd = 'php -d DB_DRIVER=sqlite -d SQLITE_PATH=' . escapeshellarg($testDbFile) . ' -r ' . escapeshellarg('
        $_SERVER["REQUEST_METHOD"] = ' . var_export($method, true) . ';
        $_SERVER["REQUEST_URI"] = ' . var_export('/api/' . $action, true) . ';
        $_GET = ' . var_export($_GET, true) . ';
        foreach (' . var_export($headers, true) . ' as $k => $v) {
            $key = "HTTP_" . strtoupper(str_replace("-", "_", $k));
            $_SERVER[$key] = $v;
        }
        $rawInput = ' . var_export(json_encode($input), true) . ';
        $tmp = tmpfile();
        fwrite($tmp, $rawInput);
        fseek($tmp, 0);
        ob_start();
        $inputPath = "data://text/plain;base64," . base64_encode($rawInput);
        // Inject into api handler
        require "backend/api.php";
        $out = ob_get_clean();
        echo $out;
    ');

    $uri = '/api/' . $action;
    if (!empty($queryParams)) {
        $uri .= '?' . http_build_query($queryParams);
    }

    $descriptorspec = [
        0 => ["pipe", "r"],
        1 => ["pipe", "w"],
        2 => ["pipe", "w"]
    ];

    $process = proc_open("php backend/api.php", $descriptorspec, $pipes, __DIR__ . '/..', [
        'REQUEST_METHOD' => $method,
        'REQUEST_URI' => $uri,
        'QUERY_STRING' => http_build_query($queryParams),
        'DB_DRIVER' => 'sqlite',
        'SQLITE_PATH' => $testDbFile,
        'HTTP_AUTHORIZATION' => $headers['Authorization'] ?? $headers['authorization'] ?? '',
        'HTTP_X_ADMIN_TOKEN' => $headers['X-Admin-Token'] ?? $headers['x-admin-token'] ?? '',
        'HTTP_X_USER_EMAIL' => $headers['X-User-Email'] ?? $headers['x-user-email'] ?? '',
    ]);

    if (is_resource($process)) {
        fwrite($pipes[0], json_encode($input));
        fclose($pipes[0]);

        $output = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        $err = stream_get_contents($pipes[2]);
        fclose($pipes[2]);

        $status = proc_close($process);
        return [
            'status' => $status,
            'body' => $output,
            'json' => json_decode($output, true),
            'err' => $err
        ];
    }

    return ['status' => -1, 'body' => '', 'json' => null, 'err' => 'proc_open failed'];
}

// ---------------------------------------------------------------------
// TEST GROUP 1: CONFIGURATION & DB DRIVER
// ---------------------------------------------------------------------

runTest("backend/config.php returns array and defines constants", function() {
    $cfg = require __DIR__ . '/../backend/config.php';
    return is_array($cfg) && isset($cfg['db_host']) && defined('DB_HOST');
});

runTest("backend/db.php establishes PDO SQLite connection successfully", function() {
    require_once __DIR__ . '/../backend/db.php';
    $conn = Database::getConnection();
    return $conn instanceof PDO;
});

// ---------------------------------------------------------------------
// TEST GROUP 2: AUTHENTICATION & SECURITY
// ---------------------------------------------------------------------

runTest("Registration requires password and creates customer with bcrypt hash", function() {
    $res = callApi('auth/register', 'POST', [
        'email' => 'customer1@test.com',
        'password' => 'SecurePass2026!',
        'fullName' => 'Jane Contemplator',
        'location' => 'Chicago, IL'
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['user']['email']) && $res['json']['user']['email'] === 'customer1@test.com' &&
           !isset($res['json']['user']['password_hash']);
});

runTest("Registration rejects duplicate email with 409 Conflict", function() {
    $res = callApi('auth/register', 'POST', [
        'email' => 'customer1@test.com',
        'password' => 'AnotherPass123!',
        'fullName' => 'Jane Duplicate'
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === false &&
           strpos($res['json']['error'], 'already exists') !== false;
});

runTest("Login verifies password with password_verify and accepts correct credentials", function() {
    $res = callApi('auth/login', 'POST', [
        'email' => 'customer1@test.com',
        'password' => 'SecurePass2026!'
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           $res['json']['user']['fullName'] === 'Jane Contemplator' &&
           !isset($res['json']['user']['password_hash']);
});

runTest("Login rejects wrong password with 401 Unauthorized (does NOT auto-register)", function() {
    $res = callApi('auth/login', 'POST', [
        'email' => 'customer1@test.com',
        'password' => 'WrongPassword!'
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === false &&
           strpos($res['json']['error'], 'Invalid email or password') !== false;
});

runTest("Login rejects non-existent user with 401 Unauthorized (NO auto-provisioning)", function() {
    $res = callApi('auth/login', 'POST', [
        'email' => 'doesnotexist@nowhere.com',
        'password' => 'SomePassword!'
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

// ---------------------------------------------------------------------
// TEST GROUP 3: AUTHORIZATION AUDIT (PROTECTED ENDPOINTS)
// ---------------------------------------------------------------------

runTest("Unauthenticated visitor CANNOT list master customer orders (returns 403)", function() {
    $res = callApi('orders', 'GET');
    return isset($res['json']['success']) && $res['json']['success'] === false &&
           strpos($res['json']['error'], 'authorization required') !== false;
});

runTest("Unauthenticated visitor CANNOT download database export (returns 403)", function() {
    $res = callApi('db/export', 'GET');
    return isset($res['json']['success']) && $res['json']['success'] === false &&
           strpos($res['json']['error'], 'authorization required') !== false;
});

runTest("Unauthenticated visitor CANNOT create products (returns 403)", function() {
    $res = callApi('products', 'POST', ['name' => 'Hacker Product']);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Unauthenticated visitor CANNOT delete products (returns 403)", function() {
    $res = callApi('products/prod-01', 'DELETE');
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Unauthenticated visitor CANNOT moderate reflections (returns 403)", function() {
    $res = callApi('reflections/ref-01', 'PUT', ['status' => 'Approved']);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Unauthenticated visitor CANNOT update site content (returns 403)", function() {
    $res = callApi('content', 'POST', ['brandName' => 'Hacked Brand']);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Customer CANNOT view another customer's orders (returns 403)", function() {
    $res = callApi('orders', 'GET', [], [
        'X-User-Email' => 'stranger@test.com'
    ], ['email' => 'customer1@test.com']);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Unauthenticated visitor CANNOT query orders by email (returns 403)", function() {
    $res = callApi('orders', 'GET', [], [], ['email' => 'customer1@test.com']);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Customer CANNOT elevate their own role to admin on profile update", function() {
    $res = callApi('users/customer1@test.com', 'PUT', [
        'fullName' => 'Jane Attempting Privilege Escalation',
        'role' => 'admin'
    ], ['X-User-Email' => 'customer1@test.com']);
    
    // Check that role was NOT escalated
    $check = callApi('users/customer1@test.com', 'GET', [], ['X-User-Email' => 'customer1@test.com']);
    return isset($check['json']['user']['role']) && $check['json']['user']['role'] === 'customer';
});

// ---------------------------------------------------------------------
// TEST GROUP 4: SERVER-VALIDATED CRYPTOGRAPHIC ADMIN AUTHENTICATION
// ---------------------------------------------------------------------

$adminToken = '';

runTest("Admin can authenticate via POST /api/auth/admin-login and receive signed token", function() use (&$adminToken) {
    $res = callApi('auth/admin-login', 'POST', [
        'email' => 'admin@ezistential.com',
        'password' => 'adminpassword123'
    ]);
    if (isset($res['json']['success']) && $res['json']['success'] === true && !empty($res['json']['token'])) {
        $adminToken = $res['json']['token'];
        return strpos($adminToken, '.') !== false;
    }
    return false;
});

runTest("Old hardcoded static token (Bearer ez-admin-2026) is STRICTLY REJECTED with 403", function() {
    $res = callApi('orders', 'GET', [], [
        'Authorization' => 'Bearer ez-admin-2026'
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Forged or tampered admin token is STRICTLY REJECTED with 403", function() {
    $res = callApi('orders', 'GET', [], [
        'Authorization' => 'Bearer eyJhbGciOiJIUzI1NiJ9.tampered_fake_signature'
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Standard customer CANNOT authenticate to admin portal (returns 403)", function() {
    $res = callApi('auth/admin-login', 'POST', [
        'email' => 'customer1@test.com',
        'password' => 'SecurePass2026!'
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Admin with signed token CAN list master orders", function() use (&$adminToken) {
    $res = callApi('orders', 'GET', [], [
        'Authorization' => 'Bearer ' . $adminToken
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['orders']) && isset($res['json']['data']);
});

runTest("Admin with signed token CAN create products and variants", function() use (&$adminToken) {
    $res = callApi('products', 'POST', [
        'id' => 'prod-signature-01',
        'name' => 'Signature Contemplative Tee',
        'slug' => 'signature-contemplative-tee',
        'price' => 48.00,
        'wholesaleCost' => 18.50,
        'isAvailable' => true,
        'storyA' => ['thesis' => 'The distance between minds'],
        'variants' => [
            [
                'id' => 'var-sig-01',
                'sku' => 'EC-SIG-M-BLK',
                'wearTypeId' => 'wt-heavyweight-tee',
                'size' => 'M',
                'colorId' => 'col-black',
                'colorName' => 'Raw Black',
                'colorHex' => '#0f0f0f',
                'inStock' => true,
                'isAvailable' => true
            ]
        ]
    ], ['Authorization' => 'Bearer ' . $adminToken]);
    return isset($res['json']['success']) && $res['json']['success'] === true;
});

runTest("Products endpoint returns dual keys (products AND data)", function() {
    $res = callApi('products', 'GET');
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['products']) && isset($res['json']['data']) &&
           count($res['json']['products']) >= 1;
});

// ---------------------------------------------------------------------
// TEST GROUP 5: COMPLETE DESIGN-TO-PRODUCT WORKFLOW
// ---------------------------------------------------------------------

runTest("Admin can create a creative lab design draft", function() use (&$adminToken) {
    $res = callApi('designs', 'POST', [
        'id' => 'des-human-condition-01',
        'name' => 'The Human Condition',
        'thesis' => 'Are we truly separate or merely observant?',
        'status' => 'approved',
        'suggestedWearTypes' => ['6.5oz Heavyweight Boxy Tee'],
        'suggestedColors' => ['Raw Black', 'Bone Off-White']
    ], ['Authorization' => 'Bearer ' . $adminToken]);
    return isset($res['json']['success']) && $res['json']['success'] === true;
});

runTest("Admin can push design to commercial product catalog (push-to-product)", function() use (&$adminToken) {
    $res = callApi('designs/des-human-condition-01/push-to-product', 'POST', [
        'versionNumber' => 1
    ], ['Authorization' => 'Bearer ' . $adminToken]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['product']['id']) &&
           strpos($res['json']['product']['slug'], 'the-human-condition') !== false;
});

runTest("Push-to-product safeguards against accidental duplicates", function() use (&$adminToken) {
    $res = callApi('designs/des-human-condition-01/push-to-product', 'POST', [
        'versionNumber' => 1,
        'forceNewEdition' => false
    ], ['Authorization' => 'Bearer ' . $adminToken]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['alreadyExists']) && $res['json']['alreadyExists'] === true;
});

// ---------------------------------------------------------------------
// TEST GROUP 6: ORDERS, FULFILLMENT & DUPLICATE PROTECTION
// ---------------------------------------------------------------------

runTest("Customer can place order with line items", function() {
    $res = callApi('orders', 'POST', [
        'orderNumber' => 'EC-TEST-9001',
        'customerName' => 'Jane Contemplator',
        'customerEmail' => 'customer1@test.com',
        'subtotal' => 48.00,
        'tax' => 4.32,
        'shippingFee' => 0.00,
        'total' => 52.32,
        'paymentMethod' => 'card',
        'shippingAddress' => [
            'fullName' => 'Jane Contemplator',
            'street' => '100 Michigan Ave',
            'city' => 'Chicago',
            'state' => 'IL',
            'zipCode' => '60601',
            'country' => 'United States'
        ],
        'items' => [
            [
                'productId' => 'prod-signature-01',
                'productName' => 'Signature Contemplative Tee',
                'sku' => 'EC-SIG-M-BLK',
                'wearType' => '6.5oz Heavyweight Boxy Tee',
                'size' => 'M',
                'color' => 'Raw Black',
                'price' => 48.00,
                'quantity' => 1
            ]
        ]
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['orderNumber']) && $res['json']['orderNumber'] === 'EC-TEST-9001';
});

runTest("Duplicate order submission with same order number is REJECTED with 409 Conflict", function() {
    $res = callApi('orders', 'POST', [
        'orderNumber' => 'EC-TEST-9001',
        'customerName' => 'Jane Contemplator',
        'customerEmail' => 'customer1@test.com',
        'subtotal' => 48.00,
        'total' => 52.32,
        'items' => []
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === false &&
           isset($res['json']['alreadyExists']) && $res['json']['alreadyExists'] === true;
});

runTest("Public lookup by exact order number returns tracking view", function() {
    $res = callApi('orders', 'GET', [], [], ['orderNumber' => 'EC-TEST-9001']);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['order']) && $res['json']['order']['order_number'] === 'EC-TEST-9001' &&
           count($res['json']['order']['items']) === 1;
});

runTest("Customer can query their own orders with X-User-Email", function() {
    $res = callApi('orders', 'GET', [], [
        'X-User-Email' => 'customer1@test.com'
    ], ['email' => 'customer1@test.com']);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           count($res['json']['orders']) >= 1;
});

runTest("Admin can trigger fulfillment and update tracking", function() use (&$adminToken) {
    $res = callApi('orders/EC-TEST-9001/fulfill', 'POST', [
        'trackingNumber' => 'USPS-9400111899562',
        'carrier' => 'USPS'
    ], ['Authorization' => 'Bearer ' . $adminToken]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           $res['json']['status'] === 'In Production' &&
           $res['json']['trackingNumber'] === 'USPS-9400111899562';
});

// ---------------------------------------------------------------------
// TEST GROUP 7: CUSTOMER REFLECTIONS
// ---------------------------------------------------------------------

runTest("Public can submit community on-body reflection", function() {
    $res = callApi('reflections', 'POST', [
        'productName' => 'Signature Contemplative Tee',
        'authorName' => 'Marcus T.',
        'authorLocation' => 'Denver, CO',
        'email' => 'marcus@test.com',
        'response' => 'Wore this to a coffee shop; a stranger asked what the thesis meant.',
        'garmentOnBodySize' => 'L',
        'permissionGranted' => true
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['id']);
});

runTest("Reflections endpoint returns dual keys (reflections AND data)", function() {
    $res = callApi('reflections', 'GET', [], [], ['status' => 'all']);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['reflections']) && isset($res['json']['data']) &&
           count($res['json']['reflections']) >= 1;
});

// ---------------------------------------------------------------------
// TEST GROUP 8: BLOG, FAQS & HARDENED FILE UPLOAD
// ---------------------------------------------------------------------

runTest("Admin can create a journal blog post", function() use (&$adminToken) {
    $res = callApi('posts', 'POST', [
        'id' => 'post-why-ec',
        'title' => 'Why Ezistential Connections Exists',
        'slug' => 'why-ezistential-connections-exists',
        'excerpt' => 'An essay on human isolation and connection.',
        'content' => 'Full architectural garment essay text.',
        'author' => 'Ezistential Studio'
    ], ['Authorization' => 'Bearer ' . $adminToken]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['slug']);
});

runTest("Public can retrieve blog posts", function() {
    $res = callApi('posts', 'GET');
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['posts']) && count($res['json']['posts']) >= 1;
});

runTest("Secure file upload validates and stores base64 PNG safely", function() {
    $onePixelPng = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
    $res = callApi('upload', 'POST', ['dataUrl' => $onePixelPng]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           isset($res['json']['url']) && strpos($res['json']['url'], '/uploads/img_ec_') === 0;
});

runTest("Malicious SVG with executable script/event handlers is sanitized on upload", function() {
    $maliciousSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">' .
                    '<script>alert("XSS")</script>' .
                    '<circle cx="50" cy="50" r="40" onload="alert(1)" fill="red"/>' .
                    '</svg>';
    $b64Svg = 'data:image/svg+xml;base64,' . base64_encode($maliciousSvg);
    $res = callApi('upload', 'POST', ['dataUrl' => $b64Svg]);

    if (isset($res['json']['success']) && $res['json']['success'] === true && !empty($res['json']['filename'])) {
        $uploadedPath = __DIR__ . '/../uploads/' . $res['json']['filename'];
        if (file_exists($uploadedPath)) {
            $savedContent = file_get_contents($uploadedPath);
            // Verify <script> and onload were completely purged
            $hasScript = stripos($savedContent, '<script') !== false;
            $hasOnload = stripos($savedContent, 'onload') !== false;
            return !$hasScript && !$hasOnload;
        }
    }
    return false;
});

runTest("Fake image upload disguised as PNG with PHP payload is REJECTED with 400", function() {
    $phpPayload = 'data:image/png;base64,' . base64_encode("<?php phpinfo(); ?>");
    $res = callApi('upload', 'POST', ['dataUrl' => $phpPayload]);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Database export produces sanitized dump without password hashes", function() use (&$adminToken) {
    $res = callApi('db/export', 'GET', [], ['Authorization' => 'Bearer ' . $adminToken]);
    if (isset($res['json']['users'])) {
        foreach ($res['json']['users'] as $u) {
            if (isset($u['password_hash']) || isset($u['password'])) {
                return false;
            }
        }
        return true;
    }
    return false;
});

// ---------------------------------------------------------------------
// SUMMARY
// ---------------------------------------------------------------------

echo "\n=========================================\n";
echo "TEST RESULTS SUMMARY:\n";
echo "Total Tests Executed: $testsTotal\n";
echo "Passed: $testsPassed\n";
echo "Failed: $testsFailed\n";
echo "Pass Rate: " . round(($testsPassed / $testsTotal) * 100, 1) . "%\n";
echo "=========================================\n";

if ($testsFailed > 0) {
    exit(1);
}
exit(0);
