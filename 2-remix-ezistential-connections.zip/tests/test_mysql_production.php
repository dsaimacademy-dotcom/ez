<?php
/**
 * Ezistential Connections — Dedicated MySQL / MariaDB Production Path Test Suite
 * 
 * Tests the real production backend against a live MySQL / MariaDB instance:
 *   - MariaDB 10.11 / MySQL 8.0 InnoDB engine
 *   - Foreign keys, cascades, JSON columns, DATETIME triggers
 *   - Dual API routing (cPanel Apache & direct action queries)
 *   - Real Payment Gateways (Stripe, PayPal, Apple Pay)
 *   - Real POD Dispatch & Sync (Printful, Apliiq)
 *   - Secure Administrator Setup & Installer Lockdown
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

$dbHost = getenv('DB_HOST') ?: '127.0.0.1';
$dbPort = getenv('DB_PORT') ?: 3306;
$dbName = getenv('DB_NAME') ?: 'ezistential_test_db';
$dbUser = getenv('DB_USER') ?: 'ezistential_user';
$dbPass = getenv('DB_PASS') ?: 'ChangeMeSecurely2026!';

echo "=== INITIALIZING EZISTENTIAL CONNECTIONS REAL MYSQL TEST SUITE ===\n";
echo "Host: {$dbHost}:{$dbPort} | Database: {$dbName} | User: {$dbUser}\n\n";

try {
    // Test direct MySQL PDO connection
    $pdo = new PDO("mysql:host={$dbHost};port={$dbPort};charset=utf8mb4", $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Create & initialize database cleanly
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `{$dbName}`");

    $schemaFile = __DIR__ . '/../backend/schema.sql';
    if (!file_exists($schemaFile)) {
        throw new Exception("Schema file not found at: {$schemaFile}");
    }

    $sql = file_get_contents($schemaFile);
    $cleanSql = preg_replace('/--.*$/m', '', $sql);
    $queries = array_filter(array_map('trim', explode(';', $cleanSql)));
    foreach ($queries as $q) {
        if (!empty($q)) {
            $pdo->exec($q);
        }
    }
} catch (Exception $e) {
    echo "FATAL: Could not connect to MySQL / MariaDB server: " . $e->getMessage() . "\n";
    exit(1);
}

// Generate server auth secret
$authSecret = bin2hex(random_bytes(32));

// Configure backend environment to use MySQL
putenv("DB_DRIVER=mysql");
putenv("DB_HOST={$dbHost}");
putenv("DB_PORT={$dbPort}");
putenv("DB_NAME={$dbName}");
putenv("DB_USER={$dbUser}");
putenv("DB_PASS={$dbPass}");
putenv("EC_AUTH_SECRET={$authSecret}");

// Provision test administrator with random password
$adminEmail = 'curator_' . bin2hex(random_bytes(3)) . '@ezistential.com';
$adminRawPassword = 'SecurePass_' . bin2hex(random_bytes(4)) . '!';
$adminHash = password_hash($adminRawPassword, PASSWORD_BCRYPT, ['cost' => 12]);
$adminId = 'usr-admin-mysql-01';

$pdo->exec("DELETE FROM users WHERE role = 'admin'");
$adminStmt = $pdo->prepare("
    INSERT INTO users (id, email, password_hash, name, role, saved_items)
    VALUES (?, ?, ?, 'Ezistential MySQL Curator', 'admin', ?)
");
$adminStmt->execute([
    $adminId,
    $adminEmail,
    $adminHash,
    json_encode(['id' => $adminId, 'email' => $adminEmail, 'fullName' => 'Ezistential MySQL Curator', 'role' => 'admin'])
]);

// Helper to simulate calling backend/api.php via proc_open
function callApi(string $action, string $method = 'GET', array $input = [], array $headers = [], array $queryParams = []): array {
    global $dbHost, $dbPort, $dbName, $dbUser, $dbPass, $authSecret;

    $uri = '/api/' . $action;
    if (!empty($queryParams)) {
        $uri .= '?' . http_build_query($queryParams);
    }

    $descriptorspec = [
        0 => ["pipe", "r"],
        1 => ["pipe", "w"],
        2 => ["pipe", "w"]
    ];

    $env = [
        'REQUEST_METHOD' => $method,
        'REQUEST_URI' => $uri,
        'QUERY_STRING' => http_build_query(array_merge(['action' => $action], $queryParams)),
        'DB_DRIVER' => 'mysql',
        'DB_HOST' => $dbHost,
        'DB_PORT' => (string)$dbPort,
        'DB_NAME' => $dbName,
        'DB_USER' => $dbUser,
        'DB_PASS' => $dbPass,
        'EC_AUTH_SECRET' => $authSecret,
        'HTTP_AUTHORIZATION' => $headers['Authorization'] ?? $headers['authorization'] ?? '',
        'HTTP_X_ADMIN_TOKEN' => $headers['X-Admin-Token'] ?? $headers['x-admin-token'] ?? '',
        'HTTP_X_USER_EMAIL' => $headers['X-User-Email'] ?? $headers['x-user-email'] ?? '',
    ];

    $process = proc_open("php backend/api.php", $descriptorspec, $pipes, __DIR__ . '/..', $env);

    if (is_resource($process)) {
        fwrite($pipes[0], json_encode($input));
        fclose($pipes[0]);

        $output = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        $err = stream_get_contents($pipes[2]);
        fclose($pipes[2]);

        $exitCode = proc_close($process);
        $json = json_decode($output, true);

        return [
            'exitCode' => $exitCode,
            'body' => $output,
            'json' => $json,
            'err' => $err
        ];
    }

    return ['exitCode' => -1, 'body' => '', 'json' => null, 'err' => 'proc_open failed'];
}

$testsTotal = 0;
$testsPassed = 0;
$testsFailed = 0;

function runTest(string $description, callable $fn) {
    global $testsTotal, $testsPassed, $testsFailed;
    $testsTotal++;
    echo "[$testsTotal] Testing: $description ... ";
    try {
        $result = $fn();
        if ($result !== false) {
            $testsPassed++;
            echo "PASS\n";
        } else {
            $testsFailed++;
            echo "FAIL (Assertion returned false)\n";
        }
    } catch (Throwable $e) {
        $testsFailed++;
        echo "FAIL (Exception: " . $e->getMessage() . " at " . $e->getFile() . ":" . $e->getLine() . ")\n";
    }
}

// ==========================================
// TEST SUITE EXECUTION
// ==========================================

runTest("MySQL / MariaDB Connection & Schema integrity", function() use ($pdo) {
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $required = ['users', 'orders', 'order_items', 'products', 'product_variants', 'designs', 'design_versions', 'wear_types', 'colors', 'sizes', 'reflections', 'site_content', 'faqs', 'blog_posts'];
    foreach ($required as $t) {
        if (!in_array($t, $tables)) return false;
    }
    return true;
});

runTest("MySQL Foreign Key constraint and ON DELETE CASCADE on order_items", function() use ($pdo) {
    $tempOrdId = 'ord-fk-test-' . bin2hex(random_bytes(4));
    $pdo->prepare("INSERT INTO orders (id, order_number, customer_name, customer_email, shipping_address, subtotal, total_amount) VALUES (?, ?, 'FK Test', 'fk@example.com', '{}', 10.00, 10.00)")
        ->execute([$tempOrdId, 'EC-FK-' . rand(1000, 9999)]);
    
    $pdo->prepare("INSERT INTO order_items (id, order_id, product_id, product_name, sku, wear_type_name, color_name, color_hex, size, quantity, unit_price) VALUES (?, ?, 'p1', 'Tee', 'SKU-FK', 'Tee', 'Black', '#000', 'M', 1, 10.00)")
        ->execute(['item-fk-1', $tempOrdId]);

    // Deleting parent order must cascade delete child items in MySQL
    $pdo->prepare("DELETE FROM orders WHERE id = ?")->execute([$tempOrdId]);
    $check = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE id = 'item-fk-1'");
    $check->execute();
    return $check->fetchColumn() === 0;
});

$adminToken = '';
runTest("Admin can authenticate via POST /api/auth/admin-login and receive signed token", function() use ($adminEmail, $adminRawPassword, &$adminToken) {
    $res = callApi('auth/admin-login', 'POST', [
        'email' => $adminEmail,
        'password' => $adminRawPassword
    ]);
    if (isset($res['json']['success']) && $res['json']['success'] === true && !empty($res['json']['token'])) {
        $adminToken = $res['json']['token'];
        return strpos($adminToken, '.') !== false;
    }
    return false;
});

runTest("Old hardcoded static token (Bearer ez-admin-2026) is STRICTLY REJECTED with 403", function() {
    $res = callApi('orders', 'GET', [], ['Authorization' => 'Bearer ez-admin-2026']);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Forged or tampered admin token is STRICTLY REJECTED with 403", function() use ($adminToken) {
    $tampered = substr($adminToken, 0, -4) . 'fake';
    $res = callApi('orders', 'GET', [], ['Authorization' => 'Bearer ' . $tampered]);
    return isset($res['json']['success']) && $res['json']['success'] === false;
});

runTest("Standard customer CANNOT authenticate to admin portal", function() use ($pdo) {
    $custPass = 'CustPass123!';
    $custHash = password_hash($custPass, PASSWORD_BCRYPT);
    $pdo->prepare("REPLACE INTO users (id, email, password_hash, name, role) VALUES ('usr-c1', 'cust@example.com', ?, 'Customer One', 'customer')")
        ->execute([$custHash]);

    $res = callApi('auth/admin-login', 'POST', [
        'email' => 'cust@example.com',
        'password' => $custPass
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === false && strpos($res['json']['error'], 'privileges') !== false;
});

runTest("Payment Gateways Probe (Stripe test key format and balance verification)", function() {
    $res = callApi('payment-gateways/verify', 'POST', [
        'provider' => 'stripe',
        'credentials' => [
            'publishableKey' => 'pk_test_sample12345678901234567890',
            'secretKey' => 'sk_test_sample12345678901234567890',
            'liveMode' => false
        ]
    ]);
    return isset($res['json']['success']);
});

runTest("Payment Gateways Probe (PayPal OAuth test verification)", function() {
    $res = callApi('payment-gateways/verify', 'POST', [
        'provider' => 'paypal',
        'credentials' => [
            'clientId' => 'test_paypal_client_id_123',
            'secretKey' => 'test_paypal_secret_key_456',
            'environment' => 'sandbox'
        ]
    ]);
    return isset($res['json']['success']);
});

runTest("Payment Gateways Probe (Apple Pay domain association verification)", function() {
    $res = callApi('payment-gateways/verify', 'POST', [
        'provider' => 'apple_pay',
        'credentials' => [
            'merchantId' => 'merchant.com.ezistential.store',
            'domainName' => 'ezistential.com'
        ]
    ]);
    return isset($res['json']['success']) && $res['json']['success'] === true;
});

$placedOrderNum = '';
$placedTxId = '';
runTest("Customer can place order with unique payment transaction reference in MySQL", function() use (&$placedOrderNum, &$placedTxId) {
    global $placedOrderNum, $placedTxId;
    $placedOrderNum = 'EC-MYSQL-' . rand(10000, 99999);
    $placedTxId = 'txn_stripe_pi_' . bin2hex(random_bytes(8));

    $res = callApi('orders', 'POST', [
        'orderNumber' => $placedOrderNum,
        'customerName' => 'Julian Alvarez',
        'customerEmail' => 'julian@example.com',
        'shippingAddress' => [
            'fullName' => 'Julian Alvarez',
            'street' => '742 Evergreen Terrace',
            'city' => 'Springfield',
            'state' => 'OR',
            'zipCode' => '97477',
            'country' => 'US'
        ],
        'subtotal' => 48.00,
        'tax' => 3.12,
        'shippingFee' => 6.00,
        'total' => 57.12,
        'paymentMethod' => 'card',
        'paymentTransactionId' => $placedTxId,
        'items' => [
            [
                'productId' => 'prod-dist-01',
                'productName' => 'The Distance Tee',
                'sku' => 'APL-TEE-6500-BLK-L',
                'wearType' => 'Heavyweight Tee',
                'color' => 'Raw Black',
                'colorHex' => '#0f0f0f',
                'size' => 'L',
                'quantity' => 1,
                'price' => 48.00
            ]
        ]
    ]);

    return isset($res['json']['success']) && $res['json']['success'] === true;
});

runTest("Duplicate payment transaction reference is STRICTLY REJECTED with 409", function() use (&$placedTxId) {
    global $placedTxId;
    $res = callApi('orders', 'POST', [
        'orderNumber' => 'EC-MYSQL-DUP-' . rand(10000, 99999),
        'customerName' => 'Impostor Customer',
        'customerEmail' => 'impostor@example.com',
        'shippingAddress' => ['street' => '123 Fake St', 'city' => 'Nowhere', 'state' => 'CA', 'zipCode' => '90001'],
        'subtotal' => 48.00,
        'total' => 48.00,
        'paymentTransactionId' => $placedTxId, // same transaction ID reused!
        'items' => []
    ]);
    return isset($res['json']['duplicateTransaction']) && $res['json']['duplicateTransaction'] === true;
});

runTest("Server-side payment transaction verification endpoint", function() use (&$placedTxId, &$placedOrderNum) {
    global $placedTxId, $placedOrderNum;
    $res = callApi('payments/verify', 'POST', [
        'provider' => 'stripe',
        'transactionId' => $placedTxId,
        'orderNumber' => $placedOrderNum,
        'amount' => 57.12
    ]);
    return isset($res['json']['verified']) && $res['json']['verified'] === true;
});

runTest("POD Order Fulfillment dispatches order and records provider ID in MySQL", function() use ($adminToken, &$placedOrderNum) {
    global $placedOrderNum;
    $res = callApi("orders/{$placedOrderNum}/fulfill", 'POST', [
        'provider' => 'printful',
        'carrier' => 'USPS Ground Advantage'
    ], ['Authorization' => "Bearer {$adminToken}"]);

    return isset($res['json']['success']) && $res['json']['success'] === true &&
           ($res['json']['alreadyFulfilled'] ?? true) === false &&
           !empty($res['json']['podOrderId']);
});

runTest("DUPLICATE POD fulfillment is PREVENTED and returns alreadyFulfilled", function() use ($adminToken, &$placedOrderNum) {
    global $placedOrderNum;
    $res = callApi("orders/{$placedOrderNum}/fulfill", 'POST', [
        'provider' => 'printful'
    ], ['Authorization' => "Bearer {$adminToken}"]);

    return isset($res['json']['success']) && $res['json']['success'] === true &&
           ($res['json']['alreadyFulfilled'] ?? false) === true;
});

runTest("POD Status Synchronization endpoint returns tracking from database", function() use ($adminToken, &$placedOrderNum) {
    global $placedOrderNum;
    $res = callApi("orders/{$placedOrderNum}/pod-status", 'GET', [], ['Authorization' => "Bearer {$adminToken}"]);
    return isset($res['json']['success']) && $res['json']['success'] === true &&
           !empty($res['json']['podOrderId']) && !empty($res['json']['trackingNumber']);
});

runTest("Installer lockdown protects configuration when installed.lock exists", function() {
    $lockFile = __DIR__ . '/../installer/installed.lock';
    @file_put_contents($lockFile, json_encode(['installed_at' => date('c'), 'test' => true]));
    
    // Test installer script output
    ob_start();
    include __DIR__ . '/../installer/index.php';
    $out = ob_get_clean();

    @unlink($lockFile); // clean up
    return strpos($out, 'Installer Locked for Production Security') !== false;
});

runTest("CLI Admin Tool updates password securely and rejects web invocation", function() use ($adminEmail) {
    // Run CLI tool via exec
    $newPass = 'NewPass_' . bin2hex(random_bytes(4)) . '!';
    $cmd = 'php ' . escapeshellarg(__DIR__ . '/../backend/cli-admin-tool.php') . ' ' . escapeshellarg($adminEmail) . ' ' . escapeshellarg($newPass);
    $out = shell_exec($cmd);

    // Verify authentication succeeds with the newly set password
    $res = callApi('auth/admin-login', 'POST', [
        'email' => $adminEmail,
        'password' => $newPass
    ]);

    return strpos($out, 'SUCCESS:') !== false && isset($res['json']['success']) && $res['json']['success'] === true;
});

runTest("Apache .htaccess protects sensitive files (database.json, schema.sql, .lock, .env)", function() {
    $ht = file_get_contents(__DIR__ . '/../.htaccess');
    return strpos($ht, 'schema') !== false &&
           strpos($ht, '.lock') !== false &&
           strpos($ht, 'cli-admin-tool') !== false &&
           strpos($ht, 'backend/api.php?action=$1') !== false;
});

echo "\n=========================================\n";
echo "MYSQL TEST RESULTS SUMMARY:\n";
echo "Total Tests Executed: {$testsTotal}\n";
echo "Passed: {$testsPassed}\n";
echo "Failed: {$testsFailed}\n";
echo "Pass Rate: " . round(($testsPassed / $testsTotal) * 100, 1) . "%\n";
echo "=========================================\n";

if ($testsFailed > 0) {
    exit(1);
}
