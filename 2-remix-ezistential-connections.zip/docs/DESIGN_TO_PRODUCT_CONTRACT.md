# EZISTENTIAL CONNECTIONS — DESIGN-TO-PRODUCT ARCHITECTURAL CONTRACT
**Version**: 1.0.0 (Production Master Specification)  
**Status**: Authoritative & Stable  
**Domain**: Creative Lab (Design Factory) ↔ Commercial Catalog Engine (Product Studio)

---

## 1. Architectural Separation of Concerns

The Ezistential Connections platform strictly segregates creative conceptualization from commercial commerce:

```
┌───────────────────────────────────────────────────────────┐
│              DESIGN FACTORY (Creative Lab)                │
│  - Concept development & thematic theses                 │
│  - Multi-iteration versioning (artwork, mockups, notes)  │
│  - Suggested garment silhouettes, colors, and sizing     │
│  - NO pricing, customer orders, or inventory management  │
└─────────────────────────────┬─────────────────────────────┘
                              │
               [ PUSH TO PRODUCT STUDIO ]
          (Bridge with Provenance Preservation)
                              │
                              ▼
┌───────────────────────────────────────────────────────────┐
│            PRODUCT STUDIO (Commercial Engine)             │
│  - Authoritative Wear Type, Color, and Size binding       │
│  - Deterministic variant matrix generation & SKUs        │
│  - Commercial pricing, profit margins & POD fulfillment  │
│  - Two Stories architecture (Story A & Story B)          │
│  - Publication readiness validation & draft states       │
└─────────────────────────────┬─────────────────────────────┘
                              │
                              ▼
┌───────────────────────────────────────────────────────────┐
│               STOREFRONT & ORDER PIPELINE                 │
│  - Validated purchasable variant selection               │
│  - Immutable cart & order item snapshots                  │
│  - Idempotent POD order dispatch (Apliiq DTF)             │
└───────────────────────────────────────────────────────────┘
```

---

## 2. Authoritative Data Relationships

### 2.1 Master Libraries (Stable Reference IDs)
All garments and variants must refer to master records via immutable, stable IDs:

- **WearType**: Primary identifier (`id`, e.g. `'wt-heavyweight-tee'`). Contains base cost, default retail price, weight, fabric, and optional `supportedSizes` / `supportedColorIds`.
- **ColorItem**: Primary identifier (`id`, e.g. `'col-obsidian-black'`). Contains display name (`name`), hex code (`hex`), and category.
- **MasterSizeItem**: Primary identifier (`id`, e.g. `'sz-l'`). Contains size name (`name`, e.g. `'L'`), chest measurement (`chestInch`), and length (`lengthInch`).

### 2.2 Product & Variant Model
```typescript
interface ProductVariant {
  id: string;               // Deterministic: `${slug}-${wearTypeId}-${colorId}-${size}`
  sku: string;              // Deterministic: `EC-${slug}-${wtCode}-${size}-${colorCode}`
  wearTypeId: string;       // Authoritative WearType reference
  wearTypeName: string;     // Historical display snapshot
  size: Size;               // Size code
  sizeId?: string;          // Master size reference
  colorId: string;          // Master color reference
  colorName: string;        // Historical color snapshot
  colorHex: string;         // Historical hex snapshot
  priceOverride?: number;   // Silhouette-specific commercial price
  inStock: boolean;         // Current availability flag
  isAvailable: boolean;     // Admin availability switch
  status: 'active' | 'inactive' | 'unsupported';
  inventoryMode: 'pod' | 'stocked' | 'made_to_order';
  quantity?: number;        // Numeric inventory (ONLY for 'stocked' mode; undefined for POD)
  podProvider?: 'apliiq' | 'printful';
  podVariantId?: string;    // External provider manufacturing SKU
}
```

---

## 3. The Controlled Design-to-Product Bridge

### 3.1 Bridge Invocation
A designer selects a specific version in Design Factory and clicks **`[ PUSH TO PRODUCT ]`**.

### 3.2 Duplicate Prevention & Provenance Protection
1. **Source Version Recording**: The generated product stores:
   - `sourceDesignId`: The exact creative concept ID.
   - `sourceDesignVersionId`: The unique iteration ID.
   - `sourceDesignVersionNumber`: The human-readable version number (e.g. `1`, `2`).
2. **Duplicate Detection**:
   - If an existing product already commercializes the specified design and version, the bridge **opens the existing product** for editing rather than silently overwriting it or creating an accidental duplicate.
   - Intentional new editions can be created with `forceNewEdition: true`.
3. **Safe Draft Initiation**:
   - Pushed products **always initiate in `readinessStatus: 'draft'`** and `isAvailable: false`.
   - The Storefront will never display or sell incomplete drafts until the administrator validates and publishes them.

### 3.3 Bridge REST API Contract
```http
POST /api/designs/:id/push-to-product
Content-Type: application/json

{
  "versionNumber": 2,
  "forceNewEdition": false
}
```

**Response (Already Commercialized)**:
```json
{
  "success": true,
  "alreadyExists": true,
  "message": "Design already commercialized as product. Loaded existing record.",
  "product": { "id": "prod-boundary-04", "name": "The Boundary Longsleeve", ... }
}
```

**Response (New Commercial Draft)**:
```json
{
  "success": true,
  "alreadyExists": false,
  "message": "Successfully created commercial product draft from design.",
  "product": { "id": "prod-from-des-01-...", "readinessStatus": "draft", "isAvailable": false, ... }
}
```

---

## 4. Publication Readiness Validation

Before a product can transition from `draft` to `published`, `validateProductReadiness(product)` enforces:
1. Product title (`name`) and valid `slug` present.
2. Base price is numeric and greater than $0.
3. Primary image URL provided.
4. At least one silhouette / Wear Type selected.
5. Commercial variant matrix generated with **at least one `active` purchasable variant**.
6. For automated POD fulfillment, active variants must have `podVariantId` mapped.

---

## 5. Storefront & Order Protection

### 5.1 Variant Purchasability
The Storefront checks `isVariantPurchasable(variant)` before permitting cart additions:
- Variants marked `'unsupported'` or `'inactive'` cannot be added to the cart.
- Disabled products or draft concepts show clear advisories ("Draft Catalog Concept (Not for Sale)" or "Silhouette / Colorway Unsupported").

### 5.2 Immutable Order Snapshots
When a purchase completes:
- `OrderItem` records a full, immutable freeze of:
  - `wearTypeId`, `wearTypeName`
  - `colorId`, `color`, `colorHex`
  - `size`, `sizeId`
  - `sku`, `podVariantId`
  - `price` (historical transaction price)
- Future price edits or renaming of Wear Types in the CMS **never alters historical orders**.

### 5.3 Idempotent POD Fulfillment
```http
POST /api/orders/:id/fulfill
Content-Type: application/json

{
  "provider": "apliiq",
  "idempotencyKey": "idem-k82f91a"
}
```
- If an order has already been submitted to POD (`status: 'Submitted to POD'` or `status: 'In Production'`), the server returns `{ success: true, alreadyFulfilled: true }` and prevents duplicate charges or manufacturing runs.

---

## 6. PHP / MySQL Backend Boundary Independence

The frontend data layer communicates through normalized REST endpoints. All business logic in `src/lib/productNormalization.ts` is purely functional and mirrors the schema needed for a standard PHP REST backend:
- `api.getProducts()` ↔ `GET /api/products` (MySQL `products` + `variants` JOIN)
- `api.updateProduct()` ↔ `PUT /api/products/:id`
- `api.createOrder()` ↔ `POST /api/orders`
- `api.fulfillOrder()` ↔ `POST /api/orders/:id/fulfill`

No Node.js-exclusive features or runtime state dependencies exist that would prevent direct deployment to standard Apache/PHP/MySQL cPanel hosting.
