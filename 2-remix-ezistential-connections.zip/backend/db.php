<?php
/**
 * Ezistential Connections — Database Connection Engine (PDO MySQL)
 * Target: cPanel / PHP 7.4+ / MySQL 5.7+ / 8.0+
 */

if (php_sapi_name() !== 'cli' && !headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
}

// Load config from file or environment
$configPath = __DIR__ . '/config.php';
$loadedConfig = null;
if (file_exists($configPath)) {
    $loadedConfig = require $configPath;
}

if (!is_array($loadedConfig)) {
    $loadedConfig = [];
}

$dbHost = $loadedConfig['db_host'] ?? (defined('DB_HOST') ? DB_HOST : (getenv('DB_HOST') ?: '127.0.0.1'));
$dbPort = $loadedConfig['db_port'] ?? (defined('DB_PORT') ? DB_PORT : (getenv('DB_PORT') ?: 3306));
$dbName = $loadedConfig['db_name'] ?? (defined('DB_NAME') ? DB_NAME : (getenv('DB_NAME') ?: 'ezistential_db'));
$dbUser = $loadedConfig['db_user'] ?? (defined('DB_USER') ? DB_USER : (getenv('DB_USER') ?: 'root'));
$dbPass = $loadedConfig['db_pass'] ?? (defined('DB_PASS') ? DB_PASS : (getenv('DB_PASS') ?: ''));
$dbCharset = $loadedConfig['db_charset'] ?? (defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4');

class Database {
    private static ?PDO $instance = null;

    public static function setConnection(?PDO $pdo): void {
        self::$instance = $pdo;
    }

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            $configPath = __DIR__ . '/config.php';
            $loadedConfig = [];
            if (file_exists($configPath)) {
                $c = require $configPath;
                if (is_array($c)) $loadedConfig = $c;
            }

            $driver = $loadedConfig['db_driver'] ?? (getenv('DB_DRIVER') ?: 'mysql');

            if ($driver === 'sqlite') {
                $sqlitePath = $loadedConfig['sqlite_path'] ?? (getenv('SQLITE_PATH') ?: (__DIR__ . '/test_database.sqlite'));
                try {
                    self::$instance = new PDO('sqlite:' . $sqlitePath, null, null, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    ]);
                    self::$instance->exec("PRAGMA foreign_keys = ON;");
                    return self::$instance;
                } catch (PDOException $e) {
                    http_response_code(500);
                    echo json_encode([
                        'success' => false,
                        'error' => 'SQLite connection failed: ' . $e->getMessage()
                    ]);
                    exit;
                }
            }

            $dbHost = getenv('DB_HOST') ?: ($loadedConfig['db_host'] ?? (defined('DB_HOST') ? DB_HOST : '127.0.0.1'));
            $dbPort = getenv('DB_PORT') ?: ($loadedConfig['db_port'] ?? (defined('DB_PORT') ? DB_PORT : 3306));
            $dbName = getenv('DB_NAME') ?: ($loadedConfig['db_name'] ?? (defined('DB_NAME') ? DB_NAME : 'ezistential_db'));
            $dbUser = getenv('DB_USER') ?: ($loadedConfig['db_user'] ?? (defined('DB_USER') ? DB_USER : 'root'));
            $dbPass = getenv('DB_PASS') !== false ? getenv('DB_PASS') : ($loadedConfig['db_pass'] ?? (defined('DB_PASS') ? DB_PASS : ''));
            $dbCharset = getenv('DB_CHARSET') ?: ($loadedConfig['db_charset'] ?? (defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4'));

            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                $dbHost,
                $dbPort,
                $dbName,
                $dbCharset ?: 'utf8mb4'
            );

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];

            try {
                self::$instance = new PDO($dsn, $dbUser, $dbPass, $options);
            } catch (PDOException $e) {
                // If in testing environment and DB_DRIVER not explicitly mysql, check if sqlite fallback is requested
                if (getenv('ALLOW_SQLITE_FALLBACK') === 'true') {
                    $sqlitePath = __DIR__ . '/test_database.sqlite';
                    self::$instance = new PDO('sqlite:' . $sqlitePath, null, null, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    ]);
                    return self::$instance;
                }

                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'error' => 'Database connection failed: ' . $e->getMessage()
                ]);
                exit;
            }
        }

        return self::$instance;
    }
}

function getDB(): PDO {
    return Database::getConnection();
}
