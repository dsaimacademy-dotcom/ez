<?php
/**
 * Ezistential Connections — Production MySQL & Environment Configuration
 * Version: 1.0.0
 * Target: cPanel / Apache 2.4+ / PHP 7.4 - 8.3+
 */

$dbHost = getenv('DB_HOST') ?: 'localhost';
$dbName = getenv('DB_NAME') ?: 'ezistential_store';
$dbUser = getenv('DB_USER') ?: 'ezistential_user';
$dbPass = getenv('DB_PASS') ?: 'ChangeMeSecurely2026!';
$dbPort = getenv('DB_PORT') ?: 3306;
$dbCharset = 'utf8mb4';
$authSecret = getenv('EC_AUTH_SECRET') ?: hash('sha256', ($dbHost . $dbName . $dbPass . 'Ezistential_Production_Secret_Salt_9981'));

if (!defined('DB_HOST')) define('DB_HOST', $dbHost);
if (!defined('DB_NAME')) define('DB_NAME', $dbName);
if (!defined('DB_USER')) define('DB_USER', $dbUser);
if (!defined('DB_PASS')) define('DB_PASS', $dbPass);
if (!defined('DB_PORT')) define('DB_PORT', $dbPort);
if (!defined('DB_CHARSET')) define('DB_CHARSET', $dbCharset);
if (!defined('AUTH_SECRET_KEY')) define('AUTH_SECRET_KEY', $authSecret);

// Production Error Handling
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

return [
    'db_host' => $dbHost,
    'db_name' => $dbName,
    'db_user' => $dbUser,
    'db_pass' => $dbPass,
    'db_port' => $dbPort,
    'db_charset' => $dbCharset,
    'auth_secret' => $authSecret,
];
