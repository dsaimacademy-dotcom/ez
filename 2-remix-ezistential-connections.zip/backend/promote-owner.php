<?php
/**
 * Ezistential Connections — Controlled Owner-Account Promotion CLI Tool
 * 
 * Safely promotes an existing verified user account to 'superadmin'.
 * 
 * SECURITY:
 * - Strictly CLI only (Web access is blocked).
 * - Requires explicit email argument and interactive or flag-based confirmation.
 * - Does NOT alter, reset, or expose the user's password.
 * - Increments token_version so existing sessions are refreshed.
 * - Logs the promotion in the immutable admin_activity_log.
 * 
 * Usage:
 *   php backend/promote-owner.php <user_email> [--confirm]
 * 
 * Example:
 *   php backend/promote-owner.php admin@ezistential.com --confirm
 */

if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    echo "ERROR: This tool may only be executed via the server command line interface (CLI).\n";
    exit(1);
}

require_once __DIR__ . '/db.php';

$email = $argv[1] ?? null;
$confirmFlag = ($argv[2] ?? '') === '--confirm';

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Usage:\n";
    echo "  php " . basename(__FILE__) . " <user_email> [--confirm]\n\n";
    echo "Example:\n";
    echo "  php " . basename(__FILE__) . " admin@ezistential.com --confirm\n";
    exit(1);
}

try {
    $db = Database::getConnection();
    $normalizedEmail = strtolower(trim($email));

    // 1. Locate the existing user
    $stmt = $db->prepare("SELECT id, email, name, role, status, token_version FROM users WHERE LOWER(email) = ?");
    $stmt->execute([$normalizedEmail]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo "ERROR: User account '{$normalizedEmail}' not found in the database.\n";
        echo "Ensure the user has first registered or been provisioned before promoting to Superadmin.\n";
        exit(1);
    }

    if ($user['role'] === 'superadmin' && $user['status'] === 'active') {
        echo "NOTICE: User '{$user['email']}' is ALREADY an active Superadmin.\n";
        exit(0);
    }

    if (!$confirmFlag) {
        echo "=======================================================\n";
        echo "CONFIRM SUPERADMIN OWNER PROMOTION\n";
        echo "=======================================================\n";
        echo "User ID:      {$user['id']}\n";
        echo "Full Name:    {$user['name']}\n";
        echo "Email:        {$user['email']}\n";
        echo "Current Role: {$user['role']}\n";
        echo "Status:       {$user['status']}\n";
        echo "-------------------------------------------------------\n";
        echo "WARNING: Superadmin role grants unrestricted platform control,\n";
        echo "including staff management, payment credentials, and database operations.\n";
        echo "Password will be preserved intact. Sessions will be refreshed.\n";
        echo "-------------------------------------------------------\n";
        echo "To proceed, run this command with the --confirm flag:\n";
        echo "  php " . basename(__FILE__) . " {$user['email']} --confirm\n";
        exit(1);
    }

    // 2. Perform promotion
    $newTokenVersion = ((int)($user['token_version'] ?? 1)) + 1;
    $upd = $db->prepare("
        UPDATE users SET
            role = 'superadmin',
            status = 'active',
            token_version = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ");
    $upd->execute([$newTokenVersion, $user['id']]);

    // 3. Log event to admin_activity_log
    $logId = 'log-pro-' . bin2hex(random_bytes(6));
    $logStmt = $db->prepare("
        INSERT INTO admin_activity_log (id, user_id, user_email, user_role, action, target_entity, target_id, details)
        VALUES (?, 'cli-tool', 'system@cli', 'system', 'user.promote_superadmin', 'user', ?, ?)
    ");
    $logStmt->execute([
        $logId,
        $user['id'],
        json_encode([
            'promoted_user_id' => $user['id'],
            'promoted_user_email' => $user['email'],
            'previous_role' => $user['role'],
            'new_role' => 'superadmin',
            'action_performed_via' => 'CLI owner promotion procedure'
        ])
    ]);

    echo "SUCCESS: Account '{$user['email']}' successfully promoted to 'superadmin'.\n";
    echo "Existing password and credentials remain intact.\n";
    echo "Active sessions incremented to token version {$newTokenVersion}.\n";
} catch (Exception $e) {
    echo "ERROR: Promotion failed: " . $e->getMessage() . "\n";
    exit(1);
}
