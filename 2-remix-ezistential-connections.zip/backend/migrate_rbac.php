<?php
/**
 * Ezistential Connections — Database Migration: RBAC & Security Hardening
 * 
 * Safely adds RBAC columns, account status, token versioning, and activity logging.
 * Compatible with MySQL 5.7+, MySQL 8.0+, MariaDB 10.3+, and SQLite.
 * 
 * Safety Guarantees:
 * - 100% non-destructive: Does NOT drop tables or existing data.
 * - Idempotent: Can be safely executed multiple times.
 * - Inspects column metadata before issuing ALTER TABLE statements.
 * - Preserves existing passwords, roles, orders, and customer records.
 * - Does NOT auto-promote accounts; promotion is handled via promote-owner.php.
 */

if (php_sapi_name() !== 'cli') {
    // Web execution safeguard: only allow CLI or authenticated administrator
    require_once __DIR__ . '/api.php';
    if (!isAdminAuthorized()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Migration can only be run via CLI or by an authorized administrator.']);
        exit;
    }
}

require_once __DIR__ . '/db.php';

try {
    $db = Database::getConnection();
    $driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);

    $results = [];

    // ========================================================
    // 1. EXTEND OR UPDATE USERS TABLE
    // ========================================================
    if ($driver === 'sqlite') {
        // Query SQLite table schema
        $cols = $db->query("PRAGMA table_info(users)")->fetchAll(PDO::FETCH_ASSOC);
        $existingCols = array_column($cols, 'name');

        if (!in_array('status', $existingCols)) {
            $db->exec("ALTER TABLE users ADD COLUMN status TEXT DEFAULT 'active'");
            $results[] = "Added column 'status' to users (SQLite)";
        }
        if (!in_array('token_version', $existingCols)) {
            $db->exec("ALTER TABLE users ADD COLUMN token_version INTEGER DEFAULT 1");
            $results[] = "Added column 'token_version' to users (SQLite)";
        }
        if (!in_array('custom_permissions', $existingCols)) {
            $db->exec("ALTER TABLE users ADD COLUMN custom_permissions TEXT NULL");
            $results[] = "Added column 'custom_permissions' to users (SQLite)";
        }
        if (!in_array('created_by_user_id', $existingCols)) {
            $db->exec("ALTER TABLE users ADD COLUMN created_by_user_id TEXT NULL");
            $results[] = "Added column 'created_by_user_id' to users (SQLite)";
        }
        if (!in_array('last_login_at', $existingCols)) {
            $db->exec("ALTER TABLE users ADD COLUMN last_login_at TEXT NULL");
            $results[] = "Added column 'last_login_at' to users (SQLite)";
        }
        if (!in_array('password_changed_at', $existingCols)) {
            $db->exec("ALTER TABLE users ADD COLUMN password_changed_at TEXT NULL");
            $results[] = "Added column 'password_changed_at' to users (SQLite)";
        }
        if (!in_array('force_password_change', $existingCols)) {
            $db->exec("ALTER TABLE users ADD COLUMN force_password_change INTEGER DEFAULT 0");
            $results[] = "Added column 'force_password_change' to users (SQLite)";
        }
    } else {
        // MySQL / MariaDB Inspection
        $dbNameStmt = $db->query("SELECT DATABASE()");
        $currentDb = $dbNameStmt->fetchColumn();

        $stmt = $db->prepare("
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users'
        ");
        $stmt->execute([$currentDb]);
        $existingCols = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // Modify role ENUM to support all 6 canonical roles + legacy admin
        try {
            $db->exec("
                ALTER TABLE `users` 
                MODIFY COLUMN `role` ENUM('superadmin', 'admin', 'manager', 'fulfillment', 'editor', 'moderator', 'customer') 
                NOT NULL DEFAULT 'customer'
            ");
            $results[] = "Updated 'role' ENUM to include 'superadmin', 'manager', 'fulfillment', 'editor', 'moderator', 'customer'";
        } catch (Exception $e) {
            $results[] = "Notice: role column modification skipped or already updated: " . $e->getMessage();
        }

        // Add missing columns one by one
        if (!in_array('status', $existingCols)) {
            $db->exec("ALTER TABLE `users` ADD COLUMN `status` ENUM('active', 'suspended', 'pending') NOT NULL DEFAULT 'active' AFTER `role`");
            $results[] = "Added column 'status' to users";
        }
        if (!in_array('token_version', $existingCols)) {
            $db->exec("ALTER TABLE `users` ADD COLUMN `token_version` INT UNSIGNED NOT NULL DEFAULT 1 AFTER `status`");
            $results[] = "Added column 'token_version' to users";
        }
        if (!in_array('custom_permissions', $existingCols)) {
            $db->exec("ALTER TABLE `users` ADD COLUMN `custom_permissions` JSON NULL AFTER `token_version`");
            $results[] = "Added column 'custom_permissions' to users";
        }
        if (!in_array('created_by_user_id', $existingCols)) {
            $db->exec("ALTER TABLE `users` ADD COLUMN `created_by_user_id` VARCHAR(64) NULL AFTER `custom_permissions`");
            $results[] = "Added column 'created_by_user_id' to users";
        }
        if (!in_array('last_login_at', $existingCols)) {
            $db->exec("ALTER TABLE `users` ADD COLUMN `last_login_at` DATETIME NULL AFTER `created_by_user_id`");
            $results[] = "Added column 'last_login_at' to users";
        }
        if (!in_array('password_changed_at', $existingCols)) {
            $db->exec("ALTER TABLE `users` ADD COLUMN `password_changed_at` DATETIME NULL AFTER `last_login_at`");
            $results[] = "Added column 'password_changed_at' to users";
        }
        if (!in_array('force_password_change', $existingCols)) {
            $db->exec("ALTER TABLE `users` ADD COLUMN `force_password_change` TINYINT(1) NOT NULL DEFAULT 0 AFTER `password_changed_at`");
            $results[] = "Added column 'force_password_change' to users";
        }

        // Add index on role & status if not present
        try {
            $idxStmt = $db->prepare("
                SELECT COUNT(1) 
                FROM INFORMATION_SCHEMA.STATISTICS 
                WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users' AND INDEX_NAME = 'idx_user_role_status'
            ");
            $idxStmt->execute([$currentDb]);
            if ($idxStmt->fetchColumn() == 0) {
                $db->exec("ALTER TABLE `users` ADD INDEX `idx_user_role_status` (`role`, `status`)");
                $results[] = "Added index 'idx_user_role_status' to users";
            }
        } catch (Exception $e) {
            // Ignore index creation errors
        }
    }

    // ========================================================
    // 2. CREATE ADMIN_ACTIVITY_LOG TABLE
    // ========================================================
    if ($driver === 'sqlite') {
        $db->exec("
            CREATE TABLE IF NOT EXISTS admin_activity_log (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                user_email TEXT NOT NULL,
                user_role TEXT NOT NULL,
                action TEXT NOT NULL,
                target_entity TEXT NOT NULL,
                target_id TEXT,
                details TEXT,
                ip_address TEXT,
                user_agent TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
        $results[] = "Ensured table 'admin_activity_log' exists (SQLite)";
    } else {
        $db->exec("
            CREATE TABLE IF NOT EXISTS `admin_activity_log` (
                `id` VARCHAR(64) NOT NULL,
                `user_id` VARCHAR(64) NOT NULL,
                `user_email` VARCHAR(255) NOT NULL,
                `user_role` VARCHAR(50) NOT NULL,
                `action` VARCHAR(100) NOT NULL,
                `target_entity` VARCHAR(50) NOT NULL,
                `target_id` VARCHAR(64) NULL,
                `details` JSON NULL,
                `ip_address` VARCHAR(45) NULL,
                `user_agent` VARCHAR(255) NULL,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                INDEX `idx_log_user` (`user_id`),
                INDEX `idx_log_action` (`action`),
                INDEX `idx_log_created` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $results[] = "Ensured table 'admin_activity_log' exists (MySQL)";
    }

    // Record migration in activity log
    $logId = 'log-mig-' . bin2hex(random_bytes(6));
    $insLog = $db->prepare("
        INSERT INTO admin_activity_log (id, user_id, user_email, user_role, action, target_entity, details)
        VALUES (?, 'system', 'system@ezistential.internal', 'system', 'system.migration_rbac', 'database', ?)
    ");
    $insLog->execute([$logId, json_encode(['results' => $results, 'timestamp' => date('Y-m-d H:i:s')])]);

    $response = [
        'success' => true,
        'message' => 'RBAC schema migration completed successfully.',
        'results' => $results
    ];

    if (php_sapi_name() === 'cli') {
        echo "=== EZISTENTIAL CONNECTIONS RBAC MIGRATION COMPLETED ===\n";
        foreach ($results as $r) {
            echo " - {$r}\n";
        }
        echo "Migration status: SUCCESS\n";
    } else {
        echo json_encode($response);
    }
} catch (Exception $e) {
    if (php_sapi_name() === 'cli') {
        echo "ERROR: Migration failed: " . $e->getMessage() . "\n";
        exit(1);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}
