-- Ezistential Connections — Complete MySQL Production Database Schema
-- Target: MySQL 5.7+ / 8.0+ / MariaDB 10.3+ (cPanel Compatible)
-- Engine: InnoDB with UTF8MB4 Full Unicode Support

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------
-- 1. Master Wear Types (Silhouettes & Blanks)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wear_types` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `wholesale_cost` DECIMAL(10,2) NOT NULL DEFAULT 18.50,
  `default_retail_price` DECIMAL(10,2) NOT NULL DEFAULT 48.00,
  `fabric_weight` VARCHAR(100) NOT NULL DEFAULT '6.5oz / 220 GSM Combed Cotton',
  `fit_profile` VARCHAR(100) NOT NULL DEFAULT 'Architectural Relaxed Boxy Fit',
  `primary_provider` ENUM('apliiq', 'printful', 'custom') NOT NULL DEFAULT 'apliiq',
  `base_garment_code` VARCHAR(100) NOT NULL DEFAULT 'APL-TEE-6500',
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 2. Master Color Library
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `colors` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `hex` VARCHAR(10) NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 3. Master Size Scale
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sizes` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(20) NOT NULL,
  `chest_inches` DECIMAL(5,1) NULL,
  `length_inches` DECIMAL(5,1) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 4. Creative Lab Design Drafts
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `designs` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `thesis` TEXT NULL,
  `status` ENUM('draft', 'in_review', 'approved', 'archived') NOT NULL DEFAULT 'draft',
  `approved_version_id` VARCHAR(64) NULL,
  `suggested_wear_types` JSON NULL,
  `suggested_colors` JSON NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 5. Design Version Iterations & Artwork Files
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `design_versions` (
  `id` VARCHAR(64) NOT NULL,
  `design_id` VARCHAR(64) NOT NULL,
  `version_number` INT NOT NULL DEFAULT 1,
  `artwork_front_url` TEXT NULL,
  `artwork_back_url` TEXT NULL,
  `artwork_sleeve_url` TEXT NULL,
  `artwork_preview_url` TEXT NULL,
  `notes` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_design_id` (`design_id`),
  CONSTRAINT `fk_versions_design` FOREIGN KEY (`design_id`) REFERENCES `designs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 6. Commercial Catalog Products
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `category` VARCHAR(100) NOT NULL DEFAULT 'Tees',
  `collection_name` VARCHAR(100) NOT NULL DEFAULT 'Inaugural Concept',
  `base_price` DECIMAL(10,2) NOT NULL DEFAULT 48.00,
  `wholesale_cost` DECIMAL(10,2) NOT NULL DEFAULT 18.50,
  `status` ENUM('draft', 'published', 'archived') NOT NULL DEFAULT 'published',
  `is_ready_for_pod` TINYINT(1) NOT NULL DEFAULT 1,
  `story_a_thesis` TEXT NULL,
  `story_a_meaning` TEXT NULL,
  `story_a_wearer_role` TEXT NULL,
  `story_a_contemplation` TEXT NULL,
  `story_b_fabric_spec` TEXT NULL,
  `story_b_weight_gsm` VARCHAR(100) NULL,
  `story_b_fit_notes` TEXT NULL,
  `story_b_print_method` VARCHAR(150) NULL,
  `primary_image_url` TEXT NOT NULL,
  `gallery_urls` JSON NULL,
  `source_design_id` VARCHAR(64) NULL,
  `source_design_version_id` VARCHAR(64) NULL,
  `source_design_version_number` INT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_product_slug` (`slug`),
  INDEX `idx_source_design` (`source_design_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 7. Product Variants (Specific SKU combinations)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `product_variants` (
  `id` VARCHAR(64) NOT NULL,
  `product_id` VARCHAR(64) NOT NULL,
  `sku` VARCHAR(100) NOT NULL UNIQUE,
  `wear_type_id` VARCHAR(64) NOT NULL,
  `wear_type_name` VARCHAR(255) NOT NULL,
  `size` VARCHAR(20) NOT NULL,
  `color_id` VARCHAR(64) NOT NULL,
  `color_name` VARCHAR(100) NOT NULL,
  `color_hex` VARCHAR(10) NOT NULL,
  `price_override` DECIMAL(10,2) NULL,
  `in_stock` TINYINT(1) NOT NULL DEFAULT 1,
  `is_available` TINYINT(1) NOT NULL DEFAULT 1,
  `status` ENUM('active', 'inactive', 'discontinued') NOT NULL DEFAULT 'active',
  `inventory_mode` ENUM('pod', 'on_hand', 'preorder') NOT NULL DEFAULT 'pod',
  `pod_provider` ENUM('apliiq', 'printful', 'custom') NOT NULL DEFAULT 'apliiq',
  `pod_product_id` VARCHAR(100) NULL,
  `pod_variant_id` VARCHAR(100) NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_variant_product` (`product_id`),
  CONSTRAINT `fk_variants_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 8. Customer Orders & Fulfillment Records
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `orders` (
  `id` VARCHAR(64) NOT NULL,
  `order_number` VARCHAR(50) NOT NULL UNIQUE,
  `customer_name` VARCHAR(255) NOT NULL,
  `customer_email` VARCHAR(255) NOT NULL,
  `shipping_address` JSON NOT NULL,
  `subtotal` DECIMAL(10,2) NOT NULL,
  `tax_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `shipping_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'USD',
  `payment_method` VARCHAR(50) NOT NULL DEFAULT 'card',
  `payment_status` ENUM('Pending', 'Paid', 'Failed', 'Refunded') NOT NULL DEFAULT 'Pending',
  `payment_transaction_id` VARCHAR(150) NULL,
  `status` ENUM('Pending Payment', 'Paid', 'Submitted to POD', 'In Production', 'Shipped', 'Delivered', 'Cancelled') NOT NULL DEFAULT 'Pending Payment',
  `pod_provider` ENUM('apliiq', 'printful', 'manual') NOT NULL DEFAULT 'apliiq',
  `pod_order_id` VARCHAR(100) NULL,
  `idempotency_key` VARCHAR(100) NULL,
  `tracking_number` VARCHAR(100) NULL,
  `tracking_carrier` VARCHAR(100) NULL DEFAULT 'USPS',
  `tracking_url` TEXT NULL,
  `submitted_to_pod_at` DATETIME NULL,
  `shipped_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_order_number` (`order_number`),
  INDEX `idx_customer_email` (`customer_email`),
  INDEX `idx_payment_tx` (`payment_transaction_id`),
  INDEX `idx_idempotency` (`idempotency_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 9. Immutable Order Items (Point-in-Time Snapshot)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` VARCHAR(64) NOT NULL,
  `order_id` VARCHAR(64) NOT NULL,
  `product_id` VARCHAR(64) NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `sku` VARCHAR(100) NOT NULL,
  `wear_type_name` VARCHAR(255) NOT NULL,
  `color_name` VARCHAR(100) NOT NULL,
  `color_hex` VARCHAR(10) NOT NULL,
  `size` VARCHAR(20) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(10,2) NOT NULL,
  `pod_variant_id` VARCHAR(100) NULL,
  `artwork_url` TEXT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_items_order` (`order_id`),
  CONSTRAINT `fk_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 10. Community Reflection Archive (Voices of Encounters)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reflections` (
  `id` VARCHAR(64) NOT NULL,
  `product_id` VARCHAR(64) NULL,
  `product_name` VARCHAR(255) NOT NULL DEFAULT 'The Distance Tee',
  `author_name` VARCHAR(255) NOT NULL DEFAULT 'Anonymous',
  `author_location` VARCHAR(255) NOT NULL DEFAULT 'Public Space',
  `email` VARCHAR(255) NULL,
  `response` TEXT NOT NULL,
  `photo_url` TEXT NULL,
  `photo_caption` TEXT NULL,
  `garment_on_body_size` VARCHAR(20) NULL DEFAULT 'L',
  `permission_granted` TINYINT(1) NOT NULL DEFAULT 1,
  `status` ENUM('Approved', 'Pending Review', 'Rejected') NOT NULL DEFAULT 'Pending Review',
  `featured_quote` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 11. Customer Accounts & Multi-Device Profiles
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(64) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NULL,
  `name` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(50) NULL,
  `saved_items` JSON NULL,
  `shipping_address` JSON NULL,
  `role` ENUM('superadmin', 'admin', 'manager', 'fulfillment', 'editor', 'moderator', 'customer') NOT NULL DEFAULT 'customer',
  `status` ENUM('active', 'suspended', 'pending') NOT NULL DEFAULT 'active',
  `token_version` INT UNSIGNED NOT NULL DEFAULT 1,
  `custom_permissions` JSON NULL,
  `created_by_user_id` VARCHAR(64) NULL,
  `last_login_at` DATETIME NULL,
  `password_changed_at` DATETIME NULL,
  `force_password_change` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_user_email` (`email`),
  INDEX `idx_user_role_status` (`role`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 11b. Immutable Administrative Activity & Security Log
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_activity_log` (
  `id` VARCHAR(64) NOT NULL,
  `user_id` VARCHAR(64) NOT NULL,
  `user_email` VARCHAR(255) NOT NULL,
  `user_role` VARCHAR(50) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `target_entity` VARCHAR(50) NOT NULL,
  `target_id` VARCHAR(64) NULL,
  `details` JSON NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_log_user` (`user_id`),
  INDEX `idx_log_action` (`action`),
  INDEX `idx_log_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 12. Global Site Content, Branding & Integration Settings
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_content` (
  `config_key` VARCHAR(100) NOT NULL,
  `config_value` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 13. FAQs
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `faqs` (
  `id` VARCHAR(64) NOT NULL,
  `category` VARCHAR(100) NOT NULL DEFAULT 'General',
  `question` VARCHAR(255) NOT NULL,
  `answer` TEXT NOT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 14. Journal & Brand Updates
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `blog_posts` (
  `id` VARCHAR(64) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `excerpt` TEXT NOT NULL,
  `content` LONGTEXT NOT NULL,
  `author` VARCHAR(100) NOT NULL DEFAULT 'Ezistential Studio',
  `published_at` VARCHAR(50) NOT NULL,
  `read_time` VARCHAR(50) NOT NULL DEFAULT '3 min read',
  `tags` JSON NULL,
  `status` ENUM('published', 'draft') NOT NULL DEFAULT 'published',
  `cover_image` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 15. Master Seed Data (Initial Library Initialization)
-- --------------------------------------------------------

INSERT IGNORE INTO `wear_types` (`id`, `name`, `description`, `wholesale_cost`, `default_retail_price`, `fabric_weight`, `fit_profile`, `primary_provider`, `base_garment_code`, `active`) VALUES
('wt-heavyweight-tee', '6.5oz Heavyweight Boxy Tee', '100% Organic Combed Ringspun Cotton. Drop-shoulder boxy architectural cut.', 18.50, 48.00, '6.5 oz / 220 GSM', 'Relaxed Boxy Fit', 'apliiq', 'APL-TEE-6500', 1),
('wt-boxy-hoodie', '14oz Architectural Boxy Hoodie', '100% Heavyweight French Terry Cotton. Seamless drop-shoulder, double-lined hood.', 34.00, 88.00, '14 oz / 460 GSM', 'Oversized Boxy Drape', 'apliiq', 'APL-HD-1400', 1),
('wt-drop-crewneck', '12oz Drop-Shoulder Crewneck', '100% Brushed Fleece Cotton with reinforced collar and storm cuffs.', 28.50, 74.00, '12 oz / 380 GSM', 'Classic Relaxed Boxy', 'apliiq', 'APL-CRW-1200', 1),
('wt-ribbed-longsleeve', '7oz Ribbed Long Sleeve Tee', '100% Combed Ringspun Cotton with 2x1 ribbed cuffs and tailored hemline.', 22.00, 58.00, '7 oz / 240 GSM', 'Clean Architectural Drop', 'apliiq', 'APL-LS-7000', 1);

INSERT IGNORE INTO `colors` (`id`, `name`, `hex`, `active`, `sort_order`) VALUES
('color-black', 'Raw Black', '#0f0f0f', 1, 1),
('color-bone', 'Bone Off-White', '#f2f0eb', 1, 2),
('color-charcoal', 'Washed Charcoal', '#303030', 1, 3),
('color-natural', 'Natural Undyed', '#e8e5dc', 1, 4),
('color-earth', 'Earthy Ochre', '#8c6239', 1, 5),
('color-slate', 'Slate Blue', '#3a4a59', 1, 6);

INSERT IGNORE INTO `sizes` (`id`, `name`, `chest_inches`, `length_inches`, `sort_order`, `active`) VALUES
('size-xs', 'XS', 35.0, 27.0, 1, 1),
('size-s', 'S', 37.0, 28.0, 2, 1),
('size-m', 'M', 41.0, 29.0, 3, 1),
('size-l', 'L', 45.0, 30.0, 4, 1),
('size-xl', 'XL', 49.0, 31.0, 5, 1),
('size-2xl', '2XL', 53.0, 32.0, 6, 1),
('size-3xl', '3XL', 57.0, 33.0, 7, 1);

INSERT IGNORE INTO `site_content` (`config_key`, `config_value`) VALUES
('brandName', '"Ezistential Connections"'),
('brandShortName', '"Ezistential"'),
('legalBusinessName', '"Ezistential Connections LLC"'),
('brandTagline', '"The Space Between People"'),
('brandLogoUrl', '"/ez-logo.svg"'),
('brandLogoDarkUrl', '"/ez-logo-white.svg"'),
('faviconUrl', '"/ez-favicon.svg"'),
('pageTitleTemplate', '"Ezistential Connections — Space Between People"'),
('metaDescription', '"Brand-led apparel exploring the space between people, human connection, identity, and difference."'),
('supportEmail', '"care@ezistential.com"'),
('ordersEmail', '"orders@ezistential.com"'),
('freeShippingThreshold', '75'),
('standardShippingRate', '6.00');

-- --------------------------------------------------------
-- 16. Default User Accounts (Superadmin & Demo Member)
-- --------------------------------------------------------
INSERT IGNORE INTO `users` (`id`, `email`, `password_hash`, `name`, `phone`, `role`, `status`, `token_version`, `saved_items`) VALUES
('usr-superadmin-01', 'alex@ezistential.com', '$2y$10$wT8hM5f5gD1C9Wn6e9nE7u1Zq0QY.Wf4J9E3pC6X2O1K8R7m9A6y2', 'Alex Vance', '(312) 555-0100', 'superadmin', 'active', 1, '{"id":"usr-superadmin-01","email":"alex@ezistential.com","fullName":"Alex Vance","role":"superadmin","status":"active"}'),
('usr-marcus-01', 'marcus@example.com', '$2y$10$wT8hM5f5gD1C9Wn6e9nE7u1Zq0QY.Wf4J9E3pC6X2O1K8R7m9A6y2', 'Marcus Vance', '(312) 555-0192', 'customer', 'active', 1, '{"id":"usr-marcus-01","fullName":"Marcus Vance","email":"marcus@example.com","location":"Chicago, IL","avatarUrl":"https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80","bio":"Architect of quiet spaces and everyday observations.","role":"customer","status":"active","addresses":[{"id":"addr-01","isDefault":true,"label":"Primary Residence","fullName":"Marcus Vance","street":"1842 N Damen Ave","apartment":"Apt 3F","city":"Chicago","state":"IL","zipCode":"60647","country":"US","phone":"(312) 555-0192"},{"id":"addr-02","isDefault":false,"label":"Design Studio","fullName":"Marcus Vance","street":"410 S Michigan Ave","apartment":"Suite 804","city":"Chicago","state":"IL","zipCode":"60605","country":"US"}],"savedGarments":[{"id":"prod-connection-03","productId":"prod-connection-03","savedAt":"2026-03-15T09:12:00.000Z","note":"Considering for the spring dialogue series in Vermont.","preferredSize":"L","preferredColor":"Vintage Bone"}],"communicationPreferences":{"orderUpdatesEmail":true,"reflectionDigestsEmail":true,"curatedEssaysEmail":false}}');

SET FOREIGN_KEY_CHECKS = 1;
