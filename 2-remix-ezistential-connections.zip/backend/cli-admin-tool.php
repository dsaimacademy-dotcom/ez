<?php
/**
 * Ezistential Connections — CLI Administrator Recovery & Provisioning Tool
 * 
 * Usage:
 *   php backend/cli-admin-tool.php <admin_email> <new_password> [admin_name]
 * 
 * SECURITY:
 *   This tool can ONLY be executed via the command line interface (CLI).
 *   Web HTTP execution is strictly blocked.
 */

if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    echo "ERROR: This tool may only be executed via the server command line interface (CLI).\n";
    exit(1);
}

require_once __DIR__ . '/db.php';

$email = $argv[1] ?? null;
$password = $argv[2] ?? null;
$name = $argv[3] ?? 'Ezistential Curator';

if (empty($email) || empty($password)) {
    echo "Usage:\n";
    echo "  php " . basename(__FILE__) . " <admin_email> <new_password> [admin_name]\n\n";
    echo "Example:\n";
    echo "  php " . basename(__FILE__) . " curator@ezistential.com StrongSecret2026! \"Ezistential Curator\"\n";
    exit(1);
}

if (strlen($password) < 8) {
    echo "ERROR: Password must be at least 8 characters long.\n";
    exit(1);
}

try {
    $db = Database::getConnection();
    $email = strtolower(trim($email));
    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

    $stmt = $db->prepare("SELECT id FROM users WHERE LOWER(email) = ?");
    $stmt->execute([$email]);
    $existing = $stmt->fetch();

    if ($existing) {
        $upd = $db->prepare("
            UPDATE users SET
                password_hash = ?,
                role = 'admin',
                name = COALESCE(?, name),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $upd->execute([$hash, $name, $existing['id']]);
        echo "SUCCESS: Administrator password for '{$email}' has been safely updated.\n";
    } else {
        $id = 'usr-admin-' . bin2hex(random_bytes(4));
        $userObj = json_encode([
            'id' => $id,
            'email' => $email,
            'fullName' => $name,
            'role' => 'admin'
        ]);
        $ins = $db->prepare("
            INSERT INTO users (id, email, password_hash, name, role, saved_items)
            VALUES (?, ?, ?, ?, 'admin', ?)
        ");
        $ins->execute([$id, $email, $hash, $name, $userObj]);
        echo "SUCCESS: New administrator account '{$email}' provisioned with secure bcrypt hash.\n";
    }
} catch (Exception $e) {
    echo "ERROR: Database operation failed: " . $e->getMessage() . "\n";
    exit(1);
}
