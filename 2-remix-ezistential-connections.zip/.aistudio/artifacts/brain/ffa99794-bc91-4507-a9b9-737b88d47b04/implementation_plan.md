# Production Implementation: Apliiq POD Fulfillment & Real-time Automation

### Objectives Completed
1. **Live Real-time Shipping Rate Calculation**:
   - Backend APIs: `POST /api/shipping/calculate-rates` and `POST /api/pod/apliiq/shipping-rates` returning Apliiq tiers:
     - Standard: USPS Ground Advantage ($6.95 flat rate, or FREE when order subtotal meets threshold)
     - Priority: USPS Priority / FedEx 2-Day Air ($12.95)
     - Express: FedEx Standard Overnight from LA facility ($24.95)
   - Storefront Checkout: Interactive selectable tier list with real-time recalculation based on customer address and package subtotal.
   - PHP Parity: Implemented in `backend/api.php` under `case 'shipping': calculate-rates`.

2. **Configurable Order Dispatch Policies**:
   - Admin Controls in `IntegrationSetup.tsx`:
     - **Instant Automated Dispatch**: Immediate submission to Apliiq manufacturing upon customer payment.
     - **1-Hour Customer Grace Window (Recommended)**: Holds order for 60 minutes for customer address/size corrections, with automated background submission once the timer expires.
     - **2-Hour Customer Grace Window**: Holds order for 120 minutes with automatic background dispatch.
     - **Manual Admin Review**: Holds order in "Ready for Review" queue until an admin approves it with 1 click.
   - Admin Portal Actions:
     - Displays countdown remaining (e.g., `45m left`) with a 1-click `Dispatch Now` manual bypass button.
     - 1-click `Approve & Dispatch` button for orders in `Ready for Review`.
   - Node backend worker: Auto-promotes expired grace period orders every 30 seconds to `'Submitted to POD'`.

3. **Industry-Standard Stock / Inventory Sync**:
   - Pre-checkout stock verification: `POST /api/pod/apliiq/check-stock` blocks orders if blank garments or sizes are out of stock.
   - Automated hourly sync worker in Node server (`setInterval` 1 hour) checking all product variants against Apliiq and updating availability.
   - Real-time webhook listener: `POST /api/pod/apliiq/webhook/inventory-updated` accepting instant stock push notifications.
   - On-demand admin trigger: "Sync Stock Now" button in Admin Integration Setup with instant status feedback and last-synced timestamp.
