/**
 * Ezistential Connection — Universal Server-First Revalidation & PWA Online Sync
 * Ensures application data is authoritative in the central database (MySQL / REST API).
 *
 * Rule: LocalStorage is strictly an ephemeral offline cache for instant UI paint.
 * As soon as the PWA or browser opens and detects an internet connection, all contexts
 * immediately revalidate against the server and update user data, catalog, orders, and content.
 */

type SyncCallback = () => void | Promise<void>;
type StatusListener = (status: { isOnline: boolean; isSyncing: boolean; lastSyncTime: number }) => void;

class ServerSyncManager {
  private listeners: Set<SyncCallback> = new Set();
  private statusListeners: Set<StatusListener> = new Set();
  private isInitialized = false;
  private lastSyncTimestamp = Date.now();
  private minSyncIntervalMs = 2000; // Debounce rapid focus/online triggers
  private activeSyncCount = 0;

  constructor() {
    this.init();
  }

  private init() {
    if (typeof window === 'undefined' || this.isInitialized) return;
    this.isInitialized = true;

    // 1. Connection Restored Event (PWA reconnects to internet)
    window.addEventListener('online', () => {
      this.notifyStatus();
      this.triggerRevalidation('online');
    });

    // 2. Offline Event
    window.addEventListener('offline', () => {
      this.notifyStatus();
    });

    // 3. Tab/App Brought to Foreground (User opens PWA / returns to tab)
    window.addEventListener('focus', () => {
      if (this.isOnline()) {
        this.triggerRevalidation('focus');
      }
    });

    // 4. Document Visibility Change (PWA switches from background to active)
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && this.isOnline()) {
          this.triggerRevalidation('visibility');
        }
      });
    }
  }

  public register(callback: SyncCallback): () => void {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  public subscribeStatus(listener: StatusListener): () => void {
    this.statusListeners.add(listener);
    listener({
      isOnline: this.isOnline(),
      isSyncing: this.activeSyncCount > 0,
      lastSyncTime: this.lastSyncTimestamp,
    });
    return () => {
      this.statusListeners.delete(listener);
    };
  }

  private notifyStatus() {
    const payload = {
      isOnline: this.isOnline(),
      isSyncing: this.activeSyncCount > 0,
      lastSyncTime: this.lastSyncTimestamp,
    };
    this.statusListeners.forEach((fn) => {
      try {
        fn(payload);
      } catch {}
    });
  }

  /**
   * Triggers all registered sync listeners with debouncing to avoid redundant spikes.
   */
  public async triggerRevalidation(reason: string = 'manual') {
    const now = Date.now();
    if (now - this.lastSyncTimestamp < this.minSyncIntervalMs && reason !== 'manual') {
      return;
    }
    this.lastSyncTimestamp = now;

    this.activeSyncCount++;
    this.notifyStatus();

    const tasks: Promise<void>[] = [];
    this.listeners.forEach((fn) => {
      try {
        const res = fn();
        if (res && typeof res.then === 'function') {
          tasks.push(
            res.catch((err) => console.warn(`[ServerSync] Error during ${reason} revalidation:`, err))
          );
        }
      } catch (err) {
        console.warn(`[ServerSync] Exception during ${reason} revalidation:`, err);
      }
    });

    if (tasks.length > 0) {
      await Promise.allSettled(tasks);
    }

    this.activeSyncCount = Math.max(0, this.activeSyncCount - 1);
    this.notifyStatus();
  }

  public isOnline(): boolean {
    if (typeof navigator !== 'undefined' && 'onLine' in navigator) {
      return navigator.onLine;
    }
    return true;
  }

  public getStatus() {
    return {
      isOnline: this.isOnline(),
      isSyncing: this.activeSyncCount > 0,
      lastSyncTime: this.lastSyncTimestamp,
    };
  }
}

export const serverSync = new ServerSyncManager();

/**
 * React hook to observe server sync status in components.
 */
import { useState, useEffect } from 'react';

export function useServerSync() {
  const [status, setStatus] = useState(() => serverSync.getStatus());

  useEffect(() => {
    return serverSync.subscribeStatus(setStatus);
  }, []);

  return {
    ...status,
    syncNow: () => serverSync.triggerRevalidation('manual'),
  };
}
