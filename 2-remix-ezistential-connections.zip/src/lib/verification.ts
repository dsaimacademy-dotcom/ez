import {
  UserProfile,
  MemberVerificationRules,
  Order,
  CustomerResponse,
  MemberBadgeConfig,
  BadgeColorTheme,
  BadgeIconType
} from '../types';

export const DEFAULT_BADGES: MemberBadgeConfig[] = [
  {
    id: 'badge_verified_wearer',
    name: 'Verified Wearer',
    slug: 'verified-wearer',
    description: 'Official verified participant with authenticated garment ownership and active profile.',
    icon: 'shield',
    colorTheme: 'emerald',
    criteria: {
      minOrders: 1,
      minReflections: 1,
      minSpend: 0,
      requirePhoto: false,
      requireLocation: true,
      minAccountAgeDays: 0,
    },
    isActive: true,
    isSystemDefault: true,
    priority: 1,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'badge_founding_patron',
    name: 'Founding Patron',
    slug: 'founding-patron',
    description: 'Pillar patron supporting independent garment craft with 3+ archival orders and $150+ committed.',
    icon: 'crown',
    colorTheme: 'gold',
    criteria: {
      minOrders: 3,
      minReflections: 0,
      minSpend: 150,
      requirePhoto: false,
      requireLocation: false,
      minAccountAgeDays: 0,
    },
    isActive: true,
    isSystemDefault: false,
    priority: 2,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'badge_chronicler',
    name: 'Chronicler of the Threshold',
    slug: 'threshold-chronicler',
    description: 'Prolific writer contributing 2+ approved philosophical reflections on connection in public space.',
    icon: 'medal',
    colorTheme: 'purple',
    criteria: {
      minOrders: 0,
      minReflections: 2,
      minSpend: 0,
      requirePhoto: false,
      requireLocation: false,
      minAccountAgeDays: 0,
    },
    isActive: true,
    isSystemDefault: false,
    priority: 3,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'badge_field_documentarian',
    name: 'Field Documentarian',
    slug: 'field-documentarian',
    description: 'Contributed verified on-body garment photography capturing real encounters in the world.',
    icon: 'compass',
    colorTheme: 'blue',
    criteria: {
      minOrders: 1,
      minReflections: 1,
      minSpend: 0,
      requirePhoto: true,
      requireLocation: false,
      minAccountAgeDays: 0,
    },
    isActive: true,
    isSystemDefault: false,
    priority: 4,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'badge_tenured_resident',
    name: 'Tenured Resident',
    slug: 'tenured-resident',
    description: 'Established community member with account tenure of 30+ days and verified location.',
    icon: 'award',
    colorTheme: 'amber',
    criteria: {
      minOrders: 1,
      minReflections: 0,
      minSpend: 0,
      requirePhoto: false,
      requireLocation: true,
      minAccountAgeDays: 30,
    },
    isActive: true,
    isSystemDefault: false,
    priority: 5,
    createdAt: '2026-01-01T00:00:00Z',
  },
];

export const DEFAULT_VERIFICATION_RULES: MemberVerificationRules = {
  enabled: true,
  requirePurchase: true,
  minPurchasesCount: 1,
  minSpendAmount: 0,
  requireReflection: true,
  minReflectionsCount: 1,
  requirePhoto: false,
  requireProfileLocation: true,
  minAccountAgeDays: 0,
  allowManualOverride: true,
  autoGrantDefaultBadge: true,
  customBadges: DEFAULT_BADGES,
};

export interface VerificationEvaluation {
  isSystemEnabled: boolean;
  isVerified: boolean;
  score: number;
  maxScore: number;
  percentage: number;
  statusLabel: 'Verified Wearer & Member' | 'Verification In Progress' | 'Member Threshold' | 'System Inactive';
  reasons: {
    hasPurchase: boolean;
    purchaseCount: number;
    purchaseMet: boolean;
    hasReflection: boolean;
    reflectionCount: number;
    reflectionMet: boolean;
    hasPhoto: boolean;
    photoMet: boolean;
    hasLocation: boolean;
    locationMet: boolean;
    isManualOverride: boolean;
    totalSpend: number;
    accountAgeDays: number;
  };
  earnedBadges: MemberBadgeConfig[];
}

export function calculateAccountAgeDays(createdAt?: string): number {
  if (!createdAt) return 0;
  const createdDate = new Date(createdAt);
  if (isNaN(createdDate.getTime())) return 0;
  const now = new Date();
  const diffMs = now.getTime() - createdDate.getTime();
  return Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
}

export function calculateUserTotalSpend(orders: Order[] = []): number {
  return orders.reduce((sum, ord) => sum + (ord.total || 0), 0);
}

export interface BadgeEvaluationResult {
  badge: MemberBadgeConfig;
  isEarned: boolean;
  progressPercentage: number;
  criteriaStatus: {
    ordersMet: boolean;
    currentOrders: number;
    targetOrders: number;
    reflectionsMet: boolean;
    currentReflections: number;
    targetReflections: number;
    spendMet: boolean;
    currentSpend: number;
    targetSpend: number;
    photoMet: boolean;
    currentPhoto: boolean;
    locationMet: boolean;
    currentLocation: boolean;
    ageMet: boolean;
    currentAgeDays: number;
    targetAgeDays: number;
  };
  isManualGranted: boolean;
  isManualRevoked: boolean;
}

export function evaluateBadgeForUser(
  badge: MemberBadgeConfig,
  user: UserProfile | null,
  userOrders: Order[] = [],
  userReflections: CustomerResponse[] = []
): BadgeEvaluationResult {
  if (!user) {
    return {
      badge,
      isEarned: false,
      progressPercentage: 0,
      criteriaStatus: {
        ordersMet: false,
        currentOrders: 0,
        targetOrders: badge.criteria.minOrders,
        reflectionsMet: false,
        currentReflections: 0,
        targetReflections: badge.criteria.minReflections,
        spendMet: false,
        currentSpend: 0,
        targetSpend: badge.criteria.minSpend,
        photoMet: false,
        currentPhoto: false,
        locationMet: false,
        currentLocation: false,
        ageMet: false,
        currentAgeDays: 0,
        targetAgeDays: badge.criteria.minAccountAgeDays,
      },
      isManualGranted: false,
      isManualRevoked: false,
    };
  }

  const isManualGranted = Boolean(user.manualBadges?.includes(badge.id));
  const isManualRevoked = Boolean(user.revokedBadges?.includes(badge.id));

  const approvedReflections = userReflections.filter((r) => r.status === 'Approved' || (r.status as string) === 'approved');
  const ordersCount = userOrders.length;
  const reflectionsCount = approvedReflections.length;
  const totalSpend = calculateUserTotalSpend(userOrders);
  const hasPhoto = approvedReflections.some((r) => Boolean(r.photoUrl));
  const hasLocation = Boolean(user.location && user.location.trim().length > 0);
  const accountAgeDays = calculateAccountAgeDays(user.createdAt);

  const ordersMet = badge.criteria.minOrders === 0 || ordersCount >= badge.criteria.minOrders;
  const reflectionsMet = badge.criteria.minReflections === 0 || reflectionsCount >= badge.criteria.minReflections;
  const spendMet = badge.criteria.minSpend === 0 || totalSpend >= badge.criteria.minSpend;
  const photoMet = !badge.criteria.requirePhoto || hasPhoto;
  const locationMet = !badge.criteria.requireLocation || hasLocation;
  const ageMet = badge.criteria.minAccountAgeDays === 0 || accountAgeDays >= badge.criteria.minAccountAgeDays;

  // Criteria metrics
  let totalCriteria = 0;
  let metCriteria = 0;

  if (badge.criteria.minOrders > 0) {
    totalCriteria++;
    if (ordersMet) metCriteria++;
  }
  if (badge.criteria.minReflections > 0) {
    totalCriteria++;
    if (reflectionsMet) metCriteria++;
  }
  if (badge.criteria.minSpend > 0) {
    totalCriteria++;
    if (spendMet) metCriteria++;
  }
  if (badge.criteria.requirePhoto) {
    totalCriteria++;
    if (photoMet) metCriteria++;
  }
  if (badge.criteria.requireLocation) {
    totalCriteria++;
    if (locationMet) metCriteria++;
  }
  if (badge.criteria.minAccountAgeDays > 0) {
    totalCriteria++;
    if (ageMet) metCriteria++;
  }

  if (totalCriteria === 0) {
    totalCriteria = 1;
    metCriteria = 1;
  }

  const criteriaFulfilled = ordersMet && reflectionsMet && spendMet && photoMet && locationMet && ageMet;
  const isEarned = isManualRevoked ? false : (isManualGranted || criteriaFulfilled);
  const progressPercentage = isEarned ? 100 : Math.round((metCriteria / totalCriteria) * 100);

  return {
    badge,
    isEarned,
    progressPercentage,
    criteriaStatus: {
      ordersMet,
      currentOrders: ordersCount,
      targetOrders: badge.criteria.minOrders,
      reflectionsMet,
      currentReflections: reflectionsCount,
      targetReflections: badge.criteria.minReflections,
      spendMet,
      currentSpend: totalSpend,
      targetSpend: badge.criteria.minSpend,
      photoMet,
      currentPhoto: hasPhoto,
      locationMet,
      currentLocation: hasLocation,
      ageMet,
      currentAgeDays: accountAgeDays,
      targetAgeDays: badge.criteria.minAccountAgeDays,
    },
    isManualGranted,
    isManualRevoked,
  };
}

export function evaluateMemberVerification(
  user: UserProfile | null,
  userOrders: Order[] = [],
  userReflections: CustomerResponse[] = [],
  rules: MemberVerificationRules = DEFAULT_VERIFICATION_RULES
): VerificationEvaluation {
  const isSystemEnabled = rules.enabled !== false;

  if (!user) {
    return {
      isSystemEnabled,
      isVerified: false,
      score: 0,
      maxScore: 4,
      percentage: 0,
      statusLabel: isSystemEnabled ? 'Member Threshold' : 'System Inactive',
      reasons: {
        hasPurchase: false,
        purchaseCount: 0,
        purchaseMet: false,
        hasReflection: false,
        reflectionCount: 0,
        reflectionMet: false,
        hasPhoto: false,
        photoMet: false,
        hasLocation: false,
        locationMet: false,
        isManualOverride: false,
        totalSpend: 0,
        accountAgeDays: 0,
      },
      earnedBadges: [],
    };
  }

  const badgesPool = rules.customBadges && rules.customBadges.length > 0
    ? rules.customBadges.filter((b) => b.isActive)
    : DEFAULT_BADGES.filter((b) => b.isActive);

  // Evaluate badges
  const badgeResults = badgesPool.map((badge) =>
    evaluateBadgeForUser(badge, user, userOrders, userReflections)
  );
  const earnedBadges = badgeResults.filter((r) => r.isEarned).map((r) => r.badge);

  const approvedReflections = userReflections.filter((r) => r.status === 'Approved' || (r.status as string) === 'approved');
  const purchaseCount = userOrders.length;
  const reflectionCount = approvedReflections.length;
  const totalSpend = calculateUserTotalSpend(userOrders);
  const hasPhoto = approvedReflections.some((r) => Boolean(r.photoUrl));
  const hasLocation = Boolean(user.location && user.location.trim().length > 0);
  const accountAgeDays = calculateAccountAgeDays(user.createdAt);

  // If system is disabled globally
  if (!isSystemEnabled) {
    return {
      isSystemEnabled: false,
      isVerified: false,
      score: 0,
      maxScore: 4,
      percentage: 0,
      statusLabel: 'System Inactive',
      reasons: {
        hasPurchase: purchaseCount > 0,
        purchaseCount,
        purchaseMet: false,
        hasReflection: reflectionCount > 0,
        reflectionCount,
        reflectionMet: false,
        hasPhoto,
        photoMet: false,
        hasLocation,
        locationMet: false,
        isManualOverride: false,
        totalSpend,
        accountAgeDays,
      },
      earnedBadges: [],
    };
  }

  // Check manual override
  if (rules.allowManualOverride && user.isVerifiedManualOverride) {
    return {
      isSystemEnabled: true,
      isVerified: true,
      score: 4,
      maxScore: 4,
      percentage: 100,
      statusLabel: 'Verified Wearer & Member',
      reasons: {
        hasPurchase: purchaseCount > 0,
        purchaseCount,
        purchaseMet: true,
        hasReflection: reflectionCount > 0,
        reflectionCount,
        reflectionMet: true,
        hasPhoto,
        photoMet: true,
        hasLocation,
        locationMet: true,
        isManualOverride: true,
        totalSpend,
        accountAgeDays,
      },
      earnedBadges,
    };
  }

  const purchaseMet = !rules.requirePurchase || purchaseCount >= rules.minPurchasesCount;
  const reflectionMet = reflectionCount >= (rules.minReflectionsCount || 1);
  const photoMet = !rules.requirePhoto || hasPhoto;
  const locationMet = !rules.requireProfileLocation || hasLocation;
  const spendMet = !rules.minSpendAmount || totalSpend >= rules.minSpendAmount;
  const ageMet = !rules.minAccountAgeDays || accountAgeDays >= rules.minAccountAgeDays;

  // Strict evidence requirement: Verified Wearer status REQUIRES verified garment ownership + curator approved evidence/reflection
  const hasApprovedEvidence = (rules.requireReflection ? reflectionMet : true) && (rules.requirePhoto ? photoMet : true) && (purchaseMet && (reflectionCount > 0 || hasPhoto));

  let activeCriteriaCount = 0;
  let metCriteriaCount = 0;

  if (rules.requirePurchase) {
    activeCriteriaCount++;
    if (purchaseMet) metCriteriaCount++;
  }

  // Reflection / observation evidence criterion
  activeCriteriaCount++;
  if (reflectionMet) metCriteriaCount++;

  if (rules.requirePhoto) {
    activeCriteriaCount++;
    if (photoMet) metCriteriaCount++;
  }

  if (rules.requireProfileLocation) {
    activeCriteriaCount++;
    if (locationMet) metCriteriaCount++;
  }

  if (rules.minSpendAmount && rules.minSpendAmount > 0) {
    activeCriteriaCount++;
    if (spendMet) metCriteriaCount++;
  }

  if (rules.minAccountAgeDays && rules.minAccountAgeDays > 0) {
    activeCriteriaCount++;
    if (ageMet) metCriteriaCount++;
  }

  if (activeCriteriaCount === 0) {
    activeCriteriaCount = 1;
    metCriteriaCount = 0;
  }

  // To be verified, purchase, evidence, location, and all rules must be met
  const isVerified = Boolean(
    purchaseMet &&
    reflectionMet &&
    photoMet &&
    locationMet &&
    spendMet &&
    ageMet &&
    hasApprovedEvidence
  );
  const percentage = Math.round((metCriteriaCount / activeCriteriaCount) * 100);

  let statusLabel: 'Verified Wearer & Member' | 'Verification In Progress' | 'Member Threshold' | 'System Inactive' = 'Verification In Progress';
  if (!isSystemEnabled) {
    statusLabel = 'System Inactive';
  } else if (isVerified) {
    statusLabel = 'Verified Wearer & Member';
  } else if (purchaseCount > 0 && !hasApprovedEvidence) {
    statusLabel = 'Verification In Progress';
  } else {
    statusLabel = 'Member Threshold';
  }

  return {
    isSystemEnabled: true,
    isVerified,
    score: metCriteriaCount,
    maxScore: activeCriteriaCount,
    percentage,
    statusLabel,
    reasons: {
      hasPurchase: purchaseCount > 0,
      purchaseCount,
      purchaseMet,
      hasReflection: reflectionCount > 0,
      reflectionCount,
      reflectionMet,
      hasPhoto,
      photoMet,
      hasLocation,
      locationMet,
      isManualOverride: false,
      totalSpend,
      accountAgeDays,
    },
    earnedBadges,
  };
}

export const BADGE_THEME_CLASSES: Record<BadgeColorTheme, {
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  iconColor: string;
  accentBg: string;
}> = {
  emerald: {
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-900',
    badgeBorder: 'border-emerald-300',
    iconColor: 'text-emerald-600',
    accentBg: 'bg-emerald-600',
  },
  amber: {
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-900',
    badgeBorder: 'border-amber-300',
    iconColor: 'text-amber-600',
    accentBg: 'bg-amber-600',
  },
  blue: {
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-900',
    badgeBorder: 'border-blue-300',
    iconColor: 'text-blue-600',
    accentBg: 'bg-blue-600',
  },
  purple: {
    badgeBg: 'bg-purple-50',
    badgeText: 'text-purple-900',
    badgeBorder: 'border-purple-300',
    iconColor: 'text-purple-600',
    accentBg: 'bg-purple-600',
  },
  rose: {
    badgeBg: 'bg-rose-50',
    badgeText: 'text-rose-900',
    badgeBorder: 'border-rose-300',
    iconColor: 'text-rose-600',
    accentBg: 'bg-rose-600',
  },
  gold: {
    badgeBg: 'bg-amber-100',
    badgeText: 'text-yellow-950',
    badgeBorder: 'border-amber-400',
    iconColor: 'text-amber-700',
    accentBg: 'bg-amber-500',
  },
  neutral: {
    badgeBg: 'bg-neutral-100',
    badgeText: 'text-neutral-900',
    badgeBorder: 'border-neutral-300',
    iconColor: 'text-neutral-700',
    accentBg: 'bg-neutral-800',
  },
};
