/**
 * Ezistential Connection — High Efficiency In-Browser Image Compressor
 * Enables fast client-side image compression to WebP/JPEG for ultra-fast loading even on slow 2G/3G/4G connections.
 */

export interface CompressionResult {
  dataUrl: string;
  originalSizeKb: number;
  compressedSizeKb: number;
  reductionPercentage: number;
  format: 'image/webp' | 'image/jpeg' | 'image/png';
  width: number;
  height: number;
}

export interface CompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number; // 0.1 to 1.0 (default 0.82)
  outputFormat?: 'image/webp' | 'image/jpeg' | 'image/png';
}

export async function compressImage(
  file: File,
  options: CompressionOptions = {}
): Promise<CompressionResult> {
  const {
    maxWidth = 1200,
    maxHeight = 1200,
    quality = 0.82,
    outputFormat = 'image/webp',
  } = options;

  const originalSizeKb = Math.round(file.size / 1024);

  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = new Image();

      img.onload = () => {
        let width = img.width;
        let height = img.height;

        // Calculate aspect-ratio preserving dimensions
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }

        // Render to canvas
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return reject(new Error('Canvas 2D context unavailable'));
        }

        // Clear and draw with high-quality smoothing
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // Attempt WebP, fallback to JPEG if format not supported
        let targetFormat = outputFormat;
        let dataUrl = '';

        try {
          dataUrl = canvas.toDataURL(targetFormat, quality);
          // If browser doesn't support webp export, toDataURL falls back to png
          if (targetFormat === 'image/webp' && !dataUrl.startsWith('data:image/webp')) {
            targetFormat = 'image/jpeg';
            dataUrl = canvas.toDataURL(targetFormat, quality);
          }
        } catch {
          targetFormat = 'image/jpeg';
          dataUrl = canvas.toDataURL('image/jpeg', quality);
        }

        // Calculate compressed size
        const head = `data:${targetFormat};base64,`;
        const base64Length = dataUrl.length - head.length;
        const compressedBytes = (base64Length * 3) / 4;
        const compressedSizeKb = Math.round(compressedBytes / 1024);

        const reductionPercentage =
          originalSizeKb > 0
            ? Math.max(0, Math.round(((originalSizeKb - compressedSizeKb) / originalSizeKb) * 100))
            : 0;

        resolve({
          dataUrl,
          originalSizeKb,
          compressedSizeKb,
          reductionPercentage,
          format: targetFormat as any,
          width,
          height,
        });
      };

      img.onerror = () => {
        reject(new Error('Failed to load image for compression'));
      };

      img.src = e.target?.result as string;
    };

    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };

    reader.readAsDataURL(file);
  });
}
