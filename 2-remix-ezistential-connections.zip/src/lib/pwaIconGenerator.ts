/**
 * PWA Icon Generator & Auto-Sizing Engine
 * 
 * Automatically creates compliant PWA manifest icons (192x192, 512x512, 512x512 maskable, 180x180 apple-touch-icon)
 * from any uploaded favicon (SVG, PNG, JPG, WebP, ICO, or DataURL) so that browser PWA install
 * prompts never fail due to missing or invalid icon sizes.
 */

export interface GeneratedPWAIcons {
  icon192: string;
  icon512: string;
  iconMaskable: string;
  appleIcon: string;
}

/**
 * Loads an image from a source string (data URL, image URL, or SVG)
 */
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    // If source is raw SVG string, convert to data URI
    let resolvedSrc = src;
    if (src.trim().startsWith('<svg')) {
      resolvedSrc = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(src)}`;
    }

    img.onload = () => resolve(img);
    img.onerror = (e) => reject(new Error(`Failed to load icon image from source: ${e}`));
    img.src = resolvedSrc;
  });
}

/**
 * Renders an image into an offscreen canvas at the target size.
 * Handles aspect ratio, centering, and optional background / safe-zone padding.
 */
function renderToCanvas(
  img: HTMLImageElement,
  targetWidth: number,
  targetHeight: number,
  options: {
    paddingPercent?: number; // 0 to 1 (e.g. 0.15 for 15% maskable safe-zone)
    backgroundColor?: string | null;
  } = {}
): string {
  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not get 2D canvas context');

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // Fill background if specified
  if (options.backgroundColor) {
    ctx.fillStyle = options.backgroundColor;
    ctx.fillRect(0, 0, targetWidth, targetHeight);
  } else {
    ctx.clearRect(0, 0, targetWidth, targetHeight);
  }

  const paddingRatio = options.paddingPercent ?? 0.05;
  const availWidth = targetWidth * (1 - paddingRatio * 2);
  const availHeight = targetHeight * (1 - paddingRatio * 2);

  // Maintain aspect ratio
  const imgWidth = img.naturalWidth || img.width || targetWidth;
  const imgHeight = img.naturalHeight || img.height || targetHeight;
  const scale = Math.min(availWidth / imgWidth, availHeight / imgHeight);

  const drawWidth = imgWidth * scale;
  const drawHeight = imgHeight * scale;
  const drawX = (targetWidth - drawWidth) / 2;
  const drawY = (targetHeight - drawHeight) / 2;

  ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);

  return canvas.toDataURL('image/png');
}

/**
 * Generates all mandatory W3C PWA icon sizes from any favicon
 */
export async function generatePWAIconsFromFavicon(faviconSource: string): Promise<GeneratedPWAIcons> {
  const img = await loadImage(faviconSource);

  // 1. Standard 192x192 PNG (Required by Chrome for beforeinstallprompt)
  const icon192 = renderToCanvas(img, 192, 192, {
    paddingPercent: 0.08,
  });

  // 2. High-Res 512x512 PNG (Required by Chrome for splash screen & app launcher)
  const icon512 = renderToCanvas(img, 512, 512, {
    paddingPercent: 0.08,
  });

  // 3. Maskable 512x512 PNG (Required by Android with safe 15% margin and solid luxury background)
  const iconMaskable = renderToCanvas(img, 512, 512, {
    paddingPercent: 0.16,
    backgroundColor: '#0a0a0a',
  });

  // 4. Apple Touch Icon 180x180 PNG (Required by iOS Safari Add to Home Screen)
  const appleIcon = renderToCanvas(img, 180, 180, {
    paddingPercent: 0.12,
    backgroundColor: '#0a0a0a',
  });

  return {
    icon192,
    icon512,
    iconMaskable,
    appleIcon,
  };
}

/**
 * Synchronizes generated icons with the backend server and public directory
 */
export async function syncPWAIconsToServer(
  icons: GeneratedPWAIcons & { faviconUrl?: string }
): Promise<boolean> {
  try {
    const res = await fetch('/api/pwa/sync-icons', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(icons),
    });
    const data = await res.json();
    return Boolean(data?.success);
  } catch (err) {
    console.warn('Failed to sync PWA icons to server:', err);
    return false;
  }
}

/**
 * Convenience helper: Takes a favicon (uploaded file/URL), resizes to all PWA sizes,
 * and sends to the server so manifest & install prompt never fail.
 */
export async function autoAdjustFaviconForPWA(faviconUrl: string): Promise<boolean> {
  if (!faviconUrl || faviconUrl === '/favicon.ico') return false;
  try {
    const icons = await generatePWAIconsFromFavicon(faviconUrl);
    return await syncPWAIconsToServer({
      ...icons,
      faviconUrl,
    });
  } catch (err) {
    console.error('Error auto-adjusting favicon for PWA:', err);
    return false;
  }
}
