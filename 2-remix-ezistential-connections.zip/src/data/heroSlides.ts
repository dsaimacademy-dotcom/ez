import { HeroSlide } from '../types';

export const DEFAULT_HERO_SLIDES: HeroSlide[] = [
  // SLIDE 1: The Foundation - Fast Legibility Standard
  {
    id: 'slide-noir-beginning',
    chapterNumber: '01',
    chapterLabel: 'The Threshold',
    tagline: 'Apparel with a Point of View',
    headline: 'Apparel with a Point of View.',
    subheadline:
      'Connection is the subject, not decoration. Heavyweight garments engineered for public space.',
    primaryCtaText: 'SHOP',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'EXPLORE',
    secondaryCtaTarget: 'collections',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'noir-black',
    overlayOpacity: 0.60,
    accentHex: '#f5f4f0',
    overlayColor: '#0a0a0a',
    gradientStyle: 'cinematic',
    active: true,
  },
  // SLIDE 2: Difference Marquee Edition
  {
    id: 'slide-golden-contrast',
    chapterNumber: '02',
    chapterLabel: 'Contrast as Catalyst',
    tagline: 'Difference Is the Threshold',
    headline: 'Difference Is the Subject, Not Decoration.',
    subheadline:
      '6.5oz architectural cuts carrying quiet questions where casual assumptions once reigned.',
    primaryCtaText: 'SHOP',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'EXPLORE',
    secondaryCtaTarget: 'collections',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'noir-black',
    overlayOpacity: 0.58,
    accentHex: '#f5f4f0',
    overlayColor: '#0a0a0a',
    gradientStyle: 'soft',
    active: true,
  },
  // SLIDE 3: The Distance Tee in Washed Charcoal
  {
    id: 'slide-terracotta-public',
    chapterNumber: '03',
    chapterLabel: 'Ideas in Motion',
    tagline: 'Worn Ideas Walk',
    headline: 'A Garment Moves Through the World.',
    subheadline:
      'Physical clothing crossing physical thresholds to invite authentic human recognition.',
    primaryCtaText: 'SHOP',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'EXPLORE',
    secondaryCtaTarget: 'collections',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'noir-black',
    overlayOpacity: 0.58,
    accentHex: '#f5f4f0',
    overlayColor: '#0a0a0a',
    gradientStyle: 'cinematic',
    active: true,
  },
  // SLIDE 4: Tactile Heavyweight Cotton Detail
  {
    id: 'slide-twilight-silence',
    chapterNumber: '04',
    chapterLabel: 'Tactile Permanence',
    tagline: 'Conceived in Chicago',
    headline: 'Tactile Permanence. Quiet Restraint.',
    subheadline:
      '6.5oz heavyweight combed cotton crafted for thoughtful individuals refusing shallow labels.',
    primaryCtaText: 'SHOP',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'EXPLORE',
    secondaryCtaTarget: 'collections',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'noir-black',
    overlayOpacity: 0.60,
    accentHex: '#f5f4f0',
    overlayColor: '#0a0a0a',
    gradientStyle: 'soft',
    active: true,
  },
  // SLIDE 5: Connection Space in Bone Off-White
  {
    id: 'slide-earth-recognition',
    chapterNumber: '05',
    chapterLabel: 'The Space Between',
    tagline: 'Somewhere Between You and Me',
    headline: 'Somewhere Between You and Me, There Is an Us.',
    subheadline:
      'Clothing cut not to impress, but to open the quiet possibility of discovery.',
    primaryCtaText: 'SHOP',
    primaryCtaTarget: 'shop',
    secondaryCtaText: 'EXPLORE',
    secondaryCtaTarget: 'collections',
    showSecondaryCta: true,
    imageUrl:
      'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=2000&q=85',
    colorMood: 'noir-black',
    overlayOpacity: 0.58,
    accentHex: '#f5f4f0',
    overlayColor: '#0a0a0a',
    gradientStyle: 'minimal',
    active: true,
  },
];
