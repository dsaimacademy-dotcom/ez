export interface FeatureFlags {
  // Reusable post-launch modules (hidden until authentic content/members exist)
  showJournal: boolean;
  showHumanExchangeArchive: boolean;
  showVerifiedMemberBadges: boolean;
  showEcEcosystem: boolean;
  showPdpReviews: boolean;

  // Navigation & structural routing
  showTopBarManifestoButton: boolean;
  showWhyWeExistInTopNav: boolean;
  showFaqInTopNav: boolean;
}

export const FEATURE_FLAGS: FeatureFlags = {
  showJournal: true,                // Active by default (can be toggled in Admin settings)
  showHumanExchangeArchive: true,   // Active by default (can be toggled in Admin settings)
  showVerifiedMemberBadges: true,   // Active by default
  showEcEcosystem: true,            // Active by default
  showPdpReviews: true,             // Active by default (PDP reflections & photo gallery)
  showTopBarManifestoButton: false,  // Preserved minimal top bar
  showWhyWeExistInTopNav: false,     // Accessible via menu navigation settings
  showFaqInTopNav: true,             // Promoted to top navigation bar
};
