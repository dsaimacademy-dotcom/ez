import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserProfile, UserAddress, SavedGarment, Size } from '../types';
import { api } from '../lib/api';
import { serverSync } from '../lib/serverSync';

interface AuthContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password?: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>;
  signup: (data: {
    fullName: string;
    email: string;
    password?: string;
    location?: string;
    reflectionInterests?: string[];
  }) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (updates: Partial<UserProfile>) => void;
  addAddress: (address: Omit<UserAddress, 'id'>) => void;
  updateAddress: (id: string, updates: Partial<UserAddress>) => void;
  deleteAddress: (id: string) => void;
  setDefaultAddress: (id: string) => void;
  toggleSavedGarment: (productId: string, note?: string, preferredSize?: Size, preferredColor?: string) => boolean;
  isGarmentSaved: (productId: string) => boolean;
  updateSavedGarment: (productId: string, updates: Partial<SavedGarment>) => void;
  exportUserData: () => void;
  deleteAccount: () => void;
  loginWithDemo: () => void;
}

const STORAGE_KEY_USER = 'ec_auth_user_v2';
const STORAGE_KEY_USERS_DB = 'ec_registered_users_v2';

const DEMO_USER: UserProfile = {
  id: 'usr-marcus-01',
  fullName: 'Marcus Vance',
  email: 'marcus@example.com',
  location: 'Chicago, IL',
  avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  bio: 'Architect of quiet spaces and everyday observations.',
  createdAt: '2024-11-12T14:30:00.000Z',
  updatedAt: new Date().toISOString(),
  addresses: [
    {
      id: 'addr-01',
      isDefault: true,
      label: 'Primary Residence',
      fullName: 'Marcus Vance',
      street: '1842 N Damen Ave',
      apartment: 'Apt 3F',
      city: 'Chicago',
      state: 'IL',
      zipCode: '60647',
      country: 'US',
      phone: '(312) 555-0192',
    },
    {
      id: 'addr-02',
      isDefault: false,
      label: 'Design Studio',
      fullName: 'Marcus Vance',
      street: '410 S Michigan Ave',
      apartment: 'Suite 804',
      city: 'Chicago',
      state: 'IL',
      zipCode: '60605',
      country: 'US',
    },
  ],
  savedGarments: [
    {
      id: 'prod-connection-03',
      productId: 'prod-connection-03',
      savedAt: '2026-03-15T09:12:00.000Z',
      note: 'Considering for the spring dialogue series in Vermont.',
      preferredSize: 'L',
      preferredColor: 'Vintage Bone',
    },
  ],
  communicationPreferences: {
    orderUpdatesEmail: true,
    reflectionDigestsEmail: true,
    curatedEssaysEmail: false,
  },
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Authoritative user state (UI cache only, immediately revalidated against MySQL / backend API)
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_USER);
      if (saved) return JSON.parse(saved);
      return DEMO_USER;
    } catch {
      return DEMO_USER;
    }
  });

  const [isLoading, setIsLoading] = useState(false);

  // Clean up legacy in-browser mock user pool residue
  useEffect(() => {
    try {
      if (typeof window !== 'undefined') {
        localStorage.removeItem(STORAGE_KEY_USERS_DB);
      }
    } catch {}
  }, []);

  // Universal Server-First Revalidation: update user profile & data as soon as internet is detected or app opens
  const syncWithCentralDB = useCallback(async () => {
    try {
      // 1. Check current authenticated session via /api/auth/me
      const me = await api.getMe();
      if (me) {
        setUser(me);
        try {
          localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(me));
        } catch {}
        return;
      }

      // 2. Revalidate by profile ID or email against central MySQL database
      let targetId = user?.id;
      if (!targetId && typeof window !== 'undefined') {
        try {
          const cached = localStorage.getItem(STORAGE_KEY_USER);
          if (cached) {
            const parsed = JSON.parse(cached);
            if (parsed && parsed.id) targetId = parsed.id;
          }
        } catch {}
      }

      if (targetId) {
        const freshUser = await api.getUser(targetId);
        if (freshUser) {
          setUser(freshUser);
          try {
            localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(freshUser));
          } catch {}
        }
      }
    } catch (err) {
      console.warn('Central DB user sync notice:', err);
    }
  }, [user?.id]);

  useEffect(() => {
    // 1. Initial sync from central server database
    syncWithCentralDB();

    // 2. Revalidate as soon as PWA reconnects to internet, window focuses, or visibility changes
    const unregister = serverSync.register(() => {
      syncWithCentralDB();
    });
    return unregister;
  }, [syncWithCentralDB]);

  // Sync active user to local storage as fallback UI cache
  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
      } else {
        localStorage.removeItem(STORAGE_KEY_USER);
      }
    } catch {
      // ignore
    }
  }, [user]);

  const login = async (email: string, password?: string, _rememberMe?: boolean) => {
    setIsLoading(true);
    const normalizedEmail = email.trim().toLowerCase();

    // Authenticate strictly with Central MySQL Database
    const res = await api.login(normalizedEmail, password);
    if (res.success && res.user) {
      setUser(res.user);
      setIsLoading(false);
      return { success: true };
    }

    setIsLoading(false);
    return { success: false, error: res.error || 'Invalid credentials or user not found in database.' };
  };

  const signup = async (data: {
    fullName: string;
    email: string;
    password?: string;
    location?: string;
    reflectionInterests?: string[];
  }) => {
    setIsLoading(true);
    const normalizedEmail = data.email.trim().toLowerCase();

    // Register with central server database (MySQL `users` table)
    const res = await api.register({
      email: normalizedEmail,
      fullName: data.fullName.trim(),
      password: data.password,
      location: data.location?.trim(),
    });

    if (res.success && res.user) {
      setUser(res.user);
      setIsLoading(false);
      return { success: true };
    }

    setIsLoading(false);
    return { success: false, error: res.error || 'Failed to create user account on central database.' };
  };

  const logout = () => {
    setUser(null);
    try {
      localStorage.removeItem(STORAGE_KEY_USER);
      localStorage.removeItem('ec_auth_token');
      localStorage.removeItem('ec_user_session');
      localStorage.removeItem('ec_user_v2');
    } catch {}
  };

  const loginWithDemo = async () => {
    try {
      const res = await api.login(DEMO_USER.email, 'connections2008');
      if (res.success && res.user) {
        setUser(res.user);
        return;
      }
    } catch {}
    setUser(DEMO_USER);
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    if (!user) return;
    const updatedUser = {
      ...user,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    setUser(updatedUser);

    // Persist to central database
    api.updateUser(user.id, updates).catch((err) => {
      console.warn('Central DB update notice:', err);
    });
  };

  const addAddress = (newAddr: Omit<UserAddress, 'id'>) => {
    if (!user) return;
    const id = `addr-${Date.now().toString(36)}`;
    const address: UserAddress = {
      ...newAddr,
      id,
    };

    let updatedAddresses = [...user.addresses];
    if (address.isDefault || updatedAddresses.length === 0) {
      updatedAddresses = updatedAddresses.map((a) => ({ ...a, isDefault: false }));
      address.isDefault = true;
    }
    updatedAddresses.push(address);

    updateProfile({ addresses: updatedAddresses });
  };

  const updateAddress = (id: string, updates: Partial<UserAddress>) => {
    if (!user) return;
    let updatedAddresses = user.addresses.map((a) => (a.id === id ? { ...a, ...updates } : a));

    if (updates.isDefault) {
      updatedAddresses = updatedAddresses.map((a) => (a.id === id ? { ...a, isDefault: true } : { ...a, isDefault: false }));
    }

    updateProfile({ addresses: updatedAddresses });
  };

  const deleteAddress = (id: string) => {
    if (!user) return;
    const remaining = user.addresses.filter((a) => a.id !== id);
    if (remaining.length > 0 && !remaining.some((a) => a.isDefault)) {
      remaining[0].isDefault = true;
    }
    updateProfile({ addresses: remaining });
  };

  const setDefaultAddress = (id: string) => {
    if (!user) return;
    const updatedAddresses = user.addresses.map((a) => ({
      ...a,
      isDefault: a.id === id,
    }));
    updateProfile({ addresses: updatedAddresses });
  };

  const toggleSavedGarment = (
    productId: string,
    note?: string,
    preferredSize?: Size,
    preferredColor?: string
  ): boolean => {
    if (!user) return false;
    const exists = user.savedGarments.some((g) => g.productId === productId);
    let nextSaved: SavedGarment[];

    if (exists) {
      nextSaved = user.savedGarments.filter((g) => g.productId !== productId);
    } else {
      nextSaved = [
        ...user.savedGarments,
        {
          id: productId,
          productId,
          savedAt: new Date().toISOString(),
          note,
          preferredSize,
          preferredColor,
        },
      ];
    }

    updateProfile({ savedGarments: nextSaved });
    return !exists;
  };

  const isGarmentSaved = (productId: string): boolean => {
    if (!user) return false;
    return user.savedGarments.some((g) => g.productId === productId);
  };

  const updateSavedGarment = (productId: string, updates: Partial<SavedGarment>) => {
    if (!user) return;
    const nextSaved = user.savedGarments.map((g) => (g.productId === productId ? { ...g, ...updates } : g));
    updateProfile({ savedGarments: nextSaved });
  };

  const exportUserData = () => {
    if (!user) return;
    const exportData = {
      brand: 'Ezistential Connection',
      version: '1.0',
      exportTimestamp: new Date().toISOString(),
      userProfile: user,
      dataPrivacyStatement: 'Ezistential Connection does not monetize or share your personal data with third-party advertising networks.',
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ezistential-account-archive-${user.email.replace(/[^a-zA-Z0-9]/g, '_')}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const deleteAccount = () => {
    if (!user) return;
    const currentId = user.id;
    api.deleteUser(currentId).catch(console.warn);
    setUser(null);
    try {
      localStorage.removeItem(STORAGE_KEY_USER);
      localStorage.removeItem('ec_auth_token');
    } catch {}
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        signup,
        logout,
        updateProfile,
        addAddress,
        updateAddress,
        deleteAddress,
        setDefaultAddress,
        toggleSavedGarment,
        isGarmentSaved,
        updateSavedGarment,
        exportUserData,
        deleteAccount,
        loginWithDemo,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
