import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Product, WearType, ColorItem, DesignDraft, MasterSizeItem } from '../types';
import { PRODUCTS as DEFAULT_PRODUCTS } from '../data/products';
import { DEFAULT_WEAR_TYPES, MASTER_COLOR_LIBRARY, DEFAULT_MASTER_SIZES } from '../data/wearTypes';
import { DEFAULT_DESIGN_DRAFTS } from '../data/designs';
import { normalizeProduct } from '../lib/productNormalization';
import { safeFetchJson } from '../lib/api';
import { serverSync } from '../lib/serverSync';

interface ProductContextType {
  products: Product[];
  wearTypes: WearType[];
  colors: ColorItem[];
  sizes: MasterSizeItem[];
  designs: DesignDraft[];
  isLoading: boolean;
  refreshProducts: () => Promise<void>;
  updateProductPrice: (id: string, newPrice: number) => void;
  toggleProductAvailability: (id: string) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  addProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  resetProducts: () => void;
  updateWearTypes: (wearTypes: WearType[]) => void;
  addWearType: (wearType: WearType) => void;
  deleteWearType: (id: string) => void;
  updateColors: (colors: ColorItem[]) => void;
  addColor: (color: ColorItem) => void;
  deleteColor: (id: string) => void;
  updateSizes: (sizes: MasterSizeItem[]) => void;
  addSize: (size: MasterSizeItem) => void;
  updateSize: (id: string, updates: Partial<MasterSizeItem>) => void;
  deleteSize: (id: string) => void;
  updateDesigns: (designs: DesignDraft[]) => void;
  addDesign: (design: DesignDraft) => void;
  updateDesign: (id: string, updates: Partial<DesignDraft>) => void;
  deleteDesign: (id: string) => void;
  pushDesignToProduct: (designId: string, versionNumber?: number, forceNewEdition?: boolean) => Promise<Product | null>;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const ProductProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Pure Server/Database-Driven State (No LocalStorage caching)
  const [products, setProducts] = useState<Product[]>(() =>
    DEFAULT_PRODUCTS.map((p) => normalizeProduct(p))
  );
  const [wearTypes, setWearTypes] = useState<WearType[]>(DEFAULT_WEAR_TYPES);
  const [colors, setColors] = useState<ColorItem[]>(MASTER_COLOR_LIBRARY);
  const [sizes, setSizes] = useState<MasterSizeItem[]>(DEFAULT_MASTER_SIZES);
  const [designs, setDesigns] = useState<DesignDraft[]>(DEFAULT_DESIGN_DRAFTS);
  const [isLoading, setIsLoading] = useState(false);

  // Clean up any legacy localStorage residue
  useEffect(() => {
    try {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('ec_products_store_v4');
        localStorage.removeItem('ec_wear_types_v2');
        localStorage.removeItem('ec_colors_store_v2');
        localStorage.removeItem('ec_sizes_store_v2');
        localStorage.removeItem('ec_designs_store_v2');
        localStorage.removeItem('ec_products_catalog_v2');
      }
    } catch {}
  }, []);

  // Live Server Sync (Express backend / PHP-parity REST endpoints)
  const refreshProducts = useCallback(async () => {
    try {
      setIsLoading(true);
      // Fetch Products from MySQL / Server DB
      const data = await safeFetchJson<any>('/api/products');
      if (data) {
        const productList = Array.isArray(data.products) ? data.products : Array.isArray(data.data) ? data.data : null;
        if (productList && productList.length > 0) {
          const normalized = productList.map((p: any) => normalizeProduct(p));
          setProducts(normalized);
        }
      }

      // Fetch Wear Types from MySQL / Server DB
      const wtData = await safeFetchJson<any>('/api/wear-types');
      if (wtData) {
        const wtList = Array.isArray(wtData.wearTypes) ? wtData.wearTypes : Array.isArray(wtData.data) ? wtData.data : null;
        if (wtList && wtList.length > 0) {
          setWearTypes(wtList);
        }
      }

      // Fetch Colors from MySQL / Server DB
      const colData = await safeFetchJson<any>('/api/colors');
      if (colData) {
        const colList = Array.isArray(colData.colors) ? colData.colors : Array.isArray(colData.data) ? colData.data : null;
        if (colList && colList.length > 0) {
          setColors(colList);
        }
      }

      // Fetch Sizes from MySQL / Server DB
      const szData = await safeFetchJson<any>('/api/sizes');
      if (szData) {
        const szList = Array.isArray(szData.sizes) ? szData.sizes : Array.isArray(szData.data) ? szData.data : null;
        if (szList && szList.length > 0) {
          setSizes(szList);
        }
      }

      // Fetch Designs from MySQL / Server DB
      const dsnData = await safeFetchJson<any>('/api/designs');
      if (dsnData) {
        const dsnList = Array.isArray(dsnData.designs) ? dsnData.designs : Array.isArray(dsnData.data) ? dsnData.data : null;
        if (dsnList && dsnList.length > 0) {
          setDesigns(dsnList);
        }
      }
    } catch (err) {
      console.warn('Central DB sync notice:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    // Initial fetch from central server database
    refreshProducts();

    // Revalidate as soon as the PWA reconnects to internet or returns to foreground
    const unregister = serverSync.register(() => {
      refreshProducts();
    });
    return unregister;
  }, [refreshProducts]);

  // Product Operations
  const updateProductPrice = (id: string, newPrice: number) => {
    const validPrice = Math.max(1, newPrice);
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, price: validPrice } : p))
    );

    fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ price: validPrice }),
    }).catch((err) => console.warn('Server price update error:', err));
  };

  const toggleProductAvailability = (id: string) => {
    const current = products.find((p) => p.id === id);
    if (!current) return;
    const newStatus = !current.isAvailable;

    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isAvailable: newStatus } : p))
    );

    fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isAvailable: newStatus }),
    }).catch((err) => console.warn('Server status update error:', err));
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );

    fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    }).catch((err) => console.warn('Server product update error:', err));
  };

  const addProduct = (product: Product) => {
    setProducts((prev) => [product, ...prev]);

    fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    }).catch((err) => console.warn('Server product add error:', err));
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));

    fetch(`/api/products/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server product delete error:', err));
  };

  const resetProducts = () => {
    setProducts(DEFAULT_PRODUCTS);
    fetch('/api/products/reset', { method: 'POST' }).catch(() => {});
  };

  // Wear Types Operations
  const updateWearTypes = (newWearTypes: WearType[]) => {
    setWearTypes(newWearTypes);

    fetch('/api/wear-types', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wearTypes: newWearTypes }),
    }).catch((err) => console.warn('Server wearTypes update error:', err));
  };

  const addWearType = (wearType: WearType) => {
    setWearTypes((prev) => [...prev, wearType]);

    fetch('/api/wear-types', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(wearType),
    }).catch((err) => console.warn('Server wearType add error:', err));
  };

  const deleteWearType = (id: string) => {
    setWearTypes((prev) => prev.filter((w) => w.id !== id));

    fetch(`/api/wear-types/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server wearType delete error:', err));
  };

  // Colors Operations
  const updateColors = (newColors: ColorItem[]) => {
    setColors(newColors);

    fetch('/api/colors', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ colors: newColors }),
    }).catch((err) => console.warn('Server colors update error:', err));
  };

  const addColor = (color: ColorItem) => {
    setColors((prev) => [...prev, color]);

    fetch('/api/colors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(color),
    }).catch((err) => console.warn('Server color add error:', err));
  };

  const deleteColor = (id: string) => {
    setColors((prev) => prev.filter((c) => c.id !== id && c.name.toLowerCase() !== id.toLowerCase()));

    fetch(`/api/colors/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server color delete error:', err));
  };

  // Sizes Operations
  const updateSizes = (newSizes: MasterSizeItem[]) => {
    setSizes(newSizes);

    fetch('/api/sizes', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sizes: newSizes }),
    }).catch((err) => console.warn('Server sizes update error:', err));
  };

  const addSize = (size: MasterSizeItem) => {
    setSizes((prev) => [...prev, size]);

    fetch('/api/sizes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(size),
    }).catch((err) => console.warn('Server size add error:', err));
  };

  const updateSize = (id: string, updates: Partial<MasterSizeItem>) => {
    setSizes((prev) =>
      prev.map((s) => (s.id === id || s.name.toUpperCase() === id.toUpperCase() ? { ...s, ...updates } : s))
    );

    fetch(`/api/sizes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    }).catch((err) => console.warn('Server size update error:', err));
  };

  const deleteSize = (id: string) => {
    setSizes((prev) => prev.filter((s) => s.id !== id && s.name.toUpperCase() !== id.toUpperCase()));

    fetch(`/api/sizes/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server size delete error:', err));
  };

  // Design Factory Operations
  const updateDesigns = (newDesigns: DesignDraft[]) => {
    setDesigns(newDesigns);
    fetch('/api/designs', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ designs: newDesigns }),
    }).catch((err) => console.warn('Server designs update error:', err));
  };

  const addDesign = (design: DesignDraft) => {
    setDesigns((prev) => [design, ...prev]);

    fetch('/api/designs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(design),
    }).catch((err) => console.warn('Server design add error:', err));
  };

  const updateDesign = (id: string, updates: Partial<DesignDraft>) => {
    setDesigns((prev) =>
      prev.map((d) => (d.id === id ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d))
    );

    fetch(`/api/designs/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    }).catch((err) => console.warn('Server design update error:', err));
  };

  const deleteDesign = (id: string) => {
    setDesigns((prev) => prev.filter((d) => d.id !== id));

    fetch(`/api/designs/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server design delete error:', err));
  };

  // Push to Product Bridge
  const pushDesignToProduct = async (
    designId: string,
    versionNumber?: number,
    forceNewEdition?: boolean
  ): Promise<Product | null> => {
    try {
      const data = await safeFetchJson<any>(`/api/designs/${designId}/push-to-product`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ versionNumber, forceNewEdition }),
      });

      if (data && data.product) {
        const norm = normalizeProduct(data.product, wearTypes, colors);
        if (!data.alreadyExists) {
          setProducts((prev) => [norm, ...prev.filter((p) => p.id !== norm.id)]);
        }
        setDesigns((prev) =>
          prev.map((d) => (d.id === designId ? { ...d, status: 'pushed_to_product' } : d))
        );
        return norm;
      }
    } catch (err) {
      console.warn('Live push-to-product API error:', err);
    }

    // Client-side fallback if server offline
    const d = designs.find((item) => item.id === designId);
    if (!d) return null;
    const v = d.versions.find((ver) => ver.versionNumber === versionNumber) || d.versions[d.versions.length - 1];
    const targetVerNum = v?.versionNumber || Number(versionNumber) || 1;

    // Check duplicate
    if (!forceNewEdition) {
      const existing = products.find(
        (p) => p.sourceDesignId === d.id && (p.sourceDesignVersionId === v?.id || p.sourceDesignVersionNumber === targetVerNum)
      );
      if (existing) {
        return existing;
      }
    }

    const rawProd: Partial<Product> = {
      id: `prod-from-${d.id}-${Date.now()}`,
      slug: `${d.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-edition`,
      name: d.name,
      tagline: d.thesis,
      price: 48,
      collectionId: 'core-concepts',
      isFeatured: false,
      isAvailable: false,
      readinessStatus: 'draft',
      sourceDesignId: d.id,
      sourceDesignVersionId: v?.id,
      sourceDesignVersionNumber: targetVerNum,
      availableWearTypes: v?.suggestedWearTypes || ['6.5oz Heavyweight Boxy Tee'],
      availableColors: (v?.suggestedColors || ['Obsidian Black', 'Raw Ecru']).map((cn) => {
        const found = colors.find((c) => c.name.toLowerCase() === cn.toLowerCase());
        return found ? { id: found.id, name: found.name, hex: found.hex } : { id: `col-${cn.toLowerCase().replace(/[^a-z0-9]/g, '-')}`, name: cn, hex: '#0f0f0f' };
      }),
      availableSizes: v?.suggestedSizes || ['S', 'M', 'L', 'XL'],
      primaryImage: v?.artworkUrl || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85',
      galleryImages: [
        {
          url: v?.artworkUrl || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85',
          alt: `${d.name} Primary Artwork`,
          viewType: 'front',
        },
      ],
      storyA: {
        headline: d.name,
        question: 'What happens when we translate this inquiry into physical form?',
        thesis: d.thesis,
        wearerRole: 'Carrying creative inquiry into public spaces.',
      },
      storyB: {
        fabric: '100% Combed Ring-Spun Cotton',
        weight: '6.5 oz / 220 GSM Heavyweight Jersey',
        fit: 'Relaxed drop-shoulder boxy architectural silhouette',
        origin: 'Ethically crafted in Los Angeles, CA',
        printTechnique: 'Direct-to-Film (DTF) Soft-Hand Archival Pigment',
        careInstructions: [
          'Machine wash cold inside out with like colors',
          'Hang dry recommended to preserve structural drape',
          'Tumble dry low if necessary',
        ],
        productionNotes: `Generated from Design Factory Draft #${d.id} (Version ${targetVerNum})`,
        estimatedDeliveryDays: 'Production: 2–4 business days. Standard US delivery: 3–5 business days.',
      },
      variants: [],
      createdAt: new Date().toISOString(),
    };

    const newProd = normalizeProduct(rawProd, wearTypes, colors);
    setProducts((prev) => [newProd, ...prev]);
    setDesigns((prev) =>
      prev.map((item) => (item.id === designId ? { ...item, status: 'pushed_to_product' } : item))
    );
    return newProd;
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        wearTypes,
        colors,
        sizes,
        designs,
        isLoading,
        refreshProducts,
        updateProductPrice,
        toggleProductAvailability,
        updateProduct,
        addProduct,
        deleteProduct,
        resetProducts,
        updateWearTypes,
        addWearType,
        deleteWearType,
        updateColors,
        addColor,
        deleteColor,
        updateSizes,
        addSize,
        updateSize,
        deleteSize,
        updateDesigns,
        addDesign,
        updateDesign,
        deleteDesign,
        pushDesignToProduct,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

export function useProducts() {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
}
