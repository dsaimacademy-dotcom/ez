import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { BlogPost } from '../types';
import { INITIAL_BLOG_POSTS } from '../data/posts';
import { safeFetchJson } from '../lib/api';
import { serverSync } from '../lib/serverSync';

interface PostContextType {
  posts: BlogPost[];
  loading: boolean;
  addPost: (postData: Omit<BlogPost, 'id'>) => Promise<BlogPost>;
  updatePost: (id: string, updates: Partial<BlogPost>) => Promise<void>;
  deletePost: (id: string) => Promise<void>;
  refreshPosts: () => Promise<void>;
}

const STORAGE_KEY_POSTS = 'ec_cms_blog_posts_v1';

const PostContext = createContext<PostContextType | undefined>(undefined);

export const PostProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [posts, setPosts] = useState<BlogPost[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_POSTS);
      return saved ? JSON.parse(saved) : INITIAL_BLOG_POSTS;
    } catch {
      return INITIAL_BLOG_POSTS;
    }
  });
  const [loading, setLoading] = useState(false);

  const refreshPosts = useCallback(async () => {
    try {
      setLoading(true);
      const data = await safeFetchJson<any>('/api/posts');
      if (data && data.posts && data.posts.length > 0) {
        setPosts(data.posts);
        localStorage.setItem(STORAGE_KEY_POSTS, JSON.stringify(data.posts));
      }
    } catch (err) {
      console.warn('Backend API unavailable, using local post cache:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshPosts();
    const unregister = serverSync.register(() => {
      refreshPosts();
    });
    return unregister;
  }, [refreshPosts]);

  const addPost = async (postData: Omit<BlogPost, 'id'>): Promise<BlogPost> => {
    const newPost: BlogPost = {
      ...postData,
      id: `post-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      publishedAt: postData.publishedAt || new Date().toISOString(),
    };

    setPosts((prev) => [newPost, ...prev]);

    try {
      const data = await safeFetchJson<any>('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newPost),
      });
      if (data && data.post) {
        setPosts((prev) => prev.map((p) => (p.id === newPost.id ? data.post : p)));
      }
    } catch (err) {
      console.warn('Backend post save fallback:', err);
    }

    return newPost;
  };

  const updatePost = async (id: string, updates: Partial<BlogPost>): Promise<void> => {
    setPosts((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p)));

    try {
      await fetch(`/api/posts/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    } catch (err) {
      console.warn('Backend post update fallback:', err);
    }
  };

  const deletePost = async (id: string): Promise<void> => {
    setPosts((prev) => prev.filter((p) => p.id !== id));

    try {
      await fetch(`/api/posts/${id}`, {
        method: 'DELETE',
      });
    } catch (err) {
      console.warn('Backend post delete fallback:', err);
    }
  };

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_POSTS, JSON.stringify(posts));
  }, [posts]);

  return (
    <PostContext.Provider value={{ posts, loading, addPost, updatePost, deletePost, refreshPosts }}>
      {children}
    </PostContext.Provider>
  );
};

export const usePosts = () => {
  const ctx = useContext(PostContext);
  if (!ctx) throw new Error('usePosts must be used within PostProvider');
  return ctx;
};
