import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Order, OrderStatus, OrderItem, ShippingAddress } from '../types';
import { generateOrderNumber, FREE_SHIPPING_THRESHOLD, STANDARD_SHIPPING_FLAT_RATE } from '../lib/utils';
import { api, safeFetchJson } from '../lib/api';
import { serverSync } from '../lib/serverSync';

interface OrderContextType {
  orders: Order[];
  createOrder: (orderData: {
    customerName: string;
    customerEmail: string;
    shippingAddress: ShippingAddress;
    items: OrderItem[];
    shippingCost?: number;
    shippingTier?: 'standard' | 'priority' | 'express';
    shippingMethodName?: string;
    dispatchMode?: 'instant' | 'grace_1h' | 'grace_2h' | 'manual';
    scheduledDispatchAt?: string;
    paymentMethod: 'card' | 'apple_pay' | 'google_pay' | 'paypal' | 'klarna' | 'afterpay' | 'cashapp';
    paymentTransactionId?: string;
    paymentDetails?: {
      brand?: string;
      last4?: string;
      wallet?: string;
      gateway?: string;
    };
  }) => Order;
  lookupOrder: (orderNumber: string, email: string) => Order | undefined;
  updateOrderStatus: (orderNumber: string, status: OrderStatus, trackingNumber?: string) => void;
  updateOrderTracking: (orderNumber: string, trackingNumber: string, carrier: string, trackingUrl?: string) => void;
  deleteOrder: (orderNumber: string) => void;
  fulfillOrder: (orderNumber: string, provider?: 'apliiq' | 'printful') => Promise<{ success: boolean; message: string; alreadyFulfilled?: boolean }>;
  resetDemoOrders: () => void;
  addSampleOrder: () => Order;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

const INITIAL_DEMO_ORDERS: Order[] = [
  {
    id: 'ord-1092',
    orderNumber: 'EC-94821-01',
    customerName: 'Marcus Vance',
    customerEmail: 'marcus@example.com',
    subtotal: 96.0,
    shippingCost: 0.0,
    taxCost: 0.0,
    total: 96.0,
    status: 'In Production',
    paymentMethod: 'card',
    paymentTransactionId: 'txn_card_demo_94821',
    podProvider: 'apliiq',
    podOrderId: 'APQ-583921',
    carrier: 'USPS Ground Advantage',
    trackingNumber: '9400 1118 9956 4821 9302 00',
    trackingUrl: 'https://tools.usps.com/go/TrackConfirmAction',
    estimatedDeliveryDate: 'April 28, 2026',
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    shippingAddress: {
      fullName: 'Marcus Vance',
      email: 'marcus@example.com',
      street: '1842 N Damen Ave',
      city: 'Chicago',
      state: 'IL',
      zipCode: '60647',
      country: 'US',
    },
    items: [
      {
        id: 'item-01',
        productId: 'prod-connection-01',
        productName: 'The Distance Tee',
        size: 'L',
        color: 'Washed Charcoal',
        price: 48.0,
        quantity: 1,
        subtotal: 48.0,
        image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
      },
      {
        id: 'item-02',
        productId: 'prod-connection-03',
        productName: 'The Friction Crewneck',
        size: 'L',
        color: 'Vintage Bone',
        price: 48.0,
        quantity: 1,
        subtotal: 48.0,
        image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80',
      },
    ],
  },
];

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Pure Server/Database-Driven State (No LocalStorage caching)
  const [orders, setOrders] = useState<Order[]>(INITIAL_DEMO_ORDERS);

  // Clean up any legacy localStorage residue
  useEffect(() => {
    try {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('ec_orders_store_v1');
        localStorage.removeItem('ec_demo_orders_v2');
      }
    } catch {}
  }, []);

  // Universal Server-First Revalidation: update orders from database as soon as internet is detected or app opens
  const syncOrders = useCallback(async () => {
    try {
      const serverOrders = await api.getOrders();
      if (serverOrders && serverOrders.length > 0) {
        setOrders(serverOrders);
      }
    } catch (err) {
      console.warn('Central DB orders sync notice:', err);
    }
  }, []);

  useEffect(() => {
    // 1. Initial fetch from server database
    syncOrders();

    // 2. Revalidate as soon as PWA reconnects to internet, window focuses, or visibility changes
    const unregister = serverSync.register(() => {
      syncOrders();
    });
    return unregister;
  }, [syncOrders]);

  const createOrder = (orderData: {
    customerName: string;
    customerEmail: string;
    shippingAddress: ShippingAddress;
    items: OrderItem[];
    shippingCost?: number;
    shippingTier?: 'standard' | 'priority' | 'express';
    shippingMethodName?: string;
    dispatchMode?: 'instant' | 'grace_1h' | 'grace_2h' | 'manual';
    scheduledDispatchAt?: string;
    paymentMethod: 'card' | 'apple_pay' | 'google_pay' | 'paypal' | 'klarna' | 'afterpay' | 'cashapp';
    paymentTransactionId?: string;
    paymentDetails?: {
      brand?: string;
      last4?: string;
      wallet?: string;
      gateway?: string;
    };
  }): Order => {
    const subtotal = orderData.items.reduce((acc, it) => acc + it.price * it.quantity, 0);
    const shippingCost =
      typeof orderData.shippingCost === 'number'
        ? orderData.shippingCost
        : subtotal >= FREE_SHIPPING_THRESHOLD
        ? 0
        : STANDARD_SHIPPING_FLAT_RATE;
    const taxCost = Math.round(subtotal * 0.065 * 100) / 100;
    const total = Math.round((subtotal + shippingCost + taxCost) * 100) / 100;

    let initialStatus: OrderStatus = 'Paid';
    let scheduledDispatchAt = orderData.scheduledDispatchAt;
    if (orderData.dispatchMode === 'grace_1h') {
      initialStatus = 'Grace Period';
      scheduledDispatchAt = scheduledDispatchAt || new Date(Date.now() + 60 * 60 * 1000).toISOString();
    } else if (orderData.dispatchMode === 'grace_2h') {
      initialStatus = 'Grace Period';
      scheduledDispatchAt = scheduledDispatchAt || new Date(Date.now() + 120 * 60 * 1000).toISOString();
    } else if (orderData.dispatchMode === 'manual') {
      initialStatus = 'Ready for Review';
    }

    const newOrder: Order = {
      id: `ord-${Date.now().toString(36)}`,
      orderNumber: generateOrderNumber(),
      customerName: orderData.customerName,
      customerEmail: orderData.customerEmail,
      shippingAddress: orderData.shippingAddress,
      items: orderData.items,
      subtotal,
      shippingCost,
      taxCost,
      total,
      status: initialStatus,
      dispatchMode: orderData.dispatchMode,
      scheduledDispatchAt,
      shippingTier: orderData.shippingTier,
      shippingMethodName: orderData.shippingMethodName,
      paymentMethod: orderData.paymentMethod,
      paymentTransactionId: orderData.paymentTransactionId || `txn_${orderData.paymentMethod}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`,
      paymentDetails: orderData.paymentDetails,
      podProvider: 'apliiq',
      podOrderId: `APQ-${Math.floor(100000 + Math.random() * 900000)}`,
      carrier: orderData.shippingMethodName || 'USPS Ground Advantage',
      trackingNumber: `9400 1118 9956 ${Math.floor(1000 + Math.random() * 9000)} ${Math.floor(1000 + Math.random() * 9000)} 00`,
      trackingUrl: 'https://tools.usps.com/go/TrackConfirmAction',
      estimatedDeliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      }),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setOrders((prev) => [newOrder, ...prev]);
    // Persist to central server database
    api.createOrder(newOrder).catch(console.warn);

    return newOrder;
  };

  const lookupOrder = (orderNumber: string, email: string): Order | undefined => {
    const cleanNum = orderNumber.trim().toUpperCase();
    const cleanEmail = email.trim().toLowerCase();

    return orders.find(
      (ord) =>
        ord.orderNumber.toUpperCase() === cleanNum &&
        ord.customerEmail.toLowerCase() === cleanEmail
    );
  };

  const updateOrderStatus = (
    orderNumber: string,
    status: OrderStatus,
    trackingNumber?: string
  ) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.orderNumber === orderNumber) {
          const updated = {
            ...ord,
            status,
            trackingNumber: trackingNumber || ord.trackingNumber,
            updatedAt: new Date().toISOString(),
          };
          api.updateOrder(ord.id || ord.orderNumber, updated).catch(console.warn);
          return updated;
        }
        return ord;
      })
    );
  };

  const updateOrderTracking = (
    orderNumber: string,
    trackingNumber: string,
    carrier: string,
    trackingUrl?: string
  ) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.orderNumber === orderNumber) {
          const updated: Order = {
            ...ord,
            trackingNumber,
            carrier,
            trackingUrl: trackingUrl || ord.trackingUrl || 'https://tools.usps.com/go/TrackConfirmAction',
            status: ord.status === 'Paid' || ord.status === 'In Production' ? 'Shipped' : ord.status,
            updatedAt: new Date().toISOString(),
          };
          api.updateOrder(ord.id || ord.orderNumber, updated).catch(console.warn);
          return updated;
        }
        return ord;
      })
    );
  };

  const deleteOrder = (orderNumber: string) => {
    setOrders((prev) => prev.filter((ord) => ord.orderNumber !== orderNumber));
  };

  const fulfillOrder = async (orderNumber: string, provider: 'apliiq' | 'printful' = 'apliiq'): Promise<{ success: boolean; message: string; alreadyFulfilled?: boolean }> => {
    const existing = orders.find((o) => o.orderNumber === orderNumber || o.id === orderNumber);
    if (!existing) {
      return { success: false, message: 'Order not found.' };
    }

    // Client idempotency check
    if (existing.status === 'Submitted to POD' || existing.status === 'In Production' || existing.podOrderId) {
      return {
        success: true,
        alreadyFulfilled: true,
        message: `Order #${existing.orderNumber} is already submitted to ${existing.podProvider || provider} (POD #${existing.podOrderId}). Duplicate fulfillment prevented.`,
      };
    }

    try {
      const data = await safeFetchJson<any>(`/api/orders/${existing.id || existing.orderNumber}/fulfill`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider, idempotencyKey: `idem-${Date.now().toString(36)}` }),
      });

      if (data && data.order) {
        setOrders((prev) => prev.map((o) => (o.orderNumber === existing.orderNumber ? data.order : o)));
        return {
          success: true,
          alreadyFulfilled: data.alreadyFulfilled,
          message: data.message,
        };
      }
    } catch (err) {
      console.warn('API fulfillment request failed, using local fallback:', err);
    }

    // Local fallback
    const podOrderId = `APQ-${Math.floor(100000 + Math.random() * 900000)}`;
    const updated: Order = {
      ...existing,
      status: 'Submitted to POD',
      podProvider: provider,
      podOrderId,
      idempotencyKey: `idem-${Date.now().toString(36)}`,
      submittedToPodAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setOrders((prev) => prev.map((o) => (o.orderNumber === existing.orderNumber ? updated : o)));
    return {
      success: true,
      alreadyFulfilled: false,
      message: `Order #${existing.orderNumber} submitted to ${provider} (POD ID: ${podOrderId}).`,
    };
  };

  const resetDemoOrders = () => {
    setOrders(INITIAL_DEMO_ORDERS);
  };

  const addSampleOrder = (): Order => {
    const sample: Order = {
      id: `ord-sample-${Date.now().toString(36)}`,
      orderNumber: generateOrderNumber(),
      customerName: 'Marcus Vance',
      customerEmail: 'marcus@example.com',
      shippingAddress: {
        fullName: 'Marcus Vance',
        email: 'marcus@example.com',
        street: '1842 N Damen Ave',
        city: 'Chicago',
        state: 'IL',
        zipCode: '60647',
        country: 'US',
      },
      items: [
        {
          id: 'item-sample-1',
          productId: 'prod-boundary-04',
          productName: 'The Boundary Longsleeve',
          size: 'XL',
          color: 'Raw Black',
          price: 54,
          quantity: 1,
          subtotal: 54,
          image: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=900&q=85',
        },
      ],
      subtotal: 54,
      shippingCost: 6.0,
      taxCost: 3.51,
      total: 63.51,
      status: 'In Production',
      paymentMethod: 'card',
      podProvider: 'apliiq',
      podOrderId: `APQ-${Math.floor(100000 + Math.random() * 900000)}`,
      carrier: 'USPS Ground Advantage',
      trackingNumber: `9400 1118 9956 ${Math.floor(1000 + Math.random() * 9000)} ${Math.floor(1000 + Math.random() * 9000)} 00`,
      trackingUrl: 'https://tools.usps.com/go/TrackConfirmAction',
      estimatedDeliveryDate: 'In 5-7 business days',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setOrders((prev) => [sample, ...prev]);
    api.createOrder(sample).catch(console.warn);
    return sample;
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        createOrder,
        lookupOrder,
        updateOrderStatus,
        updateOrderTracking,
        deleteOrder,
        fulfillOrder,
        resetDemoOrders,
        addSampleOrder,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = (): OrderContextType => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within an OrderProvider');
  }
  return context;
};
