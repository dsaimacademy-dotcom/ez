import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { FAQItem, ShapeDividerVariant, MemberVerificationRules, HeroSlide, PageSeoConfig, NavigationMenuItem } from '../types';
import { DEFAULT_VERIFICATION_RULES } from '../lib/verification';
import { FAQ_DATA as DEFAULT_FAQS } from '../data/faqs';
import { DEFAULT_HERO_SLIDES } from '../data/heroSlides';
import { DEFAULT_PAGE_SEO } from '../data/defaultPageSeo';
import { DEFAULT_NAVIGATION_MENU } from '../data/defaultNavMenu';
import { api } from '../lib/api';
import { serverSync } from '../lib/serverSync';

export interface SpotlightSlide {
  id: string;
  url: string;
  subtitle: string;
  caption: string;
}

export interface SiteContent {
  adminLoginUrl?: string;
  enableMemberVerification?: boolean;
  memberVerificationRules?: MemberVerificationRules;
  spotlightSlides?: SpotlightSlide[];
  heroSlides?: HeroSlide[];
  // Brand & Business Profile
  brandName: string;
  brandShortName: string;
  legalBusinessName: string;
  brandTagline: string;
  brandLogoUrl: string;
  brandLogoDarkUrl: string;
  faviconUrl: string;
  pageTitleTemplate: string;
  metaDescription: string;
  pageSeoConfigs?: Record<string, PageSeoConfig>;
  
  // Physical Studio & Contact Details
  businessAddressStreet: string;
  businessAddressCity: string;
  businessAddressState: string;
  businessAddressZip: string;
  businessAddressCountry: string;
  businessPhone: string;
  supportEmail: string;
  ordersEmail: string;
  pressEmail: string;
  businessHours: string;

  // Social & Community Channels (All Platforms)
  instagramHandle: string;
  instagramUrl: string;
  twitterHandle: string;
  twitterUrl: string;
  tiktokHandle: string;
  tiktokUrl: string;
  youtubeUrl: string;
  spotifyUrl: string;
  substackUrl: string;
  pinterestUrl: string;
  facebookUrl: string;
  linkedinUrl: string;
  discordUrl: string;

  // Announcements & Hero Statements
  announcementText: string;
  announcementActive: boolean;
  announcementLinkText: string;
  heroMode?: 'carousel' | 'static';
  heroChapterNumber?: string;
  heroChapterLabel?: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroTagline: string;
  heroButtonText: string;
  heroButtonTarget?: string;
  heroSecondaryButtonText?: string;
  heroSecondaryButtonTarget?: string;
  heroShowSecondaryButton?: boolean;
  heroImageUrl: string;
  heroImageOverlayOpacity: number;
  heroOverlayColor?: string;
  heroGradientStyle?: 'soft' | 'cinematic' | 'minimal' | 'none';
  heroColorMood: 'noir-black' | 'golden-amber' | 'terracotta-sunset' | 'twilight-indigo' | 'emerald-moss' | 'natural-monochrome';
  heroEnableColorBlooms?: boolean;
  heroAutoplayIntervalMs?: number;
  heroControlsStyle?: 'minimal-editorial' | 'interactive-capsule' | 'numbered-pagination';
  
  // Brand Philosophy & Story
  manifestoExcerpt: string;
  foundingQuote: string;
  storyHeadline: string;
  storyBody: string;
  connectionPromptTitle: string;
  connectionPromptSubtitle: string;

  // Frontend & Design Controls
  selectedThemeId?: string;
  shapeDividerEnabled: boolean;
  shapeDividerVariant: ShapeDividerVariant;
  shapeDividerHeight: number;
  primaryThemeColor: string;
  enableImageZoom: boolean;

  // Global Typography & Font Size Control System
  bodyFontSize?: number;
  smallFontSize?: number;
  h1FontSize?: number;
  h2FontSize?: number;
  h3FontSize?: number;
  subtitleFontSize?: number;
  navFontSize?: number;
  badgeFontSize?: number;
  bodyLineHeight?: number;

  // User Experience, Shipping & E-Commerce
  freeShippingThreshold: number;
  standardShippingRate: number;
  salesTaxRatePercent: number;
  currencyCode: string;
  currencySymbol: string;
  enableDigitalDignityExport: boolean;
  enableCookieConsentBanner: boolean;
  cookieBannerHeadline: string;
  cookieBannerDescription: string;
  enableQuickBagDrawer: boolean;
  enableReflectionModal: boolean;
  enableTourGuide: boolean;

  // Emergency Maintenance Mode & Administrative Notifications Dispatch
  enableMaintenanceMode?: boolean;
  maintenanceMessage?: string;
  maintenanceLockoutType?: 'full_lockout' | 'checkout_disabled';
  lowStockAlertThreshold?: number;
  dispatchOrderAlerts?: boolean;
  dispatchLowStockAlerts?: boolean;
  dispatchSecurityAlerts?: boolean;
  dispatchUgcAlerts?: boolean;
  emergencyBroadcastActive?: boolean;
  emergencyBroadcastMessage?: string;

  // ==========================================
  // GLOBAL PAYMENT GATEWAY INTEGRATIONS
  // ==========================================
  // 1. Stripe
  stripeEnabled: boolean;
  stripePublishableKey: string;
  stripeSecretKey: string;
  stripeWebhookSecret: string;
  stripeStatementDescriptor: string;
  stripeLiveMode: boolean;

  // 2. PayPal
  paypalEnabled: boolean;
  paypalClientId: string;
  paypalSecretKey: string;
  paypalWebhookId: string;
  paypalEnvironment: 'sandbox' | 'production';
  paypalPayIn4Enabled: boolean;

  // 3. Apple Pay
  applePayEnabled: boolean;
  applePayMerchantId: string;
  applePayDomainName: string;
  applePayCertStatus: 'verified' | 'pending' | 'unverified';

  // 4. Google Pay
  googlePayEnabled: boolean;
  googlePayMerchantId: string;
  googlePayGatewayMerchantId: string;
  googlePayEnvironment: 'TEST' | 'PRODUCTION';

  // 5. Klarna
  klarnaEnabled: boolean;
  klarnaClientId: string;
  klarnaClientSecret: string;
  klarnaRegion: string;

  // 6. Afterpay
  afterpayEnabled: boolean;
  afterpayMerchantId: string;
  afterpaySecretKey: string;
  afterpayRegion: string;

  // 7. Cash App Pay
  cashAppPayEnabled: boolean;
  cashAppCashtag: string;
  cashAppClientId: string;
  cashAppWebhookSecret: string;

  // 8. Shop Pay
  shopPayEnabled: boolean;
  shopPayStorefrontToken: string;
  shopPayDomain: string;

  // Print-On-Demand (POD) Production Integrations
  apliiqApiKey?: string;
  apliiqApiSecret?: string;
  apliiqStoreId?: string;
  apliiqLiveMode?: boolean;
  apliiqAutoDispatch?: boolean;
  apliiqOptionAEnabled?: boolean; // Option A: Catalog Batch Sync Importer
  apliiqOptionBEnabled?: boolean; // Option B: 1-Click Design ID Fetcher
  apliiqOptionCEnabled?: boolean; // Option C: Real-Time Webhook Listener
  apliiqWebhookEnabled?: boolean; // Backwards compatibility alias for Option C
  apliiqWebhookSecret?: string;
  apliiqDispatchMode?: 'instant' | 'grace_1h' | 'grace_2h' | 'manual';
  apliiqLiveShippingEnabled?: boolean;
  apliiqLastInventorySyncAt?: string | null;
  printfulApiKey?: string;
  printfulAutoDispatch?: boolean;

  // Google Search Console & SEO Integrations
  gscVerificationMetaTag?: string;
  gscPropertyUrl?: string;
  gscSitemapStatus?: string;
  ga4TrackingId?: string;
  googleMerchantCenterFeedUrl?: string;
  gscIndexingApiKey?: string;
  gscAutoIndexingEnabled?: boolean;

  // WhatsApp CallMeBot Integration
  whatsappNotificationsEnabled?: boolean;
  whatsappPhoneNumber?: string;
  whatsappApiKey?: string;
  whatsappNotifyOnNewOrder?: boolean;
  whatsappMessageTemplate?: string;

  // Transactional Email Dispatcher (Resend, SendGrid, Postmark, SMTP)
  emailProvider?: 'resend' | 'sendgrid' | 'postmark' | 'smtp' | 'simulated';
  emailApiKey?: string;
  emailFromSenderName?: string;
  emailFromSenderEmail?: string;
  emailLiveMode?: boolean;

  // SMTP Email Server & Transactional Email Templates
  smtpEnabled?: boolean;
  enableSignupVerificationEmail?: boolean;
  smtpHost?: string;
  smtpPort?: number;
  smtpEncryption?: 'TLS' | 'SSL' | 'NONE';
  smtpUsername?: string;
  smtpPassword?: string;
  smtpFromSenderName?: string;
  smtpFromSenderEmail?: string;
  smtpSignUpSubject?: string;
  smtpSignUpTemplate?: string;
  smtpPasswordResetSubject?: string;
  smtpPasswordResetTemplate?: string;
  smtpOrderConfirmSubject?: string;
  smtpOrderConfirmTemplate?: string;
  smtpOrderStatusSubject?: string;
  smtpOrderStatusTemplate?: string;

  // Editorial Page Content CMS
  whyWeExistHeadline?: string;
  whyWeExistSubtitle?: string;
  whyWeExistBody?: string;
  manifestoTitle?: string;
  manifestoPillars?: string[];
  careDirectivesTitle?: string;
  careDirectivesNotice?: string;
  contactPageTitle?: string;
  contactPageSubtitle?: string;
  shippingReturnsHeadline?: string;
  shippingReturnsBody?: string;

  // Additional Page CMS Content
  catalogSectionTitle?: string;
  catalogSectionSubtitle?: string;
  connectionSubmitPromptTitle?: string;
  connectionSubmitPromptGuide?: string;
  connectionEmptyStateNotice?: string;
  garmentFabricNotice?: string;
  garmentFulfillmentNotice?: string;
  faqPageTitle?: string;
  faqPageSubtitle?: string;
  termsPageTitle?: string;
  termsPageBody?: string;
  privacyPageTitle?: string;
  privacyPageBody?: string;
  journalPageTitle?: string;
  journalPageSubtitle?: string;
  footerSlogan?: string;
  newsletterHeading?: string;
  newsletterSubtitle?: string;

  // Header & Footer Menu Navigation Controls
  navigationMenuItems?: NavigationMenuItem[];
  showHeaderMenu?: boolean;
  showFooterMenu?: boolean;

  // Feature Systems Toggles (Admin Option to Turn On/Off)
  enableJournal?: boolean;
  enableReflections?: boolean;
  enableEcosystem?: boolean;
  enablePdpReviews?: boolean;
  showHomeHumanArchiveCta?: boolean;
}

interface ContentContextType {
  content: SiteContent;
  faqs: FAQItem[];
  navigationMenuItems: NavigationMenuItem[];
  updateContent: (updates: Partial<SiteContent>) => void;
  updateNavigationMenuItems: (items: NavigationMenuItem[]) => void;
  updateMenuItem: (id: string, updates: Partial<NavigationMenuItem>) => void;
  resetNavigationMenuItems: () => void;
  updatePageSeo: (pageId: string, updates: Partial<PageSeoConfig>) => void;
  resetPageSeo: (pageId: string) => void;
  addFaq: (faq: Omit<FAQItem, 'id'>) => void;
  updateFaq: (id: string, updates: Partial<FAQItem>) => void;
  deleteFaq: (id: string) => void;
  resetFaqs: () => void;
  resetAllContent: () => void;
}

export const DEFAULT_CONTENT: SiteContent = {
  adminLoginUrl: '/admin',
  spotlightSlides: [
    {
      id: 'slide-1',
      url: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Diverse Age Showcase · Park Series',
      caption: 'The Distance Between Us Is Man-Made',
    },
    {
      id: 'slide-2',
      url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Editorial Campaign · 02',
      caption: 'Interrupted Typography in Public Space',
    },
    {
      id: 'slide-3',
      url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Community & Connection',
      caption: 'Inaugural Statement — Est. Nov 2008',
    },
  ],
  // Brand & Business Profile
  brandName: 'Ezistential Connection',
  brandShortName: 'Ezistential',
  legalBusinessName: 'Ezistential Connection LLC',
  brandTagline: 'The Space Between People',
  brandLogoUrl: '/ez-logo.svg',
  brandLogoDarkUrl: '/ez-logo-white.svg',
  faviconUrl: '/ez-favicon.svg',
  pageTitleTemplate: 'Ezistential Connection — Space Between People',
  metaDescription: 'Brand-led apparel exploring the space between people, human connection, identity, and difference.',
  pageSeoConfigs: DEFAULT_PAGE_SEO,
  
  // Physical Studio & Contact Details
  businessAddressStreet: '1842 N Damen Ave, Suite 3F',
  businessAddressCity: 'Chicago',
  businessAddressState: 'IL',
  businessAddressZip: '60647',
  businessAddressCountry: 'United States',
  businessPhone: '+1 (312) 555-0192',
  supportEmail: 'care@ezistential.com',
  ordersEmail: 'orders@ezistential.com',
  pressEmail: 'press@ezistential.com',
  businessHours: 'Monday – Friday: 9:00 AM – 6:00 PM CST',

  // Social & Community Channels
  instagramHandle: '@ezistential',
  instagramUrl: 'https://instagram.com/ezistential',
  twitterHandle: '@ezistential',
  twitterUrl: 'https://x.com/ezistential',
  tiktokHandle: '@ezistential',
  tiktokUrl: '',
  youtubeUrl: '',
  spotifyUrl: 'https://open.spotify.com/user/ezistential',
  substackUrl: 'https://ezistential.substack.com',
  pinterestUrl: '',
  facebookUrl: '',
  linkedinUrl: '',
  discordUrl: '',

  // Announcements & Hero
  announcementText: 'Complimentary US Domestic Shipping on Orders $75+ • On-Demand 6.5oz Heavyweight Cotton',
  announcementActive: true,
  announcementLinkText: 'Explore Garments',
  heroMode: 'carousel',
  heroSlides: DEFAULT_HERO_SLIDES,
  heroChapterNumber: '01',
  heroChapterLabel: 'The Threshold',
  heroHeadline: 'We share the same world, yet we experience each other at a distance.',
  heroSubheadline: 'Ezistential Connection examines the space between people. Our garments carry quiet questions into public space, interrupting assumptions, honoring difference, and opening the possibility of discovery.',
  heroTagline: 'The Medium Is Clothing. The Subject Is Connection.',
  heroButtonText: 'Explore Garments',
  heroButtonTarget: 'shop',
  heroSecondaryButtonText: 'Why We Exist',
  heroSecondaryButtonTarget: 'why-we-exist',
  heroShowSecondaryButton: true,
  heroImageUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=2000&q=85',
  heroImageOverlayOpacity: 0.55,
  heroOverlayColor: '#0a0a0a',
  heroGradientStyle: 'soft',
  heroColorMood: 'golden-amber',
  heroEnableColorBlooms: true,
  heroAutoplayIntervalMs: 7500,
  heroControlsStyle: 'minimal-editorial',
  
  // Philosophy & Story
  manifestoExcerpt: 'Difference is not a defect to be eliminated, nor is it an excuse for division. Somewhere between you and me, there is an us worth discovering.',
  foundingQuote: 'We are not the same. That’s the point.',
  storyHeadline: 'Garments as Quiet Inquiries in Public Space',
  storyBody: 'We create tactile clothing designed to prompt dialogue, spark contemplation, and honor the nuance of human individuality without aggressive noise.',
  connectionPromptTitle: 'What does this mean to you?',
  connectionPromptSubtitle: 'Contribute your perspective to our curated Human Connection Archive.',

  // Frontend & Design
  selectedThemeId: 'editorial-noir',
  shapeDividerEnabled: true,
  shapeDividerVariant: 'editorial-notch',
  shapeDividerHeight: 64,
  primaryThemeColor: '#0a0a0a',
  enableImageZoom: true,

  // Global Typography & Font Size Control System
  bodyFontSize: 18,
  smallFontSize: 14,
  h1FontSize: 56,
  h2FontSize: 36,
  h3FontSize: 22,
  subtitleFontSize: 20,
  navFontSize: 13,
  badgeFontSize: 12,
  bodyLineHeight: 1.68,

  // UX & E-Commerce
  freeShippingThreshold: 75,
  standardShippingRate: 6.0,
  salesTaxRatePercent: 6.5,
  currencyCode: 'USD',
  currencySymbol: '$',
  enableDigitalDignityExport: true,
  enableCookieConsentBanner: true,
  cookieBannerHeadline: 'We believe your attention and data belong to you.',
  cookieBannerDescription: 'Ezistential Connection uses strictly essential session integrity to preserve your garment bag, customer account, and made-to-order inquiries. We categorically reject surveillance ad networks, data brokers, and third-party tracking pixels.',
  enableQuickBagDrawer: true,
  enableReflectionModal: true,
  enableTourGuide: true,

  // Emergency Maintenance Mode & Notifications Dispatch
  enableMaintenanceMode: false,
  maintenanceMessage: 'Storefront is undergoing scheduled maintenance. Please check back shortly.',
  maintenanceLockoutType: 'full_lockout',
  lowStockAlertThreshold: 5,
  dispatchOrderAlerts: true,
  dispatchLowStockAlerts: true,
  dispatchSecurityAlerts: true,
  dispatchUgcAlerts: false,
  emergencyBroadcastActive: false,
  emergencyBroadcastMessage: 'Notice: On-demand print queue operating at high volume.',

  // Global Payment Gateways Configuration
  // 1. Stripe
  stripeEnabled: true,
  stripePublishableKey: '',
  stripeSecretKey: '',
  stripeWebhookSecret: '',
  stripeStatementDescriptor: 'EZISTENTIAL',
  stripeLiveMode: false,

  // 2. PayPal
  paypalEnabled: false,
  paypalClientId: '',
  paypalSecretKey: '',
  paypalWebhookId: '',
  paypalEnvironment: 'sandbox',
  paypalPayIn4Enabled: false,

  // 3. Apple Pay
  applePayEnabled: false,
  applePayMerchantId: '',
  applePayDomainName: '',
  applePayCertStatus: 'unverified',

  // 4. Google Pay
  googlePayEnabled: false,
  googlePayMerchantId: '',
  googlePayGatewayMerchantId: '',
  googlePayEnvironment: 'TEST',

  // 5. Klarna
  klarnaEnabled: false,
  klarnaClientId: '',
  klarnaClientSecret: '',
  klarnaRegion: 'US',

  // 6. Afterpay
  afterpayEnabled: false,
  afterpayMerchantId: '',
  afterpaySecretKey: '',
  afterpayRegion: 'US',

  // 7. Cash App Pay
  cashAppPayEnabled: false,
  cashAppCashtag: '',
  cashAppClientId: '',
  cashAppWebhookSecret: '',

  // 8. Shop Pay
  shopPayEnabled: false,
  shopPayStorefrontToken: '',
  shopPayDomain: '',

  // Print-On-Demand (POD) Production Integrations
  apliiqApiKey: 'support@ezistential.com',
  apliiqApiSecret: 'support2026',
  apliiqStoreId: 'APQ-STORE-EZISTENTIAL-01',
  apliiqLiveMode: true,
  apliiqAutoDispatch: true,
  apliiqOptionAEnabled: true,
  apliiqOptionBEnabled: false,
  apliiqOptionCEnabled: false,
  apliiqWebhookEnabled: false,
  apliiqWebhookSecret: 'whsec_apq_live_94827104',
  apliiqDispatchMode: 'instant',
  apliiqLiveShippingEnabled: true,
  apliiqLastInventorySyncAt: null,
  printfulApiKey: '',
  printfulAutoDispatch: false,

  // Google Search Console & SEO Integrations
  gscVerificationMetaTag: '',
  gscPropertyUrl: 'https://ezistential.com',
  gscSitemapStatus: 'Active (https://ezistential.com/sitemap.xml)',
  ga4TrackingId: '',
  googleMerchantCenterFeedUrl: 'https://ezistential.com/api/feeds/google-merchant.xml',
  gscIndexingApiKey: '',
  gscAutoIndexingEnabled: true,

  // WhatsApp CallMeBot Integration
  whatsappNotificationsEnabled: false,
  whatsappPhoneNumber: '+13125550192',
  whatsappApiKey: '',
  whatsappNotifyOnNewOrder: true,
  whatsappMessageTemplate: '🛍️ *New Order Alert from {brand_name}!*\nOrder ID: #{order_id}\nCustomer: {customer_name}\nTotal: ${total_amount}\nItems: {items_summary}',

  // Transactional Email Service Configuration
  emailProvider: 'simulated',
  emailApiKey: '',
  emailFromSenderName: 'Ezistential Connection',
  emailFromSenderEmail: 'care@ezistential.com',
  emailLiveMode: false,

  // SMTP Email Server & Transactional Templates
  smtpEnabled: true,
  enableSignupVerificationEmail: true,
  smtpHost: 'mail.ezistential.com',
  smtpPort: 465,
  smtpEncryption: 'SSL',
  smtpUsername: 'support@ezistential.com',
  smtpPassword: 'support2026',
  smtpFromSenderName: 'Ezistential Connection Support',
  smtpFromSenderEmail: 'support@ezistential.com',
  smtpSignUpSubject: 'Welcome to Ezistential Connection — Space Between People',
  smtpSignUpTemplate: 'Dear {customer_name},\n\nWelcome to Ezistential Connection. Your account has been initialized.\n\nExplore our connection garments at https://ezistential.com\n\nWarm regards,\nEzistential Connection Studio',
  smtpPasswordResetSubject: 'Reset Your Ezistential Connection Password',
  smtpPasswordResetTemplate: 'Hello {customer_name},\n\nWe received a request to reset your password. Click the link below to verify:\n{reset_link}\n\nIf you did not request this, please ignore this message.\n\nEzistential Care Team',
  smtpOrderConfirmSubject: 'Order Confirmation #{order_id} — Ezistential Connection',
  smtpOrderConfirmTemplate: 'Dear {customer_name},\n\nThank you for your order #{order_id} totaling ${total_amount}.\n\nItems Ordered:\n{items_summary}\n\nWe are preparing your garments for print-on-demand fulfillment.\n\nEzistential Fulfillment',
  smtpOrderStatusSubject: 'Shipment Update for Order #{order_id} — In Transit',
  smtpOrderStatusTemplate: 'Dear {customer_name},\n\nYour order #{order_id} status has been updated to: {order_status}.\n\nTracking Reference: {tracking_number}\n\nThank you for journeying with us,\nEzistential Connection',

  // Editorial Page Content CMS Defaults
  whyWeExistHeadline: 'Why We Exist',
  whyWeExistSubtitle: 'A garment is not merely fabric; it is an artifact of presence.',
  whyWeExistBody: 'In an era of hyper-connectivity, physical proximity has become increasingly rare. Ezistential Connection creates garments that act as gentle signals—prompting reflection, dialogue, and quiet recognition between individuals.',
  manifestoTitle: 'The Ezistential Manifesto',
  manifestoPillars: [
    '1. Design with intention and physical weight.',
    '2. Honor the dignity of human presence over digital distraction.',
    '3. Create clothing that serves as a bridge, not a barrier.',
    '4. Practice ethical print-on-demand zero-waste manufacturing.'
  ],
  careDirectivesTitle: 'Garment Care & Fabric Integrity Directives',
  careDirectivesNotice: 'Crafted from 6.5oz 100% combed ring-spun cotton. Wash inside out in cold water, line dry to preserve fabric density and screenprint integrity.',
  contactPageTitle: 'Studio Premises & Inquiries',
  contactPageSubtitle: 'Our Chicago studio is open for scheduled consultations, press inquiries, and care support.',
  shippingReturnsHeadline: 'Logistics, Domestic Delivery & Returns Covenant',
  shippingReturnsBody: 'All garments are printed on-demand with 3–5 business days production time. Unworn garments in original condition may be returned within 30 days of receipt.',

  // Additional Page CMS Defaults
  catalogSectionTitle: 'On-Demand Heavyweight Garments',
  catalogSectionSubtitle: 'Heavyweight 6.5oz combed cotton garments designed to provoke quiet recognition.',
  connectionSubmitPromptTitle: 'Submit an Anonymous Reflection',
  connectionSubmitPromptGuide: 'Reflections are moderated by studio stewards before publication in the Connection Archive.',
  connectionEmptyStateNotice: 'No published reflections in this category yet. Be the first to share an entry.',
  garmentFabricNotice: '100% Combed Ring-Spun Cotton, 6.5oz Heavyweight Custom Blank.',
  garmentFulfillmentNotice: 'Printed on-demand with zero-waste manufacturing. 3–5 business days fulfillment.',
  faqPageTitle: 'Frequently Asked Questions & Care Directives',
  faqPageSubtitle: 'Answers regarding garment care, custom heavyweight sizing, and domestic shipping.',
  termsPageTitle: 'Terms of Service & Usage Covenant',
  termsPageBody: 'By interacting with the Ezistential Connection digital storefront, you agree to respectful engagement.',
  privacyPageTitle: 'Digital Dignity & Privacy Covenant',
  privacyPageBody: 'We process minimal telemetry required for order logistics. No third-party tracking or data harvesting.',
  journalPageTitle: 'Journal & Studio Updates',
  journalPageSubtitle: 'Articles, design manifestos, and studio notes from Ezistential Connection.',
  footerSlogan: 'Examining the space between people through intentional apparel.',
  newsletterHeading: 'Receive Studio Dispatches',
  newsletterSubtitle: 'Occasional letters on connection, garment releases, and studio manifestos.',

  // Header & Footer Menu Navigation Defaults
  navigationMenuItems: DEFAULT_NAVIGATION_MENU,
  showHeaderMenu: true,
  showFooterMenu: true,

  // Feature Systems Defaults (Enabled by default, can be turned off in Admin)
  enableJournal: true,
  enableReflections: true,
  enableEcosystem: true,
  enablePdpReviews: true,
  enableMemberVerification: true,
  memberVerificationRules: DEFAULT_VERIFICATION_RULES,
  showHomeHumanArchiveCta: false, // Default hidden to prevent client/visitor overwhelm; toggleable in CMS
};

const STORAGE_KEY_CONTENT = 'ec_cms_content_v8';
const STORAGE_KEY_FAQS = 'ec_cms_faqs_v8';

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [content, setContent] = useState<SiteContent>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CONTENT);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.faviconUrl || parsed.faviconUrl === '/favicon.ico') {
          parsed.faviconUrl = '/ez-favicon.svg';
        }
        if (!parsed.heroImageUrl) {
          parsed.heroImageUrl = DEFAULT_CONTENT.heroImageUrl;
        }
        if (parsed.heroImageOverlayOpacity === undefined) {
          parsed.heroImageOverlayOpacity = DEFAULT_CONTENT.heroImageOverlayOpacity;
        }
        if (!parsed.heroColorMood) {
          parsed.heroColorMood = DEFAULT_CONTENT.heroColorMood;
        }
        if (!parsed.heroSlides || !Array.isArray(parsed.heroSlides) || parsed.heroSlides.length === 0) {
          parsed.heroSlides = DEFAULT_HERO_SLIDES;
        }

        // Canonical Brand Migration: Upgrade legacy plural names to canonical singular
        if (parsed.brandName === 'Ezistential Connections' || !parsed.brandName) {
          parsed.brandName = 'Ezistential Connection';
        }
        if (parsed.legalBusinessName === 'Ezistential Connections LLC' || !parsed.legalBusinessName) {
          parsed.legalBusinessName = 'Ezistential Connection LLC';
        }
        if (parsed.pageTitleTemplate && parsed.pageTitleTemplate.includes('Ezistential Connections')) {
          parsed.pageTitleTemplate = parsed.pageTitleTemplate.replaceAll('Ezistential Connections', 'Ezistential Connection');
        }
        if (parsed.heroSubheadline && parsed.heroSubheadline.includes('Ezistential Connections')) {
          parsed.heroSubheadline = parsed.heroSubheadline.replaceAll('Ezistential Connections', 'Ezistential Connection');
        }
        if (parsed.cookieBannerDescription && parsed.cookieBannerDescription.includes('Ezistential Connections')) {
          parsed.cookieBannerDescription = parsed.cookieBannerDescription.replaceAll('Ezistential Connections', 'Ezistential Connection');
        }
        if (parsed.whyWeExistBody && parsed.whyWeExistBody.includes('Ezistential Connections')) {
          parsed.whyWeExistBody = parsed.whyWeExistBody.replaceAll('Ezistential Connections', 'Ezistential Connection');
        }
        if (parsed.termsPageBody && parsed.termsPageBody.includes('Ezistential Connections')) {
          parsed.termsPageBody = parsed.termsPageBody.replaceAll('Ezistential Connections', 'Ezistential Connection');
        }
        if (parsed.journalPageSubtitle && parsed.journalPageSubtitle.includes('Ezistential Connections')) {
          parsed.journalPageSubtitle = parsed.journalPageSubtitle.replaceAll('Ezistential Connections', 'Ezistential Connection');
        }
        if (parsed.emailFromSenderName === 'Ezistential Connections') {
          parsed.emailFromSenderName = 'Ezistential Connection';
        }
        if (parsed.smtpFromSenderName === 'Ezistential Connections') {
          parsed.smtpFromSenderName = 'Ezistential Connection';
        }

        // Ensure pageSeoConfigs is hydrated with complete defaults for all pages
        parsed.pageSeoConfigs = {
          ...DEFAULT_PAGE_SEO,
          ...(parsed.pageSeoConfigs || {}),
        };

        // Ensure navigationMenuItems is hydrated with complete defaults for all views
        if (!parsed.navigationMenuItems || !Array.isArray(parsed.navigationMenuItems) || parsed.navigationMenuItems.length === 0) {
          parsed.navigationMenuItems = DEFAULT_NAVIGATION_MENU;
        } else {
          // Merge any missing default items (e.g. if new views are introduced)
          const existingIds = new Set(parsed.navigationMenuItems.map((item: any) => item.id));
          const missingDefaults = DEFAULT_NAVIGATION_MENU.filter((defItem) => !existingIds.has(defItem.id));
          if (missingDefaults.length > 0) {
            parsed.navigationMenuItems = [...parsed.navigationMenuItems, ...missingDefaults];
          }

          // Respect user requests: Add Our Story to top header, ensure FAQ label is FAQ
          parsed.navigationMenuItems = parsed.navigationMenuItems.map((item: any) => {
            if (item.id === 'our-story') {
              return { ...item, showInHeader: true, location: item.showInFooter ? 'both' : 'header' };
            }
            if (item.id === 'track-order') {
              return { ...item, showInHeader: false, location: 'footer' };
            }
            if (item.id === 'faq') {
              const label = (item.label === 'FAQ & Care' || item.label === 'FAQ and Care') ? 'FAQ' : item.label;
              const customLabel = (item.customLabel === 'FAQ & Care' || item.customLabel === 'FAQ and Care') ? 'FAQ' : item.customLabel;
              return { ...item, label, customLabel };
            }
            return item;
          });
        }
        if (parsed.showHeaderMenu === undefined) parsed.showHeaderMenu = true;
        if (parsed.showFooterMenu === undefined) parsed.showFooterMenu = true;
        if (parsed.enableJournal === undefined) parsed.enableJournal = true;
        if (parsed.enableReflections === undefined) parsed.enableReflections = true;
        if (parsed.enableEcosystem === undefined) parsed.enableEcosystem = true;
        if (parsed.enablePdpReviews === undefined) parsed.enablePdpReviews = true;
        if (parsed.enableMemberVerification === undefined) parsed.enableMemberVerification = true;
        if (parsed.stripeEnabled === undefined) parsed.stripeEnabled = true;

        return { ...DEFAULT_CONTENT, ...parsed };
      }
      return DEFAULT_CONTENT;
    } catch {
      return DEFAULT_CONTENT;
    }
  });

  const [faqs, setFaqs] = useState<FAQItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FAQS);
      return saved ? JSON.parse(saved) : DEFAULT_FAQS;
    } catch {
      return DEFAULT_FAQS;
    }
  });

  // Universal Server-First Revalidation: update CMS & settings from database as soon as internet is detected
  const syncContentFromDB = useCallback(async () => {
    try {
      const serverData = await api.getContent();
      if (serverData) {
        const incomingContent = (serverData as any).content || ((serverData as any).brandName ? serverData : null);
        if (incomingContent && Object.keys(incomingContent).length > 0) {
          setContent((prev) => {
            const next = { ...prev, ...incomingContent };
            try {
              localStorage.setItem(STORAGE_KEY_CONTENT, JSON.stringify(next));
            } catch {}
            return next;
          });
        }
        const incomingFaqs = (serverData as any).faqs;
        if (incomingFaqs && Array.isArray(incomingFaqs) && incomingFaqs.length > 0) {
          setFaqs(incomingFaqs);
          try {
            localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(incomingFaqs));
          } catch {}
        }
      }
    } catch (err) {
      console.warn('Central DB content sync notice:', err);
    }
  }, []);

  useEffect(() => {
    // 1. Initial sync from central server database
    syncContentFromDB();

    // 2. Revalidate as soon as PWA reconnects to internet or focuses
    const unregister = serverSync.register(() => {
      syncContentFromDB();
    });
    return unregister;
  }, [syncContentFromDB]);

  // Dynamic Typography & Font Sizing live CSS injector
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    const bodySize = content.bodyFontSize ?? 18;
    const smallSize = content.smallFontSize ?? 14;
    const h1Size = content.h1FontSize ?? 56;
    const h2Size = content.h2FontSize ?? 36;
    const h3Size = content.h3FontSize ?? 22;
    const subtitleSize = content.subtitleFontSize ?? 20;
    const navSize = content.navFontSize ?? 13;
    const badgeSize = content.badgeFontSize ?? 12;
    const lineHeight = content.bodyLineHeight ?? 1.68;

    root.style.setProperty('--font-size-body', `${bodySize}px`);
    root.style.setProperty('--font-size-small', `${smallSize}px`);
    root.style.setProperty('--font-size-h1', `${h1Size}px`);
    root.style.setProperty('--font-size-h2', `${h2Size}px`);
    root.style.setProperty('--font-size-h3', `${h3Size}px`);
    root.style.setProperty('--font-size-subtitle', `${subtitleSize}px`);
    root.style.setProperty('--font-size-nav', `${navSize}px`);
    root.style.setProperty('--font-size-badge', `${badgeSize}px`);
    root.style.setProperty('--line-height-body', `${lineHeight}`);

    // Update Tailwind theme CSS variables dynamically so all utility classes react instantly
    root.style.setProperty('--text-xs', `${Math.max(10, smallSize - 1)}px`);
    root.style.setProperty('--text-sm', `${smallSize + 1}px`);
    root.style.setProperty('--text-base', `${bodySize}px`);
    root.style.setProperty('--text-lg', `${bodySize + 2}px`);
    root.style.setProperty('--text-xl', `${subtitleSize}px`);
    root.style.setProperty('--text-2xl', `${h3Size + 2}px`);
    root.style.setProperty('--text-3xl', `${Math.round(h2Size * 0.9)}px`);
    root.style.setProperty('--text-4xl', `${h2Size}px`);
    root.style.setProperty('--text-5xl', `${Math.round(h1Size * 0.9)}px`);
    root.style.setProperty('--text-6xl', `${h1Size}px`);
  }, [
    content.bodyFontSize,
    content.smallFontSize,
    content.h1FontSize,
    content.h2FontSize,
    content.h3FontSize,
    content.subtitleFontSize,
    content.navFontSize,
    content.badgeFontSize,
    content.bodyLineHeight,
  ]);

  // Save content changes to localStorage & backend
  const updateContent = (updates: Partial<SiteContent>) => {
    setContent((prev) => {
      const updated = { ...prev, ...updates };
      try {
        localStorage.setItem(STORAGE_KEY_CONTENT, JSON.stringify(updated));
      } catch (err) {
        console.error('Failed to save content locally:', err);
      }
      // Persist to central server database
      api.updateContent(updated).catch(console.warn);
      return updated;
    });
  };

  const updatePageSeo = (pageId: string, updates: Partial<PageSeoConfig>) => {
    setContent((prev) => {
      const currentConfigs = prev.pageSeoConfigs || DEFAULT_PAGE_SEO;
      const existing = currentConfigs[pageId] || DEFAULT_PAGE_SEO[pageId] || DEFAULT_PAGE_SEO.home;
      const updatedConfig = { ...existing, ...updates, id: pageId };
      const updated = {
        ...prev,
        pageSeoConfigs: {
          ...currentConfigs,
          [pageId]: updatedConfig,
        },
      };
      try {
        localStorage.setItem(STORAGE_KEY_CONTENT, JSON.stringify(updated));
      } catch (err) {
        console.error('Failed to save page SEO locally:', err);
      }
      api.updateContent(updated).catch(console.warn);
      return updated;
    });
  };

  const resetPageSeo = (pageId: string) => {
    if (DEFAULT_PAGE_SEO[pageId]) {
      updatePageSeo(pageId, DEFAULT_PAGE_SEO[pageId]);
    }
  };

  const addFaq = (newFaqData: Omit<FAQItem, 'id'>) => {
    const newFaq: FAQItem = {
      ...newFaqData,
      id: `faq-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    };
    setFaqs((prev) => {
      const updated = [...prev, newFaq];
      localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(updated));
      api.updateContent(content, updated).catch(console.warn);
      return updated;
    });
  };

  const updateFaq = (id: string, updates: Partial<FAQItem>) => {
    setFaqs((prev) => {
      const updated = prev.map((f) => (f.id === id ? { ...f, ...updates } : f));
      localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(updated));
      api.updateContent(content, updated).catch(console.warn);
      return updated;
    });
  };

  const deleteFaq = (id: string) => {
    setFaqs((prev) => {
      const updated = prev.filter((f) => f.id !== id);
      localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(updated));
      api.updateContent(content, updated).catch(console.warn);
      return updated;
    });
  };

  const resetFaqs = () => {
    setFaqs(DEFAULT_FAQS);
    localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(DEFAULT_FAQS));
    api.updateContent(content, DEFAULT_FAQS).catch(console.warn);
  };

  const resetAllContent = () => {
    setContent(DEFAULT_CONTENT);
    setFaqs(DEFAULT_FAQS);
    localStorage.setItem(STORAGE_KEY_CONTENT, JSON.stringify(DEFAULT_CONTENT));
    localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(DEFAULT_FAQS));
    api.updateContent(DEFAULT_CONTENT).catch(console.warn);
  };

  // Sync browser document title, favicon, and UX/UI theme dynamically
  useEffect(() => {
    const brand = content.brandName || 'Ezistential Connection';
    const rawTemplate = content.pageTitleTemplate || `${brand} — Space Between People`;
    const cleanTitle = rawTemplate.replaceAll('Ezistential Connections', brand);
    document.title = cleanTitle;
    if (content.faviconUrl) {
      let link: HTMLLinkElement | null = document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.getElementsByTagName('head')[0].appendChild(link);
      }
      link.href = content.faviconUrl;
    }

    // Apply Live UI Theme to document root & body
    const activeTheme = content.selectedThemeId || 'editorial-noir';
    const root = document.documentElement;
    root.setAttribute('data-theme', activeTheme);
    
    // Remove previous theme classes and attach current theme class
    const themeClasses = ['theme-editorial-noir', 'theme-warm-parchment', 'theme-raw-canvas', 'theme-cyber-minimalist'];
    themeClasses.forEach((cls) => {
      document.body.classList.remove(cls);
      root.classList.remove(cls);
    });
    document.body.classList.add(`theme-${activeTheme}`);
    root.classList.add(`theme-${activeTheme}`);

    // Update CSS custom variable for theme primary accent color
    if (content.primaryThemeColor) {
      root.style.setProperty('--color-theme-primary', content.primaryThemeColor);
    }
  }, [content.pageTitleTemplate, content.faviconUrl, content.selectedThemeId, content.primaryThemeColor]);

  const navigationMenuItems = content.navigationMenuItems || DEFAULT_NAVIGATION_MENU;

  const updateNavigationMenuItems = (items: NavigationMenuItem[]) => {
    updateContent({ navigationMenuItems: items });
  };

  const updateMenuItem = (id: string, updates: Partial<NavigationMenuItem>) => {
    const current = content.navigationMenuItems || DEFAULT_NAVIGATION_MENU;
    const updated = current.map((item) => (item.id === id ? { ...item, ...updates } : item));
    updateContent({ navigationMenuItems: updated });
  };

  const resetNavigationMenuItems = () => {
    updateContent({
      navigationMenuItems: DEFAULT_NAVIGATION_MENU,
      showHeaderMenu: true,
      showFooterMenu: true,
    });
  };

  return (
    <ContentContext.Provider
      value={{
        content,
        faqs,
        navigationMenuItems,
        updateContent,
        updateNavigationMenuItems,
        updateMenuItem,
        resetNavigationMenuItems,
        updatePageSeo,
        resetPageSeo,
        addFaq,
        updateFaq,
        deleteFaq,
        resetFaqs,
        resetAllContent,
      }}
    >
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const ctx = useContext(ContentContext);
  if (!ctx) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return ctx;
};
