import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  maxWidth = 'lg',
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 xs:p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#0a0a0a]/75 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Dialog Window */}
      <div
        className={cn(
          'relative w-full bg-[#fbfbf9] text-[#0a0a0a] shadow-2xl border border-[#e5e5e5] p-4.5 xs:p-6 sm:p-8 z-10 my-auto sm:my-8 max-h-[calc(100dvh-1.5rem)] sm:max-h-[calc(100dvh-3rem)] flex flex-col transition-transform duration-300',
          maxWidth === 'sm' && 'max-w-md',
          maxWidth === 'md' && 'max-w-lg',
          maxWidth === 'lg' && 'max-w-2xl',
          maxWidth === 'xl' && 'max-w-3xl',
          maxWidth === '2xl' && 'max-w-4xl'
        )}
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-3.5 right-3.5 sm:top-5 sm:right-5 p-2 text-neutral-500 hover:text-black transition-colors focus:outline-hidden min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5 stroke-[1.5]" />
        </button>

        {(title || subtitle) && (
          <div className="mb-4 sm:mb-6 pr-10 sm:pr-8 border-b border-neutral-200 pb-3 sm:pb-4 shrink-0">
            {title && <h3 className="font-serif text-xl sm:text-2xl tracking-tight text-neutral-900 text-balance leading-snug">{title}</h3>}
            {subtitle && <p className="text-[11px] sm:text-xs uppercase tracking-wider text-neutral-500 mt-1 font-mono">{subtitle}</p>}
          </div>
        )}

        <div className="overflow-y-auto overscroll-contain pr-1 -mr-1">{children}</div>
      </div>
    </div>
  );
};
