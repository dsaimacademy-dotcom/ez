import React from 'react';

export type ShapeDividerVariant =
  | 'zebra-contour'
  | 'editorial-notch'
  | 'textile-seam'
  | 'horizon-converge'
  | 'asymmetric-slash'
  | 'parabolic-arch'
  | 'organic-swell'
  | 'subtle-crest';

export interface ShapeDividerProps {
  variant: ShapeDividerVariant;
  /** Fill color of the shape (matches the section it points into or emerges from) */
  fillColor?: string;
  /** Background color of the parent container or underlying canvas (transparent by default to prevent color mismatches) */
  bgColor?: string;
  /** Top or bottom edge of the section */
  position?: 'top' | 'bottom';
  /** Flip horizontally for visual rhythm alternation */
  flipX?: boolean;
  /** Height in pixels or custom Tailwind height */
  height?: number;
  className?: string;
}

export const ShapeDivider: React.FC<ShapeDividerProps> = ({
  variant = 'editorial-notch',
  fillColor = '#0a0a0a',
  bgColor = 'transparent',
  position = 'bottom',
  flipX = false,
  height = 56,
  className = '',
}) => {
  const isTop = position === 'top';

  // Transform for orientation & flip
  const transform = [
    isTop ? 'rotate(180deg)' : '',
    flipX ? 'scaleX(-1)' : '',
  ]
    .filter(Boolean)
    .join(' ');

  const isWhite =
    fillColor?.toLowerCase() === '#ffffff' ||
    fillColor?.toLowerCase() === '#fff' ||
    fillColor === 'white';
  const isDarkFill =
    fillColor === '#0a0a0a' ||
    fillColor === '#141414' ||
    fillColor === '#121212' ||
    fillColor === '#1a1a1a';
  const strokeColor = isWhite
    ? 'rgba(0, 0, 0, 0.12)'
    : isDarkFill
    ? 'rgba(255, 255, 255, 0.08)'
    : 'rgba(0, 0, 0, 0.04)';

  // Architectural Shape Divider Variants
  const renderShape = () => {
    switch (variant) {
      case 'zebra-contour':
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,32 C360,62 540,16 900,48 C1140,68 1320,38 1440,30 L1440,84 L0,84 Z"
              fill={fillColor}
              style={{ fill: fillColor }}
            />
            <path
              d="M0,32 C360,62 540,16 900,48 C1140,68 1320,38 1440,30"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );

      case 'textile-seam':
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,36 L720,48 L1440,36 L1440,84 L0,84 Z"
              fill={fillColor}
              style={{ fill: fillColor }}
            />
            <path
              d="M0,36 L720,48 L1440,36"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );

      case 'horizon-converge':
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,20 L1440,56 L1440,84 L0,84 Z"
              fill={fillColor}
              style={{ fill: fillColor }}
            />
            <path
              d="M0,20 L1440,56"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );

      case 'asymmetric-slash':
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,48 L960,18 L1440,42 L1440,84 L0,84 Z"
              fill={fillColor}
              style={{ fill: fillColor }}
            />
            <path
              d="M0,48 L960,18 L1440,42"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );

      case 'parabolic-arch':
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,72 Q720,10 1440,72 L1440,84 L0,84 Z"
              fill={fillColor}
              style={{ fill: fillColor }}
            />
            <path
              d="M0,72 Q720,10 1440,72"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );

      case 'organic-swell':
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,45 C320,80 580,18 920,52 C1160,76 1340,32 1440,24 L1440,84 L0,84 Z"
              fill={fillColor}
              style={{ fill: fillColor }}
            />
            <path
              d="M0,45 C320,80 580,18 920,52 C1160,76 1340,32 1440,24"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );

      case 'subtle-crest':
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,58 C480,24 960,24 1440,58 L1440,84 L0,84 Z"
              fill={fillColor}
              style={{ fill: fillColor }}
            />
            <path
              d="M0,58 C480,24 960,24 1440,58"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );

      case 'editorial-notch':
      default:
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,28 L660,54 L720,40 L1440,24 L1440,84 L0,84 Z"
              fill={fillColor}
              style={{ fill: fillColor }}
            />
            <path
              d="M0,28 L660,54 L720,40 L1440,24"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );
    }
  };

  return (
    <div
      className={`relative w-full overflow-hidden select-none pointer-events-none z-10 block leading-none ${className}`}
      style={{
        backgroundColor: bgColor === 'transparent' ? undefined : bgColor,
        height: `${height}px`,
        transform: transform || undefined,
        transformOrigin: 'center center',
      }}
      aria-hidden="true"
    >
      {renderShape()}
    </div>
  );
};
