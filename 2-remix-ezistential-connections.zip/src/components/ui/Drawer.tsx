import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  position?: 'right' | 'left';
  widthClass?: string;
  noPadding?: boolean;
}

export const Drawer: React.FC<DrawerProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  position = 'right',
  widthClass = 'max-w-md',
  noPadding = false,
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const showHeader = Boolean(title || subtitle);
  const shouldOmitPadding = noPadding || !showHeader;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#0a0a0a]/60 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className={cn(
          'fixed inset-y-0 flex max-w-full z-10 w-full pointer-events-none',
          position === 'right' ? 'right-0 justify-end' : 'left-0 justify-start'
        )}
      >
        <div
          className={cn(
            'pointer-events-auto w-full max-w-full sm:w-full bg-[#fbfbf9] text-[#0a0a0a] shadow-2xl flex flex-col duration-300 h-full h-[100dvh] max-h-[100dvh]',
            position === 'right'
              ? 'border-l border-neutral-200 animate-in slide-in-from-right'
              : 'border-r border-neutral-200 animate-in slide-in-from-left',
            widthClass
          )}
        >
          {/* Header - Only rendered if title or subtitle is explicitly configured */}
          {showHeader && (
            <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-200 shrink-0 bg-[#f5f4f0]">
              <div>
                {title && (
                  <h2 className="font-serif text-xl tracking-tight text-neutral-900">{title}</h2>
                )}
                {subtitle && (
                  <p className="text-[11px] uppercase tracking-wider text-neutral-500 mt-0.5 font-mono">
                    {subtitle}
                  </p>
                )}
              </div>
              <button
                onClick={onClose}
                className="p-1.5 text-neutral-500 hover:text-black transition-colors rounded-xs cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center"
                aria-label="Close panel"
              >
                <X className="w-5 h-5 stroke-[1.5]" />
              </button>
            </div>
          )}

          {/* Body */}
          <div
            className={cn(
              'flex-1 flex flex-col min-h-0 overflow-y-auto',
              !shouldOmitPadding && 'px-6 py-5'
            )}
          >
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};
