import React, { useState, useEffect, useId } from 'react';

export interface ProductImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  className?: string;
  wrapperClassName?: string;
  aspectRatio?: '3/4' | '4/3' | '1/1' | '16/9' | 'auto' | string;
  sizes?: string;
  priority?: boolean;
  objectFit?: 'cover' | 'contain' | 'fill';
  showBlurPlaceholder?: boolean;
  blurColorHex?: string;
  onLoadCallback?: () => void;
}

/**
 * Helper to construct responsive `srcset` for image URLs (e.g. Unsplash or standard CDNs).
 * Supports URLs with existing width parameters or standard image endpoints.
 */
export const buildResponsiveSrcSet = (url: string): string | undefined => {
  if (!url || url.startsWith('data:') || url.startsWith('blob:')) {
    return undefined;
  }

  // Unsplash CDN support
  if (url.includes('images.unsplash.com')) {
    const baseUrl = url.split('?')[0];
    const widths = [320, 480, 640, 800, 1080, 1400, 1920];
    return widths.map((w) => `${baseUrl}?auto=format&fit=crop&w=${w}&q=80 ${w}w`).join(', ');
  }

  // Generic dynamic CDN query helper (if using w= query parameter)
  if (url.includes('?w=') || url.includes('&w=')) {
    const baseUrl = url.replace(/([?&])w=\d+/, '$1');
    const widths = [360, 640, 960, 1280, 1600];
    return widths.map((w) => `${baseUrl}&w=${w} ${w}w`).join(', ');
  }

  return undefined;
};

/**
 * Generates an ultra-light inline SVG data URI as a micro blur-up placeholder.
 */
export const createSVGBlurPlaceholder = (text: string = 'Garment', color: string = '#f5f5f4'): string => {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="100%" height="100%">
    <filter id="b" x="0" y="0">
      <feGaussianBlur stdDeviation="20" />
    </filter>
    <rect width="100%" height="100%" fill="${color}" />
    <circle cx="150" cy="180" r="80" fill="#e7e5e4" filter="url(#b)" />
    <path d="M 90,260 Q 150,220 210,260" stroke="#d6d3d1" stroke-width="12" fill="none" filter="url(#b)" />
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
};

export const ProductImage: React.FC<ProductImageProps> = ({
  src,
  alt,
  className = '',
  wrapperClassName = '',
  aspectRatio = '3/4',
  sizes = '(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw',
  priority = false,
  objectFit = 'cover',
  showBlurPlaceholder = true,
  blurColorHex = '#f5f5f4',
  onLoadCallback,
  onClick,
  ...restProps
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const uniqueFilterId = useId();

  // Reset state if image source changes
  useEffect(() => {
    setIsLoaded(false);
    setHasError(false);
  }, [src]);

  const responsiveSrcSet = buildResponsiveSrcSet(src);
  const blurPlaceholder = createSVGBlurPlaceholder(alt, blurColorHex);

  const getAspectClass = () => {
    switch (aspectRatio) {
      case '3/4':
        return 'aspect-3/4';
      case '4/3':
        return 'aspect-4/3';
      case '1/1':
      case 'square':
        return 'aspect-square';
      case '16/9':
        return 'aspect-video';
      case 'auto':
        return '';
      default:
        return aspectRatio.includes('/') ? `aspect-[${aspectRatio}]` : aspectRatio;
    }
  };

  const objectFitClass =
    objectFit === 'contain' ? 'object-contain' : objectFit === 'fill' ? 'object-fill' : 'object-cover';

  return (
    <div
      className={`relative overflow-hidden bg-neutral-100 ${getAspectClass()} ${wrapperClassName}`}
      onClick={onClick}
    >
      {/* 1. Blur-up Low Quality Placeholder / Skeleton Layer */}
      {showBlurPlaceholder && !isLoaded && !hasError && (
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none">
          {/* Micro SVG blur backdrop */}
          <img
            src={blurPlaceholder}
            alt=""
            aria-hidden="true"
            className="w-full h-full object-cover filter blur-xl scale-110 opacity-100 transition-opacity duration-700 ease-out"
          />
          {/* Subtle animated shimmer overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
        </div>
      )}

      {/* 2. Error Fallback State (Zero Broken Image Policy) */}
      {hasError ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-4 bg-neutral-100 border border-neutral-200 text-center select-none">
          <div className="w-10 h-10 mb-2 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-500">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
          <span className="font-serif text-xs text-neutral-600 line-clamp-1">{alt || 'Product Imagery'}</span>
          <span className="text-[10px] text-neutral-400 mt-0.5">Ezistential Studio</span>
        </div>
      ) : (
        /* 3. Main Product Image with Lazy Loading & Responsive Srcset */
        <img
          src={src}
          srcSet={responsiveSrcSet}
          sizes={responsiveSrcSet ? sizes : undefined}
          alt={alt}
          loading={priority ? 'eager' : 'lazy'}
          decoding="async"
          referrerPolicy="no-referrer"
          onLoad={() => {
            setIsLoaded(true);
            if (onLoadCallback) onLoadCallback();
          }}
          onError={() => {
            setHasError(true);
          }}
          className={`w-full h-full ${objectFitClass} transition-all duration-700 ease-out ${
            isLoaded
              ? 'opacity-100 blur-0 scale-100'
              : 'opacity-0 blur-md scale-103'
          } ${className}`}
          {...restProps}
        />
      )}
    </div>
  );
};

export default ProductImage;
