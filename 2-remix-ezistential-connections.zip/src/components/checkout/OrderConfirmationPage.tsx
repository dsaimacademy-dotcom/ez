import React, { useState } from 'react';
import { Check, Copy, ArrowRight, Truck, Package, Clock, ShieldCheck } from 'lucide-react';
import { Order } from '../../types';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { ProductImage } from '../ui/ProductImage';
import { Logo } from '../brand/Logo';
import { formatPrice } from '../../lib/utils';

export interface OrderConfirmationPageProps {
  order: Order;
  onTrackOrder: (orderNumber: string, email: string) => void;
  onContinueShopping: () => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({
  order,
  onTrackOrder,
  onContinueShopping,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard?.writeText(order.orderNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 space-y-12">
      {/* Hero Confirmation */}
      <div className="text-center space-y-4 border-b border-neutral-200 pb-10">
        <div className="flex justify-center mb-6">
          <Logo variant="black" className="h-7 w-auto" />
        </div>
        <div className="w-16 h-16 rounded-full bg-black text-white flex items-center justify-center mx-auto shadow-md">
          <Check className="w-8 h-8 stroke-[1.5]" />
        </div>

        <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium block">
          Order Confirmed & Payment Received
        </span>

        <h1 className="font-serif text-3xl sm:text-5xl text-neutral-900 tracking-tight">
          Thank you, {order.customerName.split(' ')[0]}.
        </h1>

        <p className="text-xs sm:text-sm text-neutral-600 max-w-xl mx-auto leading-relaxed">
          Your order has entered our on-demand production queue. A detailed dispatch confirmation has been routed to <strong>{order.customerEmail}</strong>.
        </p>

        {/* Order Number Badge & Copy */}
        <div className="pt-2 flex items-center justify-center gap-3">
          <div className="bg-[#f5f4f0] border border-neutral-300 px-4 py-2 flex items-center gap-3">
            <span className="text-xs text-neutral-500 uppercase tracking-wider">Order No:</span>
            <span className="font-mono text-sm font-semibold text-neutral-900">{order.orderNumber}</span>
            <button
              onClick={handleCopy}
              className="text-neutral-500 hover:text-black transition-colors p-1 cursor-pointer"
              title="Copy Order Number"
              aria-label="Copy Order Number"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Fulfillment Status Banner */}
      <div className="bg-[#f5f4f0] border border-neutral-200 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
          <div>
            <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-medium block">
              Current Lifecycle
            </span>
            <h3 className="font-serif text-xl text-neutral-900 mt-0.5">
              Production Queue Initiated
            </h3>
          </div>
          <Badge variant="dark">{order.status}</Badge>
        </div>

        {/* Stepper */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
          <div className="flex items-start space-x-3">
            <div className="w-7 h-7 rounded-full bg-black text-white flex items-center justify-center shrink-0 text-xs font-mono">
              1
            </div>
            <div>
              <p className="text-xs font-semibold text-neutral-900">Payment Processing</p>
              <p className="text-[11px] text-neutral-500 mt-0.5">Completed successfully via {order.paymentMethod.replace('_', ' ')}</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="w-7 h-7 rounded-full bg-black text-white flex items-center justify-center shrink-0 text-xs font-mono">
              2
            </div>
            <div>
              <p className="text-xs font-semibold text-neutral-900">On-Demand Production</p>
              <p className="text-[11px] text-neutral-500 mt-0.5">Printing & curing via Apliiq partner facility (2–4 business days)</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="w-7 h-7 rounded-full bg-neutral-200 text-neutral-600 flex items-center justify-center shrink-0 text-xs font-mono">
              3
            </div>
            <div>
              <p className="text-xs font-semibold text-neutral-900">Delivery Dispatch</p>
              <p className="text-[11px] text-neutral-500 mt-0.5">Est. {order.estimatedDeliveryDate} via USPS Ground</p>
            </div>
          </div>
        </div>
      </div>

      {/* Order Details & Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
        {/* Purchased Items */}
        <div className="space-y-4">
          <h3 className="font-serif text-lg text-neutral-900 border-b border-neutral-200 pb-2">
            Garments ({order.items.reduce((acc, i) => acc + i.quantity, 0)})
          </h3>

          <div className="divide-y divide-neutral-200">
            {order.items.map((item) => (
              <div key={item.id} className="py-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <ProductImage
                    src={item.image}
                    alt={item.productName}
                    aspectRatio="auto"
                    wrapperClassName="w-14 h-18 shrink-0 border border-neutral-200"
                    sizes="100px"
                  />
                  <div>
                    <h4 className="font-serif text-sm font-medium text-neutral-900 leading-tight">
                      {item.productName}
                    </h4>
                    <p className="text-neutral-500 text-[11px] mt-0.5">
                      {item.wearType && <span className="font-mono text-neutral-700 font-medium">{item.wearType} • </span>}
                      Size: {item.size} • Color: {item.color}
                    </p>
                    <p className="text-neutral-400 text-[10px] font-mono mt-0.5">
                      Qty: {item.quantity} × {formatPrice(item.price)}
                    </p>
                  </div>
                </div>

                <span className="font-mono text-neutral-900 font-medium">
                  {formatPrice(item.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>

          {/* Pricing Summary */}
          <div className="bg-[#f5f4f0] p-4 border border-neutral-200 space-y-2 text-xs">
            <div className="flex justify-between text-neutral-600">
              <span>Subtotal</span>
              <span className="font-mono text-neutral-900">{formatPrice(order.subtotal)}</span>
            </div>
            <div className="flex justify-between text-neutral-600">
              <span>Shipping</span>
              <span className="font-mono text-neutral-900">
                {order.shippingCost === 0 ? 'FREE' : formatPrice(order.shippingCost)}
              </span>
            </div>
            <div className="flex justify-between text-neutral-600">
              <span>Tax</span>
              <span className="font-mono text-neutral-900">{formatPrice(order.taxCost)}</span>
            </div>
            <div className="flex justify-between text-sm font-semibold text-neutral-900 pt-2 border-t border-neutral-200">
              <span>Total Paid</span>
              <span className="font-mono">{formatPrice(order.total)}</span>
            </div>
          </div>
        </div>

        {/* Shipping Destination & Action Buttons */}
        <div className="space-y-6">
          <div className="space-y-3">
            <h3 className="font-serif text-lg text-neutral-900 border-b border-neutral-200 pb-2">
              Shipping Destination
            </h3>
            <div className="text-xs text-neutral-700 space-y-1 font-sans">
              <p className="font-medium text-neutral-900">{order.shippingAddress.fullName}</p>
              <p>{order.shippingAddress.street}</p>
              {order.shippingAddress.apartment && <p>{order.shippingAddress.apartment}</p>}
              <p>
                {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}
              </p>
              <p className="text-neutral-500 uppercase tracking-widest text-[10px]">United States</p>
            </div>
          </div>

          <div className="bg-[#f5f4f0] p-4 border border-neutral-200 space-y-2">
            <div className="flex items-center space-x-2 text-xs font-semibold text-neutral-900">
              <ShieldCheck className="w-4 h-4 text-neutral-700" />
              <span>30-Day Quality Guarantee</span>
            </div>
            <p className="text-[11px] text-neutral-600 leading-relaxed font-sans">
              If your garment exhibits any defect, misprint, or damage upon arrival, contact us with your order number for an immediate replacement or refund.
            </p>
          </div>

          <div className="space-y-3 pt-2">
            <Button
              onClick={() => onTrackOrder(order.orderNumber, order.customerEmail)}
              variant="primary"
              size="lg"
              fullWidth
              className="flex items-center justify-center space-x-2"
            >
              <span>Track This Order</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>

            <Button
              onClick={onContinueShopping}
              variant="outline"
              size="md"
              fullWidth
            >
              Continue Exploring
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
