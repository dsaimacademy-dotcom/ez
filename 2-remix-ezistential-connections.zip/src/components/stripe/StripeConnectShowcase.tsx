import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Building2,
  Package,
  Plus,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
  Zap,
  Tag,
  DollarSign,
  Layers,
} from 'lucide-react';

interface ConnectedAccount {
  id: string;
  userId: string;
  displayName: string;
  contactEmail: string;
  isSimulation?: boolean;
  createdAt: string;
  accountData?: any;
}

interface ConnectProduct {
  id: string;
  name: string;
  description: string;
  priceInCents: number;
  currency: string;
  priceId?: string;
  connectedAccountId: string;
  isSimulation?: boolean;
  createdAt: string;
}

export const StripeConnectShowcase: React.FC = () => {
  const [accounts, setAccounts] = useState<ConnectedAccount[]>([]);
  const [products, setProducts] = useState<ConnectProduct[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'onboarding' | 'products' | 'storefront'>('onboarding');

  // Account creation form
  const [displayName, setDisplayName] = useState<string>('Marcus Vance Design Studio');
  const [contactEmail, setContactEmail] = useState<string>('marcus@ezistential.com');
  const [creatingAccount, setCreatingAccount] = useState<boolean>(false);
  const [accountStatusMap, setAccountStatusMap] = useState<Record<string, any>>({});
  const [checkingStatusId, setCheckingStatusId] = useState<string | null>(null);

  // Product creation form
  const [productName, setProductName] = useState<string>('Heavyweight Minimalist Hoodie (Custom Stitch)');
  const [productDesc, setProductDesc] = useState<string>('14oz French Terry Cotton designed with custom contrast tagging');
  const [productPriceUSD, setProductPriceUSD] = useState<string>('120');
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [creatingProduct, setCreatingProduct] = useState<boolean>(false);

  // Checkout process
  const [buyingProductId, setBuyingProductId] = useState<string | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const fetchStorefrontData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/stripe-connect/storefront');
      const data = await res.json();
      if (data.success) {
        setAccounts(data.accounts || []);
        setProducts(data.products || []);
        if (data.accounts?.length > 0 && !selectedAccountId) {
          setSelectedAccountId(data.accounts[0].id);
        }
      }
    } catch (err: any) {
      console.error('Failed to fetch Stripe Connect storefront data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStorefrontData();

    // Check query params for checkout returns or onboarding returns
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('purchased') === 'true') {
      setFeedbackMsg({
        type: 'success',
        text: 'Payment completed successfully via Stripe Destination Charge!',
      });
    } else if (urlParams.get('accountId') && urlParams.get('success') === 'true') {
      setFeedbackMsg({
        type: 'success',
        text: `Onboarding completed for Stripe Account ${urlParams.get('accountId')}`,
      });
    }
  }, []);

  // 1. Create Connected Account (V2 API)
  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName || !contactEmail) return;

    setCreatingAccount(true);
    setFeedbackMsg(null);

    try {
      const res = await fetch('/api/stripe-connect/accounts/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ displayName, contactEmail, country: 'us' }),
      });
      const data = await res.json();

      if (data.success) {
        setFeedbackMsg({
          type: 'success',
          text: data.message || 'Connected Account created!',
        });
        await fetchStorefrontData();
        if (data.account?.id) {
          checkAccountStatus(data.account.id);
        }
      } else {
        setFeedbackMsg({ type: 'error', text: data.error || 'Account creation failed' });
      }
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err.message || 'Failed to connect to server' });
    } finally {
      setCreatingAccount(false);
    }
  };

  // 2. Onboard Connected Account via Account Links API
  const handleOnboardAccount = async (accountId: string) => {
    setFeedbackMsg(null);
    try {
      const res = await fetch('/api/stripe-connect/account-links/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accountId, originUrl: window.location.origin }),
      });
      const data = await res.json();

      if (data.success && data.url) {
        if (data.isSimulation) {
          setFeedbackMsg({
            type: 'info',
            text: `Simulated Onboarding URL: ${data.url}. (Enter live sk_test_ key in Payment Gateways CMS to redirect to real Stripe Express UI).`,
          });
        } else {
          window.location.href = data.url;
        }
      } else {
        setFeedbackMsg({ type: 'error', text: data.error || 'Onboarding link generation failed' });
      }
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err.message || 'Onboarding link request failed' });
    }
  };

  // Check Account Status directly from API
  const checkAccountStatus = async (accountId: string) => {
    setCheckingStatusId(accountId);
    try {
      const res = await fetch(`/api/stripe-connect/accounts/${accountId}`);
      const data = await res.json();
      if (data.success) {
        setAccountStatusMap((prev) => ({
          ...prev,
          [accountId]: {
            ready: data.readyToReceivePayments,
            onboardingComplete: data.onboardingComplete,
            requirementsStatus: data.requirementsStatus,
            isSimulation: data.isSimulation,
          },
        }));
      }
    } catch (err: any) {
      console.error('Failed to retrieve account status', err);
    } finally {
      setCheckingStatusId(null);
    }
  };

  // 3. Create Product at Platform Level mapped to Connected Account
  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName || !productPriceUSD || !selectedAccountId) {
      setFeedbackMsg({ type: 'error', text: 'Product name, price, and connected account selection are required.' });
      return;
    }

    setCreatingProduct(true);
    setFeedbackMsg(null);

    try {
      const priceInCents = Math.round(parseFloat(productPriceUSD) * 100);
      const res = await fetch('/api/stripe-connect/products/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: productName,
          description: productDesc,
          priceInCents,
          connectedAccountId: selectedAccountId,
        }),
      });
      const data = await res.json();

      if (data.success) {
        setFeedbackMsg({
          type: 'success',
          text: data.message || 'Product created and mapped to Connected Account!',
        });
        await fetchStorefrontData();
        setActiveTab('storefront');
      } else {
        setFeedbackMsg({ type: 'error', text: data.error || 'Product creation failed' });
      }
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err.message || 'Failed to communicate with Stripe products API' });
    } finally {
      setCreatingProduct(false);
    }
  };

  // 4. Process Charges with Destination Charge Checkout Session
  const handlePurchaseProduct = async (prod: ConnectProduct) => {
    setBuyingProductId(prod.id);
    setFeedbackMsg(null);

    try {
      const appFeeCents = Math.round(prod.priceInCents * 0.1); // 10% platform fee
      const res = await fetch('/api/stripe-connect/checkout/create-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: prod.id,
          connectedAccountId: prod.connectedAccountId,
          priceInCents: prod.priceInCents,
          productName: prod.name,
          applicationFeeInCents: appFeeCents,
          originUrl: window.location.origin,
        }),
      });
      const data = await res.json();

      if (data.success && data.url) {
        if (data.isSimulation) {
          setFeedbackMsg({
            type: 'info',
            text: `[Sandbox Destination Charge Session Created]: ${data.message}`,
          });
        } else {
          window.location.href = data.url;
        }
      } else {
        setFeedbackMsg({ type: 'error', text: data.error || 'Checkout session failed' });
      }
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err.message || 'Failed to initiate purchase' });
    } finally {
      setBuyingProductId(null);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 font-sans">
      {/* Header Banner */}
      <div className="bg-neutral-900 text-white p-6 md:p-8 rounded-lg shadow-sm mb-8 relative overflow-hidden">
        <div className="relative z-10 space-y-2">
          <div className="flex items-center space-x-2 text-xs font-mono uppercase tracking-widest text-neutral-400">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>Stripe Connect V2 Architecture</span>
          </div>
          <h1 className="font-serif text-2xl md:text-3xl font-bold tracking-tight text-white">
            Connected Merchant Onboarding & Marketplace
          </h1>
          <p className="text-neutral-300 text-xs md:text-sm max-w-2xl font-light">
            Platform-driven pricing with Express dashboards, V2 account creation, Destination Charges with
            application fees, and real-time requirement polling.
          </p>
        </div>
      </div>

      {/* Feedback Toast / Alert */}
      {feedbackMsg && (
        <div
          className={`mb-6 p-4 rounded-md text-xs font-mono border flex items-start space-x-3 transition-all ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : feedbackMsg.type === 'error'
              ? 'bg-red-50 border-red-300 text-red-900'
              : 'bg-blue-50 border-blue-300 text-blue-900'
          }`}
        >
          {feedbackMsg.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
          )}
          <div className="flex-1">
            <span className="font-bold uppercase tracking-wider block mb-0.5">
              {feedbackMsg.type === 'success' ? 'Success' : feedbackMsg.type === 'error' ? 'Notice' : 'Information'}
            </span>
            <p className="font-sans text-xs">{feedbackMsg.text}</p>
          </div>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="flex border-b border-neutral-200 mb-8 space-x-8">
        <button
          onClick={() => setActiveTab('onboarding')}
          className={`pb-4 text-xs uppercase font-mono tracking-wider font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'onboarding'
              ? 'border-neutral-900 text-neutral-900'
              : 'border-transparent text-neutral-500 hover:text-neutral-800'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>1. Connected Accounts ({accounts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('products')}
          className={`pb-4 text-xs uppercase font-mono tracking-wider font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'products'
              ? 'border-neutral-900 text-neutral-900'
              : 'border-transparent text-neutral-500 hover:text-neutral-800'
          }`}
        >
          <Plus className="w-4 h-4" />
          <span>2. Platform Products</span>
        </button>

        <button
          onClick={() => setActiveTab('storefront')}
          className={`pb-4 text-xs uppercase font-mono tracking-wider font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'storefront'
              ? 'border-neutral-900 text-neutral-900'
              : 'border-transparent text-neutral-500 hover:text-neutral-800'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>3. Marketplace Storefront ({products.length})</span>
        </button>
      </div>

      {/* TAB 1: CONNECTED ACCOUNTS & ONBOARDING */}
      {activeTab === 'onboarding' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Create Account Form */}
          <div className="bg-white border border-neutral-200 p-6 rounded-lg space-y-4 shadow-xs">
            <div className="border-b border-neutral-100 pb-3">
              <h2 className="font-serif text-lg font-bold text-neutral-900">Create Connected Account</h2>
              <p className="text-xs text-neutral-500 mt-1">
                Creates a Stripe Express V2 account where platform manages pricing & fee collections.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-mono uppercase text-neutral-700 font-semibold mb-1">
                  Merchant Display Name *
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full text-xs p-2.5 border border-neutral-300 rounded-sm focus:outline-hidden focus:border-neutral-900"
                  placeholder="e.g. Apex Apparel Studio"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-neutral-700 font-semibold mb-1">
                  Contact Email *
                </label>
                <input
                  type="email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  className="w-full text-xs p-2.5 border border-neutral-300 rounded-sm focus:outline-hidden focus:border-neutral-900"
                  placeholder="merchant@example.com"
                  required
                />
              </div>

              <button
                type="button"
                onClick={(e) => handleCreateAccount(e as any)}
                disabled={creatingAccount}
                className="w-full bg-neutral-900 text-white hover:bg-neutral-800 text-xs font-mono uppercase font-semibold py-3 px-4 rounded-sm transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
              >
                {creatingAccount ? (
                  <span>Creating Account...</span>
                ) : (
                  <>
                    <Building2 className="w-4 h-4" />
                    <span>Create V2 Connected Account</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Connected Accounts List */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <h2 className="font-serif text-lg font-bold text-neutral-900">Registered Connected Accounts</h2>
              <button
                onClick={fetchStorefrontData}
                className="text-xs font-mono text-neutral-600 hover:text-black flex items-center space-x-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh</span>
              </button>
            </div>

            {loading ? (
              <div className="py-12 text-center text-xs font-mono text-neutral-400">
                Loading connected accounts...
              </div>
            ) : accounts.length === 0 ? (
              <div className="p-8 border border-dashed border-neutral-300 text-center rounded-lg space-y-2">
                <p className="text-xs font-mono text-neutral-500">No Stripe Connected accounts registered yet.</p>
                <p className="text-xs text-neutral-400">Use the form on the left to create your first connected account.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {accounts.map((acc) => {
                  const status = accountStatusMap[acc.id];
                  return (
                    <div
                      key={acc.id}
                      className="bg-white border border-neutral-200 p-5 rounded-lg space-y-4 hover:border-neutral-300 transition-all shadow-2xs"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-100 pb-3">
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className="font-serif font-bold text-sm text-neutral-900">
                              {acc.displayName || 'Merchant Store'}
                            </h3>
                            {acc.isSimulation && (
                              <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 font-mono rounded-xs font-semibold">
                                SANDBOX
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-neutral-500 font-mono mt-0.5">{acc.contactEmail}</p>
                        </div>

                        <div className="text-right">
                          <span className="text-[11px] font-mono text-neutral-400 block">ID: {acc.id}</span>
                        </div>
                      </div>

                      {/* Onboarding Status directly from API */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-neutral-50 p-3 rounded-md border border-neutral-200">
                        <div className="space-y-1">
                          <span className="text-[11px] font-mono uppercase text-neutral-500 font-semibold block">
                            Live Onboarding Status
                          </span>
                          <div className="flex items-center space-x-2">
                            {status?.ready ? (
                              <span className="text-xs font-semibold text-emerald-700 flex items-center space-x-1">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Active & Ready for Transfers</span>
                              </span>
                            ) : (
                              <span className="text-xs font-semibold text-amber-700 flex items-center space-x-1">
                                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                                <span>Requirements Pending</span>
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => checkAccountStatus(acc.id)}
                            disabled={checkingStatusId === acc.id}
                            className="bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-100 text-xs font-mono px-3 py-2 rounded-xs flex items-center space-x-1"
                          >
                            <RefreshCw className={`w-3 h-3 ${checkingStatusId === acc.id ? 'animate-spin' : ''}`} />
                            <span>Verify API</span>
                          </button>

                          <button
                            onClick={() => handleOnboardAccount(acc.id)}
                            className="bg-black text-white hover:bg-neutral-800 text-xs font-mono uppercase font-semibold px-4 py-2 rounded-xs flex items-center space-x-1"
                          >
                            <span>Onboard to collect payments</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: CREATE PRODUCTS AT PLATFORM LEVEL */}
      {activeTab === 'products' && (
        <div className="max-w-2xl mx-auto bg-white border border-neutral-200 p-6 md:p-8 rounded-lg shadow-xs space-y-6">
          <div className="border-b border-neutral-200 pb-4">
            <h2 className="font-serif text-xl font-bold text-neutral-900">Create Platform Level Product</h2>
            <p className="text-xs text-neutral-500 mt-1">
              Creates product at platform level using Stripe Products API and maps it to a Connected Account ID.
            </p>
          </div>

          {accounts.length === 0 ? (
            <div className="p-6 bg-amber-50 border border-amber-200 text-amber-800 text-xs font-mono rounded-md">
              Please create at least one Connected Account in Step 1 before listing products.
            </div>
          ) : (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-mono uppercase text-neutral-700 font-semibold mb-1">
                  Destination Connected Account *
                </label>
                <select
                  value={selectedAccountId}
                  onChange={(e) => setSelectedAccountId(e.target.value)}
                  className="w-full text-xs p-3 border border-neutral-300 rounded-sm focus:outline-hidden focus:border-black font-mono"
                  required
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.displayName} ({acc.id})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-neutral-700 font-semibold mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  className="w-full text-xs p-3 border border-neutral-300 rounded-sm focus:outline-hidden focus:border-black"
                  placeholder="e.g. Minimalist Heavyweight Hoodie"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-neutral-700 font-semibold mb-1">
                  Product Description
                </label>
                <textarea
                  value={productDesc}
                  onChange={(e) => setProductDesc(e.target.value)}
                  rows={3}
                  className="w-full text-xs p-3 border border-neutral-300 rounded-sm focus:outline-hidden focus:border-black"
                  placeholder="Garment details, fabric weight, composition..."
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-neutral-700 font-semibold mb-1">
                  Unit Price (USD) *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-xs font-mono text-neutral-400">$</span>
                  <input
                    type="number"
                    step="0.01"
                    value={productPriceUSD}
                    onChange={(e) => setProductPriceUSD(e.target.value)}
                    className="w-full text-xs p-3 pl-7 border border-neutral-300 rounded-sm focus:outline-hidden focus:border-black font-mono"
                    placeholder="120.00"
                    required
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={(e) => handleCreateProduct(e as any)}
                disabled={creatingProduct}
                className="w-full bg-neutral-900 text-white hover:bg-neutral-800 text-xs font-mono uppercase font-semibold py-3 px-4 rounded-sm transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
              >
                {creatingProduct ? (
                  <span>Creating Product in Stripe...</span>
                ) : (
                  <>
                    <Tag className="w-4 h-4" />
                    <span>Create Product & Link Connected Account</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: MARKETPLACE STOREFRONT */}
      {activeTab === 'storefront' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
            <div>
              <h2 className="font-serif text-xl font-bold text-neutral-900">Connect Marketplace Storefront</h2>
              <p className="text-xs text-neutral-500 mt-0.5">
                Displays products and destination accounts. Purchases route via Destination Charge with application fee.
              </p>
            </div>
            <span className="text-xs font-mono bg-neutral-100 text-neutral-700 px-3 py-1 rounded-full border border-neutral-200">
              {products.length} Item(s) Live
            </span>
          </div>

          {loading ? (
            <div className="py-12 text-center text-xs font-mono text-neutral-400">Loading marketplace...</div>
          ) : products.length === 0 ? (
            <div className="p-12 border border-dashed border-neutral-300 text-center rounded-lg space-y-3 bg-white">
              <ShoppingBag className="w-8 h-8 text-neutral-300 mx-auto" />
              <p className="text-xs font-mono text-neutral-600 font-semibold">Marketplace Storefront is empty.</p>
              <p className="text-xs text-neutral-400 max-w-md mx-auto">
                Create a connected account in Step 1 and list a platform product in Step 2 to showcase marketplace purchases here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((prod) => {
                const linkedAcc = accounts.find((a) => a.id === prod.connectedAccountId);
                const priceFormatted = (prod.priceInCents / 100).toFixed(2);
                const isBuying = buyingProductId === prod.id;

                return (
                  <div
                    key={prod.id}
                    className="bg-white border border-neutral-200 rounded-lg p-6 flex flex-col justify-between space-y-5 hover:border-neutral-300 transition-all shadow-2xs"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h3 className="font-serif text-base font-bold text-neutral-900">{prod.name}</h3>
                          <p className="text-xs text-neutral-500 line-clamp-2">{prod.description}</p>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-neutral-100 flex items-baseline justify-between">
                        <span className="text-lg font-bold font-mono text-neutral-900">${priceFormatted}</span>
                        <span className="text-[10px] font-mono text-neutral-400">ID: {prod.id.substring(0, 14)}...</span>
                      </div>

                      {/* Connected Account Badge */}
                      <div className="bg-neutral-50 p-2.5 rounded-sm border border-neutral-200 text-xs space-y-1">
                        <span className="text-[10px] uppercase font-mono text-neutral-500 font-semibold block">
                          Payout Destination Account:
                        </span>
                        <span className="font-bold text-neutral-800 block truncate">
                          {linkedAcc?.displayName || prod.connectedAccountId}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => handlePurchaseProduct(prod)}
                      disabled={isBuying}
                      className="w-full bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-mono uppercase font-semibold py-3 px-4 rounded-sm transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
                    >
                      {isBuying ? (
                        <span>Processing Session...</span>
                      ) : (
                        <>
                          <CreditCard className="w-4 h-4" />
                          <span>Buy via Destination Charge</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default StripeConnectShowcase;
