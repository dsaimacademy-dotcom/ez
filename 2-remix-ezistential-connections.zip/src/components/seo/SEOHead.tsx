import React, { useEffect } from 'react';
import { Product, FAQItem } from '../../types';
import { useContent } from '../../context/ContentContext';
import { getPageSeo } from '../../data/defaultPageSeo';

export interface SEOHeadProps {
  currentView: string;
  product?: Product;
  faqs?: FAQItem[];
  siteHeadline?: string;
  siteSubheadline?: string;
}

export const SEOHead: React.FC<SEOHeadProps> = ({
  currentView,
  product,
  faqs,
  siteHeadline,
  siteSubheadline,
}) => {
  const { content } = useContent();
  const brand = content?.brandName || 'Ezistential Connection';

  useEffect(() => {
    const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ezistential.com';
    
    // Retrieve page SEO configured in Content Editor or fallback to default
    const pageSeo = getPageSeo(currentView, content?.pageSeoConfigs, brand);

    let title = pageSeo.title;
    let description = pageSeo.description;
    let image = pageSeo.ogImage || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1200&q=85';
    let ogType = pageSeo.ogType || 'website';
    let canonicalUrl = `${baseUrl}${pageSeo.canonicalPath || (currentView === 'home' ? '' : `/${currentView}`)}`;
    let robots = pageSeo.robotsDirective || 'index, follow';
    let keywords = pageSeo.keywords || '';

    // Specific Product Detail Page dynamic override
    if (currentView === 'product' && product) {
      title = `${product.name} | ${brand}`;
      description = `"${product.tagline}". Heavyweight 6.5oz combed cotton with direct-to-film discharge print. Ethical on-demand production.`;
      image = product.primaryImage;
      canonicalUrl = `${baseUrl}/product/${product.slug}`;
      ogType = 'product';
      robots = 'index, follow';
    } else if (currentView === 'admin' || currentView === 'checkout' || currentView === 'order-confirmation' || currentView === 'cart' || currentView === 'account') {
      robots = 'noindex, nofollow';
    }

    // 2. Update Document Title
    document.title = title;

    // 3. Helper to update or create meta tag
    const setMeta = (nameAttr: string, key: string, contentVal: string) => {
      let meta = document.querySelector(`meta[${nameAttr}="${key}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(nameAttr, key);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', contentVal);
    };

    setMeta('name', 'description', description);
    setMeta('name', 'robots', robots);
    if (keywords) {
      setMeta('name', 'keywords', keywords);
    }
    setMeta('property', 'og:title', title);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:image', image);
    setMeta('property', 'og:url', canonicalUrl);
    setMeta('property', 'og:type', ogType);
    setMeta('property', 'og:site_name', brand);
    setMeta('name', 'twitter:card', 'summary_large_image');
    setMeta('name', 'twitter:title', title);
    setMeta('name', 'twitter:description', description);
    setMeta('name', 'twitter:image', image);

    // 4. Update or create canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', canonicalUrl);

    // 5. Build Schema.org Structured Data (JSON-LD)
    let jsonLdData: any = null;

    if (currentView === 'product' && product) {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'Product',
        name: product.name,
        image: [product.primaryImage, ...product.galleryImages.map((g) => g.url)],
        description: product.storyA.thesis,
        sku: product.id,
        brand: {
          '@type': 'Brand',
          name: brand,
          logo: `${baseUrl}/ez-logo.svg`,
        },
        offers: {
          '@type': 'Offer',
          url: canonicalUrl,
          priceCurrency: 'USD',
          price: product.price,
          itemCondition: 'https://schema.org/NewCondition',
          availability: product.isAvailable
            ? 'https://schema.org/InStock'
            : 'https://schema.org/OutOfStock',
          seller: {
            '@type': 'Organization',
            name: brand,
          },
        },
      };
    } else if (currentView === 'faq' && faqs && faqs.length > 0) {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqs.map((f) => ({
          '@type': 'Question',
          name: f.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: f.answer,
          },
        })),
      };
    } else if (currentView === 'shop' || currentView === 'collections') {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'CollectionPage',
        name: title,
        description,
        url: canonicalUrl,
        publisher: {
          '@type': 'Organization',
          name: brand,
          logo: `${baseUrl}/ez-logo.svg`,
        },
      };
    } else if (currentView === 'why-we-exist' || currentView === 'our-story' || currentView === 'manifesto') {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'AboutPage',
        name: title,
        description,
        url: canonicalUrl,
        mainEntity: {
          '@type': 'Organization',
          name: brand,
          slogan: content.brandTagline || 'The Space Between People',
          foundingDate: '2008-11-04',
        },
      };
    } else if (currentView === 'contact') {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'ContactPage',
        name: title,
        description,
        url: canonicalUrl,
        mainEntity: {
          '@type': 'Organization',
          name: brand,
          email: content.supportEmail || 'care@ezistential.com',
          telephone: content.businessPhone || '+1-312-555-0192',
          address: {
            '@type': 'PostalAddress',
            streetAddress: content.businessAddressStreet || '1842 N Damen Ave',
            addressLocality: content.businessAddressCity || 'Chicago',
            addressRegion: content.businessAddressState || 'IL',
            postalCode: content.businessAddressZip || '60647',
            addressCountry: 'US',
          },
        },
      };
    } else {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'ClothingStore',
        name: brand,
        description,
        url: baseUrl,
        logo: `${baseUrl}/ez-logo.svg`,
        slogan: content.brandTagline || 'The Space Between People',
        foundingDate: '2008-11-04',
        currenciesAccepted: 'USD',
        paymentAccepted: 'Credit Card, Apple Pay, Google Pay',
        priceRange: '$$',
        address: {
          '@type': 'PostalAddress',
          streetAddress: content.businessAddressStreet || '1842 N Damen Ave',
          addressLocality: content.businessAddressCity || 'Chicago',
          addressRegion: content.businessAddressState || 'IL',
          postalCode: content.businessAddressZip || '60647',
          addressCountry: 'US',
        },
      };
    }

    let scriptTag = document.getElementById('schema-org-jsonld') as HTMLScriptElement | null;
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = 'schema-org-jsonld';
      scriptTag.type = 'application/ld+json';
      document.head.appendChild(scriptTag);
    }
    scriptTag.textContent = JSON.stringify(jsonLdData, null, 2);
  }, [currentView, product, faqs, siteHeadline, siteSubheadline, content]);

  return null;
};
