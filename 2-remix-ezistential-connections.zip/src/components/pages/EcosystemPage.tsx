import React, { useState } from 'react';
import { EcosystemItem, EcosystemMediaType } from '../../types';
import { INITIAL_ECOSYSTEM_ITEMS } from '../../data/ecosystem';
import {
  Film,
  Headphones,
  Compass,
  Play,
  Pause,
  Clock,
  Calendar,
  MapPin,
  Tag,
  Search,
  X,
  Share2,
  ArrowRight,
  FileText,
  Volume2,
  VolumeX,
  Maximize2,
  ShoppingBag
} from 'lucide-react';
import { Button } from '../ui/Button';
import { useContent } from '../../context/ContentContext';

interface EcosystemPageProps {
  onNavigateToProduct?: (productId: string) => void;
  onNavigateToShop?: () => void;
}

export const EcosystemPage: React.FC<EcosystemPageProps> = ({
  onNavigateToProduct,
  onNavigateToShop,
}) => {
  const { content } = useContent();
  const brand = content.brandName || 'Ezistential Connection';
  const [items, setItems] = useState<EcosystemItem[]>(INITIAL_ECOSYSTEM_ITEMS);
  const [activeTypeFilter, setActiveTypeFilter] = useState<'all' | EcosystemMediaType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMedia, setSelectedMedia] = useState<EcosystemItem | null>(null);

  // Player State for Modal
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);

  const filteredItems = items.filter((item) => {
    const matchesType = activeTypeFilter === 'all' || item.type === activeTypeFilter;
    const matchesQuery =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesType && matchesQuery;
  });

  const featuredItem = items.find((i) => i.isFeatured) || items[0];

  const handleOpenMedia = (item: EcosystemItem) => {
    setSelectedMedia(item);
    setIsPlaying(true);
    setShowTranscript(false);
  };

  return (
    <div className="min-h-screen bg-[#fbfbf9] text-neutral-900 pt-24 pb-24">
      {/* Hero Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="border-b border-neutral-300 pb-8 space-y-4">
          <div className="flex items-center space-x-2 text-xs font-mono uppercase tracking-widest text-neutral-500">
            <Compass className="w-3.5 h-3.5 text-neutral-800" />
            <span>EC Ecosystem • Films, Audio & Exhibitions</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-extrabold text-neutral-900 tracking-tight text-balance">
            The Medium Is Clothing. The Ecosystem Is Connection.
          </h1>
          <p className="text-sm sm:text-base text-neutral-600 max-w-3xl font-sans leading-relaxed">
            Beyond garments, {brand} expands into short films, recorded audio dialogues, and spatial exhibitions that explore how distance between people is constructed and bridged.
          </p>
        </div>

        {/* Featured Spotlight Banner */}
        {featuredItem && (
          <div className="mt-8 bg-black text-white p-6 sm:p-10 border border-neutral-800 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center shadow-xl">
            <div className="lg:col-span-7 space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-mono uppercase bg-neutral-800 px-2.5 py-1 text-amber-300 border border-neutral-700 flex items-center gap-1.5">
                  {featuredItem.type === 'film' && <Film className="w-3 h-3 text-amber-400" />}
                  {featuredItem.type === 'conversation' && <Headphones className="w-3 h-3 text-emerald-400" />}
                  {featuredItem.type === 'exhibition' && <Compass className="w-3 h-3 text-cyan-400" />}
                  <span>Featured {featuredItem.type.toUpperCase()}</span>
                </span>
                {featuredItem.duration && (
                  <span className="text-[10px] font-mono text-neutral-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {featuredItem.duration}
                  </span>
                )}
              </div>

              <h2 className="font-serif text-2xl sm:text-4xl font-bold tracking-tight text-white">
                {featuredItem.title}
              </h2>
              <p className="text-xs sm:text-sm text-neutral-300 font-sans leading-relaxed">
                {featuredItem.description}
              </p>

              {featuredItem.speakers && (
                <div className="text-xs font-mono text-neutral-400">
                  <span className="text-neutral-500">Speakers: </span>
                  {featuredItem.speakers.join(' • ')}
                </div>
              )}

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <Button
                  onClick={() => handleOpenMedia(featuredItem)}
                  variant="primary"
                  className="bg-white text-black hover:bg-neutral-200 border-white text-xs font-mono py-2.5 px-6"
                >
                  <Play className="w-3.5 h-3.5 mr-2 fill-black" />
                  <span>
                    {featuredItem.type === 'film' ? 'Watch Short Film' : featuredItem.type === 'conversation' ? 'Listen to Conversation' : 'Explore Exhibition'}
                  </span>
                </Button>

                {featuredItem.relatedGarmentId && onNavigateToProduct && (
                  <button
                    onClick={() => onNavigateToProduct(featuredItem.relatedGarmentId!)}
                    className="text-xs font-mono text-neutral-300 hover:text-white underline decoration-neutral-600 underline-offset-4 flex items-center gap-1"
                  >
                    <ShoppingBag className="w-3.5 h-3.5 text-neutral-400" />
                    <span>View Related Garment</span>
                  </button>
                )}
              </div>
            </div>

            <div className="lg:col-span-5 relative group cursor-pointer overflow-hidden border border-neutral-800" onClick={() => handleOpenMedia(featuredItem)}>
              <img
                src={featuredItem.thumbnailUrl}
                alt={featuredItem.title}
                className="w-full h-64 sm:h-80 object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition-all">
                <div className="w-14 h-14 rounded-full bg-white/90 text-black flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Play className="w-6 h-6 fill-black ml-1" />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Media Filter & Search Toolbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10">
        <div className="bg-white border border-neutral-200 p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 shadow-xs">
          {/* Sub-tabs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-neutral-100 p-1 rounded-sm text-xs font-mono">
            <button
              onClick={() => setActiveTypeFilter('all')}
              className={`px-3.5 py-1.5 transition-all cursor-pointer ${
                activeTypeFilter === 'all' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
              }`}
            >
              All Media ({items.length})
            </button>
            <button
              onClick={() => setActiveTypeFilter('film')}
              className={`px-3.5 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTypeFilter === 'film' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
              }`}
            >
              <Film className="w-3 h-3" />
              <span>Films ({items.filter((i) => i.type === 'film').length})</span>
            </button>
            <button
              onClick={() => setActiveTypeFilter('conversation')}
              className={`px-3.5 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTypeFilter === 'conversation' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
              }`}
            >
              <Headphones className="w-3 h-3" />
              <span>Audio ({items.filter((i) => i.type === 'conversation').length})</span>
            </button>
            <button
              onClick={() => setActiveTypeFilter('exhibition')}
              className={`px-3.5 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTypeFilter === 'exhibition' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
              }`}
            >
              <Compass className="w-3 h-3" />
              <span>Exhibitions ({items.filter((i) => i.type === 'exhibition').length})</span>
            </button>
          </div>

          {/* Search bar */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search films, audio, tags..."
              className="w-full pl-9 pr-3 py-1.5 bg-neutral-50 border border-neutral-300 text-xs font-sans text-neutral-900 focus:outline-none focus:border-black"
            />
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {filteredItems.length === 0 ? (
          <div className="bg-white border border-neutral-200 p-12 text-center space-y-3">
            <p className="text-sm font-mono text-neutral-500">No ecosystem media matches your search query.</p>
            <button
              onClick={() => {
                setActiveTypeFilter('all');
                setSearchQuery('');
              }}
              className="text-xs font-mono text-black underline"
            >
              Clear filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-white border border-neutral-200 flex flex-col justify-between hover:border-black transition-all group duration-200 shadow-xs"
              >
                <div>
                  {/* Thumbnail Cover */}
                  <div className="relative overflow-hidden cursor-pointer aspect-video bg-neutral-900" onClick={() => handleOpenMedia(item)}>
                    <img
                      src={item.thumbnailUrl}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                    />
                    <div className="absolute top-3 left-3 bg-black/80 text-white text-[10px] font-mono uppercase px-2 py-0.5 border border-neutral-700 flex items-center gap-1">
                      {item.type === 'film' && <Film className="w-3 h-3 text-amber-400" />}
                      {item.type === 'conversation' && <Headphones className="w-3 h-3 text-emerald-400" />}
                      {item.type === 'exhibition' && <Compass className="w-3 h-3 text-cyan-400" />}
                      <span>{item.type}</span>
                    </div>

                    {item.duration && (
                      <div className="absolute bottom-3 right-3 bg-black/80 text-white text-[10px] font-mono px-2 py-0.5 border border-neutral-700 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{item.duration}</span>
                      </div>
                    )}

                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-lg">
                        <Play className="w-5 h-5 fill-black ml-0.5" />
                      </div>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 space-y-3">
                    <div className="text-[10px] font-mono text-neutral-400 flex items-center justify-between">
                      <span>{item.releaseDate}</span>
                      {item.location && <span className="flex items-center gap-1 text-neutral-600"><MapPin className="w-2.5 h-2.5" /> {item.location}</span>}
                    </div>

                    <h3 className="font-serif text-xl font-bold text-neutral-900 line-clamp-2 hover:text-neutral-700 transition-colors cursor-pointer" onClick={() => handleOpenMedia(item)}>
                      {item.title}
                    </h3>

                    <p className="text-xs text-neutral-600 font-sans leading-relaxed line-clamp-3">
                      {item.description}
                    </p>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1 pt-1">
                      {item.tags.map((tag) => (
                        <span key={tag} className="text-[9px] font-mono bg-neutral-100 text-neutral-600 px-2 py-0.5 border border-neutral-200">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                <div className="px-6 pb-6 pt-2 border-t border-neutral-100 flex items-center justify-between">
                  <button
                    onClick={() => handleOpenMedia(item)}
                    className="text-xs font-mono font-bold text-black flex items-center space-x-1 hover:translate-x-1 transition-transform cursor-pointer"
                  >
                    <span>
                      {item.type === 'film' ? 'Watch Film' : item.type === 'conversation' ? 'Listen Audio' : 'View Gallery'}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  {item.relatedGarmentId && onNavigateToProduct && (
                    <button
                      onClick={() => onNavigateToProduct(item.relatedGarmentId!)}
                      className="text-[10px] font-mono text-neutral-500 hover:text-black flex items-center gap-1"
                      title="View Related Garment"
                    >
                      <ShoppingBag className="w-3 h-3 text-neutral-400" />
                      <span>Garment</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MEDIA LIGHTBOX MODAL */}
      {selectedMedia && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-[#0f0f0f] text-white border border-neutral-800 w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl relative">
            {/* Modal Header */}
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between shrink-0">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-mono uppercase bg-neutral-800 px-2 py-0.5 text-amber-300 border border-neutral-700">
                  {selectedMedia.type.toUpperCase()}
                </span>
                <h3 className="font-serif text-base font-bold text-white truncate max-w-md">
                  {selectedMedia.title}
                </h3>
              </div>

              <button
                onClick={() => setSelectedMedia(null)}
                className="text-neutral-400 hover:text-white p-1 transition-colors cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Body / Media Player */}
            <div className="p-6 overflow-y-auto space-y-6">
              {/* VIDEO PLAYER FOR FILMS */}
              {selectedMedia.type === 'film' && (
                <div className="space-y-4">
                  <div className="relative aspect-video bg-black border border-neutral-800 overflow-hidden">
                    <video
                      src={selectedMedia.mediaUrl}
                      controls
                      autoPlay={isPlaying}
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
              )}

              {/* AUDIO PLAYER FOR CONVERSATIONS */}
              {selectedMedia.type === 'conversation' && (
                <div className="bg-neutral-900 border border-neutral-800 p-6 space-y-6 rounded-xs">
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-neutral-800 border border-neutral-700 shrink-0 flex items-center justify-center">
                      <Headphones className="w-8 h-8 text-emerald-400" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-emerald-400 uppercase">Audio Conversation</span>
                      <h4 className="font-serif text-lg font-bold text-white">{selectedMedia.title}</h4>
                      {selectedMedia.speakers && (
                        <p className="text-xs text-neutral-400 font-mono">Speakers: {selectedMedia.speakers.join(', ')}</p>
                      )}
                    </div>
                  </div>

                  {/* Audio Controls */}
                  <audio
                    src={selectedMedia.mediaUrl}
                    controls
                    autoPlay
                    className="w-full"
                  />
                </div>
              )}

              {/* EXHIBITION GALLERY FOR EXHIBITIONS */}
              {selectedMedia.type === 'exhibition' && (
                <div className="space-y-4">
                  <div className="aspect-video bg-neutral-900 border border-neutral-800 relative overflow-hidden">
                    <img
                      src={selectedMedia.thumbnailUrl}
                      alt={selectedMedia.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {selectedMedia.location && (
                    <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{selectedMedia.location}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Description & Speakers */}
              <div className="space-y-3 border-t border-neutral-800 pt-4">
                <h4 className="font-serif text-lg font-bold text-white">{selectedMedia.subtitle}</h4>
                <p className="text-xs sm:text-sm text-neutral-300 font-sans leading-relaxed">
                  {selectedMedia.description}
                </p>
              </div>

              {/* TRANSCRIPT ACCORDION */}
              {selectedMedia.transcript && (
                <div className="border border-neutral-800 bg-neutral-950 p-4 space-y-3">
                  <button
                    onClick={() => setShowTranscript(!showTranscript)}
                    className="w-full flex items-center justify-between text-xs font-mono text-neutral-300 hover:text-white cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-amber-400" />
                      <span>View Transcript & Notes</span>
                    </span>
                    <span className="text-neutral-500">{showTranscript ? 'Hide' : 'Expand'}</span>
                  </button>

                  {showTranscript && (
                    <pre className="text-xs font-mono text-neutral-400 whitespace-pre-wrap leading-relaxed border-t border-neutral-800 pt-3">
                      {selectedMedia.transcript}
                    </pre>
                  )}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0 bg-black/60">
              <div className="flex items-center space-x-2 text-xs font-mono text-neutral-400">
                <span>Released: {selectedMedia.releaseDate}</span>
              </div>

              <div className="flex items-center space-x-3">
                {selectedMedia.relatedGarmentId && onNavigateToProduct && (
                  <Button
                    onClick={() => {
                      const gid = selectedMedia.relatedGarmentId!;
                      setSelectedMedia(null);
                      onNavigateToProduct(gid);
                    }}
                    variant="primary"
                    className="bg-white text-black hover:bg-neutral-200 text-xs font-mono py-2 px-4"
                  >
                    <ShoppingBag className="w-3.5 h-3.5 mr-2" />
                    <span>View Related Garment</span>
                  </Button>
                )}
                <Button
                  onClick={() => setSelectedMedia(null)}
                  variant="outline"
                  className="border-neutral-700 text-neutral-300 hover:text-white text-xs font-mono py-2 px-4"
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
