import React, { useState, useMemo } from 'react';
import { Product, Size } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { formatPrice } from '../../lib/utils';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { ProductImage } from '../ui/ProductImage';
import {
  Search,
  SlidersHorizontal,
  X,
  Check,
  Heart,
  ChevronDown,
  RotateCcw,
  Tag,
  Palette,
  Ruler,
  DollarSign,
  Layers,
  ArrowUpDown
} from 'lucide-react';

export interface ShopPageProps {
  products: Product[];
  onNavigateToProduct: (productId: string) => void;
  onOpenAuthModal: () => void;
  initialCollectionFilter?: string;
}

const ALL_SIZES: Size[] = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];

export const ShopPage: React.FC<ShopPageProps> = ({
  products,
  onNavigateToProduct,
  onOpenAuthModal,
  initialCollectionFilter = 'all',
}) => {
  const { isGarmentSaved, toggleSavedGarment, isAuthenticated } = useAuth();

  // Filter & Sort State
  const [collectionFilter, setCollectionFilter] = useState<string>(initialCollectionFilter);
  const [colorFilter, setColorFilter] = useState<string>('all');
  const [sizeFilter, setSizeFilter] = useState<string>('all');
  const [wearTypeFilter, setWearTypeFilter] = useState<string>('all');
  const [priceTierFilter, setPriceTierFilter] = useState<'all' | 'under-45' | '45-60' | '60-plus'>('all');
  const [sortOption, setSortOption] = useState<'newest' | 'price-asc' | 'price-desc' | 'name'>('newest');
  const [searchKeyword, setSearchKeyword] = useState<string>('');

  // Mobile Drawer State
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  // Derive unique collections, colors, and wear types from available products
  const availableProducts = useMemo(() => products.filter((p) => p.isAvailable !== false), [products]);

  const collectionsList = useMemo(() => {
    const set = new Set<string>();
    availableProducts.forEach((p) => {
      if (p.collectionId) set.add(p.collectionId);
    });
    return Array.from(set);
  }, [availableProducts]);

  const colorsList = useMemo(() => {
    const map = new Map<string, string>();
    availableProducts.forEach((p) => {
      p.availableColors?.forEach((c) => {
        if (!map.has(c.name.toLowerCase())) {
          map.set(c.name.toLowerCase(), c.hex);
        }
      });
    });
    return Array.from(map.entries()).map(([name, hex]) => ({ name, hex }));
  }, [availableProducts]);

  const wearTypesList = useMemo(() => {
    const set = new Set<string>();
    availableProducts.forEach((p) => {
      p.availableWearTypes?.forEach((w) => set.add(w));
    });
    return Array.from(set);
  }, [availableProducts]);

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    return availableProducts
      .filter((p) => {
        // Collection filter
        if (collectionFilter !== 'all' && p.collectionId !== collectionFilter) {
          return false;
        }

        // Color filter
        if (colorFilter !== 'all') {
          const hasColor = p.availableColors?.some(
            (c) => c.name.toLowerCase() === colorFilter.toLowerCase()
          );
          if (!hasColor) return false;
        }

        // Size filter
        if (sizeFilter !== 'all') {
          const hasSize = p.availableSizes?.some((s) => s === sizeFilter);
          if (!hasSize) return false;
        }

        // Wear Type filter
        if (wearTypeFilter !== 'all') {
          const hasWearType = p.availableWearTypes?.some(
            (w) => w.toLowerCase() === wearTypeFilter.toLowerCase()
          );
          if (!hasWearType) return false;
        }

        // Price Tier
        if (priceTierFilter === 'under-45' && p.price >= 45) return false;
        if (priceTierFilter === '45-60' && (p.price < 45 || p.price > 60)) return false;
        if (priceTierFilter === '60-plus' && p.price <= 60) return false;

        // Search keyword
        if (searchKeyword.trim()) {
          const q = searchKeyword.toLowerCase();
          const matchName = p.name.toLowerCase().includes(q);
          const matchTagline = p.tagline?.toLowerCase().includes(q);
          const matchThesis = p.storyA?.thesis?.toLowerCase().includes(q);
          const matchFabric = p.storyB?.fabric?.toLowerCase().includes(q);
          if (!matchName && !matchTagline && !matchThesis && !matchFabric) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortOption === 'price-asc') return a.price - b.price;
        if (sortOption === 'price-desc') return b.price - a.price;
        if (sortOption === 'name') return a.name.localeCompare(b.name);
        return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
      });
  }, [
    availableProducts,
    collectionFilter,
    colorFilter,
    sizeFilter,
    wearTypeFilter,
    priceTierFilter,
    searchKeyword,
    sortOption,
  ]);

  // Active filters count
  const activeFiltersCount = [
    collectionFilter !== 'all',
    colorFilter !== 'all',
    sizeFilter !== 'all',
    wearTypeFilter !== 'all',
    priceTierFilter !== 'all',
    searchKeyword.trim().length > 0,
  ].filter(Boolean).length;

  const handleResetFilters = () => {
    setCollectionFilter('all');
    setColorFilter('all');
    setSizeFilter('all');
    setWearTypeFilter('all');
    setPriceTierFilter('all');
    setSearchKeyword('');
    setSortOption('newest');
  };

  return (
    <div className="min-h-screen bg-[#fbfbf9] text-neutral-900">
      {/* Top Banner & Header */}
      <div className="border-b border-neutral-200 bg-white">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 sm:py-14">
          <span className="text-[11px] uppercase tracking-[0.25em] text-neutral-500 font-mono font-medium block mb-2">
            The Collection Archive · Physical Inquiries
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl text-neutral-900 tracking-tight">
            All Garments
          </h1>
          <p className="text-xs sm:text-sm text-neutral-600 mt-2 max-w-2xl font-sans leading-relaxed">
            Every garment is crafted in heavyweight combed cotton and finished on demand in the United States. Designed around two stories: the philosophical idea and the practical garment.
          </p>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 sm:py-12">
        {/* Mobile Filter & Sort Bar (Sticky / Top on Mobile) */}
        <div className="lg:hidden mb-6 space-y-3">
          <div className="flex items-center gap-2">
            {/* Search Input on Mobile */}
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                placeholder="Search garments..."
                className="w-full bg-white border border-neutral-300 pl-8 pr-8 py-2 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans rounded-xs"
              />
              {searchKeyword && (
                <button
                  onClick={() => setSearchKeyword('')}
                  className="absolute right-2.5 top-2.5 text-neutral-400 hover:text-black cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter Drawer Trigger Button */}
            <button
              onClick={() => setIsMobileDrawerOpen(true)}
              className={`flex items-center gap-2 px-4 py-2 border text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer rounded-xs shrink-0 ${
                activeFiltersCount > 0
                  ? 'bg-black text-white border-black font-bold'
                  : 'bg-white text-neutral-800 border-neutral-300 hover:border-black'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filters {activeFiltersCount > 0 && `(${activeFiltersCount})`}</span>
            </button>
          </div>

          {/* Quick Horizontal Chip Bar for Mobile */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-mono scrollbar-none">
            <button
              onClick={() => setCollectionFilter('all')}
              className={`px-3 py-1 border whitespace-nowrap uppercase tracking-wider rounded-xs cursor-pointer ${
                collectionFilter === 'all'
                  ? 'bg-neutral-900 text-white border-neutral-900'
                  : 'bg-white text-neutral-600 border-neutral-200'
              }`}
            >
              All Series
            </button>
            {collectionsList.map((colId) => (
              <button
                key={colId}
                onClick={() => setCollectionFilter(colId)}
                className={`px-3 py-1 border whitespace-nowrap uppercase tracking-wider rounded-xs cursor-pointer ${
                  collectionFilter === colId
                    ? 'bg-neutral-900 text-white border-neutral-900 font-semibold'
                    : 'bg-white text-neutral-600 border-neutral-200'
                }`}
              >
                {colId.replace(/-/g, ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Desktop 2-Column Layout: Left Sidebar + Right Garment Grid */}
        <div className="lg:grid lg:grid-cols-12 lg:gap-10 items-start">
          {/* ==================================================== */}
          {/* DESKTOP LEFT FILTER SIDEBAR (Sticky, Full E-Commerce) */}
          {/* ==================================================== */}
          <aside className="hidden lg:block lg:col-span-3 sticky top-24 space-y-6 bg-white border border-neutral-200 p-6 shadow-xs rounded-xs">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-neutral-700" />
                <h3 className="font-serif text-lg font-bold text-neutral-900">Refine Collection</h3>
              </div>
              {activeFiltersCount > 0 && (
                <button
                  onClick={handleResetFilters}
                  className="text-[11px] font-mono uppercase tracking-wider text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset ({activeFiltersCount})</span>
                </button>
              )}
            </div>

            {/* 1. Keyword Search */}
            <div className="space-y-2">
              <label className="text-[11px] uppercase tracking-wider font-mono font-bold text-neutral-700 block">
                Search Inquiries
              </label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  placeholder="Keywords, concepts..."
                  className="w-full bg-[#fbfbf9] border border-neutral-300 pl-8 pr-8 py-2 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans rounded-xs"
                />
                {searchKeyword && (
                  <button
                    onClick={() => setSearchKeyword('')}
                    className="absolute right-2.5 top-2.5 text-neutral-400 hover:text-black cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* 2. Series / Collection Filter */}
            <div className="space-y-2.5 pt-4 border-t border-neutral-100">
              <label className="text-[11px] uppercase tracking-wider font-mono font-bold text-neutral-700 block flex items-center justify-between">
                <span>Series</span>
                <Layers className="w-3.5 h-3.5 text-neutral-400" />
              </label>
              <div className="space-y-1 text-xs">
                <button
                  type="button"
                  onClick={() => setCollectionFilter('all')}
                  className={`w-full text-left px-2.5 py-1.5 rounded-xs flex items-center justify-between transition-colors cursor-pointer ${
                    collectionFilter === 'all'
                      ? 'bg-neutral-900 text-white font-medium'
                      : 'text-neutral-700 hover:bg-neutral-100'
                  }`}
                >
                  <span>All Series</span>
                  <span className="font-mono text-[10px] opacity-70">({availableProducts.length})</span>
                </button>
                {collectionsList.map((colId) => {
                  const count = availableProducts.filter((p) => p.collectionId === colId).length;
                  const isSelected = collectionFilter === colId;
                  return (
                    <button
                      key={colId}
                      type="button"
                      onClick={() => setCollectionFilter(isSelected ? 'all' : colId)}
                      className={`w-full text-left px-2.5 py-1.5 rounded-xs flex items-center justify-between capitalize transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-neutral-900 text-white font-medium'
                          : 'text-neutral-700 hover:bg-neutral-100'
                      }`}
                    >
                      <span>{colId.replace(/-/g, ' ')}</span>
                      <span className="font-mono text-[10px] opacity-70">({count})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Color Swatches */}
            {colorsList.length > 0 && (
              <div className="space-y-2.5 pt-4 border-t border-neutral-100">
                <label className="text-[11px] uppercase tracking-wider font-mono font-bold text-neutral-700 block flex items-center justify-between">
                  <span>Colorway</span>
                  <Palette className="w-3.5 h-3.5 text-neutral-400" />
                </label>
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setColorFilter('all')}
                    className={`px-2 py-1.5 border rounded-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                      colorFilter === 'all'
                        ? 'bg-neutral-900 text-white border-neutral-900 font-medium'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:border-neutral-400'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full border border-neutral-300 bg-neutral-300" />
                    <span className="truncate">All Colors</span>
                  </button>
                  {colorsList.map((c) => {
                    const isSelected = colorFilter.toLowerCase() === c.name.toLowerCase();
                    return (
                      <button
                        key={c.name}
                        type="button"
                        onClick={() => setColorFilter(isSelected ? 'all' : c.name)}
                        className={`px-2 py-1.5 border rounded-xs flex items-center gap-1.5 capitalize transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-neutral-900 text-white border-neutral-900 font-medium'
                            : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:border-neutral-400'
                        }`}
                      >
                        <span
                          className="w-2.5 h-2.5 rounded-full border border-neutral-300 shrink-0"
                          style={{ backgroundColor: c.hex }}
                        />
                        <span className="truncate">{c.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 4. Sizes Filter */}
            <div className="space-y-2.5 pt-4 border-t border-neutral-100">
              <label className="text-[11px] uppercase tracking-wider font-mono font-bold text-neutral-700 block flex items-center justify-between">
                <span>Garment Size</span>
                <Ruler className="w-3.5 h-3.5 text-neutral-400" />
              </label>
              <div className="grid grid-cols-4 gap-1.5 text-xs font-mono">
                <button
                  type="button"
                  onClick={() => setSizeFilter('all')}
                  className={`py-1.5 border rounded-xs text-center transition-all cursor-pointer ${
                    sizeFilter === 'all'
                      ? 'bg-neutral-900 text-white border-neutral-900 font-bold'
                      : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:border-neutral-400'
                  }`}
                >
                  All
                </button>
                {ALL_SIZES.map((sz) => {
                  const isSelected = sizeFilter === sz;
                  return (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => setSizeFilter(isSelected ? 'all' : sz)}
                      className={`py-1.5 border rounded-xs text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-neutral-900 text-white border-neutral-900 font-bold'
                          : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:border-neutral-400'
                      }`}
                    >
                      {sz}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 5. Silhouette / Wear Type */}
            {wearTypesList.length > 0 && (
              <div className="space-y-2.5 pt-4 border-t border-neutral-100">
                <label className="text-[11px] uppercase tracking-wider font-mono font-bold text-neutral-700 block">
                  Silhouette Blank
                </label>
                <div className="space-y-1 text-xs">
                  <button
                    type="button"
                    onClick={() => setWearTypeFilter('all')}
                    className={`w-full text-left px-2.5 py-1.5 rounded-xs transition-colors cursor-pointer ${
                      wearTypeFilter === 'all'
                        ? 'bg-neutral-900 text-white font-medium'
                        : 'text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    All Silhouettes
                  </button>
                  {wearTypesList.map((wt) => {
                    const isSelected = wearTypeFilter.toLowerCase() === wt.toLowerCase();
                    return (
                      <button
                        key={wt}
                        type="button"
                        onClick={() => setWearTypeFilter(isSelected ? 'all' : wt)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-xs transition-colors cursor-pointer truncate ${
                          isSelected
                            ? 'bg-neutral-900 text-white font-medium'
                            : 'text-neutral-700 hover:bg-neutral-100'
                        }`}
                      >
                        {wt}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 6. Price Tier */}
            <div className="space-y-2.5 pt-4 border-t border-neutral-100">
              <label className="text-[11px] uppercase tracking-wider font-mono font-bold text-neutral-700 block flex items-center justify-between">
                <span>Price Bracket</span>
                <DollarSign className="w-3.5 h-3.5 text-neutral-400" />
              </label>
              <div className="space-y-1 text-xs font-mono">
                {[
                  { id: 'all', label: 'All Price Ranges' },
                  { id: 'under-45', label: 'Under $45' },
                  { id: '45-60', label: '$45 – $60' },
                  { id: '60-plus', label: '$60 and Above' },
                ].map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => setPriceTierFilter(tier.id as any)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-xs transition-colors cursor-pointer ${
                      priceTierFilter === tier.id
                        ? 'bg-neutral-900 text-white font-medium'
                        : 'text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* ==================================================== */}
          {/* RIGHT PRODUCT GRID AREA */}
          {/* ==================================================== */}
          <main className="lg:col-span-9 space-y-6">
            {/* Top Control Bar: Total count + Active filter pills + Sort dropdown */}
            <div className="bg-white border border-neutral-200 p-4 rounded-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono uppercase tracking-wider text-neutral-500 font-bold">
                  Showing {filteredProducts.length} of {availableProducts.length} Garments
                </span>
              </div>

              {/* Sort By Dropdown */}
              <div className="flex items-center space-x-2 text-xs font-mono">
                <span className="text-neutral-500 uppercase tracking-wider shrink-0 flex items-center gap-1">
                  <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400" />
                  <span>Sort:</span>
                </span>
                <select
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value as any)}
                  className="bg-[#fbfbf9] border border-neutral-300 px-3 py-1.5 text-xs text-neutral-900 font-mono uppercase tracking-wider cursor-pointer focus:outline-hidden focus:border-black rounded-xs"
                >
                  <option value="newest">Newest Arrivals</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="name">Name: A–Z</option>
                </select>
              </div>
            </div>

            {/* Active Filters Pill Row */}
            {activeFiltersCount > 0 && (
              <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                <span className="text-[11px] uppercase tracking-wider font-mono text-neutral-400">Active:</span>
                {collectionFilter !== 'all' && (
                  <span className="inline-flex items-center gap-1.5 bg-neutral-900 text-white px-2.5 py-1 rounded-xs font-mono text-[11px] capitalize">
                    Series: {collectionFilter.replace(/-/g, ' ')}
                    <button onClick={() => setCollectionFilter('all')} className="hover:text-red-400 cursor-pointer">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {colorFilter !== 'all' && (
                  <span className="inline-flex items-center gap-1.5 bg-neutral-900 text-white px-2.5 py-1 rounded-xs font-mono text-[11px] capitalize">
                    Color: {colorFilter}
                    <button onClick={() => setColorFilter('all')} className="hover:text-red-400 cursor-pointer">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {sizeFilter !== 'all' && (
                  <span className="inline-flex items-center gap-1.5 bg-neutral-900 text-white px-2.5 py-1 rounded-xs font-mono text-[11px]">
                    Size: {sizeFilter}
                    <button onClick={() => setSizeFilter('all')} className="hover:text-red-400 cursor-pointer">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {wearTypeFilter !== 'all' && (
                  <span className="inline-flex items-center gap-1.5 bg-neutral-900 text-white px-2.5 py-1 rounded-xs font-mono text-[11px]">
                    Silhouette: {wearTypeFilter}
                    <button onClick={() => setWearTypeFilter('all')} className="hover:text-red-400 cursor-pointer">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {priceTierFilter !== 'all' && (
                  <span className="inline-flex items-center gap-1.5 bg-neutral-900 text-white px-2.5 py-1 rounded-xs font-mono text-[11px]">
                    Price: {priceTierFilter.replace(/-/g, ' ')}
                    <button onClick={() => setPriceTierFilter('all')} className="hover:text-red-400 cursor-pointer">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {searchKeyword.trim() && (
                  <span className="inline-flex items-center gap-1.5 bg-neutral-900 text-white px-2.5 py-1 rounded-xs font-mono text-[11px]">
                    Search: "{searchKeyword}"
                    <button onClick={() => setSearchKeyword('')} className="hover:text-red-400 cursor-pointer">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                <button
                  onClick={handleResetFilters}
                  className="text-xs font-mono text-neutral-600 hover:text-red-600 underline underline-offset-4 cursor-pointer ml-1"
                >
                  Clear all
                </button>
              </div>
            )}

            {/* Empty State */}
            {filteredProducts.length === 0 ? (
              <div className="bg-white border border-neutral-200 p-16 text-center space-y-4 rounded-xs">
                <p className="font-serif text-2xl text-neutral-900">No garments match your active filters</p>
                <p className="text-xs text-neutral-500 max-w-md mx-auto leading-relaxed">
                  Try adjusting your color selection, silhouette choice, or clearing your search term to see more pieces.
                </p>
                <Button onClick={handleResetFilters} variant="outline" size="sm">
                  Reset All Filters
                </Button>
              </div>
            ) : (
              /* Product Grid */
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProducts.map((prod) => (
                  <div
                    key={prod.id}
                    onClick={() => onNavigateToProduct(prod.id)}
                    className="group cursor-pointer flex flex-col justify-between bg-white border border-neutral-200 p-4 rounded-xs hover:border-black transition-all duration-200 shadow-xs"
                  >
                    <div>
                      {/* Image Container with Wishlist + Collection Badge */}
                      <div className="aspect-3/4 overflow-hidden bg-neutral-100 border border-neutral-200 mb-4 relative rounded-xs">
                        <ProductImage
                          src={prod.primaryImage}
                          alt={prod.name}
                          aspectRatio="3/4"
                          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                          className="group-hover:scale-103 transition-transform duration-500"
                        />
                        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1">
                          <Badge variant="dark" size="sm">
                            {prod.collectionId?.replace(/-/g, ' ') || 'Concept'}
                          </Badge>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (!isAuthenticated) {
                              onOpenAuthModal();
                            } else {
                              toggleSavedGarment(prod.id);
                            }
                          }}
                          className={`absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center transition-transform hover:scale-110 shadow-xs z-10 ${
                            isGarmentSaved(prod.id) ? 'text-red-600' : 'text-neutral-400 hover:text-black'
                          }`}
                          title={isGarmentSaved(prod.id) ? 'Remove from Saved' : 'Save to Wishlist'}
                        >
                          <Heart className={`w-4 h-4 ${isGarmentSaved(prod.id) ? 'fill-red-600' : ''}`} />
                        </button>
                      </div>

                      {/* Colorway Dots */}
                      {prod.availableColors && prod.availableColors.length > 0 && (
                        <div className="flex items-center space-x-1.5 mb-2.5">
                          {prod.availableColors.map((c) => (
                            <span
                              key={c.name}
                              className="w-3 h-3 rounded-full border border-neutral-300"
                              style={{ backgroundColor: c.hex }}
                              title={c.name}
                            />
                          ))}
                        </div>
                      )}

                      <h3 className="font-serif text-lg font-bold text-neutral-900 group-hover:underline underline-offset-4 decoration-neutral-300 leading-snug">
                        {prod.name}
                      </h3>
                      <p className="text-xs text-neutral-500 mt-1 italic font-serif line-clamp-2">
                        "{prod.tagline}"
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-between">
                      <span className="font-mono text-sm font-bold text-neutral-900">
                        {formatPrice(prod.price)}
                      </span>
                      <span className="text-xs uppercase tracking-wider text-neutral-600 font-mono font-medium group-hover:text-black">
                        Examine →
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>

      {/* ==================================================== */}
      {/* MOBILE SLIDE-OVER FILTER DRAWER (Industry Standard) */}
      {/* ==================================================== */}
      {isMobileDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex justify-end animate-in fade-in duration-200">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setIsMobileDrawerOpen(false)}
          />

          {/* Slide-in Sheet Panel */}
          <div className="relative w-full max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300">
            {/* Header */}
            <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-neutral-800" />
                <h3 className="font-serif text-lg font-bold text-neutral-900">Filters & Refine</h3>
                {activeFiltersCount > 0 && (
                  <Badge variant="dark" size="sm">
                    {activeFiltersCount}
                  </Badge>
                )}
              </div>
              <button
                type="button"
                onClick={() => setIsMobileDrawerOpen(false)}
                className="p-1.5 text-neutral-500 hover:text-black cursor-pointer rounded-xs"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Filter Sections */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {/* Sort By */}
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-wider font-mono font-bold text-neutral-800 block">
                  Sort Order
                </label>
                <select
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value as any)}
                  className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono uppercase tracking-wider rounded-xs"
                >
                  <option value="newest">Newest Arrivals</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="name">Name: A–Z</option>
                </select>
              </div>

              {/* Series */}
              <div className="space-y-2 pt-4 border-t border-neutral-100">
                <label className="text-xs uppercase tracking-wider font-mono font-bold text-neutral-800 block">
                  Series
                </label>
                <div className="space-y-1.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setCollectionFilter('all')}
                    className={`w-full text-left p-2.5 border rounded-xs flex items-center justify-between cursor-pointer ${
                      collectionFilter === 'all'
                        ? 'bg-black text-white border-black font-semibold'
                        : 'bg-white text-neutral-700 border-neutral-200'
                    }`}
                  >
                    <span>All Series</span>
                    <span className="font-mono text-[10px]">({availableProducts.length})</span>
                  </button>
                  {collectionsList.map((colId) => (
                    <button
                      key={colId}
                      type="button"
                      onClick={() => setCollectionFilter(colId)}
                      className={`w-full text-left p-2.5 border rounded-xs flex items-center justify-between capitalize cursor-pointer ${
                        collectionFilter === colId
                          ? 'bg-black text-white border-black font-semibold'
                          : 'bg-white text-neutral-700 border-neutral-200'
                      }`}
                    >
                      <span>{colId.replace(/-/g, ' ')}</span>
                      <span className="font-mono text-[10px]">
                        ({availableProducts.filter((p) => p.collectionId === colId).length})
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Colorways */}
              {colorsList.length > 0 && (
                <div className="space-y-2 pt-4 border-t border-neutral-100">
                  <label className="text-xs uppercase tracking-wider font-mono font-bold text-neutral-800 block">
                    Colorway
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setColorFilter('all')}
                      className={`p-2 border rounded-xs flex items-center gap-2 cursor-pointer ${
                        colorFilter === 'all'
                          ? 'bg-black text-white border-black font-semibold'
                          : 'bg-white text-neutral-700 border-neutral-200'
                      }`}
                    >
                      <span className="w-3 h-3 rounded-full border border-neutral-300 bg-neutral-300" />
                      <span className="truncate">All Colors</span>
                    </button>
                    {colorsList.map((c) => (
                      <button
                        key={c.name}
                        type="button"
                        onClick={() => setColorFilter(colorFilter === c.name ? 'all' : c.name)}
                        className={`p-2 border rounded-xs flex items-center gap-2 capitalize cursor-pointer ${
                          colorFilter === c.name
                            ? 'bg-black text-white border-black font-semibold'
                            : 'bg-white text-neutral-700 border-neutral-200'
                        }`}
                      >
                        <span
                          className="w-3 h-3 rounded-full border border-neutral-300 shrink-0"
                          style={{ backgroundColor: c.hex }}
                        />
                        <span className="truncate">{c.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Garment Size */}
              <div className="space-y-2 pt-4 border-t border-neutral-100">
                <label className="text-xs uppercase tracking-wider font-mono font-bold text-neutral-800 block">
                  Garment Size
                </label>
                <div className="grid grid-cols-4 gap-2 text-xs font-mono">
                  <button
                    type="button"
                    onClick={() => setSizeFilter('all')}
                    className={`py-2 border rounded-xs text-center cursor-pointer ${
                      sizeFilter === 'all'
                        ? 'bg-black text-white border-black font-bold'
                        : 'bg-white text-neutral-700 border-neutral-200'
                    }`}
                  >
                    All
                  </button>
                  {ALL_SIZES.map((sz) => (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => setSizeFilter(sizeFilter === sz ? 'all' : sz)}
                      className={`py-2 border rounded-xs text-center cursor-pointer ${
                        sizeFilter === sz
                          ? 'bg-black text-white border-black font-bold'
                          : 'bg-white text-neutral-700 border-neutral-200'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="space-y-2 pt-4 border-t border-neutral-100">
                <label className="text-xs uppercase tracking-wider font-mono font-bold text-neutral-800 block">
                  Price Bracket
                </label>
                <div className="space-y-1.5 text-xs font-mono">
                  {[
                    { id: 'all', label: 'All Price Ranges' },
                    { id: 'under-45', label: 'Under $45' },
                    { id: '45-60', label: '$45 – $60' },
                    { id: '60-plus', label: '$60 and Above' },
                  ].map((tier) => (
                    <button
                      key={tier.id}
                      type="button"
                      onClick={() => setPriceTierFilter(tier.id as any)}
                      className={`w-full text-left p-2 border rounded-xs cursor-pointer ${
                        priceTierFilter === tier.id
                          ? 'bg-black text-white border-black font-bold'
                          : 'bg-white text-neutral-700 border-neutral-200'
                      }`}
                    >
                      {tier.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Sticky Bottom Drawer Footer Action */}
            <div className="p-4 border-t border-neutral-200 bg-white space-y-2">
              <Button
                onClick={() => setIsMobileDrawerOpen(false)}
                variant="primary"
                size="md"
                fullWidth
              >
                Show {filteredProducts.length} Garments
              </Button>
              {activeFiltersCount > 0 && (
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="w-full text-center text-xs font-mono text-neutral-500 hover:text-black py-1 cursor-pointer"
                >
                  Reset all filters
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
