import React, { useState, useEffect, useCallback } from 'react';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { Button } from '../ui/Button';
import { safeSrc } from '../../lib/utils';
import { ShapeDivider } from '../ui/ShapeDivider';
import { ProductImage } from '../ui/ProductImage';
import { DEFAULT_HERO_SLIDES } from '../../data/heroSlides';

export interface EditorialHeroProps {
  onNavigate: (view: string, param?: string) => void;
}

export { DEFAULT_HERO_SLIDES as HERO_SLIDES };

const AUTOPLAY_INTERVAL_MS = 8000;

export const EditorialHero: React.FC<EditorialHeroProps> = ({ onNavigate }) => {
  const { content } = useContent();
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [touchStartX, setTouchStartX] = useState<number | null>(null);

  const rawSlides = content.heroSlides && content.heroSlides.length > 0 ? content.heroSlides : DEFAULT_HERO_SLIDES;
  const availableSlides = rawSlides.filter((s) => s.active !== false);
  const slides = availableSlides.length > 0 ? availableSlides : DEFAULT_HERO_SLIDES;

  const isStaticMode = content.heroMode === 'static';
  const activeIndex = Math.min(currentSlideIndex, slides.length - 1);
  const activeSlide = slides[activeIndex] || DEFAULT_HERO_SLIDES[0];

  const controlsStyle = content.heroControlsStyle || 'interactive-capsule';

  const currentHeadline = activeSlide.headline;
  const currentSubheadline = activeSlide.subheadline;
  const currentTagline = activeSlide.tagline;
  const currentChapterNum = activeSlide.chapterNumber;
  const currentChapterLabel = activeSlide.chapterLabel;
  const currentButtonText = activeSlide.primaryCtaText || 'SHOP';
  const currentButtonTarget = activeSlide.primaryCtaTarget || 'shop';
  const currentSecondaryText = activeSlide.secondaryCtaText || 'EXPLORE';
  const currentSecondaryTarget = activeSlide.secondaryCtaTarget || 'collections';
  const showSecondary = activeSlide.showSecondaryCta !== false && content.heroShowSecondaryButton !== false;

  const overlayBaseColor = activeSlide.overlayColor || content.heroOverlayColor || '#0a0a0a';
  const overlayOpacity = typeof activeSlide.overlayOpacity === 'number'
    ? activeSlide.overlayOpacity
    : (typeof content.heroImageOverlayOpacity === 'number' ? content.heroImageOverlayOpacity : 0.58);

  const autoplaySpeed = content.heroAutoplayIntervalMs || AUTOPLAY_INTERVAL_MS;

  // Next / Prev slide handlers
  const goToNextSlide = useCallback(() => {
    if (isStaticMode || slides.length <= 1) return;
    setCurrentSlideIndex((prev) => (prev + 1) % slides.length);
  }, [isStaticMode, slides.length]);

  const goToPrevSlide = useCallback(() => {
    if (isStaticMode || slides.length <= 1) return;
    setCurrentSlideIndex((prev) => (prev - 1 + slides.length) % slides.length);
  }, [isStaticMode, slides.length]);

  const goToSlide = (index: number) => {
    if (isStaticMode) return;
    setCurrentSlideIndex(index % slides.length);
  };

  // Keyboard navigation for carousel
  useEffect(() => {
    if (isStaticMode || slides.length <= 1) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'ArrowLeft') {
        goToPrevSlide();
      } else if (e.key === 'ArrowRight') {
        goToNextSlide();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isStaticMode, goToNextSlide, goToPrevSlide, slides.length]);

  // Autoplay timer with pause on hover
  useEffect(() => {
    if (isPaused || isStaticMode || slides.length <= 1) return;

    const timer = setInterval(() => {
      goToNextSlide();
    }, autoplaySpeed);

    return () => clearInterval(timer);
  }, [isPaused, isStaticMode, autoplaySpeed, goToNextSlide, slides.length]);

  // Touch gesture swipe handling for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    if (isStaticMode) return;
    setTouchStartX(e.touches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (isStaticMode || touchStartX === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX - touchEndX;

    if (diff > 50) {
      goToNextSlide();
    } else if (diff < -50) {
      goToPrevSlide();
    }
    setTouchStartX(null);
  };

  return (
    <section
      aria-label="Opening Editorial Hero"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="relative bg-[#0a0a0a] text-[#fbfbf9] pt-20 pb-28 sm:pt-24 sm:pb-36 lg:pt-28 lg:pb-40 px-4 sm:px-6 lg:px-8 overflow-hidden min-h-[560px] sm:min-h-[640px] lg:min-h-[700px] flex items-center justify-center select-none"
    >
      {/* 1. Monochromatic Background Layer with Crossfade */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {slides.map((slide, index) => {
          const isCurrent = index === activeIndex;
          const slideOverlayColor = slide.overlayColor || overlayBaseColor;
          const slideOverlayOpacity = typeof slide.overlayOpacity === 'number' ? slide.overlayOpacity : overlayOpacity;

          return (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                isCurrent ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
              }`}
            >
              <ProductImage
                src={safeSrc(slide.imageUrl, DEFAULT_HERO_SLIDES[0].imageUrl)}
                alt={`${slide.chapterLabel} - ${slide.tagline}`}
                aspectRatio="auto"
                priority={index === 0}
                sizes="100vw"
                className={`transform transition-transform duration-10000 ease-linear ${
                  isCurrent ? 'scale-105' : 'scale-100'
                }`}
              />

              {/* Scrim Overlay */}
              <div
                className="absolute inset-0 transition-colors duration-500"
                style={{
                  backgroundColor: slideOverlayColor,
                  opacity: slideOverlayOpacity,
                }}
              />
            </div>
          );
        })}

        {/* Pure Monochrome Gradient Overlay for Typography Contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/80 via-[#0a0a0a]/30 to-transparent pointer-events-none" />

        {/* Film grain vignette */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-transparent to-black/70 pointer-events-none" />
      </div>

      {/* 2. Side Floating Circular Navigation Chevrons */}
      {!isStaticMode && slides.length > 1 && (
        <>
          <button
            type="button"
            onClick={goToPrevSlide}
            aria-label="Previous chapter"
            className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-black/50 hover:bg-black/85 border border-white/20 hover:border-white/50 text-white flex items-center justify-center backdrop-blur-xs transition-all z-30 cursor-pointer shadow-lg group"
          >
            <ChevronLeft className="w-5 h-5 group-hover:-translate-x-0.5 transition-transform" />
          </button>
          <button
            type="button"
            onClick={goToNextSlide}
            aria-label="Next chapter"
            className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-black/50 hover:bg-black/85 border border-white/20 hover:border-white/50 text-white flex items-center justify-center backdrop-blur-xs transition-all z-30 cursor-pointer shadow-lg group"
          >
            <ChevronRight className="w-5 h-5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </>
      )}

      {/* 3. Main Editorial Content Container - 6-Point Hierarchy Standard */}
      <div className="max-w-4xl lg:max-w-5xl mx-auto text-center space-y-5 sm:space-y-6 relative z-20 py-2 sm:py-4 px-2 sm:px-4 mb-8 sm:mb-12 lg:mb-16">
        {/* 1. Chapter & Thesis Indicator Pill (Logo removed per request, typography enlarged for high mobile & desktop legibility) */}
        <div className="inline-flex items-center space-x-2.5 sm:space-x-3 px-4 sm:px-5 py-2 sm:py-2.5 backdrop-blur-md border border-white/25 bg-black/70 rounded-full shadow-lg max-w-full overflow-hidden">
          <span className="text-white font-mono text-xs sm:text-sm md:text-base font-semibold tracking-wider shrink-0 uppercase">
            {currentChapterNum} · {currentChapterLabel}
          </span>
          {currentTagline && (
            <>
              <span className="text-neutral-500">|</span>
              <span className="text-neutral-200 truncate max-w-[260px] sm:max-w-md text-xs sm:text-sm md:text-base font-mono uppercase tracking-wider">
                {currentTagline}
              </span>
            </>
          )}
        </div>

        {/* 3. One Headline with Editorial Serif */}
        <h1
          key={`headline-${currentSlideIndex}`}
          className="font-serif text-3xl sm:text-5xl md:text-6xl lg:text-[64px] font-normal tracking-tight text-white max-w-4xl mx-auto leading-[1.12] sm:leading-[1.06] text-balance animate-in fade-in slide-in-from-bottom-2 duration-500"
        >
          {currentHeadline}
        </h1>

        {/* 4. One Support Line / Subtitle - Substantially enlarged for crystal clear mobile & desktop readability */}
        <p
          key={`subheadline-${currentSlideIndex}`}
          className="text-base sm:text-xl md:text-2xl text-neutral-100 max-w-3xl mx-auto font-sans leading-relaxed font-normal text-balance animate-in fade-in slide-in-from-bottom-2 duration-500 px-2 sm:px-0"
        >
          {currentSubheadline}
        </p>

        {/* 5. SHOP / EXPLORE (Max 2 CTAs) + Quiet Quality Signals */}
        <div className="pt-2 sm:pt-3 flex flex-col items-center max-w-2xl mx-auto space-y-4">
          {/* Dual Call-to-Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 w-full max-w-xs sm:max-w-none mx-auto">
            <Button
              onClick={() => onNavigate(currentButtonTarget)}
              variant="secondary"
              size="md"
              className="w-full sm:w-auto bg-[#fbfbf9] text-[#0a0a0a] hover:bg-neutral-200 border-transparent font-mono text-xs sm:text-sm uppercase tracking-wider group cursor-pointer py-3.5 px-8 sm:px-9 transition-colors font-bold shadow-md"
            >
              <span>{currentButtonText}</span>
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>

            {showSecondary && (
              <Button
                onClick={() => onNavigate(currentSecondaryTarget)}
                variant="outline"
                size="md"
                className="w-full sm:w-auto border-white/30 text-[#fbfbf9] hover:bg-white/10 hover:border-white font-mono text-xs sm:text-sm uppercase tracking-wider cursor-pointer py-3.5 px-7 sm:px-8 transition-colors font-medium"
              >
                {currentSecondaryText}
              </Button>
            )}
          </div>

          {/* 6. Quiet Quality + Secure Checkout Signals */}
          <div className="pt-2 flex flex-wrap items-center justify-center gap-x-4 sm:gap-x-5 gap-y-1.5 text-xs sm:text-sm font-mono text-neutral-300 tracking-wider uppercase">
            <span className="flex items-center gap-1.5 text-neutral-200">
              <ShieldCheck className="w-4 h-4 text-neutral-200 shrink-0" />
              <span>6.5oz Heavyweight Cotton</span>
            </span>
            <span className="text-neutral-500 hidden sm:inline">·</span>
            <span>Architectural Cut</span>
            <span className="text-neutral-500 hidden sm:inline">·</span>
            <span>Chicago Conceived</span>
            <span className="text-neutral-500 hidden sm:inline">·</span>
            <span className="flex items-center gap-1.5 text-neutral-200">
              <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Secure Checkout</span>
            </span>
          </div>

          {/* Slide Carousel Chapter System */}
          {!isStaticMode && slides.length > 1 && (
            <div className="flex justify-center px-2 mt-5 sm:mt-7">
              <nav
                aria-label="Editorial slide chapters"
                className="bg-[#0a0a0a]/90 backdrop-blur-md px-3 sm:px-5 py-2 rounded-full border border-white/20 flex items-center space-x-1.5 sm:space-x-3 overflow-x-auto max-w-[96vw] shadow-md scrollbar-none"
              >
                {slides.map((slide, idx) => {
                  const isActive = idx === activeIndex;
                  return (
                    <button
                      key={slide.id}
                      type="button"
                      onClick={() => goToSlide(idx)}
                      aria-label={`Go to chapter ${slide.chapterNumber}: ${slide.chapterLabel}`}
                      aria-current={isActive ? 'true' : undefined}
                      className={`px-3.5 sm:px-4 py-1.5 rounded-full text-xs sm:text-sm font-mono uppercase tracking-wider transition-all cursor-pointer flex items-center space-x-2 shrink-0 ${
                        isActive
                          ? 'bg-white/25 text-white font-bold border border-white/30 shadow-xs'
                          : 'text-neutral-400 hover:text-white hover:bg-white/5 border border-transparent'
                      }`}
                    >
                      <span
                        className={`shrink-0 rounded-full ${
                          isActive ? 'w-2.5 h-2.5 bg-amber-500 shadow-xs' : 'w-2 h-2 bg-neutral-400'
                        }`}
                      />
                      <span className="whitespace-nowrap font-medium tracking-wider">
                        {slide.chapterLabel}
                      </span>
                    </button>
                  );
                })}
              </nav>
            </div>
          )}
        </div>
      </div>

      {/* 5. Seamless Architectural Shape Divider Directly Slicing the Hero Photo into the next section */}
      {content.shapeDividerEnabled !== false && (
        <div className="absolute -bottom-px inset-x-0 z-20 pointer-events-none overflow-hidden leading-none translate-y-[0.5px]">
          <ShapeDivider
            variant={content.shapeDividerVariant || 'editorial-notch'}
            fillColor="#ffffff"
            bgColor="transparent"
            height={content.shapeDividerHeight || 56}
            position="bottom"
            className="w-full block"
          />
        </div>
      )}
    </section>
  );
};
