import React from 'react';
import { ShieldCheck, Sparkles, Feather, Truck, Award } from 'lucide-react';

export interface CraftsmanshipTrustStripProps {
  variant?: 'light' | 'dark';
}

export const CraftsmanshipTrustStrip: React.FC<CraftsmanshipTrustStripProps> = ({
  variant = 'light',
}) => {
  const isLight = variant === 'light';

  const BADGES = [
    {
      icon: Feather,
      title: '6.5oz Heavyweight Cotton',
      detail: '100% Ring-spun combed American yarns',
    },
    {
      icon: ShieldCheck,
      title: 'Studio Certified & Inspected',
      detail: 'Every seam checked in Chicago',
    },
    {
      icon: Sparkles,
      title: 'Archival Screenprint Tech',
      detail: 'Water-based non-toxic discharge ink',
    },
    {
      icon: Truck,
      title: 'Carbon-Neutral Delivery',
      detail: 'Acid-free packaging & tracked transit',
    },
    {
      icon: Award,
      title: 'Lifetime Seam Promise',
      detail: 'Reinforced dual-needle construction',
    },
  ];

  return (
    <div
      className={`w-full py-10 sm:py-14 px-4 sm:px-6 lg:px-8 transition-colors relative z-10 ${
        isLight
          ? 'bg-[#f5f4f0] text-neutral-900'
          : 'bg-[#181818] text-neutral-300'
      }`}
    >
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Subtle section label to frame the promise */}
        <div className={`flex items-center justify-between pb-3 border-b ${
          isLight ? 'border-neutral-300' : 'border-neutral-800'
        }`}>
          <span className={`text-[10px] uppercase font-mono tracking-[0.25em] font-semibold ${
            isLight ? 'text-neutral-500' : 'text-neutral-400'
          }`}>
            Quality Guarantees & Material Specifications
          </span>
          <span className={`text-[10px] uppercase font-mono tracking-wider hidden sm:inline-block ${
            isLight ? 'text-neutral-400' : 'text-neutral-500'
          }`}>
            Permanent Craftsmanship Standard
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 sm:gap-8 items-start pt-2">
          {BADGES.map((badge, idx) => {
            const Icon = badge.icon;
            return (
              <div
                key={badge.title}
                className={`flex items-start gap-3.5 ${
                  idx === BADGES.length - 1 ? 'sm:col-span-2 lg:col-span-1' : ''
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 mt-0.5 transition-transform hover:scale-105 ${
                    isLight
                      ? 'bg-white border border-neutral-300/80 text-amber-700 shadow-xs'
                      : 'bg-neutral-900 border border-neutral-700/80 text-amber-400'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <h4
                    className={`text-xs font-mono uppercase tracking-wider font-bold leading-snug ${
                      isLight ? 'text-neutral-900' : 'text-white'
                    }`}
                  >
                    {badge.title}
                  </h4>
                  <p
                    className={`text-[11px] font-sans leading-snug ${
                      isLight ? 'text-neutral-600' : 'text-neutral-400'
                    }`}
                  >
                    {badge.detail}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
