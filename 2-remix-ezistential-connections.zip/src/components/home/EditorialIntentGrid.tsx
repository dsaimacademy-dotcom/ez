import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface IntentItem {
  number: string;
  title: string;
  subtitle: string;
  tag: string;
  image: string;
  category: string;
}

interface EditorialIntentGridProps {
  onNavigate: (view: string, filter?: string) => void;
}

const INTENT_ITEMS: IntentItem[] = [
  {
    number: '01',
    title: 'The Heavyweight Foundations',
    subtitle: '6.5oz ring-spun combed cotton. Architectural boxy cut built to endure.',
    tag: 'Tees & Essentials',
    image: '/src/assets/images/intent_heavyweight_tee_1791882811354.jpg',
    category: 'tees',
  },
  {
    number: '02',
    title: 'Architectural Outerwear',
    subtitle: 'Structured wool & drop-shoulder silhouettes designed for public spaces.',
    tag: 'Jackets & Coats',
    image: '/src/assets/images/intent_outerwear_1791882833628.jpg',
    category: 'outerwear',
  },
  {
    number: '03',
    title: 'Minimalist Draped Tailoring',
    subtitle: 'Relaxed pleated trousers crafted for natural movement and subtle presence.',
    tag: 'Trousers & Bottoms',
    image: '/src/assets/images/intent_tailoring_1791882833683.jpg',
    category: 'bottoms',
  },
  {
    number: '04',
    title: 'Reflective Threshold Fleece',
    subtitle: 'Dense 450GSM loopback cotton with understated tonal micro-typography.',
    tag: 'Hoodies & Knits',
    image: '/src/assets/images/intent_reflective_hoodie_1791882858556.jpg',
    category: 'hoodies',
  },
  {
    number: '05',
    title: 'Studio Pattern & Handcraft',
    subtitle: 'Limited runs cut and assembled domestically with hand-inspected seams.',
    tag: 'Atelier Editions',
    image: '/src/assets/images/intent_craft_studio_1791882859148.jpg',
    category: 'archive',
  },
  {
    number: '06',
    title: 'Archival Numbered Artifacts',
    subtitle: 'Strict limited-batch garments carrying individual edition certificates.',
    tag: 'Limited Capsule',
    image: '/src/assets/images/intent_heavyweight_tee_1791882811354.jpg',
    category: 'capsule',
  },
];

export const EditorialIntentGrid: React.FC<EditorialIntentGridProps> = ({ onNavigate }) => {
  return (
    <section className="w-full bg-[#141414] text-[#fbfbf9] py-20 sm:py-28 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background radial atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-neutral-800/25 via-transparent to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10 space-y-12 sm:space-y-16">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 border-b border-neutral-800 pb-8">
          <div className="space-y-3 max-w-2xl">
            <span className="text-[11px] uppercase font-mono tracking-[0.25em] text-neutral-400 font-semibold block">
              Curated Silhouettes · Intent Matrix
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl tracking-tight text-white leading-tight">
              Explore by Philosophy & Cut
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 font-sans leading-relaxed">
              Every garment is conceived around the space between people — proportioned deliberately to provoke quiet discovery rather than loud performance.
            </p>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('shop')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-neutral-300 hover:text-white transition-colors cursor-pointer group shrink-0"
          >
            <span>View Full Collection</span>
            <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>
        </div>

        {/* 6-Card Intent Grid (Inspired by Reference Category Framework) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {INTENT_ITEMS.map((item) => (
            <div
              key={item.number}
              onClick={() => onNavigate('shop', item.category)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onNavigate('shop', item.category);
                }
              }}
              className="group relative bg-[#1c1c1c] border border-neutral-800 hover:border-neutral-500 rounded-xs overflow-hidden transition-all duration-300 flex flex-col justify-between cursor-pointer shadow-lg hover:shadow-2xl focus:outline-none focus:ring-2 focus:ring-white/40"
            >
              {/* Image Frame */}
              <div className="relative aspect-4/3 w-full overflow-hidden bg-neutral-900">
                <img
                  src={item.image}
                  alt={item.title}
                  loading="lazy"
                  className="w-full h-full object-cover object-center transform transition-transform duration-700 ease-out group-hover:scale-105 opacity-90 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1c1c1c] via-[#1c1c1c]/20 to-transparent" />

                {/* Numbered Pill Overlay */}
                <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-xs border border-white/20 text-white px-2.5 py-1 text-[11px] font-mono tracking-wider rounded-xs flex items-center gap-1.5">
                  <span className="text-neutral-400">{item.number}</span>
                  <span className="text-neutral-600">·</span>
                  <span className="uppercase text-[10px] tracking-widest">{item.tag}</span>
                </div>

                {/* Hover Arrow Icon */}
                <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/70 border border-white/20 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <ArrowUpRight className="w-4 h-4 text-white" />
                </div>
              </div>

              {/* Text Card Details */}
              <div className="p-6 space-y-2 flex-1 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <h3 className="font-serif text-xl sm:text-2xl text-white group-hover:text-amber-100 transition-colors tracking-tight leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-400 font-sans leading-relaxed line-clamp-2">
                    {item.subtitle}
                  </p>
                </div>

                <div className="pt-4 border-t border-neutral-800/80 flex items-center justify-between text-xs font-mono">
                  <span className="text-neutral-500 group-hover:text-neutral-300 transition-colors uppercase tracking-wider text-[11px]">
                    Explore Garments
                  </span>
                  <span className="text-amber-400/80 font-semibold group-hover:translate-x-1 transition-transform">
                    →
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
