import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '../ui/Button';
import { useContent } from '../../context/ContentContext';

interface CraftJourneyTimelineProps {
  onNavigate: (view: string) => void;
}

interface JourneyStage {
  number: string;
  title: string;
  description: string;
}

const STAGES: JourneyStage[] = [
  {
    number: '01',
    title: 'Conception & Inquiry',
    description: 'Conceived from reflections on human distance. Every garment carries an intentional essay on separation and connection.',
  },
  {
    number: '02',
    title: 'Heavyweight Cut & Loom',
    description: 'Woven from 100% ring-spun American cotton (6.5oz/220GSM). Proportioned with drop shoulders and a relaxed drape.',
  },
  {
    number: '03',
    title: 'Hand-Finished Archive',
    description: 'Strict limited runs. Inspected stitch by stitch in our Chicago studio with individual edition certificates included.',
  },
  {
    number: '04',
    title: 'Domestic Direct Delivery',
    description: 'Packed in biodegradable, acid-free archival sleeves and dispatched domestically with carbon-neutral transit.',
  },
];

export const CraftJourneyTimeline: React.FC<CraftJourneyTimelineProps> = ({ onNavigate }) => {
  const { content } = useContent();

  const manifestoTitle = content.manifestoTitle || 'We Believe in the Space Between Us';
  const manifestoExcerpt =
    content.manifestoExcerpt ||
    'We share the same world, yet we experience each other at a distance. Difference is not a defect to be eliminated, nor is it an excuse for division. Somewhere between you and me, there is an us worth discovering.';

  return (
    <section className="w-full bg-[#f5f4f0] text-neutral-900 py-14 sm:py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="max-w-6xl mx-auto space-y-10 sm:space-y-12 relative z-10">
        {/* Streamlined Manifesto Header */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <span className="text-[11px] uppercase font-mono tracking-[0.25em] text-neutral-500 font-semibold block">
            The Manifesto
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-[2.75rem] text-neutral-900 tracking-tight leading-tight text-balance">
            {manifestoTitle}
          </h2>
          <p className="text-base sm:text-lg text-neutral-700 font-sans leading-relaxed max-w-2xl mx-auto text-balance">
            {manifestoExcerpt}
          </p>
          <div className="pt-1">
            <button
              type="button"
              onClick={() => onNavigate('manifesto')}
              className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-neutral-600 hover:text-neutral-950 transition-colors underline decoration-neutral-300 underline-offset-4 cursor-pointer group"
            >
              <span>Read Full Manifesto</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
            </button>
          </div>
        </div>

        {/* Framing Header for the 4-Stage Trajectory */}
        <div className="border-t border-neutral-300/80 pt-8 sm:pt-10">
          <div className="flex items-center justify-between pb-4 sm:pb-6">
            <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-neutral-500 font-semibold">
              The Four-Stage Craft Trajectory
            </span>
            <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-400 hidden sm:inline-block">
              Idea to Delivered Garment
            </span>
          </div>

          {/* Desktop Timeline: Connected Horizontal Layout */}
          <div className="hidden md:grid md:grid-cols-4 gap-6 lg:gap-8 relative pt-2">
            {/* Subtle connecting line running behind nodes */}
            <div
              className="absolute top-6 left-6 right-6 h-[1px] bg-neutral-300/90 z-0"
              aria-hidden="true"
            />

            {STAGES.map((stage) => (
              <div key={stage.number} className="relative z-10 flex flex-col space-y-3">
                {/* Node with Stage Number */}
                <div className="w-8 h-8 rounded-full border border-neutral-900 bg-[#f5f4f0] text-neutral-900 flex items-center justify-center font-mono text-xs font-bold shadow-xs">
                  {stage.number}
                </div>

                <div className="space-y-1.5 pt-1">
                  <h3 className="font-serif text-lg font-bold text-neutral-900 tracking-tight leading-snug">
                    {stage.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-600 font-sans leading-relaxed">
                    {stage.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Mobile Timeline: Clean Connected Vertical Layout */}
          <div className="md:hidden space-y-7 relative pl-7 border-l border-neutral-300 ml-3.5 pt-1">
            {STAGES.map((stage) => (
              <div key={stage.number} className="relative space-y-1.5">
                {/* Connected Node */}
                <div className="absolute -left-[29px] top-0.5 w-7 h-7 rounded-full border border-neutral-900 bg-[#f5f4f0] text-neutral-900 flex items-center justify-center font-mono text-[11px] font-bold shadow-xs">
                  {stage.number}
                </div>

                <h3 className="font-serif text-base font-bold text-neutral-900 tracking-tight leading-snug">
                  {stage.title}
                </h3>
                <p className="text-xs text-neutral-600 font-sans leading-relaxed">
                  {stage.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Clear Call to Action Hierarchy */}
        <div className="pt-4 sm:pt-6 flex flex-col sm:flex-row items-center justify-center gap-4 text-center">
          <Button
            onClick={() => onNavigate('shop')}
            variant="primary"
            size="md"
            className="w-full sm:w-auto bg-neutral-900 hover:bg-black text-white font-mono text-xs uppercase tracking-wider px-8 py-3.5 flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            <span>Explore Current Release</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Button>

          <button
            type="button"
            onClick={() => onNavigate('manifesto')}
            className="text-xs font-mono uppercase tracking-wider text-neutral-600 hover:text-neutral-950 transition-colors py-2 px-3 underline decoration-neutral-300 underline-offset-4 cursor-pointer"
          >
            Read The Manifesto
          </button>
        </div>
      </div>
    </section>
  );
};
