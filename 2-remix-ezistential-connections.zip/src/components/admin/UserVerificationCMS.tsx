import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Shield,
  Award,
  Star,
  Compass,
  Medal,
  Flame,
  Crown,
  Gem,
  Heart,
  CheckCircle2,
  AlertCircle,
  X,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  Power,
  RefreshCw,
  UserCheck,
  UserX,
  ShoppingBag,
  MapPin,
  Camera,
  MessageSquare,
  Calendar,
  Clock,
  DollarSign,
  Package,
  Check,
  ChevronRight,
  Eye,
  SlidersHorizontal,
  Info,
  Users
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import {
  MemberVerificationRules,
  UserProfile,
  Order,
  CustomerResponse,
  MemberBadgeConfig,
  BadgeIconType,
  BadgeColorTheme,
  BadgeCriteria
} from '../../types';
import {
  DEFAULT_VERIFICATION_RULES,
  DEFAULT_BADGES,
  evaluateMemberVerification,
  evaluateBadgeForUser,
  BADGE_THEME_CLASSES,
  calculateUserTotalSpend,
  calculateAccountAgeDays
} from '../../lib/verification';

export interface UserVerificationCMSProps {
  contentRules?: MemberVerificationRules;
  onUpdateRules: (rules: MemberVerificationRules) => void;
  orders: Order[];
  responses: CustomerResponse[];
  currentUser: UserProfile | null;
  showToast: (msg: string) => void;
  isSystemEnabled?: boolean;
  onToggleSystemEnabled?: (enabled: boolean) => void;
}

// Icon helper component
export const RenderBadgeIcon: React.FC<{ icon: BadgeIconType; className?: string }> = ({ icon, className = 'w-4 h-4' }) => {
  switch (icon) {
    case 'shield':
      return <ShieldCheck className={className} />;
    case 'award':
      return <Award className={className} />;
    case 'star':
      return <Star className={className} />;
    case 'compass':
      return <Compass className={className} />;
    case 'medal':
      return <Medal className={className} />;
    case 'flame':
      return <Flame className={className} />;
    case 'crown':
      return <Crown className={className} />;
    case 'gem':
      return <Gem className={className} />;
    case 'heart':
      return <Heart className={className} />;
    case 'checkCircle':
    default:
      return <CheckCircle2 className={className} />;
  }
};

const AVAILABLE_ICONS: { id: BadgeIconType; label: string }[] = [
  { id: 'shield', label: 'Shield' },
  { id: 'award', label: 'Award' },
  { id: 'crown', label: 'Crown' },
  { id: 'medal', label: 'Medal' },
  { id: 'compass', label: 'Compass' },
  { id: 'star', label: 'Star' },
  { id: 'flame', label: 'Flame' },
  { id: 'gem', label: 'Gem' },
  { id: 'heart', label: 'Heart' },
  { id: 'checkCircle', label: 'Check Circle' },
];

const AVAILABLE_THEMES: { id: BadgeColorTheme; label: string; bgClass: string; textClass: string }[] = [
  { id: 'emerald', label: 'Emerald Green', bgClass: 'bg-emerald-500', textClass: 'text-emerald-950' },
  { id: 'gold', label: 'Gold Patron', bgClass: 'bg-amber-400', textClass: 'text-amber-950' },
  { id: 'amber', label: 'Warm Amber', bgClass: 'bg-amber-500', textClass: 'text-amber-950' },
  { id: 'purple', label: 'Imperial Violet', bgClass: 'bg-purple-500', textClass: 'text-purple-950' },
  { id: 'blue', label: 'Architect Blue', bgClass: 'bg-blue-500', textClass: 'text-blue-950' },
  { id: 'rose', label: 'Rose Resonance', bgClass: 'bg-rose-500', textClass: 'text-rose-950' },
  { id: 'neutral', label: 'Architectural Slate', bgClass: 'bg-neutral-800', textClass: 'text-white' },
];

export const UserVerificationCMS: React.FC<UserVerificationCMSProps> = ({
  contentRules,
  onUpdateRules,
  orders,
  responses,
  currentUser,
  showToast,
  isSystemEnabled = true,
  onToggleSystemEnabled,
}) => {
  const [activeTab, setActiveTab] = useState<'verification_engine' | 'badge_studio' | 'member_directory' | 'customer_account_pool'>('verification_engine');
  
  // Local rules state initialized from props or defaults
  const [rules, setRules] = useState<MemberVerificationRules>(() => {
    const initial = contentRules || DEFAULT_VERIFICATION_RULES;
    return {
      ...initial,
      enabled: initial.enabled !== undefined ? initial.enabled : isSystemEnabled,
      customBadges: initial.customBadges && initial.customBadges.length > 0 ? initial.customBadges : DEFAULT_BADGES,
    };
  });

  useEffect(() => {
    if (contentRules) {
      setRules((prev) => ({
        ...prev,
        ...contentRules,
        enabled: contentRules.enabled !== undefined ? contentRules.enabled : isSystemEnabled,
        customBadges: contentRules.customBadges && contentRules.customBadges.length > 0 ? contentRules.customBadges : prev.customBadges,
      }));
    } else {
      setRules((prev) => ({ ...prev, enabled: isSystemEnabled }));
    }
  }, [contentRules, isSystemEnabled]);

  // Badge Studio Modal state
  const [isBadgeModalOpen, setIsBadgeModalOpen] = useState(false);
  const [editingBadgeId, setEditingBadgeId] = useState<string | null>(null);

  // Badge form state
  const [badgeFormName, setBadgeFormName] = useState('');
  const [badgeFormSlug, setBadgeFormSlug] = useState('');
  const [badgeFormDescription, setBadgeFormDescription] = useState('');
  const [badgeFormIcon, setBadgeFormIcon] = useState<BadgeIconType>('shield');
  const [badgeFormTheme, setBadgeFormTheme] = useState<BadgeColorTheme>('emerald');
  const [badgeFormMinOrders, setBadgeFormMinOrders] = useState<number>(1);
  const [badgeFormMinReflections, setBadgeFormMinReflections] = useState<number>(0);
  const [badgeFormMinSpend, setBadgeFormMinSpend] = useState<number>(0);
  const [badgeFormRequirePhoto, setBadgeFormRequirePhoto] = useState<boolean>(false);
  const [badgeFormRequireLocation, setBadgeFormRequireLocation] = useState<boolean>(false);
  const [badgeFormMinAccountAgeDays, setBadgeFormMinAccountAgeDays] = useState<number>(0);
  const [badgeFormIsDefault, setBadgeFormIsDefault] = useState<boolean>(false);
  const [badgeFormIsActive, setBadgeFormIsActive] = useState<boolean>(true);

  // User Badge Management modal state
  const [managingUser, setManagingUser] = useState<UserProfile | null>(null);

  // Initial registered users list combined with current logged-in user
  const [usersList, setUsersList] = useState<UserProfile[]>(() => {
    const defaultList: UserProfile[] = [
      {
        id: 'usr-001',
        email: 'marcus.v@example.com',
        fullName: 'Marcus Vance',
        location: 'Chicago, IL',
        role: 'customer',
        createdAt: '2026-01-15T10:00:00Z',
        updatedAt: '2026-02-10T14:32:00Z',
        addresses: [],
        savedGarments: [
          {
            id: 'sg-001',
            productId: 'tee-001',
            preferredColor: 'Vintage Black',
            preferredSize: 'L',
            note: 'The Space Between Heavyweight Tee',
            savedAt: '2026-02-01T12:00:00Z',
          },
        ],
        isVerifiedManualOverride: false,
        verifiedAt: undefined,
        verificationNotes: '',
        manualBadges: [],
        communicationPreferences: { orderUpdatesEmail: true, reflectionDigestsEmail: true, curatedEssaysEmail: true },
      },
      {
        id: 'usr-002',
        email: 'elena.r@example.com',
        fullName: 'Elena Rostova',
        location: 'Austin, TX',
        role: 'customer',
        createdAt: '2026-02-01T11:20:00Z',
        updatedAt: '2026-02-14T09:15:00Z',
        addresses: [],
        savedGarments: [],
        isVerifiedManualOverride: false,
        manualBadges: ['badge_chronicler'],
        communicationPreferences: { orderUpdatesEmail: true, reflectionDigestsEmail: false, curatedEssaysEmail: true },
      },
      {
        id: 'usr-003',
        email: 'david.k@example.com',
        fullName: 'David Kim',
        location: 'Philadelphia, PA',
        role: 'customer',
        createdAt: '2026-02-05T08:12:00Z',
        updatedAt: '2026-02-22T18:40:00Z',
        addresses: [],
        savedGarments: [],
        isVerifiedManualOverride: false,
        manualBadges: [],
        communicationPreferences: { orderUpdatesEmail: true, reflectionDigestsEmail: true, curatedEssaysEmail: false },
      },
      {
        id: 'usr-004',
        email: 'sophia.m@example.com',
        fullName: 'Sophia Martinez',
        location: 'Brooklyn, NY',
        role: 'customer',
        createdAt: '2026-01-20T14:22:00Z',
        updatedAt: '2026-02-18T10:11:00Z',
        addresses: [],
        savedGarments: [],
        isVerifiedManualOverride: false,
        manualBadges: ['badge_field_documentarian'],
        communicationPreferences: { orderUpdatesEmail: true, reflectionDigestsEmail: true, curatedEssaysEmail: true },
      },
    ];

    if (currentUser && !defaultList.some((u) => u.email.toLowerCase() === currentUser.email.toLowerCase())) {
      defaultList.unshift(currentUser);
    }
    return defaultList;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [filterBadge, setFilterBadge] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'verified' | 'unverified'>('all');

  // Master System Toggle Handler
  const handleToggleMasterSystem = () => {
    const nextState = !(rules.enabled !== false);
    const updated = { ...rules, enabled: nextState };
    setRules(updated);
    onUpdateRules(updated);
    if (onToggleSystemEnabled) {
      onToggleSystemEnabled(nextState);
    }
    showToast(
      nextState
        ? '✓ Member Verification System ACTIVATED globally'
        : '⚠️ Member Verification System DEACTIVATED globally'
    );
  };

  // Rule toggle helper
  const handleToggleRule = (key: keyof MemberVerificationRules) => {
    const updated = { ...rules, [key]: !rules[key] };
    setRules(updated);
    onUpdateRules(updated);
    showToast('Verification rules updated successfully');
  };

  // Numeric rule change helper
  const handleNumberRuleChange = (key: keyof MemberVerificationRules, val: number) => {
    const updated = { ...rules, [key]: val };
    setRules(updated);
    onUpdateRules(updated);
    showToast('Verification threshold updated');
  };

  // Open modal to create a new badge
  const handleOpenCreateBadge = () => {
    setEditingBadgeId(null);
    setBadgeFormName('');
    setBadgeFormSlug('');
    setBadgeFormDescription('');
    setBadgeFormIcon('shield');
    setBadgeFormTheme('emerald');
    setBadgeFormMinOrders(1);
    setBadgeFormMinReflections(0);
    setBadgeFormMinSpend(0);
    setBadgeFormRequirePhoto(false);
    setBadgeFormRequireLocation(false);
    setBadgeFormMinAccountAgeDays(0);
    setBadgeFormIsDefault(false);
    setBadgeFormIsActive(true);
    setIsBadgeModalOpen(true);
  };

  // Open modal to edit an existing badge
  const handleOpenEditBadge = (badge: MemberBadgeConfig) => {
    setEditingBadgeId(badge.id);
    setBadgeFormName(badge.name);
    setBadgeFormSlug(badge.slug);
    setBadgeFormDescription(badge.description);
    setBadgeFormIcon(badge.icon);
    setBadgeFormTheme(badge.colorTheme);
    setBadgeFormMinOrders(badge.criteria.minOrders);
    setBadgeFormMinReflections(badge.criteria.minReflections);
    setBadgeFormMinSpend(badge.criteria.minSpend);
    setBadgeFormRequirePhoto(badge.criteria.requirePhoto);
    setBadgeFormRequireLocation(badge.criteria.requireLocation);
    setBadgeFormMinAccountAgeDays(badge.criteria.minAccountAgeDays);
    setBadgeFormIsDefault(Boolean(badge.isSystemDefault));
    setBadgeFormIsActive(badge.isActive);
    setIsBadgeModalOpen(true);
  };

  // Save new or updated badge
  const handleSaveBadge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!badgeFormName.trim()) {
      showToast('Badge name is required');
      return;
    }

    const currentBadges = rules.customBadges && rules.customBadges.length > 0 ? rules.customBadges : DEFAULT_BADGES;
    const slug = (badgeFormSlug.trim() || badgeFormName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
    
    let updatedBadges: MemberBadgeConfig[];

    if (editingBadgeId) {
      updatedBadges = currentBadges.map((b) => {
        if (b.id === editingBadgeId) {
          return {
            ...b,
            name: badgeFormName.trim(),
            slug,
            description: badgeFormDescription.trim(),
            icon: badgeFormIcon,
            colorTheme: badgeFormTheme,
            criteria: {
              minOrders: Math.max(0, badgeFormMinOrders),
              minReflections: Math.max(0, badgeFormMinReflections),
              minSpend: Math.max(0, badgeFormMinSpend),
              requirePhoto: badgeFormRequirePhoto,
              requireLocation: badgeFormRequireLocation,
              minAccountAgeDays: Math.max(0, badgeFormMinAccountAgeDays),
            },
            isActive: badgeFormIsActive,
            isSystemDefault: badgeFormIsDefault,
          };
        }
        // If this one is marked default, unmark others
        if (badgeFormIsDefault && b.id !== editingBadgeId) {
          return { ...b, isSystemDefault: false };
        }
        return b;
      });
      showToast(`✓ Badge "${badgeFormName}" updated`);
    } else {
      const newBadge: MemberBadgeConfig = {
        id: `badge_${Date.now()}`,
        name: badgeFormName.trim(),
        slug,
        description: badgeFormDescription.trim(),
        icon: badgeFormIcon,
        colorTheme: badgeFormTheme,
        criteria: {
          minOrders: Math.max(0, badgeFormMinOrders),
          minReflections: Math.max(0, badgeFormMinReflections),
          minSpend: Math.max(0, badgeFormMinSpend),
          requirePhoto: badgeFormRequirePhoto,
          requireLocation: badgeFormRequireLocation,
          minAccountAgeDays: Math.max(0, badgeFormMinAccountAgeDays),
        },
        isActive: badgeFormIsActive,
        isSystemDefault: badgeFormIsDefault,
        priority: currentBadges.length + 1,
        createdAt: new Date().toISOString(),
      };

      updatedBadges = badgeFormIsDefault
        ? [...currentBadges.map((b) => ({ ...b, isSystemDefault: false })), newBadge]
        : [...currentBadges, newBadge];

      showToast(`✓ Created new badge: "${newBadge.name}"`);
    }

    const updatedRules: MemberVerificationRules = {
      ...rules,
      customBadges: updatedBadges,
    };
    setRules(updatedRules);
    onUpdateRules(updatedRules);
    setIsBadgeModalOpen(false);
  };

  // Toggle individual badge active status
  const handleToggleBadgeActive = (badgeId: string) => {
    const currentBadges = rules.customBadges && rules.customBadges.length > 0 ? rules.customBadges : DEFAULT_BADGES;
    const updatedBadges = currentBadges.map((b) =>
      b.id === badgeId ? { ...b, isActive: !b.isActive } : b
    );
    const updatedRules = { ...rules, customBadges: updatedBadges };
    setRules(updatedRules);
    onUpdateRules(updatedRules);
    showToast('Badge status updated');
  };

  // Delete badge
  const handleDeleteBadge = (badgeId: string, badgeName: string) => {
    if (!window.confirm(`Are you sure you want to delete badge "${badgeName}"?`)) return;
    const currentBadges = rules.customBadges && rules.customBadges.length > 0 ? rules.customBadges : DEFAULT_BADGES;
    const updatedBadges = currentBadges.filter((b) => b.id !== badgeId);
    const updatedRules = { ...rules, customBadges: updatedBadges };
    setRules(updatedRules);
    onUpdateRules(updatedRules);
    showToast(`Deleted badge: "${badgeName}"`);
  };

  // Reset to default badges
  const handleResetDefaultBadges = () => {
    if (!window.confirm('Reset badges back to factory defaults? Any custom badges will be removed.')) return;
    const updatedRules = { ...rules, customBadges: DEFAULT_BADGES };
    setRules(updatedRules);
    onUpdateRules(updatedRules);
    showToast('Badges reset to factory defaults');
  };

  // Toggle individual user manual verification
  const handleToggleUserVerification = (userId: string) => {
    setUsersList((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const nextVal = !u.isVerifiedManualOverride;
          return {
            ...u,
            isVerifiedManualOverride: nextVal,
            verifiedAt: nextVal ? new Date().toISOString() : undefined,
          };
        }
        return u;
      })
    );
    showToast('User verification override updated');
  };

  // Toggle badge for user in management modal
  const handleToggleBadgeForUser = (userId: string, badgeId: string) => {
    setUsersList((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const currentManual = u.manualBadges || [];
          const hasBadge = currentManual.includes(badgeId);
          const updatedManual = hasBadge
            ? currentManual.filter((id) => id !== badgeId)
            : [...currentManual, badgeId];
          const updatedUser = { ...u, manualBadges: updatedManual };
          if (managingUser && managingUser.id === userId) {
            setManagingUser(updatedUser);
          }
          return updatedUser;
        }
        return u;
      })
    );
    showToast('Member badge permissions updated');
  };

  const activeBadgesList = rules.customBadges && rules.customBadges.length > 0
    ? rules.customBadges
    : DEFAULT_BADGES;

  // Filtered users calculation
  const filteredUsers = usersList.filter((u) => {
    const matchesSearch =
      u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.location && u.location.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    // Evaluate verification STRICTLY for this user's own orders and approved reflections
    const userOrders = orders.filter((o) => o.customerEmail?.toLowerCase() === u.email.toLowerCase());
    const userReflections = responses.filter((r) => r.email?.toLowerCase() === u.email.toLowerCase());
    const evalResult = evaluateMemberVerification(u, userOrders, userReflections, rules);
    if (filterStatus === 'verified' && !evalResult.isVerified) return false;
    if (filterStatus === 'unverified' && evalResult.isVerified) return false;

    if (filterBadge !== 'all') {
      const hasBadge = (u.manualBadges || []).includes(filterBadge) ||
        evalResult.earnedBadges.some((b) => b.id === filterBadge || b.slug === filterBadge);
      if (!hasBadge) return false;
    }

    return true;
  });

  const isSystemActive = rules.enabled !== false;

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. MASTER SYSTEM CONTROL & HEADER BANNER */}
      <div className={`p-6 sm:p-8 border relative overflow-hidden transition-all shadow-md ${
        isSystemActive
          ? 'bg-[#121212] text-white border-neutral-800'
          : 'bg-amber-950/20 text-neutral-900 border-amber-300 dark:bg-amber-950/40 dark:text-amber-100'
      }`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className={`text-[10px] uppercase font-mono tracking-widest px-2.5 py-0.5 border font-bold flex items-center gap-1.5 ${
                isSystemActive
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  : 'bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-400'
              }`}>
                <span className={`w-2 h-2 rounded-full ${isSystemActive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-500'}`} />
                {isSystemActive ? 'VERIFICATION SYSTEM ACTIVE' : 'SYSTEM PAUSED / DISABLED'}
              </span>
              <span className="text-[10px] font-mono text-neutral-400">• Customer Governance</span>
            </div>
            
            <h2 className={`font-serif text-2xl sm:text-3xl tracking-tight ${isSystemActive ? 'text-white' : 'text-neutral-900 dark:text-white'}`}>
              Member Verification & Badge Studio
            </h2>
            
            <p className={`text-xs max-w-xl leading-relaxed ${isSystemActive ? 'text-neutral-300' : 'text-neutral-700 dark:text-neutral-300'}`}>
              {isSystemActive
                ? 'Turn the verification system on or off globally, control qualifying criteria, and design custom badges awarded automatically to members upon meeting orders, reflections, spend, or tenure milestones.'
                : 'The verification system is currently turned off. Verification badges, progress meters, and verification engine tabs are hidden from customer accounts and storefront pages.'}
            </p>
          </div>

          {/* Master Toggle Button & Quick Stats */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            <div className={`p-3.5 border text-xs font-mono space-y-1 ${
              isSystemActive ? 'bg-neutral-900/90 border-neutral-800 text-neutral-300' : 'bg-white/80 border-amber-300 text-neutral-800 dark:bg-neutral-900 dark:text-neutral-200'
            }`}>
              <div className="flex items-center justify-between gap-4">
                <span className="text-[10px] uppercase tracking-wider text-neutral-400">Total Badges:</span>
                <span className="font-bold text-amber-400">{activeBadgesList.length} defined</span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <span className="text-[10px] uppercase tracking-wider text-neutral-400">Active Badges:</span>
                <span className="font-bold text-emerald-400">{activeBadgesList.filter((b) => b.isActive).length} active</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleToggleMasterSystem}
              className={`px-5 py-3.5 text-xs font-mono uppercase font-bold tracking-wider flex items-center justify-center gap-2.5 transition-all cursor-pointer border shadow-sm ${
                isSystemActive
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500 hover:shadow-emerald-900/20'
                  : 'bg-neutral-900 hover:bg-black text-white border-neutral-800'
              }`}
            >
              <Power className={`w-4 h-4 ${isSystemActive ? 'text-emerald-200' : 'text-amber-400'}`} />
              <span>{isSystemActive ? 'Turn Off System' : 'Turn On System'}</span>
            </button>
          </div>
        </div>

        {/* System Disabled Warning Banner */}
        {!isSystemActive && (
          <div className="mt-4 pt-3 border-t border-amber-300/40 flex items-center gap-2 text-xs font-mono text-amber-900 dark:text-amber-200">
            <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span>Customer-facing verification controls are paused. Click "Turn On System" to reactivate badge awarding and verification tracking.</span>
          </div>
        )}
      </div>

      {/* 2. NAVIGATION SUBTABS */}
      <div className="flex border-b border-neutral-200 bg-white p-2 space-x-2 shadow-2xs overflow-x-auto">
        <button
          onClick={() => setActiveTab('verification_engine')}
          className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center space-x-2 shrink-0 ${
            activeTab === 'verification_engine'
              ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
              : 'bg-[#fbfbf9] text-neutral-600 hover:text-black border-neutral-200'
          }`}
        >
          <SlidersHorizontal className={`w-4 h-4 ${activeTab === 'verification_engine' ? 'text-amber-300' : 'text-neutral-500'}`} />
          <span>1. Verification Criteria & Rules</span>
        </button>

        <button
          onClick={() => setActiveTab('badge_studio')}
          className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center space-x-2 shrink-0 ${
            activeTab === 'badge_studio'
              ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
              : 'bg-[#fbfbf9] text-neutral-600 hover:text-black border-neutral-200'
          }`}
        >
          <Award className={`w-4 h-4 ${activeTab === 'badge_studio' ? 'text-amber-300' : 'text-neutral-500'}`} />
          <span>2. Badge Studio & Criteria ({activeBadgesList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('member_directory')}
          className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center space-x-2 shrink-0 ${
            activeTab === 'member_directory'
              ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
              : 'bg-[#fbfbf9] text-neutral-600 hover:text-black border-neutral-200'
          }`}
        >
          <UserCheck className={`w-4 h-4 ${activeTab === 'member_directory' ? 'text-amber-300' : 'text-neutral-500'}`} />
          <span>3. Member Directory & Badging ({usersList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('customer_account_pool')}
          className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center space-x-2 shrink-0 ${
            activeTab === 'customer_account_pool'
              ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
              : 'bg-[#fbfbf9] text-neutral-600 hover:text-black border-neutral-200'
          }`}
        >
          <ShoppingBag className={`w-4 h-4 ${activeTab === 'customer_account_pool' ? 'text-amber-300' : 'text-neutral-500'}`} />
          <span>4. Activity & Wishlist Pool</span>
        </button>
      </div>

      {/* TAB 1: VERIFICATION RULES & CRITERIA CONTROL */}
      {activeTab === 'verification_engine' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-neutral-900">Core Member Verification Criteria</h3>
              <p className="text-xs text-neutral-500 font-sans mt-0.5">
                Set storewide criteria determining which members earn official verified wearer status.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-[11px] font-mono font-bold px-2.5 py-1 border ${
                isSystemActive ? 'bg-emerald-50 text-emerald-900 border-emerald-300' : 'bg-neutral-100 text-neutral-600 border-neutral-300'
              }`}>
                Status: {isSystemActive ? 'Active' : 'Turned Off'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Rule 1: Require Garment Order */}
            <div className={`p-5 border transition-all ${
              rules.requirePurchase ? 'bg-[#fbfbf9] border-neutral-300' : 'bg-neutral-50/60 border-neutral-200 opacity-80'
            }`}>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <Package className="w-4 h-4 text-neutral-700" />
                    <span className="font-serif font-bold text-sm text-neutral-900">1. Fulfilled Garment Purchase</span>
                  </div>
                  <p className="text-xs text-neutral-500 leading-relaxed">
                    Member must have completed at least one real physical garment order through checkout.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleRule('requirePurchase')}
                  className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                    rules.requirePurchase ? 'bg-neutral-900' : 'bg-neutral-300'
                  }`}
                >
                  <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    rules.requirePurchase ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              {rules.requirePurchase && (
                <div className="mt-4 pt-3 border-t border-neutral-200 flex items-center justify-between text-xs font-mono">
                  <span className="text-neutral-600">Minimum Orders Required:</span>
                  <div className="flex items-center space-x-2">
                    {[1, 2, 3, 5].map((cnt) => (
                      <button
                        key={cnt}
                        type="button"
                        onClick={() => handleNumberRuleChange('minPurchasesCount', cnt)}
                        className={`px-2.5 py-1 text-xs border cursor-pointer font-bold transition-colors ${
                          rules.minPurchasesCount === cnt
                            ? 'bg-neutral-900 text-white border-neutral-900'
                            : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                        }`}
                      >
                        {cnt}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Rule 2: Minimum Spend Requirement */}
            <div className="p-5 border bg-[#fbfbf9] border-neutral-300">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <DollarSign className="w-4 h-4 text-neutral-700" />
                    <span className="font-serif font-bold text-sm text-neutral-900">2. Minimum Total Spend ($)</span>
                  </div>
                  <p className="text-xs text-neutral-500 leading-relaxed">
                    Cumulative purchase value required before unlocking verification status.
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-neutral-200 flex items-center justify-between text-xs font-mono">
                <span className="text-neutral-600">Spend Threshold:</span>
                <div className="flex items-center space-x-2">
                  {[0, 50, 100, 150, 250].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => handleNumberRuleChange('minSpendAmount', amt)}
                      className={`px-2 py-1 text-xs border cursor-pointer font-bold transition-colors ${
                        (rules.minSpendAmount || 0) === amt
                          ? 'bg-neutral-900 text-white border-neutral-900'
                          : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                      }`}
                    >
                      {amt === 0 ? 'None ($0)' : `$${amt}`}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Rule 3: Require Field Reflection */}
            <div className={`p-5 border transition-all ${
              rules.requireReflection ? 'bg-[#fbfbf9] border-neutral-300' : 'bg-neutral-50/60 border-neutral-200 opacity-80'
            }`}>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="w-4 h-4 text-neutral-700" />
                    <span className="font-serif font-bold text-sm text-neutral-900">3. Approved Field Reflection</span>
                  </div>
                  <p className="text-xs text-neutral-500 leading-relaxed">
                    Member must have submitted at least one approved reflection to Voices from the Threshold.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleRule('requireReflection')}
                  className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                    rules.requireReflection ? 'bg-neutral-900' : 'bg-neutral-300'
                  }`}
                >
                  <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    rules.requireReflection ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              {rules.requireReflection && (
                <div className="mt-4 pt-3 border-t border-neutral-200 flex items-center justify-between text-xs font-mono">
                  <span className="text-neutral-600">Reflections Required:</span>
                  <div className="flex items-center space-x-2">
                    {[1, 2, 3].map((cnt) => (
                      <button
                        key={cnt}
                        type="button"
                        onClick={() => handleNumberRuleChange('minReflectionsCount', cnt)}
                        className={`px-2.5 py-1 text-xs border cursor-pointer font-bold transition-colors ${
                          (rules.minReflectionsCount || 1) === cnt
                            ? 'bg-neutral-900 text-white border-neutral-900'
                            : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                        }`}
                      >
                        {cnt}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Rule 4: Require Profile Location */}
            <div className={`p-5 border transition-all ${
              rules.requireProfileLocation ? 'bg-[#fbfbf9] border-neutral-300' : 'bg-neutral-50/60 border-neutral-200 opacity-80'
            }`}>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-neutral-700" />
                    <span className="font-serif font-bold text-sm text-neutral-900">4. Profile Location (City / State)</span>
                  </div>
                  <p className="text-xs text-neutral-500 leading-relaxed">
                    Account profile must declare physical geography (e.g. "Chicago, IL") anchoring identity.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleRule('requireProfileLocation')}
                  className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                    rules.requireProfileLocation ? 'bg-neutral-900' : 'bg-neutral-300'
                  }`}
                >
                  <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    rules.requireProfileLocation ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            </div>

            {/* Rule 5: Require On-Body Photo */}
            <div className={`p-5 border transition-all ${
              rules.requirePhoto ? 'bg-[#fbfbf9] border-neutral-300' : 'bg-neutral-50/60 border-neutral-200 opacity-80'
            }`}>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <Camera className="w-4 h-4 text-neutral-700" />
                    <span className="font-serif font-bold text-sm text-neutral-900">5. On-Body Photo Submission</span>
                  </div>
                  <p className="text-xs text-neutral-500 leading-relaxed">
                    Member must have uploaded an on-body photographic encounter showing garment wear in context.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleRule('requirePhoto')}
                  className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                    rules.requirePhoto ? 'bg-neutral-900' : 'bg-neutral-300'
                  }`}
                >
                  <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    rules.requirePhoto ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            </div>

            {/* Rule 6: Account Age / Tenure */}
            <div className="p-5 border bg-[#fbfbf9] border-neutral-300">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-neutral-700" />
                    <span className="font-serif font-bold text-sm text-neutral-900">6. Minimum Account Tenure (Days)</span>
                  </div>
                  <p className="text-xs text-neutral-500 leading-relaxed">
                    Number of days an account must exist before verification status can become effective.
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-neutral-200 flex items-center justify-between text-xs font-mono">
                <span className="text-neutral-600">Minimum Days:</span>
                <div className="flex items-center space-x-2">
                  {[0, 7, 14, 30].map((days) => (
                    <button
                      key={days}
                      type="button"
                      onClick={() => handleNumberRuleChange('minAccountAgeDays', days)}
                      className={`px-2 py-1 text-xs border cursor-pointer font-bold transition-colors ${
                        (rules.minAccountAgeDays || 0) === days
                          ? 'bg-neutral-900 text-white border-neutral-900'
                          : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                      }`}
                    >
                      {days === 0 ? 'Instant (0d)' : `${days} days`}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Rule 7: Allow Admin Manual Override */}
            <div className="p-5 border bg-[#fbfbf9] border-neutral-300">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <UserCheck className="w-4 h-4 text-neutral-700" />
                    <span className="font-serif font-bold text-sm text-neutral-900">7. Manual Admin Override Granted</span>
                  </div>
                  <p className="text-xs text-neutral-500 leading-relaxed">
                    Allow curators and admins to manually grant or revoke verified status regardless of criteria.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleRule('allowManualOverride')}
                  className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                    rules.allowManualOverride ? 'bg-neutral-900' : 'bg-neutral-300'
                  }`}
                >
                  <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    rules.allowManualOverride ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BADGE STUDIO & CRITERIA BUILDER */}
      {activeTab === 'badge_studio' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-neutral-900">Badge Studio & Criteria Engine</h3>
              <p className="text-xs text-neutral-500 font-sans mt-0.5">
                Create and manage custom badges awarded to members automatically when they fulfill specific order, reflection, spend, or tenure criteria.
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={handleResetDefaultBadges}
                className="text-xs font-mono"
              >
                <RefreshCw className="w-3.5 h-3.5 mr-1 text-neutral-500" />
                Reset Defaults
              </Button>
              <Button
                size="sm"
                onClick={handleOpenCreateBadge}
                className="bg-neutral-900 text-white hover:bg-black text-xs font-mono cursor-pointer"
              >
                <Plus className="w-4 h-4 mr-1 text-amber-400" />
                Create New Badge
              </Button>
            </div>
          </div>

          {/* Badges Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeBadgesList.map((badge) => {
              const theme = BADGE_THEME_CLASSES[badge.colorTheme] || BADGE_THEME_CLASSES.emerald;
              const isDefault = Boolean(badge.isSystemDefault);

              return (
                <div
                  key={badge.id}
                  className={`border p-5 rounded-xs space-y-4 relative flex flex-col justify-between transition-all ${
                    badge.isActive ? 'bg-white border-neutral-200 shadow-xs' : 'bg-neutral-50/60 border-neutral-200 opacity-60'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Header with Icon and Badge Status */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center space-x-2.5">
                        <div className={`p-2 border rounded-xs ${theme.badgeBg} ${theme.badgeBorder} ${theme.iconColor}`}>
                          <RenderBadgeIcon icon={badge.icon} className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="font-serif font-bold text-neutral-900 text-base leading-tight">
                              {badge.name}
                            </h4>
                            {isDefault && (
                              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 bg-neutral-900 text-amber-300 font-bold" title="Primary Verification Badge">
                                Primary
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] font-mono text-neutral-400">{badge.slug}</span>
                        </div>
                      </div>

                      {/* Active Toggle Switch */}
                      <button
                        type="button"
                        onClick={() => handleToggleBadgeActive(badge.id)}
                        className={`w-9 h-5 flex items-center rounded-full p-0.5 cursor-pointer transition-colors shrink-0 ${
                          badge.isActive ? 'bg-emerald-600' : 'bg-neutral-300'
                        }`}
                        title={badge.isActive ? 'Badge is Active' : 'Badge is Inactive'}
                      >
                        <div className={`bg-white w-4 h-4 rounded-full shadow-xs transform transition-transform ${
                          badge.isActive ? 'translate-x-4' : 'translate-x-0'
                        }`} />
                      </button>
                    </div>

                    <p className="text-xs text-neutral-600 line-clamp-2 leading-relaxed">
                      {badge.description}
                    </p>

                    {/* Criteria Tags */}
                    <div className="pt-2 border-t border-neutral-100 space-y-1.5">
                      <div className="text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-bold">
                        Fulfillment Criteria:
                      </div>
                      <div className="flex flex-wrap gap-1.5 text-[11px] font-mono">
                        {badge.criteria.minOrders > 0 && (
                          <span className="px-2 py-0.5 bg-neutral-100 text-neutral-800 border border-neutral-200">
                            {badge.criteria.minOrders}+ Orders
                          </span>
                        )}
                        {badge.criteria.minSpend > 0 && (
                          <span className="px-2 py-0.5 bg-neutral-100 text-neutral-800 border border-neutral-200">
                            ${badge.criteria.minSpend}+ Spend
                          </span>
                        )}
                        {badge.criteria.minReflections > 0 && (
                          <span className="px-2 py-0.5 bg-neutral-100 text-neutral-800 border border-neutral-200">
                            {badge.criteria.minReflections}+ Reflections
                          </span>
                        )}
                        {badge.criteria.requirePhoto && (
                          <span className="px-2 py-0.5 bg-neutral-100 text-neutral-800 border border-neutral-200">
                            Photo Required
                          </span>
                        )}
                        {badge.criteria.requireLocation && (
                          <span className="px-2 py-0.5 bg-neutral-100 text-neutral-800 border border-neutral-200">
                            Location Required
                          </span>
                        )}
                        {badge.criteria.minAccountAgeDays > 0 && (
                          <span className="px-2 py-0.5 bg-neutral-100 text-neutral-800 border border-neutral-200">
                            {badge.criteria.minAccountAgeDays}+ Days Old
                          </span>
                        )}
                        {badge.criteria.minOrders === 0 &&
                          badge.criteria.minSpend === 0 &&
                          badge.criteria.minReflections === 0 &&
                          !badge.criteria.requirePhoto &&
                          !badge.criteria.requireLocation &&
                          badge.criteria.minAccountAgeDays === 0 && (
                            <span className="px-2 py-0.5 bg-amber-50 text-amber-900 border border-amber-200">
                              Manual Curator Grant Only
                            </span>
                          )}
                      </div>
                    </div>
                  </div>

                  {/* Actions footer */}
                  <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs">
                    <span className={`px-2 py-0.5 text-[10px] font-mono font-bold border ${theme.badgeBg} ${theme.badgeBorder} ${theme.badgeText}`}>
                      Theme: {badge.colorTheme}
                    </span>
                    <div className="flex items-center space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleOpenEditBadge(badge)}
                        className="text-neutral-600 hover:text-black h-8 px-2"
                        title="Edit Badge Criteria"
                      >
                        <Edit2 className="w-3.5 h-3.5 mr-1" />
                        Edit
                      </Button>
                      {!isDefault && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteBadge(badge.id, badge.name)}
                          className="text-red-600 hover:text-red-800 hover:bg-red-50 h-8 px-2"
                          title="Delete Badge"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: MEMBER DIRECTORY & MANUAL BADGING */}
      {activeTab === 'member_directory' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-neutral-900">Member Directory & Criteria Audit</h3>
              <p className="text-xs text-neutral-500 font-sans mt-0.5">
                Review member verification progression, audit fulfilled criteria, and manually grant or revoke badges.
              </p>
            </div>
            <span className="text-xs font-mono text-neutral-500">
              Showing {filteredUsers.length} of {usersList.length} Accounts
            </span>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search member by name, email, or city..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-neutral-200 text-xs focus:outline-hidden focus:border-black bg-[#fbfbf9]"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="px-3 py-2 border border-neutral-200 text-xs bg-[#fbfbf9] focus:outline-hidden"
              >
                <option value="all">All Verification Statuses</option>
                <option value="verified">Verified Only</option>
                <option value="unverified">In Progress Only</option>
              </select>

              <select
                value={filterBadge}
                onChange={(e) => setFilterBadge(e.target.value)}
                className="px-3 py-2 border border-neutral-200 text-xs bg-[#fbfbf9] focus:outline-hidden"
              >
                <option value="all">All Badges</option>
                {activeBadgesList.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Members Table */}
          <div className="border border-neutral-200 overflow-x-auto">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-[#f5f4f0] border-b border-neutral-200 text-neutral-600 uppercase font-mono text-[10px] tracking-wider">
                <tr>
                  <th className="p-3.5">Member Identity</th>
                  <th className="p-3.5">Verification</th>
                  <th className="p-3.5">Orders / Spend</th>
                  <th className="p-3.5">Reflections</th>
                  <th className="p-3.5">Earned & Granted Badges</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {filteredUsers.map((u) => {
                  const userOrders = orders.filter((o) => o.customerEmail?.toLowerCase() === u.email.toLowerCase());
                  const userReflections = responses.filter((r) => r.email?.toLowerCase() === u.email.toLowerCase());
                  const evalResult = evaluateMemberVerification(u, userOrders, userReflections, rules);
                  const isVerified = evalResult.isVerified;
                  const totalSpend = calculateUserTotalSpend(userOrders);
                  const manualBadges = u.manualBadges || [];

                  return (
                    <tr key={u.id} className="hover:bg-neutral-50 transition-colors">
                      <td className="p-3.5">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-full bg-neutral-900 text-white font-serif text-xs flex items-center justify-center shrink-0">
                            {u.fullName.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-medium text-neutral-900">{u.fullName}</div>
                            <div className="text-[11px] text-neutral-500 font-mono">{u.email}</div>
                            {u.location && (
                              <div className="text-[10px] text-neutral-400 flex items-center gap-1 font-mono">
                                <MapPin className="w-2.5 h-2.5" />
                                {u.location}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>

                      <td className="p-3.5">
                        <div className="space-y-1">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-mono font-bold border ${
                            isVerified
                              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                              : 'bg-neutral-100 text-neutral-600 border-neutral-200'
                          }`}>
                            {isVerified ? <Check className="w-3 h-3 text-emerald-600" /> : <Clock className="w-3 h-3 text-neutral-400" />}
                            {isVerified ? 'Verified' : `${evalResult.percentage}%`}
                          </span>
                          {u.isVerifiedManualOverride && (
                            <div className="text-[9px] text-purple-700 font-mono">Manual Override</div>
                          )}
                        </div>
                      </td>

                      <td className="p-3.5 font-mono text-[11px]">
                        <div>{userOrders.length} order(s)</div>
                        <div className="text-neutral-500">${totalSpend.toFixed(2)}</div>
                      </td>

                      <td className="p-3.5 font-mono text-[11px]">
                        <div>{userReflections.length} submitted</div>
                        <div className="text-neutral-400">{userReflections.some((r) => r.photoUrl) ? 'Has Photo' : 'No Photo'}</div>
                      </td>

                      <td className="p-3.5">
                        <div className="flex flex-wrap gap-1 max-w-xs">
                          {evalResult.earnedBadges.map((badge) => {
                            const theme = BADGE_THEME_CLASSES[badge.colorTheme] || BADGE_THEME_CLASSES.emerald;
                            const isManual = manualBadges.includes(badge.id);

                            return (
                              <span
                                key={badge.id}
                                className={`inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-mono border ${theme.badgeBg} ${theme.badgeBorder} ${theme.badgeText}`}
                                title={isManual ? `${badge.name} (Curator Granted)` : `${badge.name} (Auto-Qualified)`}
                              >
                                <RenderBadgeIcon icon={badge.icon} className="w-3 h-3" />
                                <span>{badge.name}</span>
                                {isManual && <span className="text-[8px] text-purple-600 font-bold">*</span>}
                              </span>
                            );
                          })}
                          {evalResult.earnedBadges.length === 0 && (
                            <span className="text-[10px] font-mono text-neutral-400 italic">None yet</span>
                          )}
                        </div>
                      </td>

                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setManagingUser(u)}
                            className="text-[11px] font-mono h-7 px-2 cursor-pointer"
                          >
                            Manage Badges
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleToggleUserVerification(u.id)}
                            className={`text-[11px] font-mono h-7 px-2 ${
                              u.isVerifiedManualOverride ? 'text-red-600 hover:bg-red-50' : 'text-emerald-700 hover:bg-emerald-50'
                            }`}
                          >
                            {u.isVerifiedManualOverride ? 'Revoke' : 'Verify'}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: SAVED GARMENTS & ACTIVITY POOL */}
      {activeTab === 'customer_account_pool' && (
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-neutral-900">Member Saved Garments & Interaction Pool</h3>
              <p className="text-xs text-neutral-500 font-sans mt-0.5">
                Inspect items added to member personal archives and wishlists.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {usersList.flatMap((u) =>
              u.savedGarments.map((g) => ({ ...g, userEmail: u.email, userName: u.fullName }))
            ).length === 0 ? (
              <div className="col-span-3 p-12 text-center text-xs font-mono text-neutral-400 border border-dashed border-neutral-200">
                No saved garments recorded in current member sessions.
              </div>
            ) : (
              usersList.flatMap((u) =>
                u.savedGarments.map((g, idx) => (
                  <div key={`${u.id}-${idx}`} className="p-4 border border-neutral-200 bg-[#fbfbf9] space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="font-bold text-neutral-900">{g.note || g.productId}</span>
                      <span className="text-neutral-500 font-mono text-[10px]">{g.productId}</span>
                    </div>
                    <div className="text-[11px] font-mono text-neutral-500">
                      Saved by: {u.fullName} ({u.email})
                    </div>
                    <div className="text-[10px] font-mono text-neutral-400">
                      Color: {g.preferredColor || 'Standard'} • Size: {g.preferredSize || 'Any'}
                    </div>
                  </div>
                ))
              )
            )}
          </div>
        </div>
      )}

      {/* 3. CREATE / EDIT BADGE MODAL */}
      {isBadgeModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white max-w-2xl w-full border border-neutral-300 shadow-2xl p-6 sm:p-8 space-y-6 my-8 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
              <div>
                <h3 className="font-serif text-2xl font-bold text-neutral-900">
                  {editingBadgeId ? 'Edit Badge & Criteria' : 'Create New Member Badge'}
                </h3>
                <p className="text-xs text-neutral-500 font-sans mt-0.5">
                  Configure visual appearance, identifier, and the criteria required to unlock this badge.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsBadgeModalOpen(false)}
                className="p-1.5 text-neutral-400 hover:text-black transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBadge} className="space-y-6 text-xs font-sans">
              {/* Live Preview Card */}
              <div className="p-4 border border-neutral-200 bg-[#fcfcfb] rounded-xs space-y-2">
                <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-bold block">
                  Live Badge Preview
                </span>
                <div className="flex items-center space-x-3">
                  <div className={`p-2.5 border rounded-xs ${BADGE_THEME_CLASSES[badgeFormTheme].badgeBg} ${BADGE_THEME_CLASSES[badgeFormTheme].badgeBorder} ${BADGE_THEME_CLASSES[badgeFormTheme].iconColor}`}>
                    <RenderBadgeIcon icon={badgeFormIcon} className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-serif font-bold text-neutral-900 text-sm">
                        {badgeFormName || 'Badge Name Here'}
                      </span>
                      {badgeFormIsDefault && (
                        <span className="text-[9px] uppercase font-mono px-1 py-0.5 bg-neutral-900 text-amber-300 font-bold">
                          Primary Verification
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      {badgeFormDescription || 'Description of how a member unlocks this badge.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Basic Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[11px] font-mono uppercase tracking-wider text-neutral-700 font-bold block">
                    Badge Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Founding Patron"
                    value={badgeFormName}
                    onChange={(e) => setBadgeFormName(e.target.value)}
                    className="w-full px-3 py-2 border border-neutral-300 text-xs focus:outline-hidden focus:border-black"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-mono uppercase tracking-wider text-neutral-700 font-bold block">
                    Slug / Identifier
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. founding-patron"
                    value={badgeFormSlug}
                    onChange={(e) => setBadgeFormSlug(e.target.value)}
                    className="w-full px-3 py-2 border border-neutral-300 text-xs font-mono focus:outline-hidden focus:border-black"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-mono uppercase tracking-wider text-neutral-700 font-bold block">
                  Description / Meaning
                </label>
                <textarea
                  rows={2}
                  placeholder="Explains what this badge represents and how members achieve it..."
                  value={badgeFormDescription}
                  onChange={(e) => setBadgeFormDescription(e.target.value)}
                  className="w-full px-3 py-2 border border-neutral-300 text-xs focus:outline-hidden focus:border-black resize-none"
                />
              </div>

              {/* Icon & Theme Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-mono uppercase tracking-wider text-neutral-700 font-bold block">
                    Visual Icon
                  </label>
                  <div className="grid grid-cols-5 gap-1.5">
                    {AVAILABLE_ICONS.map((ic) => (
                      <button
                        key={ic.id}
                        type="button"
                        onClick={() => setBadgeFormIcon(ic.id)}
                        className={`p-2 border flex flex-col items-center justify-center transition-colors cursor-pointer rounded-xs ${
                          badgeFormIcon === ic.id
                            ? 'bg-neutral-900 text-white border-neutral-900'
                            : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                        }`}
                        title={ic.label}
                      >
                        <RenderBadgeIcon icon={ic.id} className="w-4 h-4" />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[11px] font-mono uppercase tracking-wider text-neutral-700 font-bold block">
                    Theme Color
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {AVAILABLE_THEMES.map((th) => (
                      <button
                        key={th.id}
                        type="button"
                        onClick={() => setBadgeFormTheme(th.id)}
                        className={`px-2 py-1.5 border text-[10px] font-mono transition-colors cursor-pointer rounded-xs text-center ${
                          badgeFormTheme === th.id
                            ? 'bg-neutral-900 text-white border-neutral-900 font-bold'
                            : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                        }`}
                      >
                        {th.label.split(' ')[0]}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Criteria Section */}
              <div className="border border-neutral-200 p-4 space-y-4 bg-[#fbfbf9]">
                <div className="border-b border-neutral-200 pb-2">
                  <h4 className="font-serif font-bold text-neutral-900 text-sm">
                    Automated Criteria Requirements
                  </h4>
                  <p className="text-[11px] text-neutral-500">
                    A member automatically unlocks this badge when ALL specified conditions below are met.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase text-neutral-600 block">
                      Min Garment Orders
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={badgeFormMinOrders}
                      onChange={(e) => setBadgeFormMinOrders(parseInt(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 border border-neutral-300 text-xs font-mono bg-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase text-neutral-600 block">
                      Min Total Spend ($)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={10000}
                      value={badgeFormMinSpend}
                      onChange={(e) => setBadgeFormMinSpend(parseInt(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 border border-neutral-300 text-xs font-mono bg-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase text-neutral-600 block">
                      Min Reflections
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={50}
                      value={badgeFormMinReflections}
                      onChange={(e) => setBadgeFormMinReflections(parseInt(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 border border-neutral-300 text-xs font-mono bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase text-neutral-600 block">
                      Min Account Age (Days)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={365}
                      value={badgeFormMinAccountAgeDays}
                      onChange={(e) => setBadgeFormMinAccountAgeDays(parseInt(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 border border-neutral-300 text-xs font-mono bg-white"
                    />
                  </div>

                  <label className="flex items-center space-x-2 cursor-pointer pt-4">
                    <input
                      type="checkbox"
                      checked={badgeFormRequirePhoto}
                      onChange={(e) => setBadgeFormRequirePhoto(e.target.checked)}
                      className="w-4 h-4 rounded-xs border-neutral-300"
                    />
                    <span className="text-[11px] text-neutral-800 font-mono">Require On-Body Photo</span>
                  </label>

                  <label className="flex items-center space-x-2 cursor-pointer pt-4">
                    <input
                      type="checkbox"
                      checked={badgeFormRequireLocation}
                      onChange={(e) => setBadgeFormRequireLocation(e.target.checked)}
                      className="w-4 h-4 rounded-xs border-neutral-300"
                    />
                    <span className="text-[11px] text-neutral-800 font-mono">Require City/State</span>
                  </label>
                </div>
              </div>

              {/* Toggles */}
              <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={badgeFormIsActive}
                    onChange={(e) => setBadgeFormIsActive(e.target.checked)}
                    className="w-4 h-4 rounded-xs border-neutral-300"
                  />
                  <span className="text-xs text-neutral-800 font-medium">Badge is Active</span>
                </label>

                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={badgeFormIsDefault}
                    onChange={(e) => setBadgeFormIsDefault(e.target.checked)}
                    className="w-4 h-4 rounded-xs border-neutral-300"
                  />
                  <span className="text-xs text-neutral-800 font-medium">Set as Primary Verified Wearer Badge</span>
                </label>
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-neutral-200">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsBadgeModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-neutral-900 text-white hover:bg-black font-mono text-xs"
                >
                  {editingBadgeId ? 'Update Badge' : 'Create Badge'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. USER BADGE MANAGEMENT MODAL */}
      {managingUser && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-lg w-full border border-neutral-300 shadow-2xl p-6 space-y-6 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <div>
                <h3 className="font-serif text-xl font-bold text-neutral-900">
                  Manage Badges: {managingUser.fullName}
                </h3>
                <p className="text-xs text-neutral-500 font-mono">
                  {managingUser.email}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setManagingUser(null)}
                className="p-1 text-neutral-400 hover:text-black cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-bold block">
                Toggle Curator Badges for This Member:
              </span>
              <div className="space-y-2">
                {activeBadgesList.map((badge) => {
                  const hasBadge = (managingUser.manualBadges || []).includes(badge.id);
                  const theme = BADGE_THEME_CLASSES[badge.colorTheme] || BADGE_THEME_CLASSES.emerald;

                  return (
                    <div
                      key={badge.id}
                      className="p-3 border border-neutral-200 flex items-center justify-between gap-3 hover:bg-neutral-50 transition-colors"
                    >
                      <div className="flex items-center space-x-2.5">
                        <div className={`p-1.5 border rounded-xs ${theme.badgeBg} ${theme.badgeBorder} ${theme.iconColor}`}>
                          <RenderBadgeIcon icon={badge.icon} className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-medium text-xs text-neutral-900">{badge.name}</div>
                          <div className="text-[10px] text-neutral-500 line-clamp-1">{badge.description}</div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleToggleBadgeForUser(managingUser.id, badge.id)}
                        className={`px-2.5 py-1 text-xs font-mono font-bold border transition-colors cursor-pointer ${
                          hasBadge
                            ? 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'
                            : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                        }`}
                      >
                        {hasBadge ? 'Granted ✓' : '+ Grant'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-3 border-t border-neutral-200 flex items-center justify-end">
              <Button
                size="sm"
                className="bg-neutral-900 text-white hover:bg-black font-mono text-xs cursor-pointer"
                onClick={() => setManagingUser(null)}
              >
                Done
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
