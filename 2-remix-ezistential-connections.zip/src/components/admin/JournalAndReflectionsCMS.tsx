import React, { useState } from 'react';
import { BookOpen, MessageSquare, ExternalLink, ShieldCheck, Trash2 } from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { useResponses } from '../../context/ResponseContext';
import { BlogPostsCMS } from './BlogPostsCMS';
import { Badge } from '../ui/Badge';
import { FEATURE_FLAGS } from '../../config/featureFlags';

export interface JournalAndReflectionsCMSProps {
  initialTab?: 'journal' | 'reflections';
  showToast?: (msg: string) => void;
  onNavigateToView?: (viewId: string) => void;
  canModerateCommunity?: boolean;
  canEditContent?: boolean;
  openConfirmDelete?: (config: {
    title: string;
    itemName: string;
    itemType?: string;
    warningMessage?: string;
    onConfirm: () => void;
  }) => void;
}

export const JournalAndReflectionsCMS: React.FC<JournalAndReflectionsCMSProps> = ({
  initialTab = 'journal',
  showToast,
  onNavigateToView,
  canModerateCommunity = true,
  canEditContent = true,
  openConfirmDelete,
}) => {
  const { content, updateContent } = useContent();
  const { responses, updateStatus, deleteResponse } = useResponses();

  const [activeTab, setActiveTab] = useState<'journal' | 'reflections'>(initialTab);

  // Feature flags / visibility
  const [enableJournal, setEnableJournal] = useState<boolean>(content.enableJournal !== false);
  const [enableReflections, setEnableReflections] = useState<boolean>(content.enableReflections !== false);

  // Journal copy states
  const [journalPageTitle, setJournalPageTitle] = useState(content.journalPageTitle || 'The Journal');
  const [journalPageSubtitle, setJournalPageSubtitle] = useState(
    content.journalPageSubtitle || 'Studio dispatches on physical presence, intentional design, and quiet recognition.'
  );

  // Reflections copy states
  const [connectionPromptTitle, setConnectionPromptTitle] = useState(content.connectionPromptTitle || 'The Connection Archive');
  const [connectionPromptSubtitle, setConnectionPromptSubtitle] = useState(
    content.connectionPromptSubtitle || 'Anonymous reflections on distance, human connection, and presence.'
  );
  const [connectionSubmitPromptTitle, setConnectionSubmitPromptTitle] = useState(
    content.connectionSubmitPromptTitle || 'Submit an Anonymous Reflection'
  );
  const [connectionSubmitPromptGuide, setConnectionSubmitPromptGuide] = useState(
    content.connectionSubmitPromptGuide || 'Reflections are moderated by studio stewards before publication in the Connection Archive.'
  );
  const [showHomeHumanArchiveCta, setShowHomeHumanArchiveCta] = useState(
    content.showHomeHumanArchiveCta === true
  );

  const handleToggleJournal = (enabled: boolean) => {
    setEnableJournal(enabled);
    updateContent({ enableJournal: enabled });
    if (showToast) {
      showToast(enabled ? 'Journal enabled across storefront and account menus' : 'Journal hidden from storefront and account menus');
    }
  };

  const handleToggleReflections = (enabled: boolean) => {
    setEnableReflections(enabled);
    updateContent({ enableReflections: enabled });
    if (showToast) {
      showToast(enabled ? 'Reflections enabled across storefront and account menus' : 'Reflections hidden from storefront and account menus');
    }
  };

  const handleSaveJournalHeaders = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      journalPageTitle: journalPageTitle.trim(),
      journalPageSubtitle: journalPageSubtitle.trim(),
    });
    if (showToast) {
      showToast('Journal titles & header copy updated live!');
    }
  };

  const handleSaveReflectionHeaders = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      connectionPromptTitle: connectionPromptTitle.trim(),
      connectionPromptSubtitle: connectionPromptSubtitle.trim(),
      connectionSubmitPromptTitle: connectionSubmitPromptTitle.trim(),
      connectionSubmitPromptGuide: connectionSubmitPromptGuide.trim(),
      showHomeHumanArchiveCta,
    });
    if (showToast) {
      showToast('Reflection prompt headers and home section status updated live!');
    }
  };

  const pendingReflectionCount = responses.filter((r) => r.status === 'Pending').length;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Unified Tab Switcher */}
      <div className="bg-white border border-neutral-200 p-2 shadow-xs flex items-center justify-between">
        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={() => setActiveTab('journal')}
            className={`flex items-center space-x-2 px-4 py-2 text-xs font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
              activeTab === 'journal'
                ? 'bg-black text-white shadow-xs'
                : 'text-neutral-600 hover:text-black hover:bg-neutral-100'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Journal Control & Dispatches</span>
            <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${enableJournal ? 'bg-emerald-500/20 text-emerald-300' : 'bg-neutral-700 text-neutral-300'}`}>
              {enableJournal ? 'ON' : 'OFF'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reflections')}
            className={`flex items-center space-x-2 px-4 py-2 text-xs font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
              activeTab === 'reflections'
                ? 'bg-black text-white shadow-xs'
                : 'text-neutral-600 hover:text-black hover:bg-neutral-100'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Reflections & Connection Archive</span>
            {pendingReflectionCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-amber-400 text-black font-semibold">
                {pendingReflectionCount}
              </span>
            )}
            <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${enableReflections ? 'bg-emerald-500/20 text-emerald-300' : 'bg-neutral-700 text-neutral-300'}`}>
              {enableReflections ? 'ON' : 'OFF'}
            </span>
          </button>
        </div>

        <div className="text-[11px] font-mono text-neutral-500 pr-3 hidden sm:block">
          Content & Editorial — Journal & Reflections Hub
        </div>
      </div>

      {/* ========================================================
          TAB 1: JOURNAL CONTROL
          ======================================================== */}
      {activeTab === 'journal' && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Master Toggle Card */}
          <div className={`p-5 border transition-all ${enableJournal ? 'bg-white border-neutral-300 shadow-xs' : 'bg-neutral-100/80 border-neutral-300'}`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center space-x-2.5">
                  <BookOpen className="w-5 h-5 text-amber-600" />
                  <h3 className="font-serif text-lg font-bold text-neutral-900">
                    Journal & Editorial Dispatches System Control
                  </h3>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-medium ${
                    enableJournal ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-neutral-200 text-neutral-700'
                  }`}>
                    {enableJournal ? 'Active in Storefront & Accounts' : 'Turned Off (Hidden from Storefront & User Accounts)'}
                  </span>
                </div>
                <p className="text-xs text-neutral-600 leading-relaxed font-sans max-w-2xl">
                  Enable or disable the Journal across the entire platform. When turned off, the Journal is cleanly hidden from storefront top navigation, mobile drawers, footer sections, and user account menus. All existing dispatches, essays, and drafts remain safely preserved.
                </p>
              </div>

              <div className="flex items-center space-x-4 shrink-0">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableJournal}
                    onChange={(e) => handleToggleJournal(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-neutral-100 flex flex-wrap items-center justify-between text-xs font-mono text-neutral-500 gap-2">
              <span>Direct Public Route: <code className="text-neutral-900 font-bold">/updates</code></span>
              {onNavigateToView && (
                <button
                  type="button"
                  onClick={() => onNavigateToView('updates')}
                  className="text-black hover:underline cursor-pointer inline-flex items-center gap-1 font-sans"
                >
                  <span>Preview Storefront Journal</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Journal Headers Form */}
          <form onSubmit={handleSaveJournalHeaders} className="space-y-4 bg-white p-5 border border-neutral-200 shadow-xs">
            <div className="border-b border-neutral-100 pb-2 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-base font-bold text-neutral-900">Journal Page Headers & Banner Copy</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  The primary title and descriptive subtitle displayed at the top of the Journal archive.
                </p>
              </div>
              <button
                type="submit"
                disabled={!canEditContent}
                className="py-1.5 px-3 bg-black text-white text-xs font-mono uppercase tracking-wider hover:bg-neutral-800 cursor-pointer disabled:opacity-40"
              >
                Save Headers
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Journal Page Title</label>
                <input
                  type="text"
                  value={journalPageTitle}
                  onChange={(e) => setJournalPageTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900 focus:border-black focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Journal Subtitle Description</label>
                <textarea
                  rows={2}
                  value={journalPageSubtitle}
                  onChange={(e) => setJournalPageSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900 leading-relaxed focus:border-black focus:outline-hidden"
                />
              </div>
            </div>
          </form>

          {/* Full Dispatches & Essays CMS */}
          <div className="bg-white p-5 border border-neutral-200 shadow-xs">
            <BlogPostsCMS />
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 2: REFLECTIONS & CONNECTION ARCHIVE
          ======================================================== */}
      {activeTab === 'reflections' && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Master Toggle Card */}
          <div className={`p-5 border transition-all ${enableReflections ? 'bg-white border-neutral-300 shadow-xs' : 'bg-neutral-100/80 border-neutral-300'}`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center space-x-2.5">
                  <MessageSquare className="w-5 h-5 text-amber-600" />
                  <h3 className="font-serif text-lg font-bold text-neutral-900">
                    Reflection System & Connection Archive Control
                  </h3>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-medium ${
                    enableReflections ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-neutral-200 text-neutral-700'
                  }`}>
                    {enableReflections ? 'Active in Storefront & Accounts' : 'Turned Off (Hidden from Storefront & User Accounts)'}
                  </span>
                </div>
                <p className="text-xs text-neutral-600 leading-relaxed font-sans max-w-2xl">
                  Enable or disable the Reflections system across the entire platform. When turned off, the Connection Archive, submission prompts, and "My Reflections" tab in user account menus are hidden, while all submitted reflections are safely preserved.
                </p>
              </div>

              <div className="flex items-center space-x-4 shrink-0">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableReflections}
                    onChange={(e) => handleToggleReflections(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-neutral-100 flex flex-wrap items-center justify-between text-xs font-mono text-neutral-500 gap-2">
              <span>Direct Public Route: <code className="text-neutral-900 font-bold">/connection</code></span>
              {onNavigateToView && (
                <button
                  type="button"
                  onClick={() => onNavigateToView('connection')}
                  className="text-black hover:underline cursor-pointer inline-flex items-center gap-1 font-sans"
                >
                  <span>Preview Connection Archive</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Reflections Copy & Homepage Section Controls */}
          <form onSubmit={handleSaveReflectionHeaders} className="space-y-4 bg-white p-5 border border-neutral-200 shadow-xs">
            <div className="border-b border-neutral-100 pb-2 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-base font-bold text-neutral-900">Archive Prompts & Homepage Section Control</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  Configure submission copy and hide/show the "Co-Creating The Human Archive" section on the homepage without deleting.
                </p>
              </div>
              <button
                type="submit"
                disabled={!canEditContent}
                className="py-1.5 px-3 bg-black text-white text-xs font-mono uppercase tracking-wider hover:bg-neutral-800 cursor-pointer disabled:opacity-40"
              >
                Save Settings
              </button>
            </div>

            <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-xs flex items-center justify-between">
              <div>
                <span className="text-xs uppercase font-mono font-bold text-neutral-900 block">
                  Homepage Section: "Co-Creating The Human Archive"
                </span>
                <p className="text-xs text-neutral-500 font-sans mt-0.5">
                  "Have you experienced a moment of recognition while wearing our garments?" — Toggle to hide or show on homepage.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0 ml-4">
                <input
                  type="checkbox"
                  checked={showHomeHumanArchiveCta}
                  onChange={(e) => setShowHomeHumanArchiveCta(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-10 h-5 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Archive Header Title</label>
                <input
                  type="text"
                  value={connectionPromptTitle}
                  onChange={(e) => setConnectionPromptTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Prompt Subtitle</label>
                <input
                  type="text"
                  value={connectionPromptSubtitle}
                  onChange={(e) => setConnectionPromptSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Submit Box Title</label>
                <input
                  type="text"
                  value={connectionSubmitPromptTitle}
                  onChange={(e) => setConnectionSubmitPromptTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Submit Guidelines</label>
                <input
                  type="text"
                  value={connectionSubmitPromptGuide}
                  onChange={(e) => setConnectionSubmitPromptGuide(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
              </div>
            </div>
          </form>

          {/* Reflections Moderation Table & Queue */}
          <div className="bg-white p-5 border border-neutral-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <div>
                <h3 className="font-serif text-lg font-bold text-neutral-900">Submitted Community Reflections</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  Review, approve, or reject field reflections. Approved reflections appear in the Connection Archive and customer quotes.
                </p>
              </div>
              <Badge variant="neutral" size="sm">
                {responses.length} Total Submissions
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {responses.map((ref) => (
                <div
                  key={ref.id}
                  className={`border p-5 space-y-3 shadow-xs transition-colors ${
                    ref.status === 'Approved'
                      ? 'border-emerald-200 bg-emerald-50/10'
                      : ref.status === 'Rejected'
                      ? 'border-red-200 opacity-60 bg-neutral-50'
                      : 'border-amber-300 bg-amber-50/30'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-500">
                      {ref.productName || 'General Reflection'}
                    </span>
                    <Badge
                      variant={
                        ref.status === 'Approved'
                          ? 'success'
                          : ref.status === 'Rejected'
                          ? 'error'
                          : 'warning'
                      }
                      size="sm"
                    >
                      {ref.status}
                    </Badge>
                  </div>

                  <p className="font-serif italic text-sm text-neutral-900 leading-relaxed">
                    "{ref.response}"
                  </p>

                  <div className="pt-2 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500 font-mono">
                    <span>
                      {ref.authorName} · {ref.authorLocation}
                    </span>
                    <span className="text-[10px]">{new Date(ref.createdAt).toLocaleDateString()}</span>
                  </div>

                  <div className="pt-2 border-t border-neutral-100 flex items-center justify-between text-xs">
                    <div className="space-x-2">
                      <button
                        disabled={!canModerateCommunity}
                        onClick={() => {
                          if (!canModerateCommunity) return;
                          updateStatus(ref.id, 'Approved');
                          if (showToast) showToast('Reflection approved for storefront display');
                        }}
                        className="px-2.5 py-1 text-[11px] font-mono rounded-xs bg-emerald-100 text-emerald-800 hover:bg-emerald-200 cursor-pointer disabled:opacity-40"
                      >
                        Approve
                      </button>
                      <button
                        disabled={!canModerateCommunity}
                        onClick={() => {
                          if (!canModerateCommunity) return;
                          updateStatus(ref.id, 'Rejected');
                          if (showToast) showToast('Reflection hidden from public view');
                        }}
                        className="px-2.5 py-1 text-[11px] font-mono rounded-xs bg-red-100 text-red-800 hover:bg-red-200 cursor-pointer disabled:opacity-40"
                      >
                        Reject
                      </button>
                    </div>

                    {openConfirmDelete && (
                      <button
                        disabled={!canModerateCommunity}
                        onClick={() => {
                          if (!canModerateCommunity) return;
                          openConfirmDelete({
                            title: 'Delete Reflection Submission',
                            itemName: `Reflection by ${ref.authorName}: "${ref.response.slice(0, 36)}..."`,
                            itemType: 'reflection',
                            warningMessage: 'This submission will be permanently removed from the community archive database.',
                            onConfirm: () => {
                              deleteResponse(ref.id);
                              if (showToast) showToast('Reflection permanently deleted.');
                            },
                          });
                        }}
                        className="p-1 rounded-xs text-neutral-400 hover:text-red-600 hover:bg-red-50 cursor-pointer disabled:opacity-40"
                        title="Permanently Delete Reflection"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {responses.length === 0 && (
              <div className="text-center py-10 bg-neutral-50 border border-dashed border-neutral-300 text-neutral-500 text-xs font-mono">
                No reflection submissions in the archive yet.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
