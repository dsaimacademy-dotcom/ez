import React, { useState } from 'react';
import { DesignDraft, DesignVersion, Size } from '../../types';
import { useProducts } from '../../context/ProductContext';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { ConfirmDeleteModal } from '../modals/ConfirmDeleteModal';
import {
  ShoppingBag,
  Layers,
  ArrowRight,
  Plus,
  Trash2,
  CheckCircle2,
  Image as ImageIcon,
  Palette,
  Tag,
  ExternalLink,
  ChevronRight,
  RotateCcw
} from 'lucide-react';

interface DesignFactoryCMSProps {
  onPushToProduct: (design: DesignDraft, versionNumber: number) => void;
  showToast: (msg: string) => void;
}

const ALL_SIZES: Size[] = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];

export const DesignFactoryCMS: React.FC<DesignFactoryCMSProps> = ({
  onPushToProduct,
  showToast,
}) => {
  const { designs, wearTypes, colors, addDesign, updateDesign, deleteDesign } = useProducts();

  const [selectedDesignId, setSelectedDesignId] = useState<string>(designs[0]?.id || '');
  const [isCreatingDesign, setIsCreatingDesign] = useState(false);
  const [isAddingVersion, setIsAddingVersion] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  // New Design Form State
  const [newDesignName, setNewDesignName] = useState('');
  const [newDesignThesis, setNewDesignThesis] = useState('');
  const [newDesignConcept, setNewDesignConcept] = useState('');
  const [newDesignArtwork, setNewDesignArtwork] = useState('https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=85');
  const [newDesignPlacement, setNewDesignPlacement] = useState('Chest 12x14 DTF soft-hand');

  // New Version Form State
  const [newVersionTitle, setNewVersionTitle] = useState('');
  const [newVersionArtwork, setNewVersionArtwork] = useState('');
  const [newVersionMockup, setNewVersionMockup] = useState('');
  const [newVersionPlacement, setNewVersionPlacement] = useState('');
  const [newVersionNotes, setNewVersionNotes] = useState('');
  const [newVersionWearTypes, setNewVersionWearTypes] = useState<string[]>(['6.5oz Heavyweight Boxy Tee']);
  const [newVersionColors, setNewVersionColors] = useState<string[]>(['Obsidian Black', 'Raw Ecru']);

  const activeDesign = designs.find((d) => d.id === selectedDesignId) || designs[0];

  const handleCreateDesignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDesignName.trim()) return;

    const newId = `dsn-${Date.now().toString(36)}`;
    const initialVersion: DesignVersion = {
      id: `ver-${newId}-1`,
      designId: newId,
      versionNumber: 1,
      title: 'Initial Creative Master',
      artworkUrl: newDesignArtwork.trim() || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=85',
      conceptNotes: newDesignConcept,
      suggestedWearTypes: ['6.5oz Heavyweight Boxy Tee'],
      suggestedColors: ['Obsidian Black', 'Raw Ecru'],
      suggestedSizes: ['S', 'M', 'L', 'XL'],
      placement: newDesignPlacement,
      status: 'approved',
      createdAt: new Date().toISOString(),
    };

    const draft: DesignDraft = {
      id: newId,
      name: newDesignName.trim(),
      thesis: newDesignThesis.trim() || 'An unhurried exploration of space and difference.',
      concept: newDesignConcept.trim(),
      status: 'approved',
      activeVersionNumber: 1,
      versions: [initialVersion],
      tags: ['Creative Lab', 'New Concept'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    addDesign(draft);
    setSelectedDesignId(newId);
    setIsCreatingDesign(false);
    setNewDesignName('');
    setNewDesignThesis('');
    setNewDesignConcept('');
    showToast(`Created creative design draft "${draft.name}".`);
  };

  const handleAddVersionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDesign) return;

    const nextVerNum = (activeDesign.versions?.length || 0) + 1;
    const newVersion: DesignVersion = {
      id: `ver-${activeDesign.id}-${nextVerNum}`,
      designId: activeDesign.id,
      versionNumber: nextVerNum,
      title: newVersionTitle.trim() || `Iteration ${nextVerNum}`,
      artworkUrl: newVersionArtwork.trim() || activeDesign.versions[0]?.artworkUrl || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=85',
      mockupUrl: newVersionMockup.trim() || undefined,
      conceptNotes: newVersionNotes.trim(),
      suggestedWearTypes: newVersionWearTypes,
      suggestedColors: newVersionColors,
      suggestedSizes: ['S', 'M', 'L', 'XL'],
      placement: newVersionPlacement.trim() || 'Center chest print',
      status: 'testing',
      createdAt: new Date().toISOString(),
    };

    const updatedVersions = [...(activeDesign.versions || []), newVersion];
    updateDesign(activeDesign.id, {
      versions: updatedVersions,
      activeVersionNumber: nextVerNum,
    });

    setIsAddingVersion(false);
    setNewVersionTitle('');
    setNewVersionArtwork('');
    setNewVersionMockup('');
    setNewVersionNotes('');
    showToast(`Added Version ${nextVerNum} to "${activeDesign.name}".`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white border border-neutral-200 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 text-[10px] font-mono bg-purple-100 text-purple-900 border border-purple-300 font-bold uppercase">
              Creative Lab
            </span>
            <h3 className="font-serif text-xl font-bold text-neutral-900">
              Design Factory: Creative Concepts & Iterations
            </h3>
          </div>
          <p className="text-xs text-neutral-500 font-sans mt-0.5">
            Decoupled creative space: develop artwork, test placement, and push approved concepts into the Product Studio.
          </p>
        </div>

        <Button
          type="button"
          variant="primary"
          size="sm"
          onClick={() => {
            setIsCreatingDesign(true);
            setIsAddingVersion(false);
          }}
          className="text-xs font-mono bg-black text-white hover:bg-neutral-800 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 mr-1.5" />
          <span>+ New Design Concept</span>
        </Button>
      </div>

      {/* Main Dual-Column Layout: Sidebar of Designs + Selected Design Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Designs List */}
        <div className="lg:col-span-4 bg-white border border-neutral-200 p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-neutral-500 font-bold">
              Design Concepts ({designs.length})
            </span>
          </div>

          <div className="space-y-2">
            {designs.map((d) => {
              const isSelected = d.id === (activeDesign?.id || '');
              return (
                <div
                  key={d.id}
                  onClick={() => {
                    setSelectedDesignId(d.id);
                    setIsCreatingDesign(false);
                    setIsAddingVersion(false);
                  }}
                  className={`p-3.5 border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-neutral-900 text-white border-black shadow-xs'
                      : 'bg-neutral-50 text-neutral-800 border-neutral-200 hover:bg-neutral-100'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-serif text-sm font-bold truncate">{d.name}</div>
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.5 border ${
                        isSelected
                          ? 'bg-neutral-800 text-neutral-200 border-neutral-700'
                          : d.status === 'approved'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : 'bg-neutral-100 text-neutral-600 border-neutral-300'
                      }`}
                    >
                      {d.status.toUpperCase()}
                    </span>
                  </div>

                  <p className={`text-xs font-serif italic mt-1 line-clamp-1 ${isSelected ? 'text-neutral-300' : 'text-neutral-600'}`}>
                    "{d.thesis}"
                  </p>

                  <div className="flex items-center justify-between text-[10px] font-mono mt-2 pt-2 border-t border-neutral-200/50">
                    <span className={isSelected ? 'text-neutral-400' : 'text-neutral-500'}>
                      {d.versions?.length || 1} versions
                    </span>
                    <span className={isSelected ? 'text-neutral-300' : 'text-neutral-600'}>
                      Active: v{d.activeVersionNumber}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Active Design Details & Versions */}
        <div className="lg:col-span-8 space-y-6">
          {/* Create Design Form */}
          {isCreatingDesign ? (
            <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
                <h4 className="font-serif text-lg font-bold text-neutral-900">Create New Design Concept</h4>
                <button
                  type="button"
                  onClick={() => setIsCreatingDesign(false)}
                  className="text-xs font-mono text-neutral-500 hover:text-black cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleCreateDesignSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Concept Name</label>
                  <input
                    type="text"
                    required
                    value={newDesignName}
                    onChange={(e) => setNewDesignName(e.target.value)}
                    placeholder="e.g. The Quiet Witness"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Core Thesis Statement</label>
                  <textarea
                    rows={2}
                    required
                    value={newDesignThesis}
                    onChange={(e) => setNewDesignThesis(e.target.value)}
                    placeholder="e.g. Some truths cannot be shouted; they must be worn into the room."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-serif italic"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Creative Background & Notes</label>
                  <textarea
                    rows={2}
                    value={newDesignConcept}
                    onChange={(e) => setNewDesignConcept(e.target.value)}
                    placeholder="Context, inspiration, and intentionality..."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Artwork URL</label>
                    <input
                      type="text"
                      value={newDesignArtwork}
                      onChange={(e) => setNewDesignArtwork(e.target.value)}
                      placeholder="https://..."
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Default Print Placement</label>
                    <input
                      type="text"
                      value={newDesignPlacement}
                      onChange={(e) => setNewDesignPlacement(e.target.value)}
                      placeholder="e.g. Left chest 3.5in + back spine"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-neutral-200">
                  <Button type="button" variant="outline" size="sm" onClick={() => setIsCreatingDesign(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" variant="primary" size="sm">
                    Save Creative Draft
                  </Button>
                </div>
              </form>
            </div>
          ) : activeDesign ? (
            <div className="space-y-6">
              {/* Concept Overview Card */}
              <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-4">
                  <div>
                    <span className="text-[10px] font-mono uppercase text-neutral-400">Concept #{activeDesign.id}</span>
                    <h3 className="font-serif text-2xl font-bold text-neutral-900">{activeDesign.name}</h3>
                    <p className="font-serif italic text-neutral-700 text-sm mt-1">"{activeDesign.thesis}"</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <select
                      value={activeDesign.status}
                      onChange={(e) => updateDesign(activeDesign.id, { status: e.target.value as any })}
                      className="bg-neutral-50 border border-neutral-300 p-1.5 text-xs font-mono font-bold"
                    >
                      <option value="draft">DRAFT</option>
                      <option value="in_testing">IN TESTING</option>
                      <option value="approved">APPROVED</option>
                      <option value="pushed_to_product">PUSHED TO PRODUCT</option>
                    </select>

                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setIsAddingVersion(true)}
                      className="text-xs font-mono"
                    >
                      <Plus className="w-3.5 h-3.5 mr-1" />
                      <span>+ Add Version</span>
                    </Button>

                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setDeleteConfirmOpen(true)}
                      className="text-xs font-mono text-red-600 border-red-200 hover:bg-red-50 hover:border-red-400"
                      title="Permanently Delete Design Concept"
                    >
                      <Trash2 className="w-3.5 h-3.5 mr-1" />
                      <span>Delete</span>
                    </Button>
                  </div>
                </div>

                <p className="text-xs text-neutral-600 font-sans leading-relaxed">
                  {activeDesign.concept || 'Exploration of human distance and presence.'}
                </p>
              </div>

              {/* Add Version Form if open */}
              {isAddingVersion && (
                <div className="bg-purple-50 border border-purple-200 p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-purple-200 pb-2">
                    <h5 className="font-serif text-sm font-bold text-purple-950">
                      Add New Iteration / Version to "{activeDesign.name}"
                    </h5>
                    <button
                      type="button"
                      onClick={() => setIsAddingVersion(false)}
                      className="text-xs font-mono text-purple-700 hover:text-black cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>

                  <form onSubmit={handleAddVersionSubmit} className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] font-mono uppercase text-purple-900 mb-1">Version Title</label>
                        <input
                          type="text"
                          value={newVersionTitle}
                          onChange={(e) => setNewVersionTitle(e.target.value)}
                          placeholder="e.g. Tone-on-tone discharge proof"
                          className="w-full bg-white border border-purple-300 p-1.5 text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono uppercase text-purple-900 mb-1">Print Placement</label>
                        <input
                          type="text"
                          value={newVersionPlacement}
                          onChange={(e) => setNewVersionPlacement(e.target.value)}
                          placeholder="e.g. Full back 14x16 DTF"
                          className="w-full bg-white border border-purple-300 p-1.5 text-xs"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-mono uppercase text-purple-900 mb-1">Artwork URL</label>
                      <input
                        type="text"
                        value={newVersionArtwork}
                        onChange={(e) => setNewVersionArtwork(e.target.value)}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full bg-white border border-purple-300 p-1.5 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-mono uppercase text-purple-900 mb-1">Wear Testing Notes</label>
                      <textarea
                        rows={2}
                        value={newVersionNotes}
                        onChange={(e) => setNewVersionNotes(e.target.value)}
                        placeholder="Notes on garment drape, ink feel, wash testing..."
                        className="w-full bg-white border border-purple-300 p-1.5 text-xs"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <Button type="button" variant="outline" size="sm" onClick={() => setIsAddingVersion(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" variant="primary" size="sm">
                        Create Version
                      </Button>
                    </div>
                  </form>
                </div>
              )}

              {/* Version History List */}
              <div className="space-y-4">
                <h4 className="font-serif text-base font-bold text-neutral-900">
                  Version History & Wear Tests ({activeDesign.versions?.length || 0})
                </h4>

                <div className="space-y-4">
                  {(activeDesign.versions || []).map((ver) => (
                    <div
                      key={ver.id}
                      className="bg-white border border-neutral-200 p-5 space-y-4 shadow-xs"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-100 pb-3">
                        <div className="flex items-center space-x-2.5">
                          <span className="w-7 h-7 rounded-full bg-black text-white font-mono text-xs flex items-center justify-center font-bold">
                            v{ver.versionNumber}
                          </span>
                          <div>
                            <div className="font-serif text-sm font-bold text-neutral-900">{ver.title || `Version ${ver.versionNumber}`}</div>
                            <span className="text-[10px] font-mono text-neutral-400">Created: {new Date(ver.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>

                        {/* PUSH TO PRODUCT BUTTON */}
                        <div className="flex items-center gap-2">
                          <Button
                            type="button"
                            variant="primary"
                            size="sm"
                            onClick={() => onPushToProduct(activeDesign, ver.versionNumber)}
                            className="bg-purple-900 hover:bg-purple-950 text-white text-xs font-mono flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <ShoppingBag className="w-3.5 h-3.5 text-purple-300" />
                            <span>[ PUSH TO PRODUCT ]</span>
                          </Button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
                        {/* Artwork Preview */}
                        <div className="sm:col-span-4 aspect-4/3 bg-neutral-100 border border-neutral-200 overflow-hidden relative">
                          <img src={ver.artworkUrl} alt={ver.title} className="w-full h-full object-cover" />
                        </div>

                        {/* Specs & Testing Details */}
                        <div className="sm:col-span-8 space-y-2 text-xs">
                          {ver.placement && (
                            <div>
                              <span className="text-neutral-500 font-mono text-[10px] uppercase block">Print Placement:</span>
                              <span className="font-mono text-neutral-800">{ver.placement}</span>
                            </div>
                          )}

                          {ver.conceptNotes && (
                            <div>
                              <span className="text-neutral-500 font-mono text-[10px] uppercase block">Design Notes:</span>
                              <span className="font-sans text-neutral-700">{ver.conceptNotes}</span>
                            </div>
                          )}

                          <div className="pt-2 flex flex-wrap items-center gap-4">
                            <div>
                              <span className="text-neutral-500 font-mono text-[10px] uppercase block mb-1">Tested Wear Types:</span>
                              <div className="flex flex-wrap gap-1">
                                {(ver.suggestedWearTypes || []).map((wt) => (
                                  <span key={wt} className="px-2 py-0.5 bg-neutral-100 border border-neutral-200 font-mono text-[10px]">
                                    {wt}
                                  </span>
                                ))}
                              </div>
                            </div>

                            <div>
                              <span className="text-neutral-500 font-mono text-[10px] uppercase block mb-1">Tested Colors:</span>
                              <div className="flex flex-wrap gap-1">
                                {(ver.suggestedColors || []).map((col) => (
                                  <span key={col} className="px-2 py-0.5 bg-neutral-100 border border-neutral-200 font-mono text-[10px]">
                                    {col}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-neutral-200 p-12 text-center text-neutral-500 font-sans text-sm">
              Select or create a design concept from the list.
            </div>
          )}
        </div>
      </div>

      {/* Confirm Delete Design Concept Modal */}
      {activeDesign && (
        <ConfirmDeleteModal
          isOpen={deleteConfirmOpen}
          title="Delete Design Concept"
          itemName={`${activeDesign.name} (Draft #${activeDesign.id})`}
          itemType="creative concept"
          warningMessage="This will permanently delete this design concept, all its iterations, artwork links, and testing notes. This action cannot be undone."
          expectedWord="DELETE"
          onConfirm={() => {
            deleteDesign(activeDesign.id);
            showToast(`Design concept "${activeDesign.name}" permanently deleted.`);
            setDeleteConfirmOpen(false);
          }}
          onClose={() => setDeleteConfirmOpen(false)}
        />
      )}
    </div>
  );
};
