import React, { useState } from 'react';
import {
  Building2,
  Globe,
  MapPin,
  Phone,
  Share2,
  DollarSign,
  CheckCircle2,
  Image as ImageIcon,
  ExternalLink,
  Instagram,
  Twitter,
  Youtube,
  Music,
  Bookmark,
  Share,
  Facebook,
  Linkedin,
  CreditCard,
  Lock,
  Zap,
  ShieldCheck,
  Smartphone,
  QrCode,
  Eye,
  EyeOff,
  Activity,
  AlertCircle,
  RefreshCw,
  Key,
  Check,
  Menu,
  Type,
  Sliders
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { Button } from '../ui/Button';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';
import { Logo } from '../brand/Logo';
import { PaymentStatusBadge, getPaymentConnectionStatus } from './PaymentStatusBadge';
import { safeFetchJson } from '../../lib/api';
import { autoAdjustFaviconForPWA } from '../../lib/pwaIconGenerator';

export type BrandSubTab = 'identity' | 'seo' | 'studio' | 'typography' | 'contacts' | 'socials' | 'fiscal';

interface ApiTestResult {
  provider: string;
  status: 'success' | 'error' | 'testing';
  message: string;
  latencyMs?: number;
  details?: string[];
}

export const BrandBusinessSetup: React.FC = () => {
  const { content, updateContent } = useContent();
  const [activeSubTab, setActiveSubTab] = useState<BrandSubTab>('identity');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [pwaSyncStatus, setPwaSyncStatus] = useState<'idle' | 'syncing' | 'success' | 'error'>('idle');

  // Identity States
  const [brandName, setBrandName] = useState(content.brandName || 'Ezistential Connection');
  const [brandShortName, setBrandShortName] = useState(content.brandShortName || 'Ezistential');
  const [brandTagline, setBrandTagline] = useState(content.brandTagline || 'The Space Between People');
  const [brandLogoUrl, setBrandLogoUrl] = useState(content.brandLogoUrl || '/ez-logo.svg');
  const [brandLogoDarkUrl, setBrandLogoDarkUrl] = useState(content.brandLogoDarkUrl || '/ez-logo-white.svg');
  const [faviconUrl, setFaviconUrl] = useState(
    (content.faviconUrl && content.faviconUrl !== '/favicon.ico') ? content.faviconUrl : '/ez-favicon.svg'
  );

  const handleFaviconChange = async (newUrl: string) => {
    setFaviconUrl(newUrl);
    if (newUrl && newUrl.trim() && newUrl !== '/favicon.ico') {
      setPwaSyncStatus('syncing');
      try {
        const ok = await autoAdjustFaviconForPWA(newUrl);
        setPwaSyncStatus(ok ? 'success' : 'error');
      } catch {
        setPwaSyncStatus('error');
      }
    }
  };

  // SEO & Online
  const [pageTitleTemplate, setPageTitleTemplate] = useState(content.pageTitleTemplate || 'Ezistential Connection — Space Between People');
  const [metaDescription, setMetaDescription] = useState(content.metaDescription || '');

  // Studio & Entity
  const [legalBusinessName, setLegalBusinessName] = useState(content.legalBusinessName || 'Ezistential Connection LLC');
  const [businessAddressStreet, setBusinessAddressStreet] = useState(content.businessAddressStreet || '1842 N Damen Ave, Suite 3F');
  const [businessAddressCity, setBusinessAddressCity] = useState(content.businessAddressCity || 'Chicago');
  const [businessAddressState, setBusinessAddressState] = useState(content.businessAddressState || 'IL');
  const [businessAddressZip, setBusinessAddressZip] = useState(content.businessAddressZip || '60647');
  const [businessAddressCountry, setBusinessAddressCountry] = useState(content.businessAddressCountry || 'United States');

  // Contacts
  const [businessPhone, setBusinessPhone] = useState(content.businessPhone || '+1 (312) 555-0192');
  const [supportEmail, setSupportEmail] = useState(content.supportEmail || 'care@ezistential.com');
  const [ordersEmail, setOrdersEmail] = useState(content.ordersEmail || 'orders@ezistential.com');
  const [pressEmail, setPressEmail] = useState(content.pressEmail || 'press@ezistential.com');
  const [businessHours, setBusinessHours] = useState(content.businessHours || 'Monday – Friday: 9:00 AM – 6:00 PM CST');

  // Socials
  const [instagramHandle, setInstagramHandle] = useState(content.instagramHandle || '@ezistential');
  const [instagramUrl, setInstagramUrl] = useState(content.instagramUrl || 'https://instagram.com/ezistential');
  const [twitterHandle, setTwitterHandle] = useState(content.twitterHandle || '@ezistential');
  const [twitterUrl, setTwitterUrl] = useState(content.twitterUrl || 'https://x.com/ezistential');
  const [tiktokHandle, setTiktokHandle] = useState(content.tiktokHandle || '');
  const [tiktokUrl, setTiktokUrl] = useState(content.tiktokUrl || '');
  const [youtubeUrl, setYoutubeUrl] = useState(content.youtubeUrl || '');
  const [spotifyUrl, setSpotifyUrl] = useState(content.spotifyUrl || 'https://open.spotify.com/user/ezistential');
  const [substackUrl, setSubstackUrl] = useState(content.substackUrl || 'https://ezistential.substack.com');
  const [pinterestUrl, setPinterestUrl] = useState(content.pinterestUrl || '');
  const [facebookUrl, setFacebookUrl] = useState(content.facebookUrl || '');
  const [linkedinUrl, setLinkedinUrl] = useState(content.linkedinUrl || '');
  const [discordUrl, setDiscordUrl] = useState(content.discordUrl || '');

  // Fiscal
  const [currencySymbol, setCurrencySymbol] = useState(content.currencySymbol || '$');
  const [currencyCode, setCurrencyCode] = useState(content.currencyCode || 'USD');
  const [salesTaxRatePercent, setSalesTaxRatePercent] = useState(content.salesTaxRatePercent || 6.5);

  // Typography & Font Sizing Controls
  const [bodyFontSize, setBodyFontSize] = useState<number>(content.bodyFontSize || 18);
  const [smallFontSize, setSmallFontSize] = useState<number>(content.smallFontSize || 14);
  const [h1FontSize, setH1FontSize] = useState<number>(content.h1FontSize || 56);
  const [h2FontSize, setH2FontSize] = useState<number>(content.h2FontSize || 36);
  const [h3FontSize, setH3FontSize] = useState<number>(content.h3FontSize || 22);
  const [subtitleFontSize, setSubtitleFontSize] = useState<number>(content.subtitleFontSize || 20);
  const [navFontSize, setNavFontSize] = useState<number>(content.navFontSize || 13);
  const [badgeFontSize, setBadgeFontSize] = useState<number>(content.badgeFontSize || 12);
  const [bodyLineHeight, setBodyLineHeight] = useState<number>(content.bodyLineHeight || 1.68);

  // Password Visibility Toggles
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const toggleSecret = (key: string) => {
    setShowSecrets((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleTypographyChange = (key: string, value: number) => {
    if (key === 'bodyFontSize') setBodyFontSize(value);
    if (key === 'smallFontSize') setSmallFontSize(value);
    if (key === 'h1FontSize') setH1FontSize(value);
    if (key === 'h2FontSize') setH2FontSize(value);
    if (key === 'h3FontSize') setH3FontSize(value);
    if (key === 'subtitleFontSize') setSubtitleFontSize(value);
    if (key === 'navFontSize') setNavFontSize(value);
    if (key === 'badgeFontSize') setBadgeFontSize(value);
    if (key === 'bodyLineHeight') setBodyLineHeight(value);

    // Apply live to context immediately for instant real-time site visual change
    updateContent({ [key]: value });
  };

  const applyPreset = (preset: 'balanced' | 'readable' | 'large' | 'compact') => {
    let updates = {
      bodyFontSize: 18,
      smallFontSize: 14,
      h1FontSize: 56,
      h2FontSize: 36,
      h3FontSize: 22,
      subtitleFontSize: 20,
      navFontSize: 13,
      badgeFontSize: 12,
      bodyLineHeight: 1.68,
    };
    if (preset === 'readable') {
      updates = {
        bodyFontSize: 19,
        smallFontSize: 15,
        h1FontSize: 62,
        h2FontSize: 38,
        h3FontSize: 24,
        subtitleFontSize: 22,
        navFontSize: 14,
        badgeFontSize: 13,
        bodyLineHeight: 1.7,
      };
    } else if (preset === 'large') {
      updates = {
        bodyFontSize: 21,
        smallFontSize: 16,
        h1FontSize: 68,
        h2FontSize: 44,
        h3FontSize: 26,
        subtitleFontSize: 24,
        navFontSize: 15,
        badgeFontSize: 14,
        bodyLineHeight: 1.75,
      };
    } else if (preset === 'compact') {
      updates = {
        bodyFontSize: 16,
        smallFontSize: 13,
        h1FontSize: 48,
        h2FontSize: 32,
        h3FontSize: 20,
        subtitleFontSize: 18,
        navFontSize: 12,
        badgeFontSize: 11,
        bodyLineHeight: 1.6,
      };
    }

    setBodyFontSize(updates.bodyFontSize);
    setSmallFontSize(updates.smallFontSize);
    setH1FontSize(updates.h1FontSize);
    setH2FontSize(updates.h2FontSize);
    setH3FontSize(updates.h3FontSize);
    setSubtitleFontSize(updates.subtitleFontSize);
    setNavFontSize(updates.navFontSize);
    setBadgeFontSize(updates.badgeFontSize);
    setBodyLineHeight(updates.bodyLineHeight);

    updateContent(updates);
    showToast(`Applied "${preset}" typography preset across site!`);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      bodyFontSize: Number(bodyFontSize) || 18,
      smallFontSize: Number(smallFontSize) || 14,
      h1FontSize: Number(h1FontSize) || 56,
      h2FontSize: Number(h2FontSize) || 36,
      h3FontSize: Number(h3FontSize) || 22,
      subtitleFontSize: Number(subtitleFontSize) || 20,
      navFontSize: Number(navFontSize) || 13,
      badgeFontSize: Number(badgeFontSize) || 12,
      bodyLineHeight: Number(bodyLineHeight) || 1.68,
      brandName: brandName.trim(),
      brandShortName: brandShortName.trim(),
      brandTagline: brandTagline.trim(),
      brandLogoUrl: brandLogoUrl.trim(),
      brandLogoDarkUrl: brandLogoDarkUrl.trim(),
      faviconUrl: faviconUrl.trim(),
      pageTitleTemplate: pageTitleTemplate.trim(),
      metaDescription: metaDescription.trim(),
      legalBusinessName: legalBusinessName.trim(),
      businessAddressStreet: businessAddressStreet.trim(),
      businessAddressCity: businessAddressCity.trim(),
      businessAddressState: businessAddressState.trim(),
      businessAddressZip: businessAddressZip.trim(),
      businessAddressCountry: businessAddressCountry.trim(),
      businessPhone: businessPhone.trim(),
      supportEmail: supportEmail.trim(),
      ordersEmail: ordersEmail.trim(),
      pressEmail: pressEmail.trim(),
      businessHours: businessHours.trim(),
      instagramHandle: instagramHandle.trim(),
      instagramUrl: instagramUrl.trim(),
      twitterHandle: twitterHandle.trim(),
      twitterUrl: twitterUrl.trim(),
      tiktokHandle: tiktokHandle.trim(),
      tiktokUrl: tiktokUrl.trim(),
      youtubeUrl: youtubeUrl.trim(),
      spotifyUrl: spotifyUrl.trim(),
      substackUrl: substackUrl.trim(),
      pinterestUrl: pinterestUrl.trim(),
      facebookUrl: facebookUrl.trim(),
      linkedinUrl: linkedinUrl.trim(),
      discordUrl: discordUrl.trim(),
      currencySymbol: currencySymbol.trim(),
      currencyCode: currencyCode.trim(),
      salesTaxRatePercent: Number(salesTaxRatePercent) || 0,
    });
    if (faviconUrl && faviconUrl.trim() && faviconUrl !== '/favicon.ico') {
      autoAdjustFaviconForPWA(faviconUrl.trim()).catch(() => {});
    }
    showToast('Brand & Business Profile saved successfully!');
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-neutral-200 gap-4">
        <div>
          <h2 className="font-serif text-2xl text-neutral-900">Brand & Business Setup</h2>
          <p className="text-xs text-neutral-500 mt-1">
            Configure identity, studio premises, customer touchpoints, social handles, and fiscal currency settings.
          </p>
        </div>
        <Button type="submit" variant="primary" size="md">
          Save All Changes
        </Button>
      </div>

      {/* Sub-Tabs Bar */}
      <div className="flex border-b border-neutral-200 overflow-x-auto gap-1">
        <button
          type="button"
          onClick={() => setActiveSubTab('identity')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'identity'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>1. Identity & Logos</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('seo')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'seo'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>2. Page Titles & SEO</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('studio')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'studio'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <MapPin className="w-3.5 h-3.5" />
          <span>3. Studio & Entity</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('typography')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'typography'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>4. Typography & Font Sizing</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('contacts')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'contacts'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Phone className="w-3.5 h-3.5" />
          <span>5. Contacts & Hours</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('socials')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'socials'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>6. Social Handles</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('fiscal')}
          className={`py-2.5 px-4 text-xs font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'fiscal'
              ? 'border-black text-black font-semibold'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>7. Currency & Tax</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
        {/* SUBTAB 1: IDENTITY */}
        {activeSubTab === 'identity' && (
          <div className="space-y-6 pt-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                  Public Brand Name *
                </label>
                <input
                  type="text"
                  required
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                  Short Brand Name (for mobile & badges)
                </label>
                <input
                  type="text"
                  value={brandShortName}
                  onChange={(e) => setBrandShortName(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                Brand Tagline
              </label>
              <input
                type="text"
                value={brandTagline}
                onChange={(e) => setBrandTagline(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
              />
            </div>

            <div className="border-t border-neutral-100 pt-6 space-y-6">
              <h3 className="font-serif text-lg text-neutral-900">Brand Visual Assets (Upload & Compress)</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <ImageUploadCompressor
                  label="Light Theme Logo (Dark Vector/PNG for White Background)"
                  value={brandLogoUrl}
                  onChange={setBrandLogoUrl}
                  maxWidth={600}
                  maxHeight={600}
                  quality={0.9}
                  helperText="Recommended: transparent SVG or PNG, ~300x80px"
                />

                <ImageUploadCompressor
                  label="Dark Theme Logo (White Vector/PNG for Dark Footer)"
                  value={brandLogoDarkUrl}
                  onChange={setBrandLogoDarkUrl}
                  maxWidth={600}
                  maxHeight={600}
                  quality={0.9}
                  previewBg="dark"
                  helperText="Recommended: transparent white SVG or PNG"
                />
              </div>

              <div className="max-w-md space-y-2">
                <ImageUploadCompressor
                  label="Browser Favicon & PWA App Icon (.ico, .png, .svg)"
                  value={faviconUrl}
                  onChange={handleFaviconChange}
                  maxWidth={1024}
                  maxHeight={1024}
                  quality={0.95}
                  helperText="Upload any SVG, PNG or ICO. The system automatically adjusts & resizes it into 192x192, 512x512, and maskable icons so the PWA install prompt won't fail."
                />
                {pwaSyncStatus === 'syncing' && (
                  <p className="text-[11px] font-mono text-amber-600 flex items-center gap-1.5 animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    Auto-adjusting icon dimensions (192x192 & 512x512) for PWA manifest...
                  </p>
                )}
                {pwaSyncStatus === 'success' && (
                  <p className="text-[11px] font-mono text-emerald-600 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    PWA install icon & manifest dimensions adjusted successfully (No install failures).
                  </p>
                )}
                {pwaSyncStatus === 'error' && (
                  <p className="text-[11px] font-mono text-red-500 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-red-500" />
                    Failed to auto-sync PWA manifest icons. Please verify image source.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}



        {/* SUBTAB 2: SEO */}
        {activeSubTab === 'seo' && (
          <div className="space-y-6 pt-2">
            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                Page Title Template *
              </label>
              <input
                type="text"
                required
                value={pageTitleTemplate}
                onChange={(e) => setPageTitleTemplate(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
              />
              <p className="text-[11px] text-neutral-500 mt-1">
                Updates document title on browser tabs and search engine snippets dynamically.
              </p>
            </div>

            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                Meta Description (Search Snippet)
              </label>
              <textarea
                rows={3}
                value={metaDescription}
                onChange={(e) => setMetaDescription(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
              />
            </div>
          </div>
        )}

        {/* SUBTAB 3: STUDIO & ENTITY */}
        {activeSubTab === 'studio' && (
          <div className="space-y-6 pt-2">
            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">
                Legal Entity Name (Invoices & Compliance) *
              </label>
              <input
                type="text"
                required
                value={legalBusinessName}
                onChange={(e) => setLegalBusinessName(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="sm:col-span-2">
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Street Address</label>
                <input
                  type="text"
                  value={businessAddressStreet}
                  onChange={(e) => setBusinessAddressStreet(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">City</label>
                <input
                  type="text"
                  value={businessAddressCity}
                  onChange={(e) => setBusinessAddressCity(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">State / Region</label>
                  <input
                    type="text"
                    value={businessAddressState}
                    onChange={(e) => setBusinessAddressState(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">ZIP Code</label>
                  <input
                    type="text"
                    value={businessAddressZip}
                    onChange={(e) => setBusinessAddressZip(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Country</label>
                <input
                  type="text"
                  value={businessAddressCountry}
                  onChange={(e) => setBusinessAddressCountry(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 4: TYPOGRAPHY & FONT SIZING */}
        {activeSubTab === 'typography' && (
          <div className="space-y-8 pt-2">
            {/* Header info & Presets bar */}
            <div className="bg-[#fcfcfb] border border-neutral-200 p-5 rounded-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 text-neutral-900 font-serif font-bold text-base">
                    <Type className="w-4 h-4 text-neutral-800 shrink-0" />
                    <span>Global Typography & Font Sizing Engine</span>
                  </div>
                  <p className="text-xs text-neutral-500 font-sans leading-relaxed">
                    Adjust font sizes site-wide across titles, section headings, subtitles, body paragraphs, and small captions. All changes update the storefront in real-time.
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => applyPreset('readable')}
                  className="shrink-0 text-xs font-mono"
                >
                  <Sliders className="w-3.5 h-3.5 mr-1.5" />
                  Recommended Scale
                </Button>
              </div>

              {/* 4 Quick Presets */}
              <div className="pt-2 border-t border-neutral-200">
                <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 font-bold block mb-2">
                  Quick One-Click Typography Presets:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => applyPreset('balanced')}
                    className="p-2.5 bg-white border border-neutral-300 hover:border-black text-left cursor-pointer transition-colors"
                  >
                    <span className="font-serif font-bold text-xs block text-neutral-900">Standard Editorial</span>
                    <span className="text-[10px] font-mono text-neutral-500 block mt-0.5">18px Body · 56px H1</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => applyPreset('readable')}
                    className="p-2.5 bg-neutral-900 text-white border border-neutral-900 text-left cursor-pointer transition-colors shadow-xs"
                  >
                    <span className="font-serif font-bold text-xs block text-white flex items-center justify-between">
                      <span>Generous & Readable</span>
                      <span className="text-[9px] font-mono uppercase bg-amber-400 text-black px-1.5 py-0.2 rounded-2xs font-semibold">★ Recommended</span>
                    </span>
                    <span className="text-[10px] font-mono text-neutral-300 block mt-0.5">19px Body · 22px Subtitle</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => applyPreset('large')}
                    className="p-2.5 bg-white border border-neutral-300 hover:border-black text-left cursor-pointer transition-colors"
                  >
                    <span className="font-serif font-bold text-xs block text-neutral-900">High Visibility / Large</span>
                    <span className="text-[10px] font-mono text-neutral-500 block mt-0.5">21px Body · 24px Subtitle</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => applyPreset('compact')}
                    className="p-2.5 bg-white border border-neutral-300 hover:border-black text-left cursor-pointer transition-colors"
                  >
                    <span className="font-serif font-bold text-xs block text-neutral-900">Compact Minimal</span>
                    <span className="text-[10px] font-mono text-neutral-500 block mt-0.5">16px Body · 48px H1</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Individual Fine-Tuned Typography Sliders */}
            <div className="space-y-6">
              <h3 className="font-serif text-lg font-bold text-neutral-900 border-b border-neutral-200 pb-2 flex items-center justify-between">
                <span>Fine-Tuned Element Font Controls</span>
                <span className="text-xs font-mono text-neutral-500 font-normal">Direct pixel sizing</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* 1. Main Body Font Size */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Main Body Font Size
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {bodyFontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={14}
                    max={26}
                    step={1}
                    value={bodyFontSize}
                    onChange={(e) => handleTypographyChange('bodyFontSize', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls general body copy, article narrative, product descriptions, and essays across the site.
                  </p>
                </div>

                {/* 2. Subtitle & Lead Paragraph Size */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Subtitle / Lead Paragraph
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {subtitleFontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={14}
                    max={30}
                    step={1}
                    value={subtitleFontSize}
                    onChange={(e) => handleTypographyChange('subtitleFontSize', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls hero banner subheadline, section intro leads, and manifesto teaser copy.
                  </p>
                </div>

                {/* 3. Small Captions & Metadata */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Small Text & Captions
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {smallFontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={11}
                    max={18}
                    step={1}
                    value={smallFontSize}
                    onChange={(e) => handleTypographyChange('smallFontSize', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls fine print, order item details, timestamps, photo credits, and secondary specs.
                  </p>
                </div>

                {/* 4. Page Titles (H1) */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Hero & Page Titles (H1)
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {h1FontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={40}
                    max={76}
                    step={2}
                    value={h1FontSize}
                    onChange={(e) => handleTypographyChange('h1FontSize', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls the opening hero headline, collection hero titles, and major page titles.
                  </p>
                </div>

                {/* 5. Section Headings (H2) */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Section Headings (H2)
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {h2FontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={24}
                    max={54}
                    step={2}
                    value={h2FontSize}
                    onChange={(e) => handleTypographyChange('h2FontSize', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls editorial section headers like "Inaugural Garments", "Manifesto", and "Reflections".
                  </p>
                </div>

                {/* 6. Card Titles & Subheadings (H3) */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Subheadings & Cards (H3)
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {h3FontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={16}
                    max={32}
                    step={1}
                    value={h3FontSize}
                    onChange={(e) => handleTypographyChange('h3FontSize', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls garment product card names, blog post titles, and modal subheadings.
                  </p>
                </div>

                {/* 7. Navigation Links */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Header & Menu Links
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {navFontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={11}
                    max={18}
                    step={1}
                    value={navFontSize}
                    onChange={(e) => handleTypographyChange('navFontSize', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls desktop navigation bar items, mobile drawer links, and breadcrumbs.
                  </p>
                </div>

                {/* 8. Badges, Pills & Quality Tags */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Badges & Quality Signals
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {badgeFontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={9}
                    max={16}
                    step={1}
                    value={badgeFontSize}
                    onChange={(e) => handleTypographyChange('badgeFontSize', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls chapter indicator pills, trust icons (6.5oz Cotton, Secure Checkout), and status badges.
                  </p>
                </div>

                {/* 9. Body Line Height */}
                <div className="bg-neutral-50/80 border border-neutral-200 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold">
                      Body Line Height Spacing
                    </label>
                    <span className="text-xs font-mono font-bold bg-black text-white px-2 py-0.5 rounded-2xs">
                      {bodyLineHeight}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={1.4}
                    max={2.0}
                    step={0.02}
                    value={bodyLineHeight}
                    onChange={(e) => handleTypographyChange('bodyLineHeight', Number(e.target.value))}
                    className="w-full accent-black cursor-pointer"
                  />
                  <p className="text-[11px] text-neutral-500 font-sans">
                    Controls vertical line spacing between sentences for maximum editorial reading comfort.
                  </p>
                </div>
              </div>
            </div>

            {/* Interactive Real-Time Live Preview Box */}
            <div className="bg-white border-2 border-neutral-900 p-6 sm:p-8 space-y-6 shadow-md rounded-xs">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
                <span className="text-xs uppercase font-mono tracking-wider font-bold text-neutral-900 flex items-center gap-2">
                  <Eye className="w-4 h-4 text-amber-500" />
                  <span>Real-Time Typography Scale Live Preview</span>
                </span>
                <span className="text-[10px] font-mono uppercase text-neutral-400">
                  Updates dynamically as you move sliders
                </span>
              </div>

              {/* Sample Renderings */}
              <div className="space-y-6 bg-[#fbfbf9] p-6 border border-neutral-200">
                {/* Badge sample */}
                <div className="flex items-center gap-2">
                  <span
                    className="font-mono uppercase tracking-wider bg-black text-white px-3 py-1 rounded-full font-semibold"
                    style={{ fontSize: `${badgeFontSize}px` }}
                  >
                    05 · THE SPACE BETWEEN
                  </span>
                  <span
                    className="font-mono uppercase tracking-wider border border-neutral-300 text-neutral-600 px-2.5 py-1 rounded-full"
                    style={{ fontSize: `${badgeFontSize}px` }}
                  >
                    6.5oz Heavyweight Cotton · Architectural Cut
                  </span>
                </div>

                {/* H1 Headline */}
                <div>
                  <h1
                    className="font-serif text-neutral-900 font-normal tracking-tight leading-tight"
                    style={{ fontSize: `${h1FontSize}px` }}
                  >
                    Somewhere Between You and Me, There Is an Us.
                  </h1>
                </div>

                {/* Subtitle / Lead */}
                <div>
                  <p
                    className="font-sans text-neutral-600 font-normal leading-relaxed"
                    style={{ fontSize: `${subtitleFontSize}px` }}
                  >
                    Clothing cut not to impress, but to open the quiet possibility of discovery.
                  </p>
                </div>

                {/* H2 Section Header */}
                <div className="border-t border-neutral-200 pt-4">
                  <h2
                    className="font-serif text-neutral-900 font-normal tracking-tight"
                    style={{ fontSize: `${h2FontSize}px` }}
                  >
                    Ideas Moving Through Public Space
                  </h2>
                </div>

                {/* H3 Subheading */}
                <div>
                  <h3
                    className="font-serif text-neutral-800 font-semibold"
                    style={{ fontSize: `${h3FontSize}px` }}
                  >
                    The Space Between Heavyweight Tee — $75
                  </h3>
                </div>

                {/* Main Body Paragraph */}
                <div>
                  <p
                    className="font-sans text-neutral-700 font-light"
                    style={{ fontSize: `${bodyFontSize}px`, lineHeight: bodyLineHeight }}
                  >
                    Conceived during reflections on election night in November 2008, this foundational design asserts that human distance is not a law of physics; it is an artifact of assumptions and unexamined separation. We share the same world, yet we experience each other at a distance.
                  </p>
                </div>

                {/* Small Metadata text */}
                <div className="border-t border-neutral-200 pt-3 flex items-center justify-between">
                  <span
                    className="font-mono text-neutral-500 uppercase tracking-wider"
                    style={{ fontSize: `${smallFontSize}px` }}
                  >
                    Chicago Conceived · US Domestic Fulfillment · Limited Run 2026
                  </span>
                  <button
                    type="button"
                    className="font-mono uppercase tracking-wider bg-black text-white px-4 py-2 font-bold cursor-pointer"
                    style={{ fontSize: `${navFontSize}px` }}
                  >
                    Sample Action Button
                  </button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <p className="text-xs text-neutral-500 font-mono">
                  Tip: Changes are actively staged. Click <strong>"Save All Changes"</strong> at top or below to permanently save to server database.
                </p>
                <div className="flex items-center space-x-3">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => applyPreset('balanced')}
                    className="text-xs font-mono"
                  >
                    Reset to Defaults
                  </Button>
                  <Button
                    type="submit"
                    variant="primary"
                    size="sm"
                    className="text-xs font-mono"
                  >
                    Save Typography
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 5: CONTACTS & HOURS */}
        {activeSubTab === 'contacts' && (
          <div className="space-y-6 pt-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Direct Telephone Hotline</label>
                <input
                  type="text"
                  value={businessPhone}
                  onChange={(e) => setBusinessPhone(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Customer Support Email</label>
                <input
                  type="email"
                  value={supportEmail}
                  onChange={(e) => setSupportEmail(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Order Inquiries Email</label>
                <input
                  type="email"
                  value={ordersEmail}
                  onChange={(e) => setOrdersEmail(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Press & Partnerships Email</label>
                <input
                  type="email"
                  value={pressEmail}
                  onChange={(e) => setPressEmail(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Customer Care Operating Hours</label>
                <input
                  type="text"
                  value={businessHours}
                  onChange={(e) => setBusinessHours(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans"
                />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 5: SOCIAL HANDLES */}
        {activeSubTab === 'socials' && (
          <div className="space-y-6 pt-2">
            <p className="text-xs text-neutral-600 leading-relaxed">
              Fill in your active social profiles. Channels left blank will automatically stay hidden from public store view.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Instagram URL</label>
                <input
                  type="text"
                  value={instagramUrl}
                  onChange={(e) => setInstagramUrl(e.target.value)}
                  placeholder="https://instagram.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">X / Twitter URL</label>
                <input
                  type="text"
                  value={twitterUrl}
                  onChange={(e) => setTwitterUrl(e.target.value)}
                  placeholder="https://x.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Spotify Playlist URL</label>
                <input
                  type="text"
                  value={spotifyUrl}
                  onChange={(e) => setSpotifyUrl(e.target.value)}
                  placeholder="https://open.spotify.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Substack / Journal URL</label>
                <input
                  type="text"
                  value={substackUrl}
                  onChange={(e) => setSubstackUrl(e.target.value)}
                  placeholder="https://ezistential.substack.com"
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">TikTok URL</label>
                <input
                  type="text"
                  value={tiktokUrl}
                  onChange={(e) => setTiktokUrl(e.target.value)}
                  placeholder="https://tiktok.com/@..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">YouTube URL</label>
                <input
                  type="text"
                  value={youtubeUrl}
                  onChange={(e) => setYoutubeUrl(e.target.value)}
                  placeholder="https://youtube.com/@..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Pinterest URL</label>
                <input
                  type="text"
                  value={pinterestUrl}
                  onChange={(e) => setPinterestUrl(e.target.value)}
                  placeholder="https://pinterest.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Facebook URL</label>
                <input
                  type="text"
                  value={facebookUrl}
                  onChange={(e) => setFacebookUrl(e.target.value)}
                  placeholder="https://facebook.com/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">LinkedIn URL</label>
                <input
                  type="text"
                  value={linkedinUrl}
                  onChange={(e) => setLinkedinUrl(e.target.value)}
                  placeholder="https://linkedin.com/company/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Discord / Community URL</label>
                <input
                  type="text"
                  value={discordUrl}
                  onChange={(e) => setDiscordUrl(e.target.value)}
                  placeholder="https://discord.gg/..."
                  className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 6: FISCAL & CURRENCY */}
        {activeSubTab === 'fiscal' && (
          <div className="space-y-6 pt-2">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Currency Symbol</label>
                <input
                  type="text"
                  value={currencySymbol}
                  onChange={(e) => setCurrencySymbol(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">ISO Currency Code</label>
                <input
                  type="text"
                  value={currencyCode}
                  onChange={(e) => setCurrencyCode(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>
              <div>
                <label className="block text-xs uppercase font-mono text-neutral-700 mb-1.5 font-medium">Estimated Sales Tax (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={salesTaxRatePercent}
                  onChange={(e) => setSalesTaxRatePercent(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* Payment Gateways Redirect Card */}
        <div className="bg-[#fcfcfb] border border-neutral-200 p-5 rounded-xs space-y-2">
          <div className="flex items-center space-x-2 text-neutral-900 font-serif font-bold text-sm">
            <CreditCard className="w-4 h-4 text-neutral-800 shrink-0" />
            <span>Payment Gateways & Connect Integrations</span>
          </div>
          <p className="text-xs text-neutral-600 font-sans leading-relaxed">
            All payment gateway controls (Stripe, Stripe Connect V2, PayPal, Apple Pay, Google Pay, Klarna, Afterpay, Cash App, Shop Pay) are managed exclusively in the <strong>Integrations</strong> tab under <strong>Payment Gateways & Connect</strong>.
          </p>
        </div>

        <div className="pt-4 border-t border-neutral-100 flex justify-end">
          <Button type="submit" variant="primary" size="md">
            Save Brand & Business Profile Changes
          </Button>
        </div>
      </div>
    </form>
  );
};
