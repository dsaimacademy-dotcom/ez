import React, { useState, useEffect } from 'react';
import {
  Users,
  Shield,
  Key,
  UserPlus,
  RefreshCw,
  Search,
  CheckCircle,
  AlertTriangle,
  Lock,
  Eye,
  EyeOff,
  Trash2,
  Edit2,
  Clock,
  History,
  Check,
  X,
  AlertCircle,
  ChevronDown,
  UserX,
  UserCheck,
  Copy
} from 'lucide-react';
import { UserProfile, UserRole, AccountStatus, AdminActivityLog } from '../../types';
import { api } from '../../lib/api';

export function generateSecurePassword(): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghjkmnpqrstuvwxyz';
  const digits = '23456789';
  const symbols = '!@#$%&*+=?';
  const all = upper + lower + digits + symbols;
  let pwd = '';
  pwd += upper[Math.floor(Math.random() * upper.length)];
  pwd += lower[Math.floor(Math.random() * lower.length)];
  pwd += digits[Math.floor(Math.random() * digits.length)];
  pwd += symbols[Math.floor(Math.random() * symbols.length)];
  for (let i = 4; i < 16; i++) {
    pwd += all[Math.floor(Math.random() * all.length)];
  }
  return pwd.split('').sort(() => Math.random() - 0.5).join('');
}

interface UserManagementCMSProps {
  currentUser: UserProfile | null;
  showToast: (msg: string) => void;
}

const ALL_ROLES: { role: UserRole; label: string; desc: string; color: string }[] = [
  { role: 'superadmin', label: 'Superadmin', desc: 'Complete platform control, staff management, integrations, and backups', color: 'bg-purple-950 text-purple-300 border-purple-800' },
  { role: 'manager', label: 'Store Manager', desc: 'Manages garments, catalog pricing, variants, and general order oversight', color: 'bg-amber-950 text-amber-300 border-amber-800' },
  { role: 'fulfillment', label: 'Fulfillment Staff', desc: 'Accesses orders, updates production progress, and POD shipping tracking', color: 'bg-blue-950 text-blue-300 border-blue-800' },
  { role: 'editor', label: 'Content Editor', desc: 'Manages journal articles, updates, and public editorial text', color: 'bg-emerald-950 text-emerald-300 border-emerald-800' },
  { role: 'moderator', label: 'Community Moderator', desc: 'Reviews and moderates customer reflections and UGC submissions', color: 'bg-cyan-950 text-cyan-300 border-cyan-800' },
  { role: 'customer', label: 'Customer', desc: 'Storefront shopper with access solely to their own profile and orders', color: 'bg-neutral-800 text-neutral-300 border-neutral-700' },
];

const PERMISSION_GROUPS = [
  {
    category: 'Garments & Catalog',
    permissions: [
      { key: 'catalog.view', label: 'View Products & Blanks', desc: 'Browse garment catalog and blanks' },
      { key: 'catalog.edit', label: 'Create & Edit Garments', desc: 'Modify pricing, stories, and variants' },
      { key: 'catalog.publish', label: 'Publish to Storefront', desc: 'Make draft garments live on the store' },
      { key: 'catalog.delete', label: 'Delete Products', desc: 'Remove items from the brand catalog' },
    ]
  },
  {
    category: 'Orders & Fulfillment',
    permissions: [
      { key: 'orders.view', label: 'View Orders', desc: 'Inspect customer orders and tracking' },
      { key: 'orders.fulfill', label: 'Dispatch to POD Providers', desc: 'Send orders to Apliiq or Printful' },
      { key: 'orders.edit', label: 'Update Tracking & Status', desc: 'Edit shipping carrier and tracking numbers' },
      { key: 'orders.export', label: 'Export Orders CSV', desc: 'Download fulfillment reports' },
    ]
  },
  {
    category: 'Content & Editorial',
    permissions: [
      { key: 'content.view', label: 'View Site Content', desc: 'Inspect page copy and blog drafts' },
      { key: 'content.edit', label: 'Edit Articles & FAQs', desc: 'Update manifestos, guides, and FAQs' },
      { key: 'content.publish', label: 'Publish Site Updates', desc: 'Make content changes live' },
    ]
  },
  {
    category: 'Community & Reflections',
    permissions: [
      { key: 'community.view', label: 'View UGC Submissions', desc: 'Browse customer story reflections' },
      { key: 'community.moderate', label: 'Moderate & Feature Quotes', desc: 'Approve, reject, or feature customer reflections' },
    ]
  },
  {
    category: 'System & Security (Superadmin Controlled)',
    isSuperadminOnly: true,
    permissions: [
      { key: 'users.view', label: 'View Staff Directory', desc: 'Access staff user list' },
      { key: 'users.create', label: 'Create Staff Accounts', desc: 'Provision staff member logins' },
      { key: 'users.edit', label: 'Edit Roles & Suspend', desc: 'Modify roles or freeze accounts' },
      { key: 'users.reset_pwd', label: 'Reset Staff Passwords', desc: 'Force password reset and invalidate sessions' },
      { key: 'integrations.edit', label: 'Manage API Credentials', desc: 'Edit Stripe, Apliiq, and Printful keys' },
      { key: 'payments.edit', label: 'Configure Payment Gateways', desc: 'Toggle Apple Pay, Google Pay, PayPal' },
      { key: 'backup.manage', label: 'Download Database Backups', desc: 'Export full SQL / JSON backups' },
      { key: 'settings.manage', label: 'Platform Settings', desc: 'Global domain, email, and brand config' },
      { key: 'audit.view', label: 'Audit Activity Logs', desc: 'Inspect security event stream' },
    ]
  }
];

export const UserManagementCMS: React.FC<UserManagementCMSProps> = ({ currentUser, showToast }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'logs'>('users');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [logs, setLogs] = useState<AdminActivityLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [resetPwdUser, setResetPwdUser] = useState<UserProfile | null>(null);
  const [deleteConfirmUser, setDeleteConfirmUser] = useState<UserProfile | null>(null);
  const [inspectCapsUser, setInspectCapsUser] = useState<UserProfile | null>(null);

  // Form states for creation
  const [createForm, setCreateForm] = useState({
    fullName: '',
    email: '',
    role: 'manager' as UserRole,
    password: '',
    customPermissions: [] as string[],
  });
  const [createError, setCreateError] = useState('');
  const [isSubmittingCreate, setIsSubmittingCreate] = useState(false);

  // Form states for editing
  const [editForm, setEditForm] = useState({
    fullName: '',
    role: 'manager' as UserRole,
    status: 'active' as AccountStatus,
    customPermissions: [] as string[],
  });
  const [editError, setEditError] = useState('');

  // Directory segmentation state
  const [directorySegment, setDirectorySegment] = useState<'all' | 'staff' | 'customers'>('all');

  // Status modal state (dedicated suspend/reactivate workflow)
  const [statusModalUser, setStatusModalUser] = useState<{ user: UserProfile; targetStatus: 'active' | 'suspended' } | null>(null);
  const [isSubmittingStatus, setIsSubmittingStatus] = useState(false);

  // Password reset state
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [showPasswordPlain, setShowPasswordPlain] = useState(false);
  const [resetSuccessCard, setResetSuccessCard] = useState<{ email: string; temporaryPassword: string } | null>(null);
  const [passwordCopied, setPasswordCopied] = useState(false);
  const [resetPwdError, setResetPwdError] = useState('');

  // Owner promotion tool state
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState(false);
  const [ownerKeyInput, setOwnerKeyInput] = useState('');
  const [ownerEmailInput, setOwnerEmailInput] = useState('');
  const [ownerPromoteError, setOwnerPromoteError] = useState('');

  const isSuperadmin = currentUser?.role === 'superadmin' || currentUser?.role === 'admin';
  const userCaps = currentUser?.effectiveCapabilities || (currentUser as any)?.effective_capabilities || [];
  const canCreateStaff = isSuperadmin || userCaps.includes('users.create');
  const canEditStaff = isSuperadmin || userCaps.includes('users.edit');
  const canResetPassword = isSuperadmin || userCaps.includes('users.reset_pwd');

  // Segment counts & filtering helpers
  const staffRoles = ['superadmin', 'admin', 'manager', 'fulfillment', 'editor', 'moderator'];
  const totalCount = users.length;
  const staffCount = users.filter((u) => staffRoles.includes((u.role || '').toLowerCase())).length;
  const customerCount = users.filter((u) => (u.role || 'customer').toLowerCase() === 'customer').length;

  const displayedUsers = users.filter((u) => {
    const r = (u.role || 'customer').toLowerCase();
    if (directorySegment === 'staff') {
      if (!staffRoles.includes(r)) return false;
    } else if (directorySegment === 'customers') {
      if (r !== 'customer') return false;
    }
    return true;
  });

  const activeSuperadmins = users.filter(
    (u) => (u.role === 'superadmin' || u.role === 'admin') && (u.status || 'active') === 'active'
  );

  const isSoleSuperadminUser = (u: UserProfile | null): boolean => {
    if (!u) return false;
    const isSuper = u.role === 'superadmin' || u.role === 'admin';
    return isSuper && (u.status || 'active') === 'active' && activeSuperadmins.length <= 1;
  };

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await api.adminGetUsers({
        role: roleFilter !== 'all' ? roleFilter : undefined,
        status: statusFilter !== 'all' ? statusFilter : undefined,
        search: searchQuery.trim() || undefined,
      });
      setUsers(data);
    } catch {
      showToast('Could not load user accounts.');
    } finally {
      setLoading(false);
    }
  };

  const fetchLogs = async () => {
    try {
      const data = await api.adminGetLogs(50);
      setLogs(data);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchUsers();
    if (activeTab === 'logs') {
      fetchLogs();
    }
  }, [roleFilter, statusFilter, activeTab]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchUsers();
  };

  // Open Edit Modal
  const openEditModal = (user: UserProfile) => {
    setEditingUser(user);
    setEditForm({
      fullName: user.fullName || '',
      role: (user.role || 'customer') as UserRole,
      status: (user.status || 'active') as AccountStatus,
      customPermissions: Array.isArray(user.customPermissions) ? user.customPermissions : [],
    });
    setEditError('');
  };

  // Submit Create User
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError('');
    if (!createForm.email.includes('@')) {
      setCreateError('Please provide a valid email address.');
      return;
    }
    if (createForm.password.length < 8) {
      setCreateError('Password must be at least 8 characters long.');
      return;
    }

    setIsSubmittingCreate(true);
    try {
      const res = await api.adminCreateUser({
        fullName: createForm.fullName.trim(),
        email: createForm.email.trim(),
        role: createForm.role,
        password: createForm.password,
        customPermissions: createForm.customPermissions,
      });

      if (res.success) {
        showToast(`Staff account created for ${createForm.fullName}.`);
        setIsCreateModalOpen(false);
        setCreateForm({
          fullName: '',
          email: '',
          role: 'manager',
          password: '',
          customPermissions: [],
        });
        fetchUsers();
      } else {
        setCreateError(res.error || 'Failed to create user.');
      }
    } catch (err: any) {
      setCreateError(err?.message || 'Error communicating with server.');
    } finally {
      setIsSubmittingCreate(false);
    }
  };

  // Submit Edit User
  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setEditError('');

    try {
      const res = await api.adminUpdateUser(editingUser.id, {
        fullName: editForm.fullName.trim(),
        role: editForm.role,
        status: editForm.status,
        customPermissions: editForm.customPermissions,
      });

      if (res.success) {
        showToast(`Updated account permissions for ${editForm.fullName}.`);
        setEditingUser(null);
        fetchUsers();
      } else {
        setEditError(res.error || 'Failed to update user.');
      }
    } catch (err: any) {
      setEditError(err?.message || 'Error saving user changes.');
    }
  };

  // Dedicated Suspend / Reactivate handler
  const handleStatusToggle = async () => {
    if (!statusModalUser) return;
    setIsSubmittingStatus(true);
    try {
      const res = await api.adminUpdateUser(statusModalUser.user.id, {
        status: statusModalUser.targetStatus,
      });
      if (res.success) {
        showToast(
          statusModalUser.targetStatus === 'suspended'
            ? `Account for ${statusModalUser.user.email} suspended. Active sessions terminated.`
            : `Account for ${statusModalUser.user.email} reactivated.`
        );
        setStatusModalUser(null);
        fetchUsers();
      } else {
        showToast(res.error || 'Failed to update account status.');
      }
    } catch (err: any) {
      showToast(err?.message || 'Network error updating status.');
    } finally {
      setIsSubmittingStatus(false);
    }
  };

  // Submit Password Reset
  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetPwdUser) return;
    setResetPwdError('');

    if (newPasswordInput.length < 8) {
      setResetPwdError('Password must be at least 8 characters.');
      return;
    }

    try {
      const res = await api.adminResetPassword(resetPwdUser.id, newPasswordInput);
      if (res.success) {
        setResetSuccessCard({
          email: resetPwdUser.email,
          temporaryPassword: newPasswordInput,
        });
        showToast(`Password updated for ${resetPwdUser.email}. Active sessions invalidated.`);
        fetchUsers();
      } else {
        setResetPwdError(res.error || 'Password reset rejected.');
      }
    } catch (err: any) {
      setResetPwdError(err?.message || 'Failed to reset password.');
    }
  };

  // Confirm Delete
  const handleDeleteConfirm = async () => {
    if (!deleteConfirmUser) return;
    try {
      const res = await api.adminDeleteUser(deleteConfirmUser.id);
      if (res.success) {
        showToast(`User account ${deleteConfirmUser.email} deleted.`);
        setDeleteConfirmUser(null);
        fetchUsers();
      } else {
        showToast(res.error || 'Could not delete user.');
      }
    } catch {
      showToast('Network error while deleting account.');
    }
  };

  // Controlled Owner Promotion Submit
  const handleOwnerPromotionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setOwnerPromoteError('');
    if (!ownerEmailInput || !ownerKeyInput) {
      setOwnerPromoteError('Both email and owner verification key are required.');
      return;
    }

    try {
      const res = await api.adminPromoteOwner(ownerEmailInput.trim(), ownerKeyInput.trim());
      if (res.success) {
        showToast(res.message || 'Account successfully promoted to Superadmin.');
        setIsOwnerModalOpen(false);
        setOwnerKeyInput('');
        setOwnerEmailInput('');
        fetchUsers();
      } else {
        setOwnerPromoteError(res.error || 'Promotion rejected.');
      }
    } catch (err: any) {
      setOwnerPromoteError(err?.message || 'Verification key invalid.');
    }
  };

  const getRoleBadge = (role?: string) => {
    const r = (role || 'customer').toLowerCase();
    const config = ALL_ROLES.find(item => item.role === r) || ALL_ROLES[ALL_ROLES.length - 1];
    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono border uppercase tracking-wider ${config.color}`}>
        {config.label}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b border-[#222222]">
        <div>
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-purple-400" />
            <h1 className="text-xl font-serif text-white tracking-wide">User & Staff Role Management</h1>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Configure administrative staff access, role-based restrictions, session integrity, and security audit logs.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSuperadmin && (
            <button
              onClick={() => setIsOwnerModalOpen(true)}
              className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 text-xs font-mono rounded transition-colors flex items-center space-x-2 cursor-pointer"
            >
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span>Verify Owner</span>
            </button>
          )}

          {canCreateStaff && (
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-mono uppercase tracking-wider rounded transition-colors flex items-center space-x-2 cursor-pointer shadow-sm"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Create Staff User</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-4 border-b border-[#222222]">
        <button
          onClick={() => setActiveTab('users')}
          className={`pb-3 text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer border-b-2 ${
            activeTab === 'users'
              ? 'border-purple-500 text-white font-medium'
              : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          Staff & Customer Directory ({users.length})
        </button>

        <button
          onClick={() => setActiveTab('logs')}
          className={`pb-3 text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer border-b-2 flex items-center space-x-2 ${
            activeTab === 'logs'
              ? 'border-purple-500 text-white font-medium'
              : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <History className="w-3.5 h-3.5 text-neutral-400" />
          <span>Audit Activity Log</span>
        </button>
      </div>

      {activeTab === 'users' && (
        <div className="space-y-4">
          {/* Segmented Category Filter */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setDirectorySegment('all')}
              className={`px-3 py-1.5 rounded-sm text-xs font-mono transition-colors flex items-center space-x-2 cursor-pointer ${
                directorySegment === 'all'
                  ? 'bg-neutral-200 text-neutral-950 font-semibold shadow-xs'
                  : 'bg-[#181818] text-neutral-400 hover:text-white hover:bg-neutral-800 border border-[#2b2b2b]'
              }`}
            >
              <span>All Accounts</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${directorySegment === 'all' ? 'bg-neutral-950 text-white' : 'bg-neutral-800 text-neutral-400'}`}>
                {totalCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setDirectorySegment('staff')}
              className={`px-3 py-1.5 rounded-sm text-xs font-mono transition-colors flex items-center space-x-2 cursor-pointer ${
                directorySegment === 'staff'
                  ? 'bg-purple-600 text-white font-semibold shadow-xs'
                  : 'bg-[#181818] text-neutral-400 hover:text-white hover:bg-neutral-800 border border-[#2b2b2b]'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Staff Members</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${directorySegment === 'staff' ? 'bg-purple-900 text-purple-200' : 'bg-neutral-800 text-neutral-400'}`}>
                {staffCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setDirectorySegment('customers')}
              className={`px-3 py-1.5 rounded-sm text-xs font-mono transition-colors flex items-center space-x-2 cursor-pointer ${
                directorySegment === 'customers'
                  ? 'bg-neutral-200 text-neutral-950 font-semibold shadow-xs'
                  : 'bg-[#181818] text-neutral-400 hover:text-white hover:bg-neutral-800 border border-[#2b2b2b]'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Customers</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${directorySegment === 'customers' ? 'bg-neutral-950 text-white' : 'bg-neutral-800 text-neutral-400'}`}>
                {customerCount}
              </span>
            </button>
          </div>

          {/* Filters & Search */}
          <div className="p-4 bg-[#111111] border border-[#222222] rounded-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <form onSubmit={handleSearchSubmit} className="flex-1 max-w-md relative">
              <input
                type="text"
                placeholder="Search by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 pl-9 rounded-sm focus:outline-none focus:border-purple-500"
              />
              <Search className="w-4 h-4 text-neutral-500 absolute left-2.5 top-2.5" />
            </form>

            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center space-x-2">
                <span className="text-[11px] font-mono text-neutral-400">Role:</span>
                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="bg-[#181818] border border-[#333333] text-neutral-200 text-xs px-2.5 py-1.5 rounded-sm focus:outline-none focus:border-purple-500"
                >
                  <option value="all">All Roles</option>
                  <option value="superadmin">Superadmin</option>
                  <option value="manager">Store Manager</option>
                  <option value="fulfillment">Fulfillment Staff</option>
                  <option value="editor">Content Editor</option>
                  <option value="moderator">Community Moderator</option>
                  <option value="customer">Customer</option>
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-[11px] font-mono text-neutral-400">Status:</span>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="bg-[#181818] border border-[#333333] text-neutral-200 text-xs px-2.5 py-1.5 rounded-sm focus:outline-none focus:border-purple-500"
                >
                  <option value="all">All Statuses</option>
                  <option value="active">Active</option>
                  <option value="suspended">Suspended</option>
                </select>
              </div>

              <button
                onClick={fetchUsers}
                className="p-1.5 bg-[#181818] hover:bg-neutral-800 text-neutral-300 border border-[#333333] rounded-sm transition-colors cursor-pointer"
                title="Refresh user list"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {/* Users Table */}
          <div className="border border-[#222222] bg-[#111111] rounded-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#161616] text-neutral-400 font-mono uppercase text-[10px] tracking-wider border-b border-[#222222]">
                  <tr>
                    <th className="py-3 px-4">User / Email</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Session Token</th>
                    <th className="py-3 px-4">Last Login</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e1e1e] text-neutral-300">
                  {displayedUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center space-y-2 font-mono">
                        <div className="text-neutral-500">
                          {loading ? 'Loading directory...' : 'No accounts matching criteria.'}
                        </div>
                        {!loading && (searchQuery || roleFilter !== 'all' || statusFilter !== 'all' || directorySegment !== 'all') && (
                          <div>
                            <button
                              type="button"
                              onClick={() => {
                                setSearchQuery('');
                                setRoleFilter('all');
                                setStatusFilter('all');
                                setDirectorySegment('all');
                                fetchUsers();
                              }}
                              className="text-xs font-mono text-purple-400 hover:text-purple-300 underline cursor-pointer"
                            >
                              Reset All Filters
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ) : (
                    displayedUsers.map((u) => {
                      const isSuspended = (u.status || 'active') === 'suspended';
                      const isCurrentActor = currentUser?.id === u.id || currentUser?.email.toLowerCase() === u.email.toLowerCase();
                      const isSole = isSoleSuperadminUser(u);

                      return (
                        <tr key={u.id} className="hover:bg-[#151515] transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-medium text-white flex items-center space-x-2">
                              <span>{u.fullName || 'Unnamed'}</span>
                              {isCurrentActor && (
                                <span className="text-[9px] font-mono bg-purple-900 text-purple-200 px-1 rounded">You</span>
                              )}
                              {isSole && (
                                <span className="text-[9px] font-mono bg-amber-950 text-amber-300 border border-amber-800 px-1 rounded" title="Sole Active Superadmin (Protected)">
                                  Protected
                                </span>
                              )}
                            </div>
                            <div className="text-neutral-400 font-mono text-[11px]">{u.email}</div>
                          </td>

                          <td className="py-3 px-4">
                            {getRoleBadge(u.role)}
                          </td>

                          <td className="py-3 px-4">
                            {isSuspended ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono bg-red-950 text-red-300 border border-red-800">
                                Suspended
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                                Active
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-4 font-mono text-[11px] text-neutral-400">
                            v{u.tokenVersion || 1}
                          </td>

                          <td className="py-3 px-4 text-neutral-400 font-mono text-[11px]">
                            {u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleDateString() : 'Never'}
                          </td>

                          <td className="py-3 px-4 text-right">
                            <div className="inline-flex items-center space-x-1.5">
                              <button
                                onClick={() => setInspectCapsUser(u)}
                                className="p-1 hover:bg-neutral-800 text-neutral-400 hover:text-white rounded transition-colors"
                                title="Inspect effective capabilities"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>

                              {canEditStaff && (
                                <button
                                  onClick={() => openEditModal(u)}
                                  className="p-1 hover:bg-neutral-800 text-neutral-400 hover:text-amber-400 rounded transition-colors"
                                  title="Edit role, permissions, status"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                              )}

                              {canEditStaff && (
                                isSuspended ? (
                                  <button
                                    onClick={() => setStatusModalUser({ user: u, targetStatus: 'active' })}
                                    className="p-1 hover:bg-neutral-800 text-neutral-400 hover:text-emerald-400 rounded transition-colors"
                                    title="Reactivate account access"
                                  >
                                    <UserCheck className="w-3.5 h-3.5" />
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => !isSole && !isCurrentActor && setStatusModalUser({ user: u, targetStatus: 'suspended' })}
                                    disabled={isSole || isCurrentActor}
                                    className={`p-1 rounded transition-colors ${
                                      isSole || isCurrentActor
                                        ? 'text-neutral-700 cursor-not-allowed'
                                        : 'hover:bg-neutral-800 text-neutral-400 hover:text-amber-400'
                                    }`}
                                    title={
                                      isSole
                                        ? 'Sole Active Superadmin (Protected)'
                                        : isCurrentActor
                                        ? 'Cannot suspend your own active session'
                                        : 'Suspend account & invalidate sessions'
                                    }
                                  >
                                    <UserX className="w-3.5 h-3.5" />
                                  </button>
                                )
                              )}

                              {canResetPassword && (
                                <button
                                  onClick={() => {
                                    setResetPwdUser(u);
                                    setResetSuccessCard(null);
                                    setNewPasswordInput('');
                                    setShowPasswordPlain(false);
                                  }}
                                  className="p-1 hover:bg-neutral-800 text-neutral-400 hover:text-purple-400 rounded transition-colors"
                                  title="Reset password"
                                >
                                  <Key className="w-3.5 h-3.5" />
                                </button>
                              )}

                              {canEditStaff && (
                                <button
                                  onClick={() => setDeleteConfirmUser(u)}
                                  disabled={isCurrentActor || isSole}
                                  className={`p-1 rounded transition-colors ${
                                    isCurrentActor || isSole
                                      ? 'text-neutral-700 cursor-not-allowed'
                                      : 'hover:bg-neutral-800 text-neutral-400 hover:text-red-400'
                                  }`}
                                  title={
                                    isSole
                                      ? 'Sole Active Superadmin (Protected)'
                                      : isCurrentActor
                                      ? 'Cannot delete your own active account'
                                      : 'Delete account'
                                  }
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Audit Activity Logs Tab */}
      {activeTab === 'logs' && (
        <div className="border border-[#222222] bg-[#111111] rounded-sm overflow-hidden">
          <div className="p-4 bg-[#141414] border-b border-[#222222] flex items-center justify-between">
            <div className="text-xs font-mono uppercase text-neutral-400">
              Chronological Security & Access Audit Stream
            </div>
            <button
              onClick={fetchLogs}
              className="p-1.5 bg-[#181818] hover:bg-neutral-800 text-neutral-300 border border-[#333333] rounded-sm transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#161616] text-neutral-400 font-mono uppercase text-[10px] tracking-wider border-b border-[#222222]">
                <tr>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Actor</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Action</th>
                  <th className="py-3 px-4">Target</th>
                  <th className="py-3 px-4">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e1e1e] text-neutral-300 font-mono text-[11px]">
                {logs.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-neutral-500 font-mono">
                      No administrative audit activity recorded yet.
                    </td>
                  </tr>
                ) : (
                  logs.map((log) => {
                    const createdAtStr = log.createdAt || (log as any).created_at;
                    const displayDate = createdAtStr ? new Date(createdAtStr).toLocaleString() : 'Just now';
                    const displayEmail = log.actorEmail || (log as any).user_email || 'unknown';
                    const displayRole = log.actorRole || (log as any).user_role || 'anonymous';
                    const displayTargetType = log.targetType || (log as any).target_entity || null;
                    const displayTargetId = log.targetId || (log as any).target_id || null;

                    return (
                      <tr key={log.id} className="hover:bg-[#151515] transition-colors">
                        <td className="py-3 px-4 text-neutral-400">
                          {displayDate}
                        </td>
                        <td className="py-3 px-4 text-white">
                          {displayEmail}
                        </td>
                        <td className="py-3 px-4">
                          {getRoleBadge(displayRole)}
                        </td>
                        <td className="py-3 px-4 text-amber-300 font-semibold">
                          {log.action}
                        </td>
                        <td className="py-3 px-4 text-neutral-400">
                          {displayTargetType ? `${displayTargetType} (${displayTargetId || '-'})` : '-'}
                        </td>
                        <td className="py-3 px-4 text-neutral-400 max-w-xs truncate">
                          {log.details ? JSON.stringify(log.details) : '-'}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CREATE STAFF MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#121212] border border-[#2b2b2b] w-full max-w-2xl rounded-sm p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#222222] pb-3">
              <div className="flex items-center space-x-2">
                <UserPlus className="w-5 h-5 text-purple-400" />
                <h3 className="text-base font-serif text-white">Provision New Staff Account</h3>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {createError && (
              <div className="p-3 bg-red-950/60 border border-red-800 text-red-200 text-xs rounded-sm flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{createError}</span>
              </div>
            )}

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={createForm.fullName}
                    onChange={(e) => setCreateForm({ ...createForm, fullName: e.target.value })}
                    placeholder="e.g. Jordan Hayes"
                    className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={createForm.email}
                    onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })}
                    placeholder="staff@ezistential.com"
                    className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Assigned Role</label>
                  <select
                    value={createForm.role}
                    onChange={(e) => setCreateForm({ ...createForm, role: e.target.value as UserRole })}
                    className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-purple-500"
                  >
                    {ALL_ROLES.map((r) => (
                      <option key={r.role} value={r.role}>
                        {r.label} — {r.desc}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-mono text-neutral-300">Initial Password (min 8 chars)</label>
                    <button
                      type="button"
                      onClick={() => {
                        const pwd = generateSecurePassword();
                        setCreateForm({ ...createForm, password: pwd });
                        showToast('Generated secure temporary password');
                      }}
                      className="text-[11px] font-mono text-purple-400 hover:text-purple-300 flex items-center space-x-1 cursor-pointer"
                    >
                      <Key className="w-3 h-3" />
                      <span>Generate Secure</span>
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    minLength={8}
                    value={createForm.password}
                    onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })}
                    placeholder="Enter or generate secure password"
                    className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-purple-500 font-mono"
                  />
                </div>
              </div>

              {/* Optional Custom Permissions Toggles */}
              <div className="border border-[#222222] bg-[#161616] p-4 rounded-sm space-y-3">
                <div className="text-xs font-mono text-neutral-300 font-semibold uppercase tracking-wider flex items-center justify-between">
                  <span>Fine-Grained Permissions (Optional Custom Overrides)</span>
                  <span className="text-[10px] text-neutral-500 lowercase font-normal">Superadmin capabilities are locked</span>
                </div>

                <div className="space-y-4">
                  {PERMISSION_GROUPS.map((grp) => {
                    const isGroupLocked = grp.isSuperadminOnly && !isSuperadmin;

                    return (
                      <div key={grp.category} className="space-y-2">
                        <div className="text-[11px] font-mono text-amber-400 font-medium">
                          {grp.category}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {grp.permissions.map((p) => {
                            const isChecked = createForm.customPermissions.includes(p.key);
                            const disabled = isGroupLocked;

                            return (
                              <label
                                key={p.key}
                                className={`flex items-start space-x-2 text-xs p-2 rounded border cursor-pointer transition-colors ${
                                  isChecked
                                    ? 'bg-purple-950/40 border-purple-800 text-white'
                                    : 'bg-[#1a1a1a] border-[#292929] text-neutral-400 hover:text-white'
                                } ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
                              >
                                <input
                                  type="checkbox"
                                  disabled={disabled}
                                  checked={isChecked}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setCreateForm({
                                        ...createForm,
                                        customPermissions: [...createForm.customPermissions, p.key]
                                      });
                                    } else {
                                      setCreateForm({
                                        ...createForm,
                                        customPermissions: createForm.customPermissions.filter(k => k !== p.key)
                                      });
                                    }
                                  }}
                                  className="mt-0.5 rounded border-[#333333] text-purple-600 focus:ring-0"
                                />
                                <div>
                                  <div className="font-mono text-[11px]">{p.label}</div>
                                  <div className="text-[10px] text-neutral-500">{p.desc}</div>
                                </div>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-[#222222]">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white text-xs font-mono rounded cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingCreate}
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-mono uppercase tracking-wider rounded cursor-pointer transition-colors flex items-center space-x-2"
                >
                  {isSubmittingCreate ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                  <span>Create Account</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT USER MODAL */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#121212] border border-[#2b2b2b] w-full max-w-2xl rounded-sm p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#222222] pb-3">
              <div>
                <h3 className="text-base font-serif text-white">Edit Account & Permissions</h3>
                <p className="text-xs text-neutral-400 font-mono">{editingUser.email}</p>
              </div>
              <button
                onClick={() => setEditingUser(null)}
                className="text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {editError && (
              <div className="p-3 bg-red-950/60 border border-red-800 text-red-200 text-xs rounded-sm flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{editError}</span>
              </div>
            )}

            {isSoleSuperadminUser(editingUser) && (
              <div className="p-3 bg-amber-950/40 border border-amber-800 text-amber-200 text-xs rounded-sm space-y-1 font-sans">
                <div className="font-semibold flex items-center space-x-1.5">
                  <Shield className="w-3.5 h-3.5 shrink-0 text-amber-400" />
                  <span>Sole Active Superadmin (Protected)</span>
                </div>
                <p className="text-[11px] text-amber-300 leading-relaxed">
                  This account is the platform's sole active Superadmin. Role demotion and suspension are disabled to prevent platform lockout.
                </p>
              </div>
            )}

            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={editForm.fullName}
                    onChange={(e) => setEditForm({ ...editForm, fullName: e.target.value })}
                    className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Role</label>
                  <select
                    disabled={isSoleSuperadminUser(editingUser)}
                    value={editForm.role}
                    onChange={(e) => setEditForm({ ...editForm, role: e.target.value as UserRole })}
                    className={`w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-purple-500 ${
                      isSoleSuperadminUser(editingUser) ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {ALL_ROLES.map((r) => (
                      <option key={r.role} value={r.role}>
                        {r.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Account Status</label>
                  <select
                    disabled={isSoleSuperadminUser(editingUser)}
                    value={editForm.status}
                    onChange={(e) => setEditForm({ ...editForm, status: e.target.value as AccountStatus })}
                    className={`w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-purple-500 ${
                      isSoleSuperadminUser(editingUser) ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>
              </div>

              {/* Custom Permissions */}
              <div className="border border-[#222222] bg-[#161616] p-4 rounded-sm space-y-3">
                <div className="text-xs font-mono text-neutral-300 font-semibold uppercase tracking-wider flex items-center justify-between">
                  <span>Custom Permissions</span>
                  <span className="text-[10px] text-neutral-500">Changing permissions automatically invalidates active sessions</span>
                </div>

                <div className="space-y-4">
                  {PERMISSION_GROUPS.map((grp) => {
                    const isGroupLocked = grp.isSuperadminOnly && !isSuperadmin;

                    return (
                      <div key={grp.category} className="space-y-2">
                        <div className="text-[11px] font-mono text-amber-400 font-medium">
                          {grp.category}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {grp.permissions.map((p) => {
                            const isChecked = editForm.customPermissions.includes(p.key);
                            const disabled = isGroupLocked;

                            return (
                              <label
                                key={p.key}
                                className={`flex items-start space-x-2 text-xs p-2 rounded border cursor-pointer transition-colors ${
                                  isChecked
                                    ? 'bg-purple-950/40 border-purple-800 text-white'
                                    : 'bg-[#1a1a1a] border-[#292929] text-neutral-400 hover:text-white'
                                } ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
                              >
                                <input
                                  type="checkbox"
                                  disabled={disabled}
                                  checked={isChecked}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setEditForm({
                                        ...editForm,
                                        customPermissions: [...editForm.customPermissions, p.key]
                                      });
                                    } else {
                                      setEditForm({
                                        ...editForm,
                                        customPermissions: editForm.customPermissions.filter(k => k !== p.key)
                                      });
                                    }
                                  }}
                                  className="mt-0.5 rounded border-[#333333] text-purple-600 focus:ring-0"
                                />
                                <div>
                                  <div className="font-mono text-[11px]">{p.label}</div>
                                  <div className="text-[10px] text-neutral-500">{p.desc}</div>
                                </div>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-[#222222]">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white text-xs font-mono rounded cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-mono uppercase tracking-wider rounded cursor-pointer transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PASSWORD RESET MODAL */}
      {resetPwdUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#121212] border border-[#2b2b2b] w-full max-w-md rounded-sm p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#222222] pb-3">
              <div className="flex items-center space-x-2">
                <Lock className="w-5 h-5 text-purple-400" />
                <h3 className="text-base font-serif text-white">Reset Staff Password</h3>
              </div>
              <button
                onClick={() => {
                  setResetPwdUser(null);
                  setResetSuccessCard(null);
                  setNewPasswordInput('');
                }}
                className="text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {resetSuccessCard ? (
              <div className="space-y-4 animate-in fade-in duration-200">
                <div className="p-4 bg-emerald-950/40 border border-emerald-800 rounded-sm space-y-3">
                  <div className="flex items-center space-x-2 text-emerald-400 text-xs font-mono">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    <span>Password updated. Active sessions terminated.</span>
                  </div>

                  <div className="space-y-1">
                    <div className="text-[10px] uppercase font-mono text-neutral-400">Account</div>
                    <div className="text-xs font-mono text-white">{resetSuccessCard.email}</div>
                  </div>

                  <div className="space-y-1">
                    <div className="text-[10px] uppercase font-mono text-neutral-400">New Temporary Password</div>
                    <div className="flex items-center justify-between bg-[#161616] p-2.5 rounded border border-[#2b2b2b]">
                      <code className="text-sm font-mono text-emerald-300 font-semibold tracking-wider select-all">
                        {resetSuccessCard.temporaryPassword}
                      </code>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(resetSuccessCard.temporaryPassword);
                          setPasswordCopied(true);
                          setTimeout(() => setPasswordCopied(false), 2000);
                        }}
                        className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-mono rounded flex items-center space-x-1.5 transition-colors cursor-pointer"
                      >
                        {passwordCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{passwordCopied ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>

                  <p className="text-[11px] font-sans text-neutral-400 leading-relaxed">
                    Provide this temporary password securely to the user. All previous active sessions on other devices have been invalidated.
                  </p>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setResetSuccessCard(null);
                      setResetPwdUser(null);
                      setNewPasswordInput('');
                    }}
                    className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-200 text-xs font-mono rounded cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <>
                <p className="text-xs text-neutral-300 font-sans leading-relaxed">
                  Setting a new password for <span className="font-mono text-purple-300">{resetPwdUser.email}</span> will immediately invalidate any active sessions or tokens across all devices.
                </p>

                {resetPwdError && (
                  <div className="p-3 bg-red-950/60 border border-red-800 text-red-200 text-xs rounded-sm">
                    {resetPwdError}
                  </div>
                )}

                <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-mono text-neutral-300">New Password (min 8 chars)</label>
                      <button
                        type="button"
                        onClick={() => {
                          const pwd = generateSecurePassword();
                          setNewPasswordInput(pwd);
                          setShowPasswordPlain(true);
                          showToast('Generated secure temporary password');
                        }}
                        className="text-[11px] font-mono text-purple-400 hover:text-purple-300 flex items-center space-x-1 cursor-pointer"
                      >
                        <Key className="w-3 h-3" />
                        <span>Generate Secure</span>
                      </button>
                    </div>

                    <div className="relative">
                      <input
                        type={showPasswordPlain ? 'text' : 'password'}
                        required
                        minLength={8}
                        value={newPasswordInput}
                        onChange={(e) => setNewPasswordInput(e.target.value)}
                        placeholder="Enter or generate password"
                        className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 pr-9 rounded-sm focus:outline-none focus:border-purple-500 font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPasswordPlain(!showPasswordPlain)}
                        className="absolute right-2.5 top-2.5 text-neutral-500 hover:text-neutral-300 cursor-pointer"
                        title={showPasswordPlain ? 'Hide password' : 'Show password'}
                      >
                        {showPasswordPlain ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-end space-x-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setResetPwdUser(null)}
                      className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 text-xs font-mono rounded cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-mono uppercase tracking-wider rounded cursor-pointer transition-colors"
                    >
                      Reset & Invalidate
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      )}

      {/* CONFIRM STATUS TOGGLE MODAL (SUSPEND / REACTIVATE) */}
      {statusModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#121212] border border-[#2b2b2b] w-full max-w-md rounded-sm p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#222222] pb-3">
              <div className="flex items-center space-x-2">
                {statusModalUser.targetStatus === 'suspended' ? (
                  <UserX className="w-5 h-5 text-red-400" />
                ) : (
                  <UserCheck className="w-5 h-5 text-emerald-400" />
                )}
                <h3 className="text-base font-serif text-white">
                  {statusModalUser.targetStatus === 'suspended' ? 'Suspend Account Access' : 'Reactivate Account Access'}
                </h3>
              </div>
              <button
                onClick={() => setStatusModalUser(null)}
                className="text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 font-sans">
              <p className="text-xs text-neutral-300 leading-relaxed">
                Are you sure you want to {statusModalUser.targetStatus === 'suspended' ? 'suspend' : 'reactivate'} the account for{' '}
                <span className="font-mono text-white font-medium">{statusModalUser.user.fullName || statusModalUser.user.email}</span>{' '}
                (<span className="font-mono text-purple-300">{statusModalUser.user.email}</span>)?
              </p>

              {statusModalUser.targetStatus === 'suspended' ? (
                <div className="p-3 bg-red-950/40 border border-red-800 text-red-200 text-xs rounded-sm space-y-1">
                  <div className="font-semibold flex items-center space-x-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>Immediate Invalidation Warning</span>
                  </div>
                  <p className="text-[11px] text-red-300 leading-relaxed">
                    Suspending this account will immediately increment its session token version, invalidating all active logins across every device. The user will be blocked from logging in until reactivated.
                  </p>
                </div>
              ) : (
                <div className="p-3 bg-emerald-950/40 border border-emerald-800 text-emerald-200 text-xs rounded-sm space-y-1">
                  <div className="font-semibold flex items-center space-x-1.5">
                    <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>Restoration of Privileges</span>
                  </div>
                  <p className="text-[11px] text-emerald-300 leading-relaxed">
                    Reactivating will immediately allow this user to authenticate again with their existing credentials.
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-[#222222]">
              <button
                type="button"
                disabled={isSubmittingStatus}
                onClick={() => setStatusModalUser(null)}
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 text-xs font-mono rounded cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isSubmittingStatus}
                onClick={handleStatusToggle}
                className={`px-4 py-2 text-white text-xs font-mono uppercase tracking-wider rounded cursor-pointer transition-colors flex items-center space-x-2 ${
                  statusModalUser.targetStatus === 'suspended'
                    ? 'bg-red-700 hover:bg-red-600'
                    : 'bg-emerald-600 hover:bg-emerald-500'
                }`}
              >
                {isSubmittingStatus ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : statusModalUser.targetStatus === 'suspended' ? (
                  <UserX className="w-3.5 h-3.5" />
                ) : (
                  <UserCheck className="w-3.5 h-3.5" />
                )}
                <span>{statusModalUser.targetStatus === 'suspended' ? 'Suspend & Terminate Sessions' : 'Reactivate Access'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* INSPECT EFFECTIVE CAPABILITIES MODAL (CATEGORIZED BY MODULE) */}
      {inspectCapsUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#121212] border border-[#2b2b2b] w-full max-w-xl rounded-sm p-6 space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-[#222222] pb-3 shrink-0">
              <div>
                <h3 className="text-base font-serif text-white">Effective Capabilities Inspector</h3>
                <p className="text-xs text-neutral-400 font-mono">
                  {inspectCapsUser.fullName} &middot; {inspectCapsUser.email}
                </p>
              </div>
              <button
                onClick={() => setInspectCapsUser(null)}
                className="text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between bg-[#161616] p-3 border border-[#222222] rounded-sm shrink-0">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono text-neutral-400">Assigned Role:</span>
                {getRoleBadge(inspectCapsUser.role)}
              </div>
              <div className="text-[11px] font-mono text-neutral-400">
                {(inspectCapsUser.effectiveCapabilities || []).length} Granted Capability(s)
              </div>
            </div>

            <div className="overflow-y-auto space-y-3 pr-1 flex-1">
              {(() => {
                const effectiveCaps: string[] = inspectCapsUser.effectiveCapabilities || (inspectCapsUser as any).effective_capabilities || [];
                const customList: string[] = inspectCapsUser.customPermissions || [];

                if (effectiveCaps.length === 0) {
                  return (
                    <div className="p-8 text-center bg-[#161616] border border-[#222222] rounded-sm space-y-2">
                      <Shield className="w-8 h-8 text-neutral-600 mx-auto" />
                      <p className="text-xs text-neutral-400 font-mono">No administrative capabilities assigned.</p>
                      <p className="text-[11px] text-neutral-600 font-sans">Standard customer accounts only possess access to personal orders and profile.</p>
                    </div>
                  );
                }

                // Group capabilities by category
                const renderedKeys = new Set<string>();

                const groups = PERMISSION_GROUPS.map((grp) => {
                  const activeInGrp = grp.permissions.filter((p) => {
                    if (effectiveCaps.includes(p.key)) {
                      renderedKeys.add(p.key);
                      return true;
                    }
                    return false;
                  });
                  return {
                    category: grp.category,
                    permissions: activeInGrp,
                  };
                }).filter((g) => g.permissions.length > 0);

                const unmapped = effectiveCaps.filter((cap) => !renderedKeys.has(cap));

                return (
                  <div className="space-y-3 font-mono text-xs">
                    {groups.map((grp) => (
                      <div key={grp.category} className="bg-[#161616] border border-[#262626] rounded-sm p-3 space-y-2">
                        <div className="text-[10px] uppercase font-bold tracking-wider text-amber-400 border-b border-[#222222] pb-1.5 flex items-center justify-between">
                          <span>{grp.category}</span>
                          <span className="text-neutral-500 font-normal">{grp.permissions.length} active</span>
                        </div>
                        <div className="space-y-1.5 pt-1">
                          {grp.permissions.map((p) => {
                            const isCustom = customList.includes(p.key);
                            return (
                              <div key={p.key} className="flex items-center justify-between text-[11px] py-1 border-b border-[#1f1f1f] last:border-b-0">
                                <div className="flex items-center space-x-2">
                                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                                  <span className="text-neutral-200 font-sans">{p.label}</span>
                                  <code className="text-[10px] text-neutral-500">({p.key})</code>
                                </div>
                                <span
                                  className={`text-[9px] px-1.5 py-0.5 rounded font-mono ${
                                    isCustom
                                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                      : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                                  }`}
                                >
                                  {isCustom ? 'Custom Grant' : 'Role Default'}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}

                    {unmapped.length > 0 && (
                      <div className="bg-[#161616] border border-[#262626] rounded-sm p-3 space-y-2">
                        <div className="text-[10px] uppercase font-bold tracking-wider text-neutral-400 border-b border-[#222222] pb-1.5 flex items-center justify-between">
                          <span>Additional & Customer Capabilities</span>
                          <span className="text-neutral-500 font-normal">{unmapped.length} active</span>
                        </div>
                        <div className="space-y-1.5 pt-1">
                          {unmapped.map((cap) => (
                            <div key={cap} className="flex items-center justify-between text-[11px] py-1 border-b border-[#1f1f1f] last:border-b-0">
                              <div className="flex items-center space-x-2">
                                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                                <code className="text-neutral-300">{cap}</code>
                              </div>
                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700 font-mono">
                                Role Default
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            <div className="flex justify-end pt-3 border-t border-[#222222] shrink-0">
              <button
                onClick={() => setInspectCapsUser(null)}
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs font-mono rounded cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      {deleteConfirmUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#121212] border border-red-900/60 w-full max-w-md rounded-sm p-6 space-y-4">
            <div className="flex items-center space-x-2 text-red-400">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h3 className="text-base font-serif text-white">Permanently Delete Account?</h3>
            </div>

            <p className="text-xs text-neutral-300">
              Are you sure you want to permanently delete <span className="font-mono text-white">{deleteConfirmUser.email}</span>? This action is irreversible.
            </p>

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-[#222222]">
              <button
                onClick={() => setDeleteConfirmUser(null)}
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 text-xs font-mono rounded cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfirm}
                className="px-4 py-2 bg-red-700 hover:bg-red-600 text-white text-xs font-mono uppercase tracking-wider rounded cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* OWNER PROMOTION MODAL */}
      {isOwnerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#121212] border border-amber-900/60 w-full max-w-md rounded-sm p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#222222] pb-3">
              <div className="flex items-center space-x-2">
                <Shield className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-serif text-white">Controlled Owner Verification</h3>
              </div>
              <button
                onClick={() => setIsOwnerModalOpen(false)}
                className="text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-neutral-300">
              To safely promote an existing verified account to <span className="text-purple-300 font-mono font-semibold">Superadmin</span> without automatic promotion based on email address, enter the owner verification secret key.
            </p>

            {ownerPromoteError && (
              <div className="p-3 bg-red-950/60 border border-red-800 text-red-200 text-xs rounded-sm">
                {ownerPromoteError}
              </div>
            )}

            <form onSubmit={handleOwnerPromotionSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1">Account Email to Promote</label>
                <input
                  type="email"
                  required
                  value={ownerEmailInput}
                  onChange={(e) => setOwnerEmailInput(e.target.value)}
                  placeholder="admin@ezistential.com"
                  className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1">Owner Verification Key</label>
                <input
                  type="password"
                  required
                  value={ownerKeyInput}
                  onChange={(e) => setOwnerKeyInput(e.target.value)}
                  placeholder="Enter EC_OWNER_PROMOTION_KEY"
                  className="w-full bg-[#181818] border border-[#333333] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsOwnerModalOpen(false)}
                  className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 text-xs font-mono rounded cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-mono uppercase tracking-wider rounded cursor-pointer"
                >
                  Verify & Promote
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
