import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Image as ImageIcon,
  Type,
  Link,
  Palette,
  CheckCircle2,
  Upload,
  RefreshCw,
  Eye,
  Smartphone,
  Monitor,
  ArrowRight,
  Layers,
  ChevronRight,
  ChevronLeft,
  Check,
  RotateCcw,
  Plus,
  Trash2,
  Copy,
  ArrowUp,
  ArrowDown,
  LayoutGrid,
  ExternalLink,
  SlidersHorizontal,
  X
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { ShapeDividerVariant, HeroSlide } from '../../types';
import { Button } from '../ui/Button';
import { ShapeDivider } from '../ui/ShapeDivider';
import { DEFAULT_HERO_SLIDES } from '../../data/heroSlides';
import { safeSrc } from '../../lib/utils';

export interface HomeBannerStudioProps {
  onBackToStore?: () => void;
  showToast: (msg: string) => void;
}

export const BANNER_PHOTO_PRESETS = [
  {
    id: 'noir-shadow',
    label: 'Noir Archival Shadow',
    url: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=2000&q=85',
    category: 'Noir Black',
    colorMood: 'noir-black' as const,
  },
  {
    id: 'golden-contrast',
    label: 'Golden Hour Sunlight',
    url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=2000&q=85',
    category: 'Warmth',
    colorMood: 'golden-amber' as const,
  },
  {
    id: 'street-public',
    label: 'Urban Sidewalk Dialogue',
    url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=2000&q=85',
    category: 'Public Space',
    colorMood: 'terracotta-sunset' as const,
  },
  {
    id: 'twilight-transit',
    label: 'Twilight Street Transit',
    url: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=2000&q=85',
    category: 'Indigo Twilight',
    colorMood: 'twilight-indigo' as const,
  },
  {
    id: 'minimal-earth',
    label: 'Architectural Earth Drape',
    url: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=2000&q=85',
    category: 'Studio Minimal',
    colorMood: 'golden-amber' as const,
  },
  {
    id: 'emerald-botanic',
    label: 'Deep Emerald Threshold',
    url: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=2000&q=85',
    category: 'Forest Emerald',
    colorMood: 'emerald-moss' as const,
  },
  {
    id: 'chicago-concrete',
    label: 'Brutalist Concrete & Stone',
    url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=2000&q=85',
    category: 'Architectural',
    colorMood: 'natural-monochrome' as const,
  },
  {
    id: 'fabric-detail',
    label: 'Combed Cotton Loom Weave',
    url: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=2000&q=85',
    category: 'Textile',
    colorMood: 'noir-black' as const,
  },
];

export const OVERLAY_COLOR_PRESETS = [
  { name: 'Pure Noir Black', hex: '#0a0a0a' },
  { name: 'Deep Charcoal', hex: '#171717' },
  { name: 'Midnight Indigo', hex: '#090d16' },
  { name: 'Deep Emerald Moss', hex: '#05140f' },
  { name: 'Dark Terracotta Umber', hex: '#1a0f0a' },
];

export const PAGE_TARGET_OPTIONS = [
  { value: 'shop', label: 'All Garments Catalog (Shop)' },
  { value: 'collections', label: 'Inaugural Collections' },
  { value: 'manifesto', label: 'Brand Manifesto' },
  { value: 'why-we-exist', label: 'Why We Exist' },
  { value: 'our-story', label: 'Our Origin Story' },
  { value: 'connection', label: 'Community Exchange & Archive' },
  { value: 'sustainability', label: 'Tactile Longevity & Sustainability' },
  { value: 'size-guide', label: 'Architectural Size Guide' },
];

export const HomeBannerStudio: React.FC<HomeBannerStudioProps> = ({ onBackToStore, showToast }) => {
  const { content, updateContent } = useContent();

  // Local slides state
  const [slides, setSlides] = useState<HeroSlide[]>(() => {
    if (content.heroSlides && Array.isArray(content.heroSlides) && content.heroSlides.length > 0) {
      return content.heroSlides;
    }
    return DEFAULT_HERO_SLIDES;
  });

  // Mode: 'overview' (deck of all banners) vs 'editor' (detailed editor for active slide)
  const [studioMode, setStudioMode] = useState<'overview' | 'editor'>('overview');
  const [editingSlideId, setEditingSlideId] = useState<string>(slides[0]?.id || DEFAULT_HERO_SLIDES[0].id);

  // Global Hero settings
  const [heroMode, setHeroMode] = useState<'carousel' | 'static'>(content.heroMode || 'carousel');
  const [heroControlsStyle, setHeroControlsStyle] = useState<'minimal-editorial' | 'interactive-capsule' | 'numbered-pagination'>(
    content.heroControlsStyle || 'minimal-editorial'
  );
  const [heroAutoplayIntervalMs, setHeroAutoplayIntervalMs] = useState<number>(content.heroAutoplayIntervalMs || 7500);
  const [heroEnableColorBlooms, setHeroEnableColorBlooms] = useState(content.heroEnableColorBlooms !== false);
  const [shapeDividerEnabled, setShapeDividerEnabled] = useState(content.shapeDividerEnabled !== false);
  const [shapeDividerVariant, setShapeDividerVariant] = useState<ShapeDividerVariant>(content.shapeDividerVariant || 'zebra-contour');
  const [shapeDividerHeight, setShapeDividerHeight] = useState<number>(content.shapeDividerHeight || 56);

  // Active slide being edited
  const editingSlide = slides.find((s) => s.id === editingSlideId) || slides[0] || DEFAULT_HERO_SLIDES[0];

  // Editor Sub-tabs
  const [activeEditorTab, setActiveEditorTab] = useState<'visuals' | 'typography' | 'buttons' | 'atmosphere' | 'divider' | 'controls'>('visuals');
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');

  // Sync slides with context if updated externally
  useEffect(() => {
    if (content.heroSlides && Array.isArray(content.heroSlides) && content.heroSlides.length > 0) {
      setSlides(content.heroSlides);
    }
  }, [content.heroSlides]);

  // Update specific field of the current editing slide
  const updateCurrentSlide = (fields: Partial<HeroSlide>) => {
    setSlides((prev) =>
      prev.map((slide) => {
        if (slide.id === editingSlideId) {
          return { ...slide, ...fields };
        }
        return slide;
      })
    );
  };

  // Open full editor for a specific slide
  const handleOpenEditor = (slideId: string) => {
    setEditingSlideId(slideId);
    setStudioMode('editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Add new slide
  const handleAddNewSlide = () => {
    const nextNumber = (slides.length + 1).toString().padStart(2, '0');
    const newSlide: HeroSlide = {
      id: `slide-custom-${Date.now()}`,
      chapterNumber: nextNumber,
      chapterLabel: `New Chapter ${nextNumber}`,
      tagline: 'Ezistential Connection · New Thesis',
      headline: 'The space between us is where inquiry begins.',
      subheadline:
        'Crafted with tactile heavyweight fabrics designed to interrupt indifference and prompt genuine human recognition in public space.',
      primaryCtaText: 'Explore Garments',
      primaryCtaTarget: 'shop',
      secondaryCtaText: 'Why We Exist',
      secondaryCtaTarget: 'why-we-exist',
      showSecondaryCta: true,
      imageUrl: BANNER_PHOTO_PRESETS[slides.length % BANNER_PHOTO_PRESETS.length].url,
      colorMood: 'golden-amber',
      overlayOpacity: 0.55,
      accentHex: '#d4d4d4',
      overlayColor: '#0a0a0a',
      gradientStyle: 'soft',
      active: true,
    };

    const updated = [...slides, newSlide];
    setSlides(updated);
    setEditingSlideId(newSlide.id);
    setStudioMode('editor');
    showToast(`Created Banner #${nextNumber}! Full editor is now open.`);
  };

  // Duplicate slide
  const handleDuplicateSlide = (slideId: string) => {
    const target = slides.find((s) => s.id === slideId);
    if (!target) return;

    const nextNumber = (slides.length + 1).toString().padStart(2, '0');
    const duplicate: HeroSlide = {
      ...target,
      id: `slide-custom-${Date.now()}`,
      chapterNumber: nextNumber,
      chapterLabel: `${target.chapterLabel} (Copy)`,
      active: true,
    };

    const updated = [...slides, duplicate];
    setSlides(updated);
    showToast(`Duplicated slide "${target.chapterLabel}".`);
  };

  // Remove slide
  const handleRemoveSlide = (slideId: string) => {
    if (slides.length <= 1) {
      showToast('You must keep at least one active banner slide.');
      return;
    }
    const target = slides.find((s) => s.id === slideId);
    const updated = slides.filter((s) => s.id !== slideId);
    setSlides(updated);
    if (editingSlideId === slideId) {
      setEditingSlideId(updated[0].id);
    }
    showToast(`Removed banner "${target?.chapterLabel || slideId}".`);
  };

  // Toggle active status
  const handleToggleSlideActive = (slideId: string) => {
    setSlides((prev) =>
      prev.map((s) => (s.id === slideId ? { ...s, active: s.active === false ? true : false } : s))
    );
  };

  // Move slide up / down
  const handleMoveSlide = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= slides.length) return;

    const updated = [...slides];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;

    // Refresh chapter numbers sequentially
    const renumbered = updated.map((s, idx) => ({
      ...s,
      chapterNumber: (idx + 1).toString().padStart(2, '0'),
    }));

    setSlides(renumbered);
  };

  // Handle local image upload for the active slide
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (JPG, PNG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        updateCurrentSlide({ imageUrl: dataUrl });
        showToast('Local image uploaded! Live preview updated.');
      }
    };
    reader.readAsDataURL(file);
  };

  // Save and publish all banners to ContentContext & backend
  const handleSaveAndPublishAll = () => {
    // If Slide 1 is updated, keep legacy top-level fields synced for backwards compatibility
    const slide1 = slides[0] || DEFAULT_HERO_SLIDES[0];

    updateContent({
      heroSlides: slides,
      heroMode,
      heroChapterNumber: slide1.chapterNumber,
      heroChapterLabel: slide1.chapterLabel,
      heroTagline: slide1.tagline,
      heroHeadline: slide1.headline,
      heroSubheadline: slide1.subheadline,
      heroButtonText: slide1.primaryCtaText,
      heroButtonTarget: slide1.primaryCtaTarget,
      heroSecondaryButtonText: slide1.secondaryCtaText,
      heroSecondaryButtonTarget: slide1.secondaryCtaTarget,
      heroShowSecondaryButton: slide1.showSecondaryCta !== false,
      heroImageUrl: slide1.imageUrl,
      heroImageOverlayOpacity: slide1.overlayOpacity,
      heroOverlayColor: slide1.overlayColor || '#0a0a0a',
      heroGradientStyle: slide1.gradientStyle || 'soft',
      heroColorMood: slide1.colorMood || 'golden-amber',
      heroEnableColorBlooms,
      heroAutoplayIntervalMs,
      heroControlsStyle,
      shapeDividerEnabled,
      shapeDividerVariant,
      shapeDividerHeight,
    });

    showToast(`Published ${slides.length} hero banner slides to live storefront!`);
  };

  // Reset all banners to factory defaults
  const handleResetDefaults = () => {
    setSlides(DEFAULT_HERO_SLIDES);
    setEditingSlideId(DEFAULT_HERO_SLIDES[0].id);
    setHeroMode('carousel');
    setHeroControlsStyle('minimal-editorial');
    setHeroAutoplayIntervalMs(7500);
    setHeroEnableColorBlooms(true);
    setShapeDividerEnabled(true);
    setShapeDividerVariant('zebra-contour');
    setShapeDividerHeight(56);
    showToast('Reset all banners to factory editorial defaults.');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Studio Header & Quick Action Bar */}
      <div className="bg-[#141414] border border-[#262626] p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-[10px] uppercase font-mono tracking-widest text-neutral-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Storefront Visual Engine · Master Hero Banners</span>
          </div>
          <h2 className="font-serif text-2xl text-white">Home Banner & Hero Studio</h2>
          <p className="text-xs text-neutral-400 font-sans max-w-2xl leading-relaxed">
            Manage all opening hero banners: add new slides, delete unwanted ones, reorder slides, and access the full live editor for individual typography, imagery, and mood overlays.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 text-xs font-mono uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Reset to brand defaults"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All</span>
          </button>

          {onBackToStore && (
            <button
              type="button"
              onClick={onBackToStore}
              className="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 text-xs font-mono uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>View Store</span>
            </button>
          )}

          <Button
            onClick={handleSaveAndPublishAll}
            variant="secondary"
            size="md"
            className="bg-white text-black hover:bg-neutral-200 border-transparent text-xs font-mono uppercase tracking-wider shadow-lg cursor-pointer"
          >
            <Check className="w-4 h-4 mr-1.5" />
            <span>Save & Publish ({slides.length} Slides)</span>
          </Button>
        </div>
      </div>

      {/* Global Mode Switcher & Navigation Bar */}
      <div className="bg-[#181818] border border-[#2a2a2a] p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => setStudioMode('overview')}
            className={`px-4 py-2 text-xs font-mono uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer ${
              studioMode === 'overview'
                ? 'bg-white text-black font-bold shadow-xs'
                : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>All Banners Deck ({slides.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setStudioMode('editor')}
            className={`px-4 py-2 text-xs font-mono uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer ${
              studioMode === 'editor'
                ? 'bg-white text-black font-bold shadow-xs'
                : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Full Slide Editor</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex items-center space-x-2 text-xs font-mono text-neutral-400">
            <span>Controls:</span>
            <select
              value={heroControlsStyle}
              onChange={(e) => {
                setHeroControlsStyle(e.target.value as any);
                showToast(`Switched controls to: ${e.target.value === 'minimal-editorial' ? 'Former Classic / Minimal' : e.target.value === 'interactive-capsule' ? 'Interactive Capsule' : 'Numbered Pagination'}`);
              }}
              className="bg-black border border-neutral-700 text-white text-xs px-2.5 py-1.5 font-mono rounded-sm focus:outline-hidden"
            >
              <option value="minimal-editorial">Former Classic (Architectural)</option>
              <option value="interactive-capsule">Interactive Capsule (Floating)</option>
              <option value="numbered-pagination">Numbered Minimal Tabs</option>
            </select>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono text-neutral-400">
            <span>Display:</span>
            <select
              value={heroMode}
              onChange={(e) => setHeroMode(e.target.value as any)}
              className="bg-black border border-neutral-700 text-white text-xs px-2.5 py-1.5 font-mono rounded-sm focus:outline-hidden"
            >
              <option value="carousel">Multi-Slide Carousel (Autoplay)</option>
              <option value="static">Single Static Hero (Slide 1)</option>
            </select>
          </div>

          <Button
            onClick={handleAddNewSlide}
            variant="outline"
            size="sm"
            className="bg-emerald-950/40 text-emerald-300 border-emerald-700/60 hover:bg-emerald-900/60 text-xs font-mono cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 mr-1" />
            <span>+ Add New Banner</span>
          </Button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODE 1: ALL BANNERS OVERVIEW DECK */}
      {/* ========================================================================= */}
      {studioMode === 'overview' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {slides.map((slide, index) => {
              const isActive = slide.active !== false;
              return (
                <div
                  key={slide.id}
                  className={`bg-[#141414] border transition-all overflow-hidden flex flex-col justify-between group ${
                    slide.id === editingSlideId
                      ? 'border-white ring-1 ring-white/50'
                      : 'border-[#262626] hover:border-neutral-500'
                  }`}
                >
                  <div>
                    {/* Thumbnail Preview Card with live scrim & badges */}
                    <div className="aspect-16/9 relative bg-black overflow-hidden">
                      <img
                        src={safeSrc(slide.imageUrl, DEFAULT_HERO_SLIDES[0].imageUrl)}
                        alt={slide.chapterLabel}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                      <div
                        className="absolute inset-0"
                        style={{
                          backgroundColor: slide.overlayColor || '#0a0a0a',
                          opacity: typeof slide.overlayOpacity === 'number' ? slide.overlayOpacity : 0.55,
                        }}
                      />

                      {/* Top Badges */}
                      <div className="absolute top-3 inset-x-3 flex items-center justify-between z-10">
                        <span className="px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest bg-black/80 text-white border border-white/20 backdrop-blur-xs">
                          Ch. {slide.chapterNumber}
                        </span>

                        <div className="flex items-center space-x-1">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleSlideActive(slide.id);
                            }}
                            className={`px-2 py-0.5 text-[10px] font-mono border backdrop-blur-xs cursor-pointer ${
                              isActive
                                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                                : 'bg-neutral-900/80 text-neutral-400 border-neutral-700'
                            }`}
                          >
                            {isActive ? 'Active' : 'Inactive'}
                          </button>
                        </div>
                      </div>

                      {/* Bottom Chapter Title in Image */}
                      <div className="absolute bottom-3 inset-x-3 z-10">
                        <p className="text-white font-serif text-sm font-semibold truncate drop-shadow-md">
                          {slide.chapterLabel}
                        </p>
                      </div>
                    </div>

                    {/* Banner Content Summary */}
                    <div className="p-4 space-y-3">
                      <div>
                        <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-500 line-clamp-1">
                          {slide.tagline}
                        </span>
                        <h4 className="font-serif text-base text-white font-medium mt-1 line-clamp-2 leading-snug">
                          "{slide.headline}"
                        </h4>
                        <p className="text-xs text-neutral-400 font-sans mt-1 line-clamp-2 leading-relaxed">
                          {slide.subheadline}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-[#262626] flex items-center justify-between text-[11px] font-mono text-neutral-400">
                        <span className="truncate max-w-[140px]">
                          CTA: <strong className="text-white">{slide.primaryCtaText}</strong>
                        </span>
                        <span className="text-neutral-500">→ /{slide.primaryCtaTarget}</span>
                      </div>
                    </div>
                  </div>

                  {/* Card Action Footer */}
                  <div className="p-3 bg-[#0d0d0d] border-t border-[#262626] flex items-center justify-between gap-2">
                    <div className="flex items-center space-x-1">
                      <button
                        type="button"
                        disabled={index === 0}
                        onClick={() => handleMoveSlide(index, 'up')}
                        className="p-1.5 text-neutral-400 hover:text-white disabled:opacity-30 hover:bg-neutral-800 rounded-sm cursor-pointer"
                        title="Move Up in sequence"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={index === slides.length - 1}
                        onClick={() => handleMoveSlide(index, 'down')}
                        className="p-1.5 text-neutral-400 hover:text-white disabled:opacity-30 hover:bg-neutral-800 rounded-sm cursor-pointer"
                        title="Move Down in sequence"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDuplicateSlide(slide.id)}
                        className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-sm cursor-pointer"
                        title="Duplicate this banner"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => handleRemoveSlide(slide.id)}
                        className="p-1.5 text-neutral-500 hover:text-red-400 hover:bg-red-950/40 rounded-sm cursor-pointer"
                        title="Delete this banner"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleOpenEditor(slide.id)}
                        className="px-3 py-1.5 bg-white text-black hover:bg-neutral-200 text-xs font-mono uppercase tracking-wider font-bold cursor-pointer"
                      >
                        Open Editor
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add Banner Prompt Box */}
          <div className="p-8 border border-dashed border-[#333333] bg-[#111111] text-center space-y-3">
            <h3 className="font-serif text-lg text-white">Create Another Opening Narrative Banner</h3>
            <p className="text-xs text-neutral-400 font-sans max-w-lg mx-auto">
              Add multiple chapters to your homepage hero carousel. Seamlessly introduce seasonal campaigns, special releases, or philosophical essays.
            </p>
            <Button
              onClick={handleAddNewSlide}
              variant="secondary"
              size="md"
              className="bg-white text-black hover:bg-neutral-200 text-xs font-mono uppercase cursor-pointer"
            >
              <Plus className="w-4 h-4 mr-1.5" />
              <span>+ Add New Banner Slide</span>
            </Button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODE 2: FULL COMPREHENSIVE SLIDE EDITOR */}
      {/* ========================================================================= */}
      {studioMode === 'editor' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          {/* Active Editing Slide Selector / Stepper */}
          <div className="bg-[#141414] border border-[#262626] p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center space-x-3 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
              <button
                type="button"
                onClick={() => setStudioMode('overview')}
                className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 text-xs font-mono uppercase tracking-wider flex items-center gap-1 shrink-0 cursor-pointer"
              >
                <span>← All Banners</span>
              </button>

              <span className="text-neutral-600 font-mono">|</span>

              <div className="flex items-center space-x-1.5">
                {slides.map((s, idx) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setEditingSlideId(s.id)}
                    className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer shrink-0 border ${
                      s.id === editingSlideId
                        ? 'bg-white text-black font-bold border-white shadow-xs'
                        : 'bg-black text-neutral-400 border-neutral-800 hover:text-white hover:border-neutral-600'
                    }`}
                  >
                    <span>{s.chapterNumber} · {s.chapterLabel.slice(0, 14)}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-2 shrink-0">
              <button
                type="button"
                onClick={() => handleToggleSlideActive(editingSlide.id)}
                className={`px-3 py-1.5 text-xs font-mono border cursor-pointer ${
                  editingSlide.active !== false
                    ? 'bg-emerald-950/60 text-emerald-300 border-emerald-600/60'
                    : 'bg-neutral-900 text-neutral-400 border-neutral-700'
                }`}
              >
                {editingSlide.active !== false ? '● Active on Store' : '○ Inactive'}
              </button>

              <button
                type="button"
                onClick={() => handleDuplicateSlide(editingSlide.id)}
                className="p-1.5 text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 rounded-sm cursor-pointer"
                title="Duplicate Slide"
              >
                <Copy className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => handleRemoveSlide(editingSlide.id)}
                className="p-1.5 text-neutral-400 hover:text-red-400 bg-neutral-900 border border-neutral-800 rounded-sm cursor-pointer"
                title="Delete Slide"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive Real-Time Live Preview Box for Active Slide */}
          <div className="bg-[#141414] border border-[#262626] overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-[#262626] bg-[#0c0c0c] flex items-center justify-between">
              <div className="flex items-center space-x-2 text-xs font-mono text-neutral-400">
                <span className="font-bold text-white uppercase tracking-wider">
                  Live Preview · Chapter {editingSlide.chapterNumber}: {editingSlide.chapterLabel}
                </span>
                <span>•</span>
                <span className="text-[11px] text-neutral-500">
                  {editingSlide.colorMood}
                </span>
              </div>

              <div className="flex items-center space-x-1.5 bg-neutral-900 border border-neutral-800 p-0.5 rounded-sm">
                <button
                  type="button"
                  onClick={() => setPreviewDevice('desktop')}
                  className={`p-1.5 text-xs font-mono flex items-center gap-1 transition-colors cursor-pointer ${
                    previewDevice === 'desktop' ? 'bg-neutral-800 text-white' : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                  title="Desktop View"
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span className="text-[10px] hidden sm:inline">Desktop</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDevice('mobile')}
                  className={`p-1.5 text-xs font-mono flex items-center gap-1 transition-colors cursor-pointer ${
                    previewDevice === 'mobile' ? 'bg-neutral-800 text-white' : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                  title="Mobile View"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span className="text-[10px] hidden sm:inline">Mobile</span>
                </button>
              </div>
            </div>

            {/* Live Visual Canvas */}
            <div
              className={`relative mx-auto transition-all duration-300 ${
                previewDevice === 'mobile'
                  ? 'max-w-sm my-6 border-4 border-neutral-800 rounded-3xl overflow-hidden shadow-2xl'
                  : 'w-full'
              }`}
            >
              <div
                className="relative bg-[#0a0a0a] text-white overflow-hidden flex items-center justify-center select-none"
                style={{
                  minHeight: previewDevice === 'mobile' ? '540px' : '480px',
                  padding: previewDevice === 'mobile' ? '3rem 1.5rem' : '4.5rem 2rem',
                }}
              >
                {/* 1. Background Image */}
                <div className="absolute inset-0 z-0">
                  <img
                    src={safeSrc(editingSlide.imageUrl, DEFAULT_HERO_SLIDES[0].imageUrl)}
                    alt="Hero Preview"
                    className="w-full h-full object-cover object-center transform scale-100"
                  />
                  {/* Dynamic Opacity Scrim */}
                  <div
                    className="absolute inset-0 transition-all duration-300"
                    style={{
                      backgroundColor: editingSlide.overlayColor || '#0a0a0a',
                      opacity: typeof editingSlide.overlayOpacity === 'number' ? editingSlide.overlayOpacity : 0.55,
                    }}
                  />
                </div>

                {/* 2. Color Mood Blooms */}
                {heroEnableColorBlooms && (
                  <>
                    <div
                      className="absolute -top-16 -left-16 w-80 h-80 rounded-full blur-3xl pointer-events-none opacity-40 transition-all"
                      style={{
                        backgroundColor:
                          editingSlide.colorMood === 'golden-amber'
                            ? 'rgba(245, 158, 11, 0.35)'
                            : editingSlide.colorMood === 'terracotta-sunset'
                            ? 'rgba(234, 88, 12, 0.35)'
                            : editingSlide.colorMood === 'twilight-indigo'
                            ? 'rgba(99, 102, 241, 0.35)'
                            : editingSlide.colorMood === 'emerald-moss'
                            ? 'rgba(16, 185, 129, 0.35)'
                            : 'rgba(255, 255, 255, 0.08)',
                      }}
                    />
                    <div
                      className="absolute -bottom-16 -right-16 w-80 h-80 rounded-full blur-3xl pointer-events-none opacity-40 transition-all"
                      style={{
                        backgroundColor:
                          editingSlide.colorMood === 'golden-amber'
                            ? 'rgba(217, 119, 6, 0.3)'
                            : editingSlide.colorMood === 'terracotta-sunset'
                            ? 'rgba(194, 65, 12, 0.3)'
                            : editingSlide.colorMood === 'twilight-indigo'
                            ? 'rgba(79, 70, 229, 0.3)'
                            : editingSlide.colorMood === 'emerald-moss'
                            ? 'rgba(5, 150, 105, 0.3)'
                            : 'rgba(255, 255, 255, 0.05)',
                      }}
                    />
                  </>
                )}

                {/* 3. Gradient Style Overlay */}
                {editingSlide.gradientStyle === 'cinematic' && (
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/70 pointer-events-none" />
                )}
                {editingSlide.gradientStyle === 'soft' && (
                  <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/40 pointer-events-none" />
                )}

                {/* 4. Live Editorial Typography Container */}
                <div className="max-w-3xl mx-auto text-center space-y-4 relative z-10 px-2 pb-12">
                  {/* Tagline / Chapter Pill Badge */}
                  <div className="inline-flex items-center space-x-2 px-4 py-1.5 backdrop-blur-md border border-white/25 bg-black/65 rounded-full text-xs sm:text-sm font-mono uppercase tracking-wider shadow-lg">
                    <span
                      className="w-2 h-2 rounded-full animate-pulse shrink-0"
                      style={{ backgroundColor: editingSlide.accentHex || '#f59e0b' }}
                    />
                    <span className="text-white font-bold shrink-0">
                      {editingSlide.chapterNumber} · {editingSlide.chapterLabel}
                    </span>
                    {editingSlide.tagline && (
                      <>
                        <span className="text-neutral-400">|</span>
                        <span className="text-neutral-200 truncate max-w-[240px] sm:max-w-md">
                          {editingSlide.tagline}
                        </span>
                      </>
                    )}
                  </div>

                  {/* Main Headline */}
                  <h1
                    className={`font-serif tracking-tight text-white leading-tight drop-shadow-md ${
                      previewDevice === 'mobile' ? 'text-2xl' : 'text-3xl sm:text-4xl lg:text-5xl'
                    }`}
                  >
                    {editingSlide.headline}
                  </h1>

                  {/* Subheadline Narrative */}
                  <p
                    className={`text-neutral-100 font-sans mx-auto leading-relaxed max-w-2xl font-normal ${
                      previewDevice === 'mobile' ? 'text-sm' : 'text-base sm:text-xl'
                    }`}
                  >
                    {editingSlide.subheadline}
                  </p>

                  {/* Call to Action Buttons & Carousel Chapter Controls */}
                  <div className="pt-2 space-y-3">
                    <div className="flex flex-wrap items-center justify-center gap-3">
                      <div className="px-6 py-3 bg-white text-black text-xs font-mono uppercase tracking-wider font-bold shadow-lg flex items-center gap-1.5">
                        <span>{editingSlide.primaryCtaText}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>

                      {editingSlide.showSecondaryCta !== false && (
                        <div className="px-5 py-3 bg-black/40 text-white border border-white/30 text-xs font-mono uppercase tracking-wider backdrop-blur-xs">
                          <span>{editingSlide.secondaryCtaText || 'Why We Exist'}</span>
                        </div>
                      )}
                    </div>

                    {/* 5. Live Navigation Controls Preview Bar */}
                    {heroMode === 'carousel' && (
                      <div className="pt-0.5 flex justify-center pointer-events-none">
                        {heroControlsStyle === 'interactive-capsule' ? (
                          <div className="mx-auto bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/20 flex items-center space-x-1.5 text-[9px] font-mono text-white">
                            <span>● {editingSlide.chapterLabel}</span>
                            <span className="text-neutral-500">|</span>
                            <span className="text-neutral-400">Capsule Navigation</span>
                          </div>
                        ) : heroControlsStyle === 'numbered-pagination' ? (
                          <div className="mx-auto flex space-x-1 text-[9px] font-mono">
                            {slides.map((s, i) => (
                              <span
                                key={s.id}
                                className={`px-2 py-0.5 ${
                                  s.id === editingSlideId
                                    ? 'bg-white text-black font-bold'
                                    : 'bg-black/60 text-neutral-400 border border-neutral-800'
                                }`}
                              >
                                {s.chapterNumber}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <div className="w-full flex items-center justify-between text-[10px] font-mono text-neutral-400">
                            <div className="bg-black/50 px-2.5 py-0.5 border border-neutral-800 text-white font-bold">
                              {editingSlide.chapterNumber} / {slides.length.toString().padStart(2, '0')}
                            </div>
                            <div className="flex space-x-2 text-[9px]">
                              {slides.map((s) => (
                                <span
                                  key={s.id}
                                  className={`px-1 border-b ${
                                    s.id === editingSlideId
                                      ? 'border-white text-white font-bold'
                                      : 'border-transparent text-neutral-500'
                                  }`}
                                >
                                  {s.chapterNumber} {s.chapterLabel}
                                </span>
                              ))}
                            </div>
                            <div className="flex space-x-1 text-white">
                              <span className="w-5 h-5 bg-black/60 border border-neutral-800 flex items-center justify-center">‹</span>
                              <span className="w-5 h-5 bg-black/60 border border-neutral-800 flex items-center justify-center">›</span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* 6. Live Shape Divider Preview at Base */}
                {shapeDividerEnabled && (
                  <div className="absolute bottom-0 inset-x-0 z-20 pointer-events-none">
                    <ShapeDivider
                      variant={shapeDividerVariant}
                      height={Math.max(28, Math.min(shapeDividerHeight, 64))}
                      fillColor="#141414"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Full Slide Editor Control Tabs */}
          <div className="bg-[#141414] border border-[#262626] overflow-hidden">
            {/* Tab Navigation */}
            <div className="flex border-b border-[#262626] bg-[#0c0c0c] overflow-x-auto">
              <button
                type="button"
                onClick={() => setActiveEditorTab('visuals')}
                className={`px-5 py-3.5 text-xs font-mono uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activeEditorTab === 'visuals'
                    ? 'border-white text-white bg-[#141414]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>01 · Visuals & Imagery</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveEditorTab('typography')}
                className={`px-5 py-3.5 text-xs font-mono uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activeEditorTab === 'typography'
                    ? 'border-white text-white bg-[#141414]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Type className="w-3.5 h-3.5" />
                <span>02 · Narrative & Typography</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveEditorTab('buttons')}
                className={`px-5 py-3.5 text-xs font-mono uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activeEditorTab === 'buttons'
                    ? 'border-white text-white bg-[#141414]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Link className="w-3.5 h-3.5" />
                <span>03 · Buttons & Targets</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveEditorTab('atmosphere')}
                className={`px-5 py-3.5 text-xs font-mono uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activeEditorTab === 'atmosphere'
                    ? 'border-white text-white bg-[#141414]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Palette className="w-3.5 h-3.5" />
                <span>04 · Atmosphere & Mood</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveEditorTab('divider')}
                className={`px-5 py-3.5 text-xs font-mono uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activeEditorTab === 'divider'
                    ? 'border-white text-white bg-[#141414]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>05 · Transition Divider</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveEditorTab('controls')}
                className={`px-5 py-3.5 text-xs font-mono uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activeEditorTab === 'controls'
                    ? 'border-white text-white bg-[#141414]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>06 · Controls & Display System</span>
              </button>
            </div>

            {/* TAB CONTENTS */}
            <div className="p-6">
              {/* TAB 1: VISUALS & IMAGERY */}
              {activeEditorTab === 'visuals' && (
                <div className="space-y-6 animate-in fade-in duration-150">
                  <div>
                    <h3 className="text-white font-serif text-lg">Background Imagery for Slide #{editingSlide.chapterNumber}</h3>
                    <p className="text-xs text-neutral-400 font-sans mt-0.5">
                      Select from curated archival photography presets, enter a direct URL, or upload your own editorial asset.
                    </p>
                  </div>

                  {/* Preset Photo Gallery */}
                  <div className="space-y-2">
                    <label className="text-xs font-mono uppercase text-neutral-300">
                      Curated Editorial Photography Presets
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {BANNER_PHOTO_PRESETS.map((preset) => {
                        const isSelected = editingSlide.imageUrl === preset.url;
                        return (
                          <div
                            key={preset.id}
                            onClick={() => {
                              updateCurrentSlide({
                                imageUrl: preset.url,
                                colorMood: preset.colorMood,
                              });
                              showToast(`Applied preset "${preset.label}".`);
                            }}
                            className={`group relative aspect-4/3 overflow-hidden border cursor-pointer transition-all ${
                              isSelected
                                ? 'border-white ring-2 ring-white/60'
                                : 'border-neutral-800 hover:border-neutral-500 opacity-70 hover:opacity-100'
                            }`}
                          >
                            <img
                              src={preset.url}
                              alt={preset.label}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                            <div className="absolute bottom-2 inset-x-2">
                              <span className="text-[10px] font-mono font-bold text-white block truncate">
                                {preset.label}
                              </span>
                              <span className="text-[9px] font-mono text-neutral-400">
                                {preset.category}
                              </span>
                            </div>
                            {isSelected && (
                              <div className="absolute top-2 right-2 bg-white text-black p-0.5 rounded-full shadow-md">
                                <Check className="w-3 h-3 stroke-[3]" />
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Custom URL & Local Upload Input Controls */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-[#262626]">
                    <div className="space-y-2">
                      <label className="text-xs font-mono uppercase text-neutral-300 block">
                        Direct Image URL
                      </label>
                      <input
                        type="url"
                        value={editingSlide.imageUrl}
                        onChange={(e) => updateCurrentSlide({ imageUrl: e.target.value })}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full bg-black border border-neutral-700 px-3 py-2.5 text-xs text-white font-mono focus:border-white focus:outline-hidden"
                      />
                      <span className="text-[11px] text-neutral-500 font-sans block">
                        Provide a high-resolution 16:9 image (minimum 1920×1080 recommended).
                      </span>
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-mono uppercase text-neutral-300 block">
                        Upload Local File
                      </label>
                      <label className="w-full border border-dashed border-neutral-700 hover:border-white bg-black p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors">
                        <Upload className="w-5 h-5 text-neutral-400" />
                        <span className="text-xs font-mono text-neutral-300">
                          Choose File (JPG, PNG, WebP)
                        </span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageFileUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: NARRATIVE & TYPOGRAPHY */}
              {activeEditorTab === 'typography' && (
                <div className="space-y-6 animate-in fade-in duration-150">
                  <div>
                    <h3 className="text-white font-serif text-lg">Narrative & Philosophy Copy</h3>
                    <p className="text-xs text-neutral-400 font-sans mt-0.5">
                      Shape the thesis statement, chapter markers, and opening questions displayed to storefront visitors.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono uppercase text-neutral-300 block">
                        Chapter Number
                      </label>
                      <input
                        type="text"
                        value={editingSlide.chapterNumber}
                        onChange={(e) => updateCurrentSlide({ chapterNumber: e.target.value })}
                        placeholder="01"
                        className="w-full bg-black border border-neutral-700 px-3 py-2 text-xs font-mono text-white focus:border-white focus:outline-hidden"
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1.5">
                      <label className="text-xs font-mono uppercase text-neutral-300 block">
                        Chapter Title / Label
                      </label>
                      <input
                        type="text"
                        value={editingSlide.chapterLabel}
                        onChange={(e) => updateCurrentSlide({ chapterLabel: e.target.value })}
                        placeholder="The Threshold"
                        className="w-full bg-black border border-neutral-700 px-3 py-2 text-xs font-sans text-white focus:border-white focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-mono uppercase text-neutral-300 block">
                      Top Floating Badge / Tagline
                    </label>
                    <input
                      type="text"
                      value={editingSlide.tagline}
                      onChange={(e) => updateCurrentSlide({ tagline: e.target.value })}
                      placeholder="The Medium Is Clothing. The Subject Is Connection."
                      className="w-full bg-black border border-neutral-700 px-3 py-2 text-xs font-mono text-white focus:border-white focus:outline-hidden"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-mono uppercase text-neutral-300 block">
                      Primary Editorial Headline (Garamond Serif)
                    </label>
                    <textarea
                      rows={2}
                      value={editingSlide.headline}
                      onChange={(e) => updateCurrentSlide({ headline: e.target.value })}
                      placeholder="We share the same world, yet we experience each other at a distance."
                      className="w-full bg-black border border-neutral-700 p-3 text-sm font-serif text-white focus:border-white focus:outline-hidden"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-mono uppercase text-neutral-300 block">
                      Subheadline Narrative / Story Body
                    </label>
                    <textarea
                      rows={4}
                      value={editingSlide.subheadline}
                      onChange={(e) => updateCurrentSlide({ subheadline: e.target.value })}
                      placeholder="Ezistential Connection examines the space between people..."
                      className="w-full bg-black border border-neutral-700 p-3 text-xs font-sans text-neutral-200 leading-relaxed focus:border-white focus:outline-hidden"
                    />
                  </div>
                </div>
              )}

              {/* TAB 3: BUTTONS & TARGETS */}
              {activeEditorTab === 'buttons' && (
                <div className="space-y-6 animate-in fade-in duration-150">
                  <div>
                    <h3 className="text-white font-serif text-lg">Action Buttons & Destination Routing</h3>
                    <p className="text-xs text-neutral-400 font-sans mt-0.5">
                      Configure button labels and destination page views for this banner.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Primary Button */}
                    <div className="bg-[#101010] p-4 border border-[#2a2a2a] space-y-3">
                      <div className="flex items-center space-x-2 text-xs font-mono text-white font-bold uppercase tracking-wider">
                        <span className="w-2 h-2 bg-white rounded-full" />
                        <span>Primary Call to Action</span>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[11px] font-mono text-neutral-400 block">Button Label</label>
                        <input
                          type="text"
                          value={editingSlide.primaryCtaText}
                          onChange={(e) => updateCurrentSlide({ primaryCtaText: e.target.value })}
                          placeholder="Explore Garments"
                          className="w-full bg-black border border-neutral-700 px-3 py-2 text-xs text-white font-mono focus:border-white focus:outline-hidden"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[11px] font-mono text-neutral-400 block">Destination Page View</label>
                        <select
                          value={editingSlide.primaryCtaTarget}
                          onChange={(e) => updateCurrentSlide({ primaryCtaTarget: e.target.value })}
                          className="w-full bg-black border border-neutral-700 px-3 py-2 text-xs text-white font-mono focus:border-white focus:outline-hidden"
                        >
                          {PAGE_TARGET_OPTIONS.map((opt) => (
                            <option key={opt.value} value={opt.value}>
                              {opt.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Secondary Button */}
                    <div className="bg-[#101010] p-4 border border-[#2a2a2a] space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 text-xs font-mono text-white font-bold uppercase tracking-wider">
                          <span className="w-2 h-2 bg-neutral-500 rounded-full" />
                          <span>Secondary Call to Action</span>
                        </div>
                        <label className="flex items-center space-x-2 text-xs font-mono text-neutral-400 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={editingSlide.showSecondaryCta !== false}
                            onChange={(e) => updateCurrentSlide({ showSecondaryCta: e.target.checked })}
                            className="rounded-xs"
                          />
                          <span>Show Button</span>
                        </label>
                      </div>

                      {editingSlide.showSecondaryCta !== false ? (
                        <>
                          <div className="space-y-1.5">
                            <label className="text-[11px] font-mono text-neutral-400 block">Button Label</label>
                            <input
                              type="text"
                              value={editingSlide.secondaryCtaText || 'Why We Exist'}
                              onChange={(e) => updateCurrentSlide({ secondaryCtaText: e.target.value })}
                              placeholder="Why We Exist"
                              className="w-full bg-black border border-neutral-700 px-3 py-2 text-xs text-white font-mono focus:border-white focus:outline-hidden"
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[11px] font-mono text-neutral-400 block">Destination Page View</label>
                            <select
                              value={editingSlide.secondaryCtaTarget || 'why-we-exist'}
                              onChange={(e) => updateCurrentSlide({ secondaryCtaTarget: e.target.value })}
                              className="w-full bg-black border border-neutral-700 px-3 py-2 text-xs text-white font-mono focus:border-white focus:outline-hidden"
                            >
                              {PAGE_TARGET_OPTIONS.map((opt) => (
                                <option key={opt.value} value={opt.value}>
                                  {opt.label}
                                </option>
                              ))}
                            </select>
                          </div>
                        </>
                      ) : (
                        <p className="text-xs text-neutral-500 font-sans italic py-4">
                          Secondary button is hidden for this slide.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: ATMOSPHERE & MOOD */}
              {activeEditorTab === 'atmosphere' && (
                <div className="space-y-6 animate-in fade-in duration-150">
                  <div>
                    <h3 className="text-white font-serif text-lg">Atmosphere, Color Mood & Scrim</h3>
                    <p className="text-xs text-neutral-400 font-sans mt-0.5">
                      Control the lighting blooms, contrast overlay, and mood coloring for this slide.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Color Mood */}
                    <div className="space-y-2">
                      <label className="text-xs font-mono uppercase text-neutral-300 block">
                        Ambient Color Mood
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: 'noir-black', name: 'Noir Black', hex: '#d4d4d4' },
                          { id: 'golden-amber', name: 'Golden Amber', hex: '#f59e0b' },
                          { id: 'terracotta-sunset', name: 'Terracotta Sunset', hex: '#ea580c' },
                          { id: 'twilight-indigo', name: 'Twilight Indigo', hex: '#6366f1' },
                          { id: 'emerald-moss', name: 'Emerald Moss', hex: '#10b981' },
                          { id: 'natural-monochrome', name: 'Natural Monochrome', hex: '#a3a3a3' },
                        ].map((mood) => {
                          const isSelected = (editingSlide.colorMood || 'golden-amber') === mood.id;
                          return (
                            <button
                              key={mood.id}
                              type="button"
                              onClick={() =>
                                updateCurrentSlide({
                                  colorMood: mood.id as any,
                                  accentHex: mood.hex,
                                })
                              }
                              className={`p-3 border text-left flex items-center justify-between transition-colors cursor-pointer ${
                                isSelected
                                  ? 'bg-neutral-800 border-white text-white'
                                  : 'bg-black border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-600'
                              }`}
                            >
                              <div className="flex items-center space-x-2">
                                <span
                                  className="w-3 h-3 rounded-full"
                                  style={{ backgroundColor: mood.hex }}
                                />
                                <span className="text-xs font-mono">{mood.name}</span>
                              </div>
                              {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Scrim Opacity Slider & Overlay Color */}
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs font-mono">
                          <span className="text-neutral-300 uppercase">Image Overlay Darkness</span>
                          <span className="text-white font-bold">
                            {Math.round(((editingSlide.overlayOpacity ?? 0.55) as number) * 100)}%
                          </span>
                        </div>
                        <input
                          type="range"
                          min={0.1}
                          max={0.9}
                          step={0.05}
                          value={editingSlide.overlayOpacity ?? 0.55}
                          onChange={(e) => updateCurrentSlide({ overlayOpacity: parseFloat(e.target.value) })}
                          className="w-full accent-white cursor-pointer"
                        />
                        <div className="flex justify-between text-[10px] font-mono text-neutral-500">
                          <span>10% (Bright photo)</span>
                          <span>55% (Recommended)</span>
                          <span>90% (Deep dark)</span>
                        </div>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-[#262626]">
                        <label className="text-xs font-mono uppercase text-neutral-300 block">
                          Overlay Scrim Base Color
                        </label>
                        <div className="flex flex-wrap items-center gap-2">
                          {OVERLAY_COLOR_PRESETS.map((col) => (
                            <button
                              key={col.hex}
                              type="button"
                              onClick={() => updateCurrentSlide({ overlayColor: col.hex })}
                              className={`px-2.5 py-1 text-xs font-mono border flex items-center gap-1.5 transition-colors cursor-pointer ${
                                (editingSlide.overlayColor || '#0a0a0a') === col.hex
                                  ? 'border-white text-white bg-neutral-800'
                                  : 'border-neutral-800 text-neutral-400 hover:text-white'
                              }`}
                            >
                              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: col.hex }} />
                              <span>{col.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: TRANSITION DIVIDER */}
              {activeEditorTab === 'divider' && (
                <div className="space-y-6 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-white font-serif text-lg">Architectural Shape Divider</h3>
                      <p className="text-xs text-neutral-400 font-sans mt-0.5">
                        Seamlessly blends the base of the hero carousel into the next page section.
                      </p>
                    </div>
                    <label className="flex items-center space-x-2 text-xs font-mono text-neutral-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={shapeDividerEnabled}
                        onChange={(e) => setShapeDividerEnabled(e.target.checked)}
                        className="rounded-xs"
                      />
                      <span>Enable Divider</span>
                    </label>
                  </div>

                  {shapeDividerEnabled ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                      <div className="space-y-2">
                        <label className="text-xs font-mono uppercase text-neutral-300 block">
                          Divider Geometry Variant
                        </label>
                        <div className="space-y-1.5">
                          {[
                            { id: 'editorial-notch', name: 'Editorial Notch (Architectural Inset)' },
                            { id: 'parabolic-arch', name: 'Parabolic Arch (Smooth Curved Dome)' },
                            { id: 'organic-swell', name: 'Organic Swell (Natural Fluid Contour)' },
                            { id: 'subtle-crest', name: 'Subtle Crest (Soft Convex Rise)' },
                            { id: 'zebra-contour', name: 'Zebra Contour (Smooth Fluid Curves)' },
                            { id: 'textile-seam', name: 'Textile Seam (Stitched Fabric Hem)' },
                            { id: 'horizon-converge', name: 'Horizon Converge (Minimalist Diagonal)' },
                            { id: 'asymmetric-slash', name: 'Asymmetric Slash (Modern Dynamic Cut)' },
                          ].map((shape) => {
                            const isSelected = shapeDividerVariant === shape.id;
                            return (
                              <button
                                key={shape.id}
                                type="button"
                                onClick={() => setShapeDividerVariant(shape.id as any)}
                                className={`w-full p-2.5 border text-left text-xs font-mono flex items-center justify-between transition-colors cursor-pointer ${
                                  isSelected
                                    ? 'bg-neutral-800 border-white text-white font-bold'
                                    : 'bg-black border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-600'
                                }`}
                              >
                                <span>{shape.name}</span>
                                {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs font-mono">
                            <span className="text-neutral-300 uppercase">Divider Height</span>
                            <span className="text-white font-bold">{shapeDividerHeight}px</span>
                          </div>
                          <input
                            type="range"
                            min={32}
                            max={120}
                            step={4}
                            value={shapeDividerHeight}
                            onChange={(e) => setShapeDividerHeight(parseInt(e.target.value))}
                            className="w-full accent-white cursor-pointer"
                          />
                        </div>

                        <div className="p-4 bg-black border border-neutral-800 text-xs font-mono text-neutral-400 space-y-1">
                          <span className="text-white font-bold block">Preview Note:</span>
                          <p>
                            Shape dividers automatically adopt the background color of the storefront container for an organic, gapless transition.
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-neutral-500 font-sans italic py-4">
                      Shape divider is currently turned off. The hero will end with a standard clean horizontal edge.
                    </p>
                  )}
                </div>
              )}

              {/* TAB 6: CONTROLS & DISPLAY SYSTEM */}
              {activeEditorTab === 'controls' && (
                <div className="space-y-8 animate-in fade-in duration-150">
                  <div>
                    <h3 className="text-white font-serif text-lg">Hero Controls & Navigation System</h3>
                    <p className="text-xs text-neutral-400 font-sans mt-0.5">
                      Configure the storefront navigation controls, chapter switcher style, kicker badge appearance, and carousel autoplay dynamics.
                    </p>
                  </div>

                  {/* 3 Control Styles Selector Cards */}
                  <div className="space-y-3">
                    <label className="text-xs font-mono uppercase text-neutral-300 block">
                      Select Controls & Navigation Style
                    </label>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Option 1: Former Classic Architectural */}
                      <div
                        onClick={() => {
                          setHeroControlsStyle('minimal-editorial');
                          showToast('Switched to Former Classic Architectural controls.');
                        }}
                        className={`p-4 border text-left space-y-3 cursor-pointer transition-all relative ${
                          heroControlsStyle === 'minimal-editorial'
                            ? 'bg-neutral-900 border-white text-white shadow-lg'
                            : 'bg-black border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                        }`}
                      >
                        {heroControlsStyle === 'minimal-editorial' && (
                          <span className="absolute top-3 right-3 px-2 py-0.5 bg-white text-black text-[9px] font-mono uppercase font-bold tracking-wider">
                            Active
                          </span>
                        )}
                        <div className="space-y-1">
                          <h4 className="font-serif text-sm font-bold text-white">Former Classic / Architectural</h4>
                          <p className="text-[11px] font-sans text-neutral-400 leading-relaxed">
                            Understated, quiet studio layout. Discrete chapter tabs, numbered counter (01 / 04), sleek corner chevrons, and minimal serif/monospaced kicker.
                          </p>
                        </div>
                        {/* Mini Visual Preview */}
                        <div className="p-3 bg-neutral-950 border border-neutral-800 space-y-2 text-[10px] font-mono">
                          <div className="text-neutral-400 tracking-widest text-[9px]">CHAPTER 01 · THE THRESHOLD</div>
                          <div className="flex items-center justify-between border-t border-neutral-800 pt-2 text-neutral-400">
                            <span className="text-white font-bold">01 / 04</span>
                            <div className="flex space-x-2 text-[9px]">
                              <span className="border-b border-white text-white">01</span>
                              <span className="opacity-50">02</span>
                              <span className="opacity-50">03</span>
                            </div>
                            <span className="text-neutral-500">‹ ›</span>
                          </div>
                        </div>
                      </div>

                      {/* Option 2: Interactive Capsule */}
                      <div
                        onClick={() => {
                          setHeroControlsStyle('interactive-capsule');
                          showToast('Switched to Interactive Floating Capsule controls.');
                        }}
                        className={`p-4 border text-left space-y-3 cursor-pointer transition-all relative ${
                          heroControlsStyle === 'interactive-capsule'
                            ? 'bg-neutral-900 border-white text-white shadow-lg'
                            : 'bg-black border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                        }`}
                      >
                        {heroControlsStyle === 'interactive-capsule' && (
                          <span className="absolute top-3 right-3 px-2 py-0.5 bg-white text-black text-[9px] font-mono uppercase font-bold tracking-wider">
                            Active
                          </span>
                        )}
                        <div className="space-y-1">
                          <h4 className="font-serif text-sm font-bold text-white">Interactive Floating Capsule</h4>
                          <p className="text-[11px] font-sans text-neutral-400 leading-relaxed">
                            Modern capsule pill kicker with live pulse dot, floating circular side chevrons, and bottom floating chapter pill dock with play/pause counter.
                          </p>
                        </div>
                        {/* Mini Visual Preview */}
                        <div className="p-3 bg-neutral-950 border border-neutral-800 space-y-2 text-[10px] font-mono text-center">
                          <div className="inline-block px-2 py-0.5 rounded-full border border-white/20 bg-white/10 text-white text-[9px]">
                            ● 01 / The Threshold
                          </div>
                          <div className="flex items-center justify-center pt-1">
                            <div className="px-3 py-1 rounded-full bg-white/20 border border-white/30 text-[9px] text-white">
                              ( 01 ) ( 02 ) ( 03 )
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Option 3: Numbered Pagination */}
                      <div
                        onClick={() => {
                          setHeroControlsStyle('numbered-pagination');
                          showToast('Switched to Numbered Minimal Tabs.');
                        }}
                        className={`p-4 border text-left space-y-3 cursor-pointer transition-all relative ${
                          heroControlsStyle === 'numbered-pagination'
                            ? 'bg-neutral-900 border-white text-white shadow-lg'
                            : 'bg-black border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                        }`}
                      >
                        {heroControlsStyle === 'numbered-pagination' && (
                          <span className="absolute top-3 right-3 px-2 py-0.5 bg-white text-black text-[9px] font-mono uppercase font-bold tracking-wider">
                            Active
                          </span>
                        )}
                        <div className="space-y-1">
                          <h4 className="font-serif text-sm font-bold text-white">Numbered Minimalist Tabs</h4>
                          <p className="text-[11px] font-sans text-neutral-400 leading-relaxed">
                            Ultra-clean numbered badges `[ 01 ]` `[ 02 ]` `[ 03 ]` `[ 04 ]` positioned cleanly along the bottom base with smooth transition highlights.
                          </p>
                        </div>
                        {/* Mini Visual Preview */}
                        <div className="p-3 bg-neutral-950 border border-neutral-800 space-y-2 text-[10px] font-mono text-center">
                          <div className="text-neutral-400 text-[9px]">CHAPTER INQUIRY 01</div>
                          <div className="flex justify-center space-x-1.5 pt-1 text-[9px]">
                            <span className="px-1.5 py-0.5 bg-white text-black font-bold">01</span>
                            <span className="px-1.5 py-0.5 border border-neutral-700 text-neutral-400">02</span>
                            <span className="px-1.5 py-0.5 border border-neutral-700 text-neutral-400">03</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Autoplay Interval & Carousel Controls */}
                  <div className="p-6 bg-black border border-neutral-800 space-y-6">
                    <h4 className="text-xs uppercase font-mono tracking-wider text-neutral-300 font-bold">
                      Carousel Timing & Animation Dynamics
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs font-mono">
                      <div className="space-y-2">
                        <label className="text-neutral-400 block">Autoplay Transition Speed</label>
                        <select
                          value={heroAutoplayIntervalMs}
                          onChange={(e) => setHeroAutoplayIntervalMs(parseInt(e.target.value))}
                          className="w-full bg-[#111] border border-neutral-700 text-white p-2.5 text-xs font-mono"
                        >
                          <option value="4000">4 Seconds (Fast Pace)</option>
                          <option value="6000">6 Seconds (Standard Dynamic)</option>
                          <option value="7500">7.5 Seconds (Recommended Editorial)</option>
                          <option value="10000">10 Seconds (Relaxed Contemplative)</option>
                          <option value="14000">14 Seconds (Slow Reading)</option>
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-neutral-400 block">Display Mode</label>
                        <select
                          value={heroMode}
                          onChange={(e) => setHeroMode(e.target.value as any)}
                          className="w-full bg-[#111] border border-neutral-700 text-white p-2.5 text-xs font-mono"
                        >
                          <option value="carousel">Multi-Slide Carousel (Autoplay Enabled)</option>
                          <option value="static">Single Static Focus Hero (Slide 1 Only)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Editor Footer Action Bar */}
            <div className="p-4 bg-[#0d0d0d] border-t border-[#262626] flex items-center justify-between">
              <button
                type="button"
                onClick={() => setStudioMode('overview')}
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 text-xs font-mono uppercase tracking-wider cursor-pointer"
              >
                Done Editing (Return to Deck)
              </button>

              <div className="flex items-center space-x-2">
                <Button
                  onClick={handleSaveAndPublishAll}
                  variant="secondary"
                  size="md"
                  className="bg-white text-black hover:bg-neutral-200 text-xs font-mono uppercase font-bold cursor-pointer"
                >
                  <Check className="w-4 h-4 mr-1.5" />
                  <span>Save & Publish All Slides</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
