import React, { useState } from 'react';
import {
  CreditCard,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Activity,
  Key,
  Eye,
  EyeOff,
  Copy,
  Check,
  ExternalLink,
  Download,
  Lock,
  RefreshCw,
  Zap,
  Sliders
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { PaymentStatusBadge, getPaymentConnectionStatus } from './PaymentStatusBadge';
import { Button } from '../ui/Button';
import { safeFetchJson } from '../../lib/api';
import { StripeConnectShowcase } from '../stripe/StripeConnectShowcase';

interface ApiTestResult {
  provider: string;
  status: 'testing' | 'success' | 'error';
  message: string;
  latencyMs?: number;
  details?: string[];
}

export const PaymentGatewaysCMS: React.FC<{ showToast: (msg: string) => void }> = ({ showToast }) => {
  const { content, updateContent } = useContent();

  // ==========================================
  // PAYMENT INTEGRATIONS DETAILS & CREDENTIALS
  // ==========================================
  // 1. Stripe
  const [stripeEnabled, setStripeEnabled] = useState(content.stripeEnabled !== false);
  const [stripePublishableKey, setStripePublishableKey] = useState(content.stripePublishableKey || '');
  const [stripeSecretKey, setStripeSecretKey] = useState(content.stripeSecretKey || '');
  const [stripeWebhookSecret, setStripeWebhookSecret] = useState(content.stripeWebhookSecret || '');
  const [stripeStatementDescriptor, setStripeStatementDescriptor] = useState(content.stripeStatementDescriptor || 'EZISTENTIAL');
  const [stripeLiveMode, setStripeLiveMode] = useState(content.stripeLiveMode || false);
  const [showStripeConnect, setShowStripeConnect] = useState(false);

  // 2. PayPal
  const [paypalEnabled, setPaypalEnabled] = useState(content.paypalEnabled || false);
  const [paypalClientId, setPaypalClientId] = useState(content.paypalClientId || '');
  const [paypalSecretKey, setPaypalSecretKey] = useState(content.paypalSecretKey || '');
  const [paypalWebhookId, setPaypalWebhookId] = useState(content.paypalWebhookId || '');
  const [paypalEnvironment, setPaypalEnvironment] = useState<'sandbox' | 'production'>(content.paypalEnvironment || 'sandbox');
  const [paypalPayIn4Enabled, setPaypalPayIn4Enabled] = useState(content.paypalPayIn4Enabled || false);

  // 3. Apple Pay
  const [applePayEnabled, setApplePayEnabled] = useState(content.applePayEnabled || false);
  const [applePayMerchantId, setApplePayMerchantId] = useState(content.applePayMerchantId || '');
  const [applePayDomainName, setApplePayDomainName] = useState(content.applePayDomainName || '');
  const [applePayCertStatus, setApplePayCertStatus] = useState<'verified' | 'pending' | 'unverified'>(content.applePayCertStatus || 'unverified');

  // 4. Google Pay
  const [googlePayEnabled, setGooglePayEnabled] = useState(content.googlePayEnabled || false);
  const [googlePayMerchantId, setGooglePayMerchantId] = useState(content.googlePayMerchantId || '');
  const [googlePayGatewayMerchantId, setGooglePayGatewayMerchantId] = useState(content.googlePayGatewayMerchantId || '');
  const [googlePayEnvironment, setGooglePayEnvironment] = useState<'TEST' | 'PRODUCTION'>(content.googlePayEnvironment || 'TEST');

  // 5. Klarna
  const [klarnaEnabled, setKlarnaEnabled] = useState(content.klarnaEnabled || false);
  const [klarnaClientId, setKlarnaClientId] = useState(content.klarnaClientId || '');
  const [klarnaClientSecret, setKlarnaClientSecret] = useState(content.klarnaClientSecret || '');
  const [klarnaRegion, setKlarnaRegion] = useState(content.klarnaRegion || 'US');

  // 6. Afterpay
  const [afterpayEnabled, setAfterpayEnabled] = useState(content.afterpayEnabled || false);
  const [afterpayMerchantId, setAfterpayMerchantId] = useState(content.afterpayMerchantId || '');
  const [afterpaySecretKey, setAfterpaySecretKey] = useState(content.afterpaySecretKey || '');
  const [afterpayRegion, setAfterpayRegion] = useState(content.afterpayRegion || 'US');

  // 7. Cash App Pay
  const [cashAppPayEnabled, setCashAppPayEnabled] = useState(content.cashAppPayEnabled || false);
  const [cashAppCashtag, setCashAppCashtag] = useState(content.cashAppCashtag || '');
  const [cashAppClientId, setCashAppClientId] = useState(content.cashAppClientId || '');
  const [cashAppWebhookSecret, setCashAppWebhookSecret] = useState(content.cashAppWebhookSecret || '');

  // 8. Shop Pay
  const [shopPayEnabled, setShopPayEnabled] = useState(content.shopPayEnabled || false);
  const [shopPayStorefrontToken, setShopPayStorefrontToken] = useState(content.shopPayStorefrontToken || '');
  const [shopPayDomain, setShopPayDomain] = useState(content.shopPayDomain || '');

  // Password Visibility Toggles
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const toggleSecret = (key: string) => {
    setShowSecrets((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Immediate toggle helper so changes take effect without needing manual save
  const handleToggleGateway = (field: string, value: boolean, label: string) => {
    if (field === 'stripeEnabled') setStripeEnabled(value);
    if (field === 'paypalEnabled') setPaypalEnabled(value);
    if (field === 'paypalPayIn4Enabled') setPaypalPayIn4Enabled(value);
    if (field === 'applePayEnabled') setApplePayEnabled(value);
    if (field === 'googlePayEnabled') setGooglePayEnabled(value);
    if (field === 'klarnaEnabled') setKlarnaEnabled(value);
    if (field === 'afterpayEnabled') setAfterpayEnabled(value);
    if (field === 'cashAppPayEnabled') setCashAppPayEnabled(value);
    if (field === 'shopPayEnabled') setShopPayEnabled(value);

    updateContent({ [field]: value });
    showToast(`${label} ${value ? 'turned ON' : 'turned OFF'} across store.`);
  };

  // API Health/Testing States
  const [apiTests, setApiTests] = useState<Record<string, ApiTestResult>>({});
  const [copiedCard, setCopiedCard] = useState<string | null>(null);

  // Live Gateway Content Helper for Status Badges
  const currentGatewayContent = {
    ...content,
    stripeEnabled,
    stripePublishableKey,
    stripeSecretKey,
    stripeWebhookSecret,
    stripeLiveMode,
    paypalEnabled,
    paypalClientId,
    paypalSecretKey,
    paypalEnvironment,
    paypalPayIn4Enabled,
    applePayEnabled,
    applePayMerchantId,
    applePayDomainName,
    applePayCertStatus,
    googlePayEnabled,
    googlePayMerchantId,
    googlePayGatewayMerchantId,
    googlePayEnvironment,
    klarnaEnabled,
    klarnaClientId,
    klarnaClientSecret,
    klarnaRegion,
    afterpayEnabled,
    afterpayMerchantId,
    afterpaySecretKey,
    afterpayRegion,
    cashAppPayEnabled,
    cashAppCashtag,
    cashAppClientId,
    shopPayEnabled,
    shopPayStorefrontToken,
    shopPayDomain,
  };

  const connectedCount = [
    'stripe',
    'paypal',
    'apple_pay',
    'google_pay',
    'klarna',
    'afterpay',
    'cashapp',
    'shoppay',
  ].filter((p) => getPaymentConnectionStatus(p as any, currentGatewayContent).status === 'Connected').length;

  const handleTestApi = async (provider: string) => {
    setApiTests((prev) => ({
      ...prev,
      [provider]: {
        provider,
        status: 'testing',
        message: `Querying live ${provider} API server endpoint...`,
      },
    }));

    let credentialsPayload: any = {};
    if (provider === 'stripe') {
      credentialsPayload = {
        publishableKey: stripePublishableKey,
        secretKey: stripeSecretKey,
        liveMode: stripeLiveMode,
      };
    } else if (provider === 'paypal') {
      credentialsPayload = {
        clientId: paypalClientId,
        secretKey: paypalSecretKey,
        environment: paypalEnvironment,
      };
    } else if (provider === 'apple_pay') {
      credentialsPayload = {
        merchantId: applePayMerchantId,
        domainName: applePayDomainName,
      };
    } else if (provider === 'google_pay') {
      credentialsPayload = {
        merchantId: googlePayMerchantId,
        gatewayMerchantId: googlePayGatewayMerchantId,
        environment: googlePayEnvironment,
      };
    } else if (provider === 'klarna') {
      credentialsPayload = {
        clientId: klarnaClientId,
        clientSecret: klarnaClientSecret,
        region: klarnaRegion,
      };
    } else if (provider === 'afterpay') {
      credentialsPayload = {
        merchantId: afterpayMerchantId,
        secretKey: afterpaySecretKey,
        region: afterpayRegion,
      };
    } else if (provider === 'cashapp') {
      credentialsPayload = {
        cashtag: cashAppCashtag,
        clientId: cashAppClientId,
      };
    } else if (provider === 'shoppay') {
      credentialsPayload = {
        storefrontToken: shopPayStorefrontToken,
        domain: shopPayDomain,
      };
    }

    try {
      const data = await safeFetchJson<any>('/api/payment-gateways/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          credentials: credentialsPayload,
        }),
      });

      if (data && data.success) {
        setApiTests((prev) => ({
          ...prev,
          [provider]: {
            provider,
            status: 'success',
            message: data.message || `Successfully connected to ${data.provider || provider} gateway.`,
            latencyMs: data.latencyMs,
            details: data.details,
          },
        }));

        if (provider === 'apple_pay') {
          setApplePayCertStatus('verified');
        }

        showToast(`${provider.toUpperCase()} cryptographic handshake verified (${data.latencyMs || 42}ms)`);
      } else {
        setApiTests((prev) => ({
          ...prev,
          [provider]: {
            provider,
            status: 'error',
            message: data?.error || 'Gateway rejected credentials. Verify keys or sandbox settings.',
          },
        }));
      }
    } catch (err: any) {
      setApiTests((prev) => ({
        ...prev,
        [provider]: {
          provider,
          status: 'error',
          message: `Network error reaching gateway verification server: ${err.message}`,
        },
      }));
    }
  };

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      stripeEnabled,
      stripePublishableKey: stripePublishableKey.trim(),
      stripeSecretKey: stripeSecretKey.trim(),
      stripeWebhookSecret: stripeWebhookSecret.trim(),
      stripeStatementDescriptor: stripeStatementDescriptor.trim(),
      stripeLiveMode,
      paypalEnabled,
      paypalClientId: paypalClientId.trim(),
      paypalSecretKey: paypalSecretKey.trim(),
      paypalWebhookId: paypalWebhookId.trim(),
      paypalEnvironment,
      paypalPayIn4Enabled,
      applePayEnabled,
      applePayMerchantId: applePayMerchantId.trim(),
      applePayDomainName: applePayDomainName.trim(),
      applePayCertStatus,
      googlePayEnabled,
      googlePayMerchantId: googlePayMerchantId.trim(),
      googlePayGatewayMerchantId: googlePayGatewayMerchantId.trim(),
      googlePayEnvironment,
      klarnaEnabled,
      klarnaClientId: klarnaClientId.trim(),
      klarnaClientSecret: klarnaClientSecret.trim(),
      klarnaRegion,
      afterpayEnabled,
      afterpayMerchantId: afterpayMerchantId.trim(),
      afterpaySecretKey: afterpaySecretKey.trim(),
      afterpayRegion,
      cashAppPayEnabled,
      cashAppCashtag: cashAppCashtag.trim(),
      cashAppClientId: cashAppClientId.trim(),
      cashAppWebhookSecret: cashAppWebhookSecret.trim(),
      shopPayEnabled,
      shopPayStorefrontToken: shopPayStorefrontToken.trim(),
      shopPayDomain: shopPayDomain.trim(),
    });

    showToast('All Payment Gateways, API keys, and environment settings saved globally!');
  };

  const copyTestCard = (num: string) => {
    navigator.clipboard?.writeText(num);
    setCopiedCard(num);
    showToast(`Test card ${num} copied to clipboard`);
    setTimeout(() => setCopiedCard(null), 2500);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* GLOBAL PAYMENT GATEWAYS HEALTH MATRIX */}
      <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-100 pb-4 gap-4">
          <div>
            <h3 className="font-serif text-lg font-bold text-neutral-900 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <span>Payment Gateway Integration & Encryption Keys</span>
            </h3>
            <p className="text-xs text-neutral-500 font-sans mt-0.5">
              Live cryptographic credentials, test sandbox toggles, and real-time connectivity status across all 8 supported payment networks.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-300 font-mono text-xs font-bold">
              {connectedCount} of 8 Networks Connected
            </span>
            <Button type="button" onClick={handleSaveAll} variant="primary" size="sm" className="bg-black text-white hover:bg-neutral-800">
              Save All Gateways
            </Button>
          </div>
        </div>

        {/* 8-Network Grid Matrix */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { id: 'stripe', name: 'Stripe Cards', icon: '💳' },
            { id: 'paypal', name: 'PayPal & 4x', icon: '🅿️' },
            { id: 'apple_pay', name: 'Apple Pay', icon: '' },
            { id: 'google_pay', name: 'Google Pay', icon: 'G' },
            { id: 'klarna', name: 'Klarna BNPL', icon: 'K' },
            { id: 'afterpay', name: 'Afterpay', icon: '▲' },
            { id: 'cashapp', name: 'Cash App', icon: '$' },
            { id: 'shoppay', name: 'Shop Pay', icon: '🛍️' },
          ].map((gw) => (
            <div key={gw.id} className="p-3.5 bg-neutral-50 border border-neutral-200 rounded-xs space-y-2 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="font-serif text-xs font-bold text-neutral-900 flex items-center gap-1.5">
                  <span>{gw.icon}</span>
                  <span>{gw.name}</span>
                </span>
              </div>
              <div>
                <PaymentStatusBadge provider={gw.id as any} content={currentGatewayContent} size="sm" showSublabel={false} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ======================================================== */}
      {/* 1. STRIPE CARD PROCESSING */}
      {/* ======================================================== */}
      <div className={`border p-6 space-y-5 transition-all ${stripeEnabled ? 'border-neutral-300 bg-white shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-80'}`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-200 pb-4 gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center font-bold text-sm">
              S
            </div>
            <div>
              <h3 className="font-serif text-lg font-bold text-neutral-900">1. Stripe Payment Gateway</h3>
              <p className="text-xs text-neutral-500">Credit & Debit cards (Visa, Mastercard, Amex, Discover, JCB)</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <PaymentStatusBadge provider="stripe" content={currentGatewayContent} size="md" />
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={stripeEnabled}
                onChange={(e) => handleToggleGateway('stripeEnabled', e.target.checked, 'Stripe Card Processing')}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
              Stripe Publishable Key *
            </label>
            <input
              type="text"
              value={stripePublishableKey}
              onChange={(e) => setStripePublishableKey(e.target.value)}
              placeholder="pk_live_... or pk_test_..."
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
            />
            <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">Client-side checkout encryption token</span>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs uppercase font-mono text-neutral-700 font-medium">
                Stripe Secret API Key *
              </label>
              <button
                type="button"
                onClick={() => toggleSecret('stripeSecret')}
                className="text-[11px] text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer font-mono"
              >
                {showSecrets['stripeSecret'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 text-neutral-600" />}
                <span>{showSecrets['stripeSecret'] ? 'Hide' : 'Show'}</span>
              </button>
            </div>
            <input
              type={showSecrets['stripeSecret'] ? 'text' : 'password'}
              value={stripeSecretKey}
              onChange={(e) => setStripeSecretKey(e.target.value)}
              placeholder="sk_live_... or sk_test_..."
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
            />
            <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">Server proxy token for charge creation</span>
          </div>

          <div>
            <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
              Stripe Webhook Signing Secret
            </label>
            <input
              type="text"
              value={stripeWebhookSecret}
              onChange={(e) => setStripeWebhookSecret(e.target.value)}
              placeholder="whsec_..."
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
            />
            <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">Used to verify asynchronous webhooks at /api/webhooks/stripe</span>
          </div>

          <div>
            <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
              Statement Descriptor (Credit Card Statement)
            </label>
            <input
              type="text"
              value={stripeStatementDescriptor}
              onChange={(e) => setStripeStatementDescriptor(e.target.value)}
              placeholder="EZISTENTIAL"
              maxLength={22}
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 uppercase focus:border-black focus:outline-hidden"
            />
            <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">Max 22 characters shown on bank statements</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-3 border-t border-neutral-100 gap-3">
          <label className="flex items-center space-x-2 text-xs font-mono cursor-pointer">
            <input
              type="checkbox"
              checked={stripeLiveMode}
              onChange={(e) => setStripeLiveMode(e.target.checked)}
              className="rounded-xs border-neutral-300 text-black focus:ring-black"
            />
            <span className="font-semibold text-neutral-900">Enable Live Production Mode</span>
            <span className={`text-[10px] px-2 py-0.5 border font-bold ${stripeLiveMode ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-amber-100 text-amber-800 border-amber-300'}`}>
              {stripeLiveMode ? 'REAL MONEY CHARGES' : 'TEST SANDBOX'}
            </span>
          </label>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => copyTestCard('4242 4242 4242 4242')}
              className="text-xs font-mono text-neutral-600 hover:text-black flex items-center gap-1 border border-neutral-200 px-2 py-1 bg-neutral-50"
            >
              {copiedCard === '4242 4242 4242 4242' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
              <span>Test Card: 4242...</span>
            </button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => handleTestApi('stripe')}
              disabled={apiTests['stripe']?.status === 'testing'}
              className="flex items-center gap-1.5"
            >
              <Activity className="w-3.5 h-3.5 text-emerald-600" />
              <span>{apiTests['stripe']?.status === 'testing' ? 'Verifying...' : 'Test Stripe API Connection'}</span>
            </Button>
          </div>
        </div>

        {/* Live Test Status Feedback */}
        {apiTests['stripe'] && (
          <div className={`p-4 border text-xs font-mono space-y-2 animate-in fade-in duration-200 ${apiTests['stripe'].status === 'success' ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : apiTests['stripe'].status === 'error' ? 'bg-red-50 border-red-300 text-red-900' : 'bg-neutral-50 border-neutral-300 text-neutral-700'}`}>
            <div className="flex items-center justify-between font-bold">
              <span className="flex items-center gap-1.5">
                {apiTests['stripe'].status === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-red-600" />}
                <span>{apiTests['stripe'].message}</span>
              </span>
              {apiTests['stripe'].latencyMs && <span className="text-[10px] text-neutral-500">{apiTests['stripe'].latencyMs}ms latency</span>}
            </div>
            {apiTests['stripe'].details && (
              <ul className="list-disc list-inside text-[11px] text-neutral-600 space-y-0.5 pt-1">
                {apiTests['stripe'].details?.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </ul>
            )}
          </div>
        )}

        {/* Embedded Stripe Connect V2 Suite Showcase */}
        <div className="pt-4 border-t border-neutral-200">
          <div className="bg-neutral-900 text-white p-4 rounded-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-emerald-400" />
                <h4 className="font-serif font-bold text-sm">Stripe Connect V2 Marketplace Suite</h4>
              </div>
              <p className="text-xs text-neutral-300 font-light mt-0.5">
                Onboard merchants, list platform products, inspect requirements via API, & process destination charges.
              </p>
            </div>
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setShowStripeConnect(!showStripeConnect)}
              className="whitespace-nowrap font-mono text-xs"
            >
              {showStripeConnect ? 'Hide Connect Suite' : 'Launch Connect Suite'}
            </Button>
          </div>

          {showStripeConnect && (
            <div className="mt-6 p-4 bg-neutral-50 border border-neutral-300 rounded-md animate-in fade-in duration-300">
              <StripeConnectShowcase />
            </div>
          )}
        </div>
      </div>

      {/* ======================================================== */}
      {/* 2. PAYPAL & PAY IN 4 */}
      {/* ======================================================== */}
      <div className={`border p-6 space-y-5 transition-all ${paypalEnabled ? 'border-neutral-300 bg-white shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-80'}`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-200 pb-4 gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-full bg-[#003087] text-white flex items-center justify-center font-bold text-sm">
              P
            </div>
            <div>
              <h3 className="font-serif text-lg font-bold text-neutral-900">2. PayPal & PayPal Pay in 4</h3>
              <p className="text-xs text-neutral-500">PayPal Wallet, Venmo, and 4-installment interest-free financing</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <PaymentStatusBadge provider="paypal" content={currentGatewayContent} size="md" />
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={paypalEnabled}
                onChange={(e) => handleToggleGateway('paypalEnabled', e.target.checked, 'PayPal Gateway')}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#003087]"></div>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
              PayPal Client ID *
            </label>
            <input
              type="text"
              value={paypalClientId}
              onChange={(e) => setPaypalClientId(e.target.value)}
              placeholder="AaBbCcDdEeFf..."
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs uppercase font-mono text-neutral-700 font-medium">
                PayPal Secret Key *
              </label>
              <button
                type="button"
                onClick={() => toggleSecret('paypalSecret')}
                className="text-[11px] text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer font-mono"
              >
                {showSecrets['paypalSecret'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 text-neutral-600" />}
                <span>{showSecrets['paypalSecret'] ? 'Hide' : 'Show'}</span>
              </button>
            </div>
            <input
              type={showSecrets['paypalSecret'] ? 'text' : 'password'}
              value={paypalSecretKey}
              onChange={(e) => setPaypalSecretKey(e.target.value)}
              placeholder="••••••••••••"
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
              PayPal Webhook ID
            </label>
            <input
              type="text"
              value={paypalWebhookId}
              onChange={(e) => setPaypalWebhookId(e.target.value)}
              placeholder="9JH20149021481"
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
              Environment Mode
            </label>
            <select
              value={paypalEnvironment}
              onChange={(e) => setPaypalEnvironment(e.target.value as any)}
              className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 cursor-pointer focus:border-black focus:outline-hidden"
            >
              <option value="sandbox">Sandbox (Testing / Simulator)</option>
              <option value="production">Production (Real Transactions)</option>
            </select>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-3 border-t border-neutral-100 gap-3">
          <label className="flex items-center space-x-2 text-xs font-mono cursor-pointer">
            <input
              type="checkbox"
              checked={paypalPayIn4Enabled}
              onChange={(e) => setPaypalPayIn4Enabled(e.target.checked)}
              className="rounded-xs border-neutral-300 text-black focus:ring-black"
            />
            <span>Enable PayPal "Pay in 4" Interest-Free Installment Option on Checkout</span>
          </label>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => handleTestApi('paypal')}
            disabled={apiTests['paypal']?.status === 'testing'}
            className="flex items-center gap-1.5"
          >
            <Activity className="w-3.5 h-3.5 text-blue-600" />
            <span>{apiTests['paypal']?.status === 'testing' ? 'Testing...' : 'Test PayPal API Connection'}</span>
          </Button>
        </div>

        {apiTests['paypal'] && (
          <div className="p-4 border text-xs font-mono space-y-2 bg-blue-50 border-blue-300 text-blue-900 animate-in fade-in duration-200">
            <div className="flex items-center justify-between font-bold">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-blue-600" />
                <span>{apiTests['paypal'].message}</span>
              </span>
              {apiTests['paypal'].latencyMs && <span className="text-[10px] text-neutral-500">{apiTests['paypal'].latencyMs}ms latency</span>}
            </div>
            {apiTests['paypal'].details && (
              <ul className="list-disc list-inside text-[11px] text-neutral-700 space-y-0.5 pt-1">
                {apiTests['paypal'].details?.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* 3. APPLE PAY & GOOGLE PAY EXPRESS */}
      {/* ======================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Apple Pay */}
        <div className={`border p-6 space-y-5 transition-all ${applePayEnabled ? 'border-neutral-300 bg-white shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-80'}`}>
          <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
            <div>
              <h3 className="font-serif text-base font-bold text-neutral-900">3.  Apple Pay Express</h3>
              <p className="text-[11px] text-neutral-500">Biometric Face ID & Touch ID on Safari / iOS devices</p>
            </div>
            <div className="flex items-center space-x-2">
              <PaymentStatusBadge provider="apple_pay" content={currentGatewayContent} size="sm" />
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={applePayEnabled}
                  onChange={(e) => handleToggleGateway('applePayEnabled', e.target.checked, 'Apple Pay Gateway')}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-black after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
              </label>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <label className="block text-neutral-700 mb-1">Apple Merchant ID</label>
              <input
                type="text"
                value={applePayMerchantId}
                onChange={(e) => setApplePayMerchantId(e.target.value)}
                placeholder="merchant.com.ezistential.store"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-neutral-700 mb-1">Verified Domain Name</label>
              <input
                type="text"
                value={applePayDomainName}
                onChange={(e) => setApplePayDomainName(e.target.value)}
                placeholder="ezistential.com"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-neutral-100">
            <a
              href="/.well-known/apple-developer-merchantid-domain-association"
              target="_blank"
              rel="noreferrer"
              className="text-[11px] font-mono text-emerald-700 hover:underline flex items-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Domain File Association Active</span>
              <ExternalLink className="w-3 h-3 ml-0.5" />
            </a>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => handleTestApi('apple_pay')}
            >
              Test Apple Pay
            </Button>
          </div>

          {apiTests['apple_pay'] && (
            <div className="p-3 bg-neutral-900 text-white text-xs font-mono space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{apiTests['apple_pay'].message}</span>
              </div>
            </div>
          )}
        </div>

        {/* Google Pay */}
        <div className={`border p-6 space-y-5 transition-all ${googlePayEnabled ? 'border-neutral-300 bg-white shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-80'}`}>
          <div className="flex items-center justify-between border-b border-neutral-200 pb-3 gap-2">
            <div>
              <h3 className="font-mono text-base font-bold text-neutral-900">4. G Pay Google Wallet</h3>
              <p className="text-[11px] text-neutral-500">1-click tokenized checkout across Chrome, Android, and Web</p>
            </div>
            <div className="flex items-center space-x-2">
              <PaymentStatusBadge provider="google_pay" content={currentGatewayContent} size="sm" />
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={googlePayEnabled}
                  onChange={(e) => handleToggleGateway('googlePayEnabled', e.target.checked, 'Google Pay Gateway')}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-black after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
              </label>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <label className="block text-neutral-700 mb-1">Google Merchant ID (Business Console)</label>
              <input
                type="text"
                value={googlePayMerchantId}
                onChange={(e) => setGooglePayMerchantId(e.target.value)}
                placeholder="BCR2DN4TX..."
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-neutral-700 mb-1">Gateway Merchant ID</label>
              <input
                type="text"
                value={googlePayGatewayMerchantId}
                onChange={(e) => setGooglePayGatewayMerchantId(e.target.value)}
                placeholder="ezistential_stripe_gw"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-neutral-700 mb-1">Environment Mode</label>
              <select
                value={googlePayEnvironment}
                onChange={(e) => setGooglePayEnvironment(e.target.value as any)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono cursor-pointer focus:border-black focus:outline-hidden"
              >
                <option value="TEST">TEST (Sandbox Simulator)</option>
                <option value="PRODUCTION">PRODUCTION (Live Cards)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-neutral-100">
            <span className="text-[11px] font-mono text-neutral-500">Gateway Tokenizer linked</span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => handleTestApi('google_pay')}
            >
              Test Google Pay
            </Button>
          </div>

          {apiTests['google_pay'] && (
            <div className="p-3 bg-neutral-100 border border-neutral-300 text-neutral-900 text-xs font-mono space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{apiTests['google_pay'].message}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ======================================================== */}
      {/* 4. BNPL (KLARNA & AFTERPAY) */}
      {/* ======================================================== */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Klarna */}
        <div className={`border p-5 space-y-4 ${klarnaEnabled ? 'border-neutral-300 bg-white shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-80'}`}>
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3 gap-2">
            <div>
              <span className="font-sans font-bold text-sm block text-neutral-900">5. Klarna. Pay in 4</span>
              <span className="text-[10px] text-neutral-500">BNPL 4 Interest-Free Installments</span>
            </div>
            <div className="flex items-center space-x-2">
              <PaymentStatusBadge provider="klarna" content={currentGatewayContent} size="sm" showSublabel={false} />
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={klarnaEnabled}
                  onChange={(e) => handleToggleGateway('klarnaEnabled', e.target.checked, 'Klarna Gateway')}
                  className="sr-only peer"
                />
                <div className="w-8 h-4 bg-neutral-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-black after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all"></div>
              </label>
            </div>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Klarna API Client ID</label>
              <input
                type="text"
                value={klarnaClientId}
                onChange={(e) => setKlarnaClientId(e.target.value)}
                placeholder="K882104-..."
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Klarna Client Secret</label>
              <input
                type="password"
                value={klarnaClientSecret}
                onChange={(e) => setKlarnaClientSecret(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Region</label>
              <select
                value={klarnaRegion}
                onChange={(e) => setKlarnaRegion(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              >
                <option value="US">United States (USD)</option>
                <option value="EU">European Union (EUR)</option>
                <option value="UK">United Kingdom (GBP)</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end pt-2 border-t border-neutral-100">
            <button
              type="button"
              onClick={() => handleTestApi('klarna')}
              className="text-xs font-mono text-neutral-700 hover:text-black underline cursor-pointer"
            >
              Test Klarna Connection
            </button>
          </div>
        </div>

        {/* Afterpay */}
        <div className={`border p-5 space-y-4 ${afterpayEnabled ? 'border-neutral-300 bg-white shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-80'}`}>
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3 gap-2">
            <div>
              <span className="font-mono font-bold text-sm block text-neutral-900">6. Afterpay / Clearpay</span>
              <span className="text-[10px] text-neutral-500">4-Part Installment Gateway</span>
            </div>
            <div className="flex items-center space-x-2">
              <PaymentStatusBadge provider="afterpay" content={currentGatewayContent} size="sm" showSublabel={false} />
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={afterpayEnabled}
                  onChange={(e) => handleToggleGateway('afterpayEnabled', e.target.checked, 'Afterpay Gateway')}
                  className="sr-only peer"
                />
                <div className="w-8 h-4 bg-neutral-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-black after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all"></div>
              </label>
            </div>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Afterpay Merchant ID</label>
              <input
                type="text"
                value={afterpayMerchantId}
                onChange={(e) => setAfterpayMerchantId(e.target.value)}
                placeholder="80042109"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Afterpay Secret Key</label>
              <input
                type="password"
                value={afterpaySecretKey}
                onChange={(e) => setAfterpaySecretKey(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Operating Region</label>
              <select
                value={afterpayRegion}
                onChange={(e) => setAfterpayRegion(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              >
                <option value="US">United States (USD)</option>
                <option value="CA">Canada (CAD)</option>
                <option value="AU">Australia (AUD)</option>
                <option value="UK">United Kingdom (GBP)</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end pt-2 border-t border-neutral-100">
            <button
              type="button"
              onClick={() => handleTestApi('afterpay')}
              className="text-xs font-mono text-neutral-700 hover:text-black underline cursor-pointer"
            >
              Test Afterpay Connection
            </button>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 5. CASH APP & SHOP PAY */}
      {/* ======================================================== */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Cash App */}
        <div className={`border p-5 space-y-4 ${cashAppPayEnabled ? 'border-neutral-300 bg-white shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-80'}`}>
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3 gap-2">
            <div>
              <span className="font-mono font-bold text-sm text-[#00A827] block">7. $ Cash App Pay</span>
              <span className="text-[10px] text-neutral-500">QR Code & Direct Cashtag Flow</span>
            </div>
            <div className="flex items-center space-x-2">
              <PaymentStatusBadge provider="cashapp" content={currentGatewayContent} size="sm" showSublabel={false} />
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={cashAppPayEnabled}
                  onChange={(e) => handleToggleGateway('cashAppPayEnabled', e.target.checked, 'Cash App Pay')}
                  className="sr-only peer"
                />
                <div className="w-8 h-4 bg-neutral-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-[#00D632] after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all"></div>
              </label>
            </div>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Business Cashtag ($handle)</label>
              <input
                type="text"
                value={cashAppCashtag}
                onChange={(e) => setCashAppCashtag(e.target.value)}
                placeholder="$EzistentialStudio"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Square / Cash App Client ID</label>
              <input
                type="text"
                value={cashAppClientId}
                onChange={(e) => setCashAppClientId(e.target.value)}
                placeholder="sq0idp-..."
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Webhook Signature Key</label>
              <input
                type="text"
                value={cashAppWebhookSecret}
                onChange={(e) => setCashAppWebhookSecret(e.target.value)}
                placeholder="sq_wh_sec_..."
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2 border-t border-neutral-100">
            <button
              type="button"
              onClick={() => handleTestApi('cashapp')}
              className="text-xs font-mono text-neutral-700 hover:text-black underline cursor-pointer"
            >
              Test Cash App
            </button>
          </div>
        </div>

        {/* Shop Pay */}
        <div className={`border p-5 space-y-4 ${shopPayEnabled ? 'border-neutral-300 bg-white shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-80'}`}>
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3 gap-2">
            <div>
              <span className="font-sans font-bold text-sm text-[#5A31F4] block">8. Shop Pay 1-Click</span>
              <span className="text-[10px] text-neutral-500">Accelerated SMS Tokenized Checkout</span>
            </div>
            <div className="flex items-center space-x-2">
              <PaymentStatusBadge provider="shoppay" content={currentGatewayContent} size="sm" showSublabel={false} />
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={shopPayEnabled}
                  onChange={(e) => handleToggleGateway('shopPayEnabled', e.target.checked, 'Shop Pay')}
                  className="sr-only peer"
                />
                <div className="w-8 h-4 bg-neutral-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-[#5A31F4] after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all"></div>
              </label>
            </div>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Shop Domain</label>
              <input
                type="text"
                value={shopPayDomain}
                onChange={(e) => setShopPayDomain(e.target.value)}
                placeholder="shop.ezistential.com"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-600 mb-1">Storefront API Access Token</label>
              <input
                type="password"
                value={shopPayStorefrontToken}
                onChange={(e) => setShopPayStorefrontToken(e.target.value)}
                placeholder="shpat_..."
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono focus:border-black focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2 border-t border-neutral-100">
            <button
              type="button"
              onClick={() => handleTestApi('shoppay')}
              className="text-xs font-mono text-neutral-700 hover:text-black underline cursor-pointer"
            >
              Test Shop Pay
            </button>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Save Bar */}
      <div className="sticky bottom-0 bg-white/95 backdrop-blur-xs border-t border-neutral-200 p-4 -mx-6 -mb-6 flex items-center justify-between z-10 shadow-lg">
        <span className="text-xs font-mono text-neutral-600">
          Status: <strong className="text-neutral-900">{connectedCount} of 8 Networks Configured</strong>
        </span>
        <Button type="button" onClick={handleSaveAll} variant="primary" size="sm" className="bg-black text-white hover:bg-neutral-800">
          Save All Payment Gateways
        </Button>
      </div>
    </div>
  );
};
