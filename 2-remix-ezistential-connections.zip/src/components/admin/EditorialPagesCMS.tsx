import React, { useState, useEffect } from 'react';
import {
  FileText,
  CheckCircle2,
  BookOpen,
  Compass,
  Heart,
  HelpCircle,
  Phone,
  Truck,
  Save,
  Check,
  Globe,
  Layout,
  ShoppingBag,
  Shield,
  Send,
  MessageSquare,
  Menu,
  Plus,
  Trash2,
  Edit2,
  Search,
  X,
  RotateCcw,
  ExternalLink,
  Sliders
} from 'lucide-react';
import { useContent, SpotlightSlide } from '../../context/ContentContext';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { ConfirmDeleteModal } from '../modals/ConfirmDeleteModal';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';
import { PageSeoMetadataCMS } from './PageSeoMetadataCMS';
import { MenuNavigationCMS } from './MenuNavigationCMS';
import { BlogPostsCMS } from './BlogPostsCMS';
import { HomeBannerStudio } from './HomeBannerStudio';
import type { FAQItem } from '../../types';

export type PageCmsTab =
  | 'home'
  | 'banner'
  | 'why_we_exist'
  | 'our_story'
  | 'manifesto'
  | 'connection'
  | 'care_shipping'
  | 'contact'
  | 'journal'
  | 'footer_legal';

export interface EditorialPagesCMSProps {
  initialTab?: PageCmsTab;
  onNavigateToView?: (view: string) => void;
  canEditContent?: boolean;
}

export const EditorialPagesCMS: React.FC<EditorialPagesCMSProps> = ({
  initialTab = 'home',
  onNavigateToView,
  canEditContent = true,
}) => {
  const {
    content,
    updateContent,
    faqs,
    addFaq,
    updateFaq,
    deleteFaq,
    resetFaqs,
  } = useContent();
  const [activeTab, setActiveTab] = useState<PageCmsTab>(initialTab);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Master Journal Toggle State
  const [enableJournal, setEnableJournal] = useState<boolean>(content.enableJournal !== false);
  useEffect(() => {
    setEnableJournal(content.enableJournal !== false);
  }, [content.enableJournal]);

  const handleToggleJournal = (enabled: boolean) => {
    setEnableJournal(enabled);
    updateContent({ enableJournal: enabled });
    setToastMessage(enabled ? 'Journal & Dispatches activated across storefront.' : 'Journal & Dispatches deactivated and hidden from all menus.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  // FAQ & Guidelines CMS State
  const [faqSearch, setFaqSearch] = useState('');
  const [faqCategoryFilter, setFaqCategoryFilter] = useState('All');
  const [faqModalOpen, setFaqModalOpen] = useState(false);
  const [editingFaqId, setEditingFaqId] = useState<string | null>(null);
  const [faqFormQuestion, setFaqFormQuestion] = useState('');
  const [faqFormAnswer, setFaqFormAnswer] = useState('');
  const [faqFormCategory, setFaqFormCategory] = useState<FAQItem['category']>('Returns & Care');
  const [faqDeleteModalItem, setFaqDeleteModalItem] = useState<{ id: string; question: string } | null>(null);

  const handleOpenAddFaq = () => {
    setEditingFaqId(null);
    setFaqFormQuestion('');
    setFaqFormAnswer('');
    setFaqFormCategory('Returns & Care');
    setFaqModalOpen(true);
  };

  const handleOpenEditFaq = (faq: { id: string; question: string; answer: string; category?: string }) => {
    setEditingFaqId(faq.id);
    setFaqFormQuestion(faq.question);
    setFaqFormAnswer(faq.answer);
    setFaqFormCategory((faq.category as FAQItem['category']) || 'Returns & Care');
    setFaqModalOpen(true);
  };

  const handleSaveFaq = (e: React.FormEvent) => {
    e.preventDefault();
    if (!faqFormQuestion.trim() || !faqFormAnswer.trim()) {
      setToastMessage('Question and answer cannot be empty.');
      setTimeout(() => setToastMessage(null), 3000);
      return;
    }

    if (editingFaqId) {
      updateFaq(editingFaqId, {
        question: faqFormQuestion.trim(),
        answer: faqFormAnswer.trim(),
        category: faqFormCategory,
      });
      setToastMessage('FAQ updated successfully.');
    } else {
      addFaq({
        question: faqFormQuestion.trim(),
        answer: faqFormAnswer.trim(),
        category: faqFormCategory,
      });
      setToastMessage('New FAQ added successfully.');
    }
    setTimeout(() => setToastMessage(null), 3000);
    setFaqModalOpen(false);
  };

  const filteredFaqs = faqs.filter((faq) => {
    const matchesCategory = faqCategoryFilter === 'All' || faq.category === faqCategoryFilter;
    const matchesSearch =
      faq.question.toLowerCase().includes(faqSearch.toLowerCase()) ||
      faq.answer.toLowerCase().includes(faqSearch.toLowerCase()) ||
      faq.category.toLowerCase().includes(faqSearch.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // 1. Homepage & Hero & Garments Catalog
  const [announcementText, setAnnouncementText] = useState(content.announcementText || '');
  const [announcementActive, setAnnouncementActive] = useState(content.announcementActive !== false);
  const [announcementLinkText, setAnnouncementLinkText] = useState(content.announcementLinkText || 'Explore Garments');
  const [heroHeadline, setHeroHeadline] = useState(content.heroHeadline || '');
  const [heroSubheadline, setHeroSubheadline] = useState(content.heroSubheadline || '');
  const [heroTagline, setHeroTagline] = useState(content.heroTagline || '');
  const [heroButtonText, setHeroButtonText] = useState(content.heroButtonText || 'Explore Connection Garments');
  const [heroImageUrl, setHeroImageUrl] = useState(content.heroImageUrl || 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=2000&q=85');
  const [heroImageOverlayOpacity, setHeroImageOverlayOpacity] = useState(
    typeof content.heroImageOverlayOpacity === 'number' ? content.heroImageOverlayOpacity : 0.52
  );
  const [heroColorMood, setHeroColorMood] = useState(content.heroColorMood || 'golden-amber');
  const [catalogSectionTitle, setCatalogSectionTitle] = useState(
    content.catalogSectionTitle || 'On-Demand Heavyweight Garments'
  );
  const [catalogSectionSubtitle, setCatalogSectionSubtitle] = useState(
    content.catalogSectionSubtitle || 'Heavyweight 6.5oz combed cotton garments designed to provoke quiet recognition.'
  );
  const [spotlightSlides, setSpotlightSlides] = useState<SpotlightSlide[]>(
    content.spotlightSlides || [
      {
        id: 'slide-1',
        url: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=1200&q=85',
        subtitle: 'Diverse Age Showcase · Park Series',
        caption: 'The Distance Between Us Is Man-Made',
      },
      {
        id: 'slide-2',
        url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1200&q=85',
        subtitle: 'Editorial Campaign · 02',
        caption: 'Interrupted Typography in Public Space',
      },
      {
        id: 'slide-3',
        url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=85',
        subtitle: 'Community & Connection',
        caption: 'Inaugural Statement — Est. Nov 2008',
      },
    ]
  );

  // 2. Why We Exist
  const [whyWeExistHeadline, setWhyWeExistHeadline] = useState(content.whyWeExistHeadline || 'Why We Exist');
  const [whyWeExistSubtitle, setWhyWeExistSubtitle] = useState(
    content.whyWeExistSubtitle || 'A garment is not merely fabric; it is an artifact of presence.'
  );
  const [whyWeExistBody, setWhyWeExistBody] = useState(content.whyWeExistBody || '');
  const [foundingQuote, setFoundingQuote] = useState(content.foundingQuote || '');

  // 3. Our Story
  const [storyHeadline, setStoryHeadline] = useState(content.storyHeadline || 'From Chicago to the World: The Story of Ezistential');
  const [storyBody, setStoryBody] = useState(content.storyBody || '');

  // 4. Manifesto
  const [manifestoTitle, setManifestoTitle] = useState(content.manifestoTitle || 'The Ezistential Manifesto');
  const [manifestoExcerpt, setManifestoExcerpt] = useState(content.manifestoExcerpt || '');
  const [pillar1, setPillar1] = useState(content.manifestoPillars?.[0] || '1. Design with intention and physical weight.');
  const [pillar2, setPillar2] = useState(
    content.manifestoPillars?.[1] || '2. Honor the dignity of human presence over digital distraction.'
  );
  const [pillar3, setPillar3] = useState(content.manifestoPillars?.[2] || '3. Create clothing that serves as a bridge, not a barrier.');
  const [pillar4, setPillar4] = useState(
    content.manifestoPillars?.[3] || '4. Practice ethical print-on-demand zero-waste manufacturing.'
  );

  // 5. Connection Archive
  const [connectionPromptTitle, setConnectionPromptTitle] = useState(content.connectionPromptTitle || 'The Connection Archive');
  const [connectionPromptSubtitle, setConnectionPromptSubtitle] = useState(
    content.connectionPromptSubtitle || 'Anonymous reflections on distance, human connection, and presence.'
  );
  const [connectionSubmitPromptTitle, setConnectionSubmitPromptTitle] = useState(
    content.connectionSubmitPromptTitle || 'Submit an Anonymous Reflection'
  );
  const [connectionSubmitPromptGuide, setConnectionSubmitPromptGuide] = useState(
    content.connectionSubmitPromptGuide || 'Reflections are moderated by studio stewards before publication in the Connection Archive.'
  );
  const [connectionEmptyStateNotice, setConnectionEmptyStateNotice] = useState(
    content.connectionEmptyStateNotice || 'No published reflections in this category yet. Be the first to share an entry.'
  );
  const [showHomeHumanArchiveCta, setShowHomeHumanArchiveCta] = useState(
    content.showHomeHumanArchiveCta === true
  );

  // 6. Care & Garment Specs & Shipping
  const [careDirectivesTitle, setCareDirectivesTitle] = useState(
    content.careDirectivesTitle || 'Garment Care & Fabric Integrity Directives'
  );
  const [careDirectivesNotice, setCareDirectivesNotice] = useState(content.careDirectivesNotice || '');
  const [garmentFabricNotice, setGarmentFabricNotice] = useState(
    content.garmentFabricNotice || '100% Combed Ring-Spun Cotton, 6.5oz Heavyweight Custom Blank.'
  );
  const [garmentFulfillmentNotice, setGarmentFulfillmentNotice] = useState(
    content.garmentFulfillmentNotice || 'Printed on-demand with zero-waste manufacturing. 3–5 business days fulfillment.'
  );
  const [shippingReturnsHeadline, setShippingReturnsHeadline] = useState(
    content.shippingReturnsHeadline || 'Logistics, Domestic Delivery & Returns Covenant'
  );
  const [shippingReturnsBody, setShippingReturnsBody] = useState(content.shippingReturnsBody || '');

  // 7. Contact Page
  const [contactPageTitle, setContactPageTitle] = useState(content.contactPageTitle || 'Studio Premises & Inquiries');
  const [contactPageSubtitle, setContactPageSubtitle] = useState(content.contactPageSubtitle || '');

  // 8. FAQ Page
  const [faqPageTitle, setFaqPageTitle] = useState(
    content.faqPageTitle || 'Frequently Asked Questions & Care Directives'
  );
  const [faqPageSubtitle, setFaqPageSubtitle] = useState(
    content.faqPageSubtitle || 'Answers regarding garment care, custom heavyweight sizing, and domestic shipping.'
  );

  // 9. Journal & Updates Page
  const [journalPageTitle, setJournalPageTitle] = useState(content.journalPageTitle || 'Journal & Studio Updates');
  const [journalPageSubtitle, setJournalPageSubtitle] = useState(
    content.journalPageSubtitle || 'Articles, design manifestos, and studio notes from Ezistential Connection.'
  );

  // 10. Footer & Legal Pages
  const [footerSlogan, setFooterSlogan] = useState(
    content.footerSlogan || 'Examining the space between people through intentional apparel.'
  );
  const [newsletterHeading, setNewsletterHeading] = useState(content.newsletterHeading || 'Receive Studio Dispatches');
  const [newsletterSubtitle, setNewsletterSubtitle] = useState(
    content.newsletterSubtitle || 'Occasional letters on connection, garment releases, and studio manifestos.'
  );
  const [termsPageTitle, setTermsPageTitle] = useState(content.termsPageTitle || 'Terms of Service & Usage Covenant');
  const [termsPageBody, setTermsPageBody] = useState(content.termsPageBody || '');
  const [privacyPageTitle, setPrivacyPageTitle] = useState(content.privacyPageTitle || 'Digital Dignity & Privacy Covenant');
  const [privacyPageBody, setPrivacyPageBody] = useState(content.privacyPageBody || '');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSavePageContent = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      announcementText: announcementText.trim(),
      announcementActive,
      announcementLinkText: announcementLinkText.trim(),
      heroHeadline: heroHeadline.trim(),
      heroSubheadline: heroSubheadline.trim(),
      heroTagline: heroTagline.trim(),
      heroButtonText: heroButtonText.trim(),
      heroImageUrl: heroImageUrl.trim(),
      heroImageOverlayOpacity: Number(heroImageOverlayOpacity),
      heroColorMood,
      catalogSectionTitle: catalogSectionTitle.trim(),
      catalogSectionSubtitle: catalogSectionSubtitle.trim(),
      spotlightSlides,

      whyWeExistHeadline: whyWeExistHeadline.trim(),
      whyWeExistSubtitle: whyWeExistSubtitle.trim(),
      whyWeExistBody: whyWeExistBody.trim(),
      foundingQuote: foundingQuote.trim(),

      storyHeadline: storyHeadline.trim(),
      storyBody: storyBody.trim(),

      manifestoTitle: manifestoTitle.trim(),
      manifestoExcerpt: manifestoExcerpt.trim(),
      manifestoPillars: [pillar1.trim(), pillar2.trim(), pillar3.trim(), pillar4.trim()],

      connectionPromptTitle: connectionPromptTitle.trim(),
      connectionPromptSubtitle: connectionPromptSubtitle.trim(),
      connectionSubmitPromptTitle: connectionSubmitPromptTitle.trim(),
      connectionSubmitPromptGuide: connectionSubmitPromptGuide.trim(),
      connectionEmptyStateNotice: connectionEmptyStateNotice.trim(),
      showHomeHumanArchiveCta,

      careDirectivesTitle: careDirectivesTitle.trim(),
      careDirectivesNotice: careDirectivesNotice.trim(),
      garmentFabricNotice: garmentFabricNotice.trim(),
      garmentFulfillmentNotice: garmentFulfillmentNotice.trim(),
      shippingReturnsHeadline: shippingReturnsHeadline.trim(),
      shippingReturnsBody: shippingReturnsBody.trim(),

      contactPageTitle: contactPageTitle.trim(),
      contactPageSubtitle: contactPageSubtitle.trim(),

      faqPageTitle: faqPageTitle.trim(),
      faqPageSubtitle: faqPageSubtitle.trim(),

      journalPageTitle: journalPageTitle.trim(),
      journalPageSubtitle: journalPageSubtitle.trim(),

      footerSlogan: footerSlogan.trim(),
      newsletterHeading: newsletterHeading.trim(),
      newsletterSubtitle: newsletterSubtitle.trim(),
      termsPageTitle: termsPageTitle.trim(),
      termsPageBody: termsPageBody.trim(),
      privacyPageTitle: privacyPageTitle.trim(),
      privacyPageBody: privacyPageBody.trim(),
    });
    showToast('Page CMS updated! All page content is synchronized live across the storefront.');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-neutral-200 gap-4">
        <div>
          <h2 className="font-serif text-2xl text-neutral-900">Page CMS — Storefront Copy Controller</h2>
          <p className="text-xs text-neutral-500 mt-1">
            Complete page content management. Every headline, paragraph, quote, and notice across the storefront is editable below.
          </p>
        </div>
        <Button onClick={handleSavePageContent} variant="primary" size="md">
          <Save className="w-3.5 h-3.5 mr-1.5" />
          <span>Publish Page Updates</span>
        </Button>
      </div>

      {/* Page Tabs Bar */}
      <div className="flex border-b border-neutral-200 overflow-x-auto gap-1 text-xs font-mono">
        {[
          { id: 'home', label: '1. Home & Hero Copy', icon: Globe },
          { id: 'banner', label: '2. Home Banner Studio', icon: Sliders },
          { id: 'why_we_exist', label: '3. Why We Exist', icon: Compass },
          { id: 'our_story', label: '4. Our Story', icon: BookOpen },
          { id: 'manifesto', label: '5. Manifesto', icon: FileText },
          { id: 'connection', label: '6. Connection Archive', icon: Heart },
          { id: 'care_shipping', label: '7. Care & Shipping', icon: Truck },
          { id: 'contact', label: '8. Contact Page', icon: Phone },
          { id: 'journal', label: '9. Journal Page CMS', icon: BookOpen },
          { id: 'footer_legal', label: '10. Footer & Legal', icon: Shield },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as PageCmsTab)}
              className={`py-2.5 px-3.5 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                isActive
                  ? 'border-black text-black font-bold bg-neutral-50'
                  : 'border-transparent text-neutral-500 hover:text-black'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Page CMS Container */}
      <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
        {/* TAB 1: HOMEPAGE & HERO & CATALOG */}
        {activeTab === 'home' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Homepage, Hero & Garment Catalog Editor</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Edit top announcement bar, primary hero statement, subheadline, tagline, CTA button, and garment section titles.
              </p>
            </div>

            <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-4">
              <label className="flex items-center space-x-3 text-xs text-neutral-900 font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={announcementActive}
                  onChange={(e) => setAnnouncementActive(e.target.checked)}
                  className="accent-black w-4 h-4"
                />
                <span>Enable Top Announcement Bar</span>
              </label>

              {announcementActive && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Announcement Statement</label>
                    <input
                      type="text"
                      value={announcementText}
                      onChange={(e) => setAnnouncementText(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2 text-xs font-sans text-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">Link Label</label>
                    <input
                      type="text"
                      value={announcementLinkText}
                      onChange={(e) => setAnnouncementLinkText(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2 text-xs font-sans text-neutral-900"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4 pt-2">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                  Main Hero Opening Statement (Headline) *
                </label>
                <textarea
                  rows={2}
                  required
                  value={heroHeadline}
                  onChange={(e) => setHeroHeadline(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-sm font-serif text-neutral-900 focus:outline-hidden focus:border-black leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                  Hero Subheadline Description
                </label>
                <textarea
                  rows={3}
                  value={heroSubheadline}
                  onChange={(e) => setHeroSubheadline(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 focus:outline-hidden focus:border-black leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Hero Tagline Pill</label>
                  <input
                    type="text"
                    value={heroTagline}
                    onChange={(e) => setHeroTagline(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Primary CTA Button Text</label>
                  <input
                    type="text"
                    value={heroButtonText}
                    onChange={(e) => setHeroButtonText(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden font-bold uppercase"
                  />
                </div>
              </div>

              {/* Hero Atmospheric Background Image & Color Mood */}
              <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-4 pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs uppercase font-mono font-bold text-neutral-800">
                      Hero Atmospheric Background Image &amp; Color Mood
                    </h4>
                    <p className="text-[11px] text-neutral-500 font-sans">
                      Add rich color and evocative editorial photography to the opening hero section.
                    </p>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-neutral-200 text-neutral-700">
                    Live Hero
                  </span>
                </div>

                <div className="space-y-3">
                  <ImageUploadCompressor
                    label="Hero Background Image (.jpg, .png, .webp)"
                    value={heroImageUrl}
                    onChange={setHeroImageUrl}
                    maxWidth={2000}
                    maxHeight={1400}
                    quality={0.88}
                    helperText="Recommended: 1920x1080 landscape editorial photo with rich lighting"
                  />

                  {/* Curated Presets */}
                  <div className="space-y-1.5 pt-1">
                    <label className="block text-[11px] uppercase font-mono text-neutral-600">
                      Or Choose a Curated Editorial Preset:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        {
                          name: 'Golden Hour',
                          url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=2000&q=85',
                          mood: 'golden-amber' as const,
                          color: '#f59e0b',
                        },
                        {
                          name: 'Terracotta Sunset',
                          url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=2000&q=85',
                          mood: 'terracotta-sunset' as const,
                          color: '#ea580c',
                        },
                        {
                          name: 'Architectural Light',
                          url: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=2000&q=85',
                          mood: 'golden-amber' as const,
                          color: '#d97706',
                        },
                        {
                          name: 'Twilight Dusk',
                          url: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=2000&q=85',
                          mood: 'twilight-indigo' as const,
                          color: '#6366f1',
                        },
                      ].map((preset) => (
                        <button
                          key={preset.name}
                          type="button"
                          onClick={() => {
                            setHeroImageUrl(preset.url);
                            setHeroColorMood(preset.mood);
                          }}
                          className={`p-2 border text-left flex items-center gap-2 transition-all cursor-pointer ${
                            heroImageUrl === preset.url
                              ? 'border-black bg-white shadow-xs font-semibold'
                              : 'border-neutral-300 bg-neutral-100 hover:border-neutral-400'
                          }`}
                        >
                          <span
                            className="w-3 h-3 rounded-full shrink-0"
                            style={{ backgroundColor: preset.color }}
                          />
                          <span className="text-[11px] font-sans truncate">{preset.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Color Mood & Opacity Sliders */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div>
                      <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">
                        Ambient Color Mood (Light Blooms)
                      </label>
                      <select
                        value={heroColorMood}
                        onChange={(e) => setHeroColorMood(e.target.value as any)}
                        className="w-full bg-white border border-neutral-300 p-2 text-xs font-sans text-neutral-900 cursor-pointer"
                      >
                        <option value="golden-amber">Golden Amber (Warm Sunlight &amp; Terracotta)</option>
                        <option value="terracotta-sunset">Terracotta Sunset (Sienna &amp; Rose Twilight)</option>
                        <option value="twilight-indigo">Twilight Indigo (Cosmic Indigo &amp; Cobalt)</option>
                        <option value="natural-monochrome">Natural Minimal (Subtle Candle Warmth)</option>
                      </select>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[11px] uppercase font-mono text-neutral-600">
                          Scrim Overlay Darkness
                        </label>
                        <span className="text-xs font-mono text-neutral-700">
                          {Math.round(heroImageOverlayOpacity * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0.2"
                        max="0.85"
                        step="0.05"
                        value={heroImageOverlayOpacity}
                        onChange={(e) => setHeroImageOverlayOpacity(parseFloat(e.target.value))}
                        className="w-full accent-black cursor-pointer"
                      />
                      <p className="text-[10px] text-neutral-500 font-sans mt-0.5">
                        Balances vivid image background colors with crisp white headline contrast
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-3 pt-4">
                <h4 className="text-xs uppercase font-mono font-bold text-neutral-800">Homepage Garments Section Title</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">Section Title</label>
                    <input
                      type="text"
                      value={catalogSectionTitle}
                      onChange={(e) => setCatalogSectionTitle(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">Section Subtitle</label>
                    <input
                      type="text"
                      value={catalogSectionSubtitle}
                      onChange={(e) => setCatalogSectionSubtitle(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                    />
                  </div>
                </div>
              </div>

              {/* Spotlight Carousel Slides Manager */}
              <div className="pt-6 border-t border-neutral-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-serif text-base font-bold text-neutral-900">Home Spotlight Carousel Slides</h4>
                    <p className="text-xs text-neutral-500 font-sans">
                      Manage marketing images, subtitles, and captions for the homepage spotlight carousel. Add, edit, or remove slides freely.
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="primary"
                    size="sm"
                    onClick={() => {
                      setSpotlightSlides((prev) => [
                        ...prev,
                        {
                          id: `slide-${Date.now()}`,
                          url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1200&q=85',
                          subtitle: 'New Slide Series',
                          caption: 'Enter slide caption',
                        },
                      ]);
                    }}
                  >
                    + Add New Slide
                  </Button>
                </div>

                <div className="space-y-4">
                  {spotlightSlides.map((slide, index) => (
                    <div key={slide.id} className="p-4 bg-white border border-neutral-300 space-y-3 relative shadow-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono font-bold text-neutral-700">Slide #{index + 1}</span>
                        {spotlightSlides.length > 1 && (
                          <button
                            type="button"
                            onClick={() => {
                              setSpotlightSlides((prev) => prev.filter((s) => s.id !== slide.id));
                            }}
                            className="text-xs text-red-600 hover:text-red-800 font-mono cursor-pointer"
                          >
                            Remove Slide
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="sm:col-span-3">
                          <ImageUploadCompressor
                            label="Slide Image (Upload & Compress or Paste URL)"
                            value={slide.url}
                            onChange={(url) => {
                              setSpotlightSlides((prev) => prev.map((s) => (s.id === slide.id ? { ...s, url } : s)));
                            }}
                            helperText="Optimizes uploaded imagery into WebP format for high performance storefront display."
                            previewBg="dark"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase font-mono text-neutral-600 mb-1">Subtitle / Series Tag</label>
                          <input
                            type="text"
                            value={slide.subtitle}
                            onChange={(e) => {
                              const val = e.target.value;
                              setSpotlightSlides((prev) => prev.map((s) => (s.id === slide.id ? { ...s, subtitle: val } : s)));
                            }}
                            className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-sans text-neutral-900"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] uppercase font-mono text-neutral-600 mb-1">Caption / Statement</label>
                          <input
                            type="text"
                            value={slide.caption}
                            onChange={(e) => {
                              const val = e.target.value;
                              setSpotlightSlides((prev) => prev.map((s) => (s.id === slide.id ? { ...s, caption: val } : s)));
                            }}
                            className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-serif text-neutral-900"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: HOME BANNER STUDIO (HERO ENGINE) */}
        {activeTab === 'banner' && (
          <div className="pt-2 animate-in fade-in duration-150">
            <HomeBannerStudio showToast={showToast} onBackToStore={() => onNavigateToView?.('home')} />
          </div>
        )}

        {/* TAB 2: WHY WE EXIST PAGE */}
        {activeTab === 'why_we_exist' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Why We Exist Page Content</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Configure philosophy copy, sub-titles, and core purpose narrative.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Page Title</label>
                <input
                  type="text"
                  value={whyWeExistHeadline}
                  onChange={(e) => setWhyWeExistHeadline(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Subtitle Quote</label>
                <input
                  type="text"
                  value={whyWeExistSubtitle}
                  onChange={(e) => setWhyWeExistSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif italic text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Philosophy Narrative Body</label>
                <textarea
                  rows={6}
                  value={whyWeExistBody}
                  onChange={(e) => setWhyWeExistBody(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed focus:outline-hidden focus:border-black"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Founding Philosophy Quote</label>
                <input
                  type="text"
                  value={foundingQuote}
                  onChange={(e) => setFoundingQuote(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif italic text-neutral-900"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: OUR STORY PAGE */}
        {activeTab === 'our_story' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Our Story & Brand Origin Page</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Narrative regarding studio origins, physical Chicago premises, and craftsmanship philosophy.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Story Headline</label>
                <input
                  type="text"
                  value={storyHeadline}
                  onChange={(e) => setStoryHeadline(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Story Body Narrative</label>
                <textarea
                  rows={8}
                  value={storyBody}
                  onChange={(e) => setStoryBody(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed focus:outline-hidden focus:border-black"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: MANIFESTO */}
        {activeTab === 'manifesto' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">The Ezistential Manifesto & Core Pillars</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Manage manifesto header, excerpt, and four founding tenets.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Manifesto Page Title</label>
                <input
                  type="text"
                  value={manifestoTitle}
                  onChange={(e) => setManifestoTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Primary Excerpt</label>
                <textarea
                  rows={3}
                  value={manifestoExcerpt}
                  onChange={(e) => setManifestoExcerpt(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-serif italic text-neutral-900 leading-relaxed"
                />
              </div>

              <div className="space-y-3 pt-2">
                <h4 className="text-xs uppercase font-mono font-bold text-neutral-700">4 Directives & Brand Pillars</h4>
                <input
                  type="text"
                  value={pillar1}
                  onChange={(e) => setPillar1(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
                <input
                  type="text"
                  value={pillar2}
                  onChange={(e) => setPillar2(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
                <input
                  type="text"
                  value={pillar3}
                  onChange={(e) => setPillar3(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
                <input
                  type="text"
                  value={pillar4}
                  onChange={(e) => setPillar4(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: CONNECTION ARCHIVE */}
        {activeTab === 'connection' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Connection Archive & Reflection Prompts</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Manage prompt headers, submission guidelines, and empty state notes for community reflections.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Archive Header Title</label>
                <input
                  type="text"
                  value={connectionPromptTitle}
                  onChange={(e) => setConnectionPromptTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Prompt Subtitle</label>
                <textarea
                  rows={2}
                  value={connectionPromptSubtitle}
                  onChange={(e) => setConnectionPromptSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Submit Box Title</label>
                  <input
                    type="text"
                    value={connectionSubmitPromptTitle}
                    onChange={(e) => setConnectionSubmitPromptTitle(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans font-bold text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Submit Box Guidelines</label>
                  <input
                    type="text"
                    value={connectionSubmitPromptGuide}
                    onChange={(e) => setConnectionSubmitPromptGuide(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Empty Reflection Notice</label>
                <input
                  type="text"
                  value={connectionEmptyStateNotice}
                  onChange={(e) => setConnectionEmptyStateNotice(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
              </div>

              {/* Homepage CTA Toggle */}
              <div className="pt-4 border-t border-neutral-200 mt-4 bg-neutral-50 p-4 border rounded-xs space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs uppercase font-mono font-bold text-neutral-900 block">
                      Homepage Callout: "Co-Creating The Human Archive"
                    </span>
                    <p className="text-xs text-neutral-500 font-sans mt-0.5">
                      "Have you experienced a moment of recognition while wearing our garments?" — Toggle to hide or show on the homepage without deleting.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0 ml-4">
                    <input
                      type="checkbox"
                      checked={showHomeHumanArchiveCta}
                      onChange={(e) => setShowHomeHumanArchiveCta(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-10 h-5 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
                  </label>
                </div>
                <div className="text-[11px] font-mono text-neutral-500">
                  Status: <span className={showHomeHumanArchiveCta ? "text-emerald-700 font-bold" : "text-neutral-600 font-bold"}>
                    {showHomeHumanArchiveCta ? "Visible on Homepage" : "Hidden from Homepage (Preserved in CMS)"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: CARE & GARMENT SPECS & SHIPPING */}
        {activeTab === 'care_shipping' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Garment Fabric Specs, Care & Shipping Policy</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Fabric care directives, cotton density notes, print-on-demand fulfillment notes, and domestic delivery covenants.
              </p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Garment Blank Specs Note</label>
                  <input
                    type="text"
                    value={garmentFabricNotice}
                    onChange={(e) => setGarmentFabricNotice(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans font-bold text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Print-on-Demand Fulfillment Notice</label>
                  <input
                    type="text"
                    value={garmentFulfillmentNotice}
                    onChange={(e) => setGarmentFulfillmentNotice(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Care Directives Title</label>
                <input
                  type="text"
                  value={careDirectivesTitle}
                  onChange={(e) => setCareDirectivesTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Fabric & Wash Instructions</label>
                <textarea
                  rows={3}
                  value={careDirectivesNotice}
                  onChange={(e) => setCareDirectivesNotice(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                />
              </div>

              <div className="pt-4 border-t border-neutral-100 space-y-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Shipping & Returns Headline</label>
                  <input
                    type="text"
                    value={shippingReturnsHeadline}
                    onChange={(e) => setShippingReturnsHeadline(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Shipping & Returns Policy Body</label>
                  <textarea
                    rows={4}
                    value={shippingReturnsBody}
                    onChange={(e) => setShippingReturnsBody(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: CONTACT PAGE */}
        {activeTab === 'contact' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Contact & Studio Premises Page</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Configure titles and contact introduction. Physical address and email addresses sync automatically from Business Setup.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Contact Page Header</label>
                <input
                  type="text"
                  value={contactPageTitle}
                  onChange={(e) => setContactPageTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Contact Intro Subtitle</label>
                <textarea
                  rows={3}
                  value={contactPageSubtitle}
                  onChange={(e) => setContactPageSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB: FAQ & GUIDELINES (Removed from admin menu as requested) */}
        {false && (
          <div className="space-y-8 animate-in fade-in duration-150">
            {/* 1. Page Header Copy Section */}
            <div className="space-y-4 bg-neutral-50/70 p-5 border border-neutral-200">
              <div className="border-b border-neutral-200 pb-2">
                <h3 className="font-serif text-base font-bold text-neutral-900">FAQ Page Header & Introduction</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  The primary headline and explanatory text that introduces the public FAQ & Care route.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">FAQ Page Header Title</label>
                  <input
                    type="text"
                    value={faqPageTitle}
                    onChange={(e) => setFaqPageTitle(e.target.value)}
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900 focus:border-black focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">FAQ Page Subtitle Description</label>
                  <textarea
                    rows={2}
                    value={faqPageSubtitle}
                    onChange={(e) => setFaqPageSubtitle(e.target.value)}
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900 leading-relaxed focus:border-black focus:outline-hidden"
                  />
                </div>
              </div>
            </div>

            {/* 2. Care & Directives Guidelines Box */}
            <div className="bg-amber-50/60 border border-amber-200 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Truck className="w-4 h-4 text-amber-800" />
                  <span className="text-xs font-mono uppercase tracking-wider font-bold text-amber-950">
                    Garment Care & Customer Guidelines
                  </span>
                </div>
                <span className="text-[10px] font-mono bg-amber-200 text-amber-900 px-2 py-0.5 rounded font-medium">
                  Published Guidance
                </span>
              </div>
              <p className="text-xs text-amber-900/80 leading-relaxed font-sans">
                These core manufacturing care specifications and fulfillment guidelines are automatically referenced alongside the FAQ questions to inform customer expectations.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 text-xs font-sans">
                <div className="bg-white p-3 border border-amber-200/80 space-y-1">
                  <span className="font-mono text-[10px] font-bold text-neutral-700 block">1. WASHING DIRECTIVE</span>
                  <p className="text-neutral-600 text-[11px]">Cold machine wash with like colors. Inside-out prevents silkscreen abrasions.</p>
                </div>
                <div className="bg-white p-3 border border-amber-200/80 space-y-1">
                  <span className="font-mono text-[10px] font-bold text-neutral-700 block">2. DRYING DIRECTIVE</span>
                  <p className="text-neutral-600 text-[11px]">Hang dry in shade or tumble dry low. Maintains 300 GSM combed cotton shape.</p>
                </div>
                <div className="bg-white p-3 border border-amber-200/80 space-y-1">
                  <span className="font-mono text-[10px] font-bold text-neutral-700 block">3. SIZING SPECIFICATION</span>
                  <p className="text-neutral-600 text-[11px]">Boxy drop-shoulder cut. True-to-size for relaxed drape, size down for tailored fit.</p>
                </div>
                <div className="bg-white p-3 border border-amber-200/80 space-y-1">
                  <span className="font-mono text-[10px] font-bold text-neutral-700 block">4. DISPATCH & TRANSIT</span>
                  <p className="text-neutral-600 text-[11px]">Made-to-order via Apliiq POD in 2–4 business days with carbon-neutral transit.</p>
                </div>
              </div>
            </div>

            {/* 3. FAQ Questions & Answers Management Controller */}
            <div className="space-y-4">
              <div className="bg-white border border-neutral-200 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
                <div>
                  <h4 className="font-serif text-base font-bold text-neutral-900 flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-cyan-600" />
                    <span>Frequently Asked Questions Catalog ({faqs.length})</span>
                  </h4>
                  <p className="text-xs text-neutral-500 font-sans mt-0.5">
                    Add, edit, reorganize, or remove customer inquiries and answers.
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (window.confirm('Reset all FAQs back to default questions?')) {
                        resetFaqs();
                        setToastMessage('FAQs reinstated to default questions.');
                        setTimeout(() => setToastMessage(null), 3000);
                      }
                    }}
                    className="text-xs font-mono"
                    title="Restore default questions"
                  >
                    <RotateCcw className="w-3.5 h-3.5 mr-1" />
                    <span>Reset Defaults</span>
                  </Button>

                  <Button
                    type="button"
                    variant="primary"
                    size="sm"
                    onClick={handleOpenAddFaq}
                    className="text-xs font-mono"
                  >
                    <Plus className="w-3.5 h-3.5 mr-1" />
                    <span>+ Add New FAQ Question</span>
                  </Button>
                </div>
              </div>

              {/* Filters & Search Bar */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-neutral-50 p-3 border border-neutral-200">
                <div className="flex flex-wrap items-center gap-1 text-xs font-mono">
                  {['All', 'Brand & Meaning', 'Products & Sizing', 'Shipping & Delivery', 'Returns & Care'].map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setFaqCategoryFilter(cat)}
                      className={`px-2.5 py-1 rounded-xs transition-colors cursor-pointer ${
                        faqCategoryFilter === cat
                          ? 'bg-black text-white font-bold'
                          : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-100'
                      }`}
                    >
                      {cat} {cat === 'All' ? `(${faqs.length})` : `(${faqs.filter(f => f.category === cat).length})`}
                    </button>
                  ))}
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search question or keywords..."
                    value={faqSearch}
                    onChange={(e) => setFaqSearch(e.target.value)}
                    className="w-full bg-white border border-neutral-300 pl-8 pr-3 py-1.5 text-xs font-sans focus:outline-hidden focus:border-black"
                  />
                </div>
              </div>

              {/* FAQ Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredFaqs.map((faq) => (
                  <div
                    key={faq.id}
                    className="bg-white border border-neutral-200 p-5 space-y-3 shadow-xs hover:border-neutral-400 transition-colors flex flex-col justify-between"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">
                          {faq.category}
                        </span>
                        <div className="flex items-center space-x-1">
                          <button
                            type="button"
                            onClick={() => handleOpenEditFaq(faq)}
                            className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded cursor-pointer transition-colors"
                            title="Edit FAQ"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setFaqDeleteModalItem({ id: faq.id, question: faq.question })}
                            className="p-1.5 text-neutral-500 hover:text-red-600 hover:bg-red-50 rounded cursor-pointer transition-colors"
                            title="Delete FAQ"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <h4 className="font-serif text-base font-bold text-neutral-900">
                        {faq.question}
                      </h4>
                      <p className="text-xs text-neutral-600 leading-relaxed font-sans font-light">
                        {faq.answer}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {filteredFaqs.length === 0 && (
                <div className="text-center py-12 bg-neutral-50 border border-dashed border-neutral-300 p-6 space-y-2">
                  <p className="font-serif text-neutral-800 text-sm">No FAQ questions match your filter.</p>
                  <Button type="button" variant="outline" size="sm" onClick={() => { setFaqSearch(''); setFaqCategoryFilter('All'); }}>
                    Clear Filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 10: JOURNAL PAGE CMS (SYSTEM CONTROLLER + HEADERS + DISPATCHES & ESSAYS) */}
        {activeTab === 'journal' && (
          <div className="space-y-8 animate-in fade-in duration-150">
            {/* 1. Master Journal System Control Card */}
            <div className={`p-5 border transition-all ${enableJournal ? 'bg-white border-neutral-300 shadow-xs' : 'bg-neutral-100/80 border-neutral-300'}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2.5">
                    <BookOpen className="w-5 h-5 text-amber-600" />
                    <h3 className="font-serif text-lg font-bold text-neutral-900">
                      Journal & Editorial Dispatches System Control
                    </h3>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-medium ${
                      enableJournal ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-neutral-200 text-neutral-700'
                    }`}>
                      {enableJournal ? 'Active & Published' : 'Turned Off (Hidden from All Menus)'}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-600 leading-relaxed font-sans max-w-2xl">
                    Master toggle for the Journal module. When turned off, the Journal is cleanly hidden from storefront top navigation, mobile drawers, footer sections, and user account menus. All existing dispatches, essays, and drafts remain safely preserved in the database.
                  </p>
                </div>

                <div className="flex items-center space-x-4 shrink-0">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enableJournal}
                      onChange={(e) => handleToggleJournal(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
                  </label>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-neutral-100 flex flex-wrap items-center justify-between text-xs font-mono text-neutral-500 gap-2">
                <span>Direct Public Route: <code className="text-neutral-900 font-bold">/updates</code></span>
                {onNavigateToView && (
                  <button
                    type="button"
                    onClick={() => onNavigateToView('updates')}
                    className="text-black hover:underline cursor-pointer inline-flex items-center gap-1 font-sans"
                  >
                    <span>Preview Storefront Journal</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 2. Journal Page Header Copy */}
            <div className="space-y-4 bg-neutral-50/70 p-5 border border-neutral-200">
              <div className="border-b border-neutral-200 pb-2">
                <h3 className="font-serif text-base font-bold text-neutral-900">Journal Page Headers & Banner Copy</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  The primary title and descriptive subtitle displayed at the top of the Journal archive.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Journal Page Title</label>
                  <input
                    type="text"
                    value={journalPageTitle}
                    onChange={(e) => setJournalPageTitle(e.target.value)}
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900 focus:border-black focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Journal Subtitle Description</label>
                  <textarea
                    rows={2}
                    value={journalPageSubtitle}
                    onChange={(e) => setJournalPageSubtitle(e.target.value)}
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900 leading-relaxed focus:border-black focus:outline-hidden"
                  />
                </div>
              </div>
            </div>

            {/* 3. Complete Dispatches & Essays CMS */}
            <div className="space-y-3">
              <div className="border-b border-neutral-200 pb-2 flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-lg font-bold text-neutral-900">
                    Dispatches, Essays & Studio Articles
                  </h3>
                  <p className="text-xs text-neutral-500 font-sans">
                    Write, edit, publish, draft, and tag all editorial articles in the Journal.
                  </p>
                </div>
              </div>

              <BlogPostsCMS />
            </div>
          </div>
        )}

        {/* TAB 10: FOOTER & LEGAL PAGES */}
        {activeTab === 'footer_legal' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Footer Slogan & Legal Covenant Pages</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Manage global footer slogan, newsletter invitation copy, Terms of Service, and Privacy Policy.
              </p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Footer Slogan Quote</label>
                  <input
                    type="text"
                    value={footerSlogan}
                    onChange={(e) => setFooterSlogan(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif italic text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Newsletter Box Heading</label>
                  <input
                    type="text"
                    value={newsletterHeading}
                    onChange={(e) => setNewsletterHeading(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Newsletter Subtitle Description</label>
                <input
                  type="text"
                  value={newsletterSubtitle}
                  onChange={(e) => setNewsletterSubtitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900"
                />
              </div>

              <div className="pt-4 border-t border-neutral-100 space-y-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Terms of Service Page Title</label>
                  <input
                    type="text"
                    value={termsPageTitle}
                    onChange={(e) => setTermsPageTitle(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Terms of Service Page Body</label>
                  <textarea
                    rows={4}
                    value={termsPageBody}
                    onChange={(e) => setTermsPageBody(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-100 space-y-4">
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Privacy Policy Page Title</label>
                  <input
                    type="text"
                    value={privacyPageTitle}
                    onChange={(e) => setPrivacyPageTitle(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Privacy Policy Page Body</label>
                  <textarea
                    rows={4}
                    value={privacyPageBody}
                    onChange={(e) => setPrivacyPageBody(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs font-sans text-neutral-900 leading-relaxed"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="pt-4 border-t border-neutral-200 flex justify-end">
          <Button type="button" onClick={handleSavePageContent} variant="primary" size="md">
            <Check className="w-3.5 h-3.5 mr-1.5" />
            <span>Publish All Page CMS Updates</span>
          </Button>
        </div>
      </div>

      {/* FAQ Item Add/Edit Modal */}
      {faqModalOpen && (
        <Modal
          isOpen={faqModalOpen}
          onClose={() => setFaqModalOpen(false)}
          title={editingFaqId ? 'Edit FAQ Question & Guidance' : 'Add New FAQ Question'}
        >
          <form onSubmit={handleSaveFaq} className="space-y-4">
            <div>
              <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                Inquiry Category
              </label>
              <select
                value={faqFormCategory}
                onChange={(e) => setFaqFormCategory(e.target.value as FAQItem['category'])}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900 focus:outline-hidden focus:border-black"
              >
                <option value="Brand & Meaning">Brand & Meaning</option>
                <option value="Products & Sizing">Products & Sizing</option>
                <option value="Shipping & Delivery">Shipping & Delivery</option>
                <option value="Returns & Care">Returns & Care</option>
              </select>
            </div>

            <div>
              <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                Question Headline *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. How should I wash and care for this heavy garment?"
                value={faqFormQuestion}
                onChange={(e) => setFaqFormQuestion(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-serif font-bold text-neutral-900 focus:outline-hidden focus:border-black"
              />
            </div>

            <div>
              <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                Detailed Guidance & Answer *
              </label>
              <textarea
                required
                rows={4}
                placeholder="Provide clear, thoughtful customer guidance..."
                value={faqFormAnswer}
                onChange={(e) => setFaqFormAnswer(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900 leading-relaxed focus:outline-hidden focus:border-black"
              />
            </div>

            <div className="pt-3 border-t border-neutral-200 flex items-center justify-end space-x-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setFaqModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="sm">
                <Check className="w-3.5 h-3.5 mr-1" />
                <span>{editingFaqId ? 'Save Changes' : 'Publish Question'}</span>
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* FAQ Delete Confirmation Modal */}
      {faqDeleteModalItem && (
        <ConfirmDeleteModal
          isOpen={Boolean(faqDeleteModalItem)}
          onClose={() => setFaqDeleteModalItem(null)}
          onConfirm={() => {
            if (faqDeleteModalItem) {
              deleteFaq(faqDeleteModalItem.id);
              setFaqDeleteModalItem(null);
              setToastMessage('FAQ removed.');
              setTimeout(() => setToastMessage(null), 3000);
            }
          }}
          title="Delete FAQ Question"
          itemName={faqDeleteModalItem.question}
          itemType="FAQ question"
          warningMessage="This question and guidance will be permanently removed from customer care and the public FAQ page."
        />
      )}
    </div>
  );
};
