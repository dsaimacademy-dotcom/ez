import React, { useState } from 'react';
import {
  Globe,
  Search,
  CheckCircle2,
  Share2,
  RefreshCw,
  Save,
  Check,
  Eye,
  Code,
  Sliders,
  ShieldCheck,
  Image as ImageIcon,
  ExternalLink,
  Layers,
  ArrowRight
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { PageSeoConfig } from '../../types';
import { DEFAULT_PAGE_SEO, getPageSeo } from '../../data/defaultPageSeo';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';
import { Button } from '../ui/Button';

export interface PageSeoMetadataCMSProps {
  initialPageId?: string;
  showToast?: (message: string) => void;
}

export const PageSeoMetadataCMS: React.FC<PageSeoMetadataCMSProps> = ({
  initialPageId = 'home',
  showToast,
}) => {
  const { content, updatePageSeo, resetPageSeo } = useContent();
  const brand = content?.brandName || 'Ezistential Connection';

  const pageList = Object.values(DEFAULT_PAGE_SEO);
  const [selectedPageId, setSelectedPageId] = useState<string>(initialPageId);
  const [activeViewMode, setActiveViewMode] = useState<'editor' | 'serp' | 'social' | 'schema'>('editor');
  const [searchFilter, setSearchFilter] = useState('');
  const [hasSaved, setHasSaved] = useState(false);

  // Current page config (either custom or default fallback)
  const currentSeo = getPageSeo(selectedPageId, content?.pageSeoConfigs, brand);

  // Form states for selected page
  const [title, setTitle] = useState(currentSeo.title);
  const [description, setDescription] = useState(currentSeo.description);
  const [keywords, setKeywords] = useState(currentSeo.keywords || '');
  const [ogImage, setOgImage] = useState(currentSeo.ogImage || '');
  const [canonicalPath, setCanonicalPath] = useState(currentSeo.canonicalPath || '');
  const [robotsDirective, setRobotsDirective] = useState(currentSeo.robotsDirective || 'index, follow');
  const [schemaType, setSchemaType] = useState(currentSeo.schemaType || 'WebPage');

  // When changing selected page, sync local form states
  const handleSelectPage = (pageId: string) => {
    setSelectedPageId(pageId);
    const seo = getPageSeo(pageId, content?.pageSeoConfigs, brand);
    setTitle(seo.title);
    setDescription(seo.description);
    setKeywords(seo.keywords || '');
    setOgImage(seo.ogImage || '');
    setCanonicalPath(seo.canonicalPath || '');
    setRobotsDirective(seo.robotsDirective || 'index, follow');
    setSchemaType(seo.schemaType || 'WebPage');
    setHasSaved(false);
  };

  React.useEffect(() => {
    if (initialPageId) {
      handleSelectPage(initialPageId);
    }
  }, [initialPageId]);

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    updatePageSeo(selectedPageId, {
      title,
      description,
      keywords,
      ogImage,
      canonicalPath,
      robotsDirective,
      schemaType,
    });
    setHasSaved(true);
    if (showToast) {
      showToast(`SEO metadata for "${currentSeo.pageName}" saved successfully!`);
    }
    setTimeout(() => setHasSaved(false), 3000);
  };

  const handleResetToDefault = () => {
    resetPageSeo(selectedPageId);
    const def = DEFAULT_PAGE_SEO[selectedPageId] || DEFAULT_PAGE_SEO.home;
    const resolvedTitle = def.title.replace(/Ezistential Connection/g, brand);
    setTitle(resolvedTitle);
    setDescription(def.description);
    setKeywords(def.keywords || '');
    setOgImage(def.ogImage || '');
    setCanonicalPath(def.canonicalPath || '');
    setRobotsDirective(def.robotsDirective || 'index, follow');
    setSchemaType(def.schemaType || 'WebPage');
    if (showToast) {
      showToast(`Reset "${def.pageName}" to optimized launch defaults!`);
    }
  };

  const filteredPages = pageList.filter((p) =>
    p.pageName.toLowerCase().includes(searchFilter.toLowerCase()) ||
    p.id.toLowerCase().includes(searchFilter.toLowerCase()) ||
    p.title.toLowerCase().includes(searchFilter.toLowerCase())
  );

  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ezistential.com';
  const fullCanonicalUrl = `${baseUrl}${canonicalPath.startsWith('/') ? canonicalPath : `/${canonicalPath}`}`;

  // Generate real-time Schema.org JSON-LD preview
  const jsonLdPreview = {
    '@context': 'https://schema.org',
    '@type': schemaType,
    name: title,
    description: description,
    url: fullCanonicalUrl,
    publisher: {
      '@type': 'Organization',
      name: brand,
      logo: `${baseUrl}/ez-logo.svg`,
    },
    ...(schemaType === 'ClothingStore' ? {
      currenciesAccepted: 'USD',
      paymentAccepted: 'Credit Card, Apple Pay, Google Pay',
      priceRange: '$$',
      address: {
        '@type': 'PostalAddress',
        addressCountry: 'US',
      },
    } : {}),
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-white p-6 sm:p-8 border border-neutral-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[11px] font-mono uppercase tracking-widest text-neutral-500 font-bold">
              Production Launch Crawlability Engine
            </span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl text-neutral-900 tracking-tight">
            Per-Page SEO & Structured Metadata Manager
          </h2>
          <p className="text-xs sm:text-sm text-neutral-600 font-sans leading-relaxed max-w-2xl">
            Audit, edit, and fine-tune search snippet titles, meta descriptions, OpenGraph social cards, canonical paths, and Schema.org rich results for every storefront destination.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleResetToDefault}
            className="text-xs font-mono"
            title="Restore recommended pre-launch metadata"
          >
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
            <span>Reset to Launch Defaults</span>
          </Button>
          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={() => handleSave()}
            className="text-xs font-mono"
          >
            {hasSaved ? (
              <>
                <Check className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
                <span>Saved Live!</span>
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5 mr-1.5" />
                <span>Save Page SEO</span>
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Main Grid: Left Page Selector, Right SEO Editor & Previews */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Page Directory List (4 cols) */}
        <div className="lg:col-span-4 bg-white border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-200 bg-neutral-50 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-neutral-700 font-bold">
                Storefront Pages ({pageList.length})
              </span>
              <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-xs font-medium">
                100% Crawlable
              </span>
            </div>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search page or route..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-neutral-300 font-sans focus:outline-hidden focus:border-black"
              />
            </div>
          </div>

          <div className="divide-y divide-neutral-100">
            {filteredPages.map((page) => {
              const isSelected = page.id === selectedPageId;
              const hasCustom = Boolean(content?.pageSeoConfigs?.[page.id]);
              return (
                <button
                  key={page.id}
                  type="button"
                  onClick={() => handleSelectPage(page.id)}
                  className={`w-full text-left p-3.5 transition-colors flex items-start justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-neutral-900 text-white'
                      : 'hover:bg-neutral-50 text-neutral-800'
                  }`}
                >
                  <div className="space-y-1 min-w-0 pr-2">
                    <div className="flex items-center space-x-2">
                      <span className={`text-xs font-mono font-medium truncate ${isSelected ? 'text-white' : 'text-neutral-900'}`}>
                        {page.pageName}
                      </span>
                      {hasCustom && (
                        <span className={`text-[9px] font-mono px-1 rounded ${isSelected ? 'bg-neutral-700 text-neutral-200' : 'bg-neutral-100 text-neutral-600'}`}>
                          Custom
                        </span>
                      )}
                    </div>
                    <p className={`text-[11px] truncate font-sans ${isSelected ? 'text-neutral-400' : 'text-neutral-500'}`}>
                      {page.canonicalPath}
                    </p>
                  </div>
                  <ArrowRight className={`w-3.5 h-3.5 shrink-0 mt-1 ${isSelected ? 'text-white' : 'text-neutral-300'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: SEO Configuration & Real-Time Previews (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Subtabs for View / Mode */}
          <div className="flex items-center space-x-2 border-b border-neutral-200 pb-2">
            {[
              { id: 'editor', label: 'Metadata Editor', icon: Sliders },
              { id: 'serp', label: 'Google Search Simulator', icon: Globe },
              { id: 'social', label: 'OpenGraph Card Simulator', icon: Share2 },
              { id: 'schema', label: 'JSON-LD Rich Schema', icon: Code },
            ].map((tab) => {
              const IconComp = tab.icon;
              const isActive = activeViewMode === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveViewMode(tab.id as any)}
                  className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider flex items-center space-x-2 cursor-pointer transition-colors ${
                    isActive
                      ? 'bg-neutral-900 text-white font-bold'
                      : 'bg-white text-neutral-600 hover:text-black hover:bg-neutral-100 border border-neutral-200'
                  }`}
                >
                  <IconComp className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* VIEW 1: METADATA EDITOR FORM */}
          {activeViewMode === 'editor' && (
            <form onSubmit={handleSave} className="bg-white p-6 sm:p-7 border border-neutral-200 space-y-6 shadow-xs">
              <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 font-bold block">
                    Editing Target
                  </span>
                  <h3 className="font-serif text-xl text-neutral-900 font-semibold">
                    {currentSeo.pageName} ({currentSeo.canonicalPath})
                  </h3>
                </div>
                <span className="text-xs font-mono bg-neutral-100 text-neutral-700 px-2 py-1 rounded-xs">
                  Directive: {robotsDirective}
                </span>
              </div>

              {/* Page Title */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs uppercase font-mono tracking-wider text-neutral-700 font-semibold block">
                    Page Document Title (`&lt;title&gt;` & `og:title`) *
                  </label>
                  <span className={`text-[11px] font-mono ${title.length > 60 ? 'text-amber-600 font-bold' : title.length < 30 ? 'text-neutral-400' : 'text-emerald-700 font-medium'}`}>
                    {title.length} / 60 chars {title.length <= 60 && title.length >= 30 ? '(Optimal)' : ''}
                  </span>
                </div>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden focus:border-black"
                  placeholder="e.g. Ezistential Connection | The Space Between Us"
                />
                <p className="text-[11px] text-neutral-500 font-sans">
                  The primary anchor for search engines and browser tabs. Recommended between 30 and 60 characters.
                </p>
              </div>

              {/* Meta Description */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs uppercase font-mono tracking-wider text-neutral-700 font-semibold block">
                    Meta Description (`&lt;meta name="description"&gt;`) *
                  </label>
                  <span className={`text-[11px] font-mono ${description.length > 160 ? 'text-amber-600 font-bold' : description.length < 120 ? 'text-neutral-400' : 'text-emerald-700 font-medium'}`}>
                    {description.length} / 160 chars {description.length <= 160 && description.length >= 120 ? '(Optimal)' : ''}
                  </span>
                </div>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden focus:border-black leading-relaxed"
                  placeholder="Compelling 1–2 sentence summary of this page..."
                />
                <p className="text-[11px] text-neutral-500 font-sans">
                  Rendered beneath the headline in Google snippets. Keep between 120 and 160 characters to avoid truncation.
                </p>
              </div>

              {/* Search Keywords */}
              <div className="space-y-1.5">
                <label className="text-xs uppercase font-mono tracking-wider text-neutral-700 font-semibold block">
                  Search Keywords (`&lt;meta name="keywords"&gt;`)
                </label>
                <input
                  type="text"
                  value={keywords}
                  onChange={(e) => setKeywords(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden focus:border-black"
                  placeholder="e.g. heavyweight cotton, philosophical streetwear, made to order..."
                />
                <p className="text-[11px] text-neutral-500 font-sans">
                  Comma-separated keywords defining thematic topical clusters.
                </p>
              </div>

              {/* Canonical Path & Robots Directive */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2">
                <div className="space-y-1.5">
                  <label className="text-xs uppercase font-mono tracking-wider text-neutral-700 font-semibold block">
                    Canonical Path (`rel="canonical"`)
                  </label>
                  <input
                    type="text"
                    value={canonicalPath}
                    onChange={(e) => setCanonicalPath(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden focus:border-black"
                    placeholder="/shop"
                  />
                  <p className="text-[10px] text-neutral-500 font-mono">
                    Resolves to: {fullCanonicalUrl}
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs uppercase font-mono tracking-wider text-neutral-700 font-semibold block">
                    Robots Crawl Directive
                  </label>
                  <select
                    value={robotsDirective}
                    onChange={(e) => setRobotsDirective(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden focus:border-black cursor-pointer"
                  >
                    <option value="index, follow">index, follow (Fully indexed & crawlable)</option>
                    <option value="noindex, follow">noindex, follow (Hide snippet, follow links)</option>
                    <option value="noindex, nofollow">noindex, nofollow (Strictly private)</option>
                  </select>
                  <p className="text-[10px] text-neutral-500 font-mono">
                    Instructs Googlebot and Bingbot indexing behavior.
                  </p>
                </div>
              </div>

              {/* Schema Type */}
              <div className="space-y-1.5 pt-2">
                <label className="text-xs uppercase font-mono tracking-wider text-neutral-700 font-semibold block">
                  Schema.org Structured Data Entity Type
                </label>
                <select
                  value={schemaType}
                  onChange={(e) => setSchemaType(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden focus:border-black cursor-pointer"
                >
                  <option value="ClothingStore">ClothingStore / Brand (E-Commerce Storefront)</option>
                  <option value="CollectionPage">CollectionPage (Product Catalog / Series)</option>
                  <option value="Product">Product (Single Garment Spec)</option>
                  <option value="FAQPage">FAQPage (Help & Care Questions)</option>
                  <option value="AboutPage">AboutPage (Philosophy / Story / Manifesto)</option>
                  <option value="ContactPage">ContactPage (Studio Directory)</option>
                  <option value="WebPage">WebPage (General Policy / Utility)</option>
                </select>
              </div>

              {/* OpenGraph Social Image */}
              <div className="space-y-2 pt-2 border-t border-neutral-100">
                <label className="text-xs uppercase font-mono tracking-wider text-neutral-700 font-semibold block">
                  Social Share Card Image (`og:image` & `twitter:image`)
                </label>
                <div className="space-y-3">
                  <input
                    type="url"
                    value={ogImage}
                    onChange={(e) => setOgImage(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden focus:border-black"
                    placeholder="https://images.unsplash.com/..."
                  />
                  <ImageUploadCompressor
                    value={ogImage}
                    onChange={(url: string) => setOgImage(url)}
                    label="Upload & Compress Custom 1200x630 Social Banner"
                    helperText="High-resolution banner for Twitter, Facebook, LinkedIn, and iMessage previews"
                    maxWidth={1200}
                    maxHeight={630}
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleResetToDefault}
                  className="text-xs font-mono text-neutral-500 hover:text-black underline cursor-pointer"
                >
                  Restore default metadata for this page
                </button>
                <Button type="submit" variant="primary" size="md">
                  <Save className="w-3.5 h-3.5 mr-1.5" />
                  <span>Save Page Metadata</span>
                </Button>
              </div>
            </form>
          )}

          {/* VIEW 2: SERP SEARCH SIMULATOR */}
          {activeViewMode === 'serp' && (
            <div className="bg-white p-6 sm:p-7 border border-neutral-200 space-y-6 shadow-xs">
              <div className="border-b border-neutral-100 pb-3">
                <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 font-bold block">
                  Search Engine Results Page (SERP)
                </span>
                <h3 className="font-serif text-lg text-neutral-900">
                  Google Desktop & Mobile Search Preview
                </h3>
              </div>

              {/* Simulated Google Card */}
              <div className="p-5 bg-white border border-neutral-200 rounded-sm shadow-xs max-w-2xl space-y-2 font-sans">
                <div className="flex items-center space-x-2 text-xs text-neutral-600">
                  <div className="w-4 h-4 rounded-full bg-black flex items-center justify-center text-white text-[9px] font-serif">
                    Z
                  </div>
                  <span className="text-neutral-800 font-medium">{brand}</span>
                  <span className="text-neutral-400">›</span>
                  <span className="text-neutral-500 font-mono text-[11px] truncate">{fullCanonicalUrl}</span>
                </div>

                <h4 className="text-[#1a0dab] hover:underline cursor-pointer text-lg font-normal leading-snug">
                  {title}
                </h4>

                <p className="text-xs text-[#4d5156] leading-relaxed line-clamp-2">
                  {description}
                </p>

                <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-neutral-500 border-t border-neutral-100 font-mono">
                  <span>Robots: <strong>{robotsDirective}</strong></span>
                  <span>•</span>
                  <span>Canonical: <strong>{canonicalPath}</strong></span>
                  <span>•</span>
                  <span>Type: <strong>{schemaType}</strong></span>
                </div>
              </div>
            </div>
          )}

          {/* VIEW 3: SOCIAL OPENGRAPH CARD SIMULATOR */}
          {activeViewMode === 'social' && (
            <div className="bg-white p-6 sm:p-7 border border-neutral-200 space-y-6 shadow-xs">
              <div className="border-b border-neutral-100 pb-3">
                <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 font-bold block">
                  Social Graph Card Preview
                </span>
                <h3 className="font-serif text-lg text-neutral-900">
                  X / Twitter / Facebook / iMessage Preview (16:9)
                </h3>
              </div>

              {/* Simulated Social Card */}
              <div className="border border-neutral-300 rounded-xs overflow-hidden max-w-lg bg-neutral-900 text-white shadow-md">
                <div className="aspect-16/9 bg-neutral-800 relative overflow-hidden">
                  {ogImage ? (
                    <img
                      src={ogImage}
                      alt={title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-neutral-500 font-mono text-xs">
                      No Image Configured
                    </div>
                  )}
                  <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-xs px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider text-white border border-white/20">
                    {brand}
                  </div>
                </div>

                <div className="p-4 space-y-1.5 bg-[#141414] border-t border-neutral-800">
                  <div className="text-[10px] font-mono uppercase tracking-wider text-neutral-400">
                    ezistential.com
                  </div>
                  <h4 className="font-serif text-base font-medium text-white leading-snug">
                    {title}
                  </h4>
                  <p className="text-xs text-neutral-400 font-sans line-clamp-2 leading-relaxed">
                    {description}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* VIEW 4: JSON-LD SCHEMA CODE */}
          {activeViewMode === 'schema' && (
            <div className="bg-white p-6 sm:p-7 border border-neutral-200 space-y-4 shadow-xs">
              <div className="border-b border-neutral-100 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 font-bold block">
                    Structured Data
                  </span>
                  <h3 className="font-serif text-lg text-neutral-900">
                    Live Schema.org JSON-LD Output
                  </h3>
                </div>
                <span className="text-xs font-mono bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5">
                  Valid Schema.org
                </span>
              </div>

              <pre className="bg-[#0a0a0a] text-emerald-400 p-5 text-xs font-mono overflow-x-auto border border-neutral-800 rounded-xs leading-relaxed">
                {JSON.stringify(jsonLdPreview, null, 2)}
              </pre>

              <p className="text-xs text-neutral-500 font-sans">
                Automatically rendered inside `&lt;script type="application/ld+json"&gt;` in the page head, allowing Google to generate rich knowledge graphs and search results.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
