import React, { useState, useEffect } from 'react';
import {
  Settings,
  SlidersHorizontal,
  ShieldCheck,
  Bell,
  Database,
  CheckCircle2,
  Lock,
  Download,
  Upload,
  RefreshCw,
  AlertTriangle,
  Server,
  Key,
  Truck,
  Eye,
  Mail,
  Zap,
  Check,
  Save,
  Send,
  FileText,
  Smartphone,
  Tag,
  ExternalLink,
  ShieldAlert,
  BellRing,
  User,
  Copy,
  Link,
  EyeOff
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { useProducts } from '../../context/ProductContext';
import { useOrders } from '../../context/OrderContext';
import { usePosts } from '../../context/PostContext';
import { Button } from '../ui/Button';
import { api } from '../../lib/api';

export type SettingsSubTab = 'ux' | 'security' | 'notifications' | 'email_templates' | 'backup';
export type EmailTemplateKey = 'signup' | 'password' | 'order_status' | 'order_confirm';

export const SettingsSetup: React.FC<{
  initialSubTab?: SettingsSubTab;
  onOpenDataBackupModal?: () => void;
}> = ({ initialSubTab = 'ux', onOpenDataBackupModal }) => {
  const { content, updateContent, faqs } = useContent();
  const { products } = useProducts();
  const { orders } = useOrders();
  const { posts } = usePosts();

  const [activeSubTab, setActiveSubTab] = useState<SettingsSubTab>(initialSubTab);
  const [activeEmailKey, setActiveEmailKey] = useState<EmailTemplateKey>('signup');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Storefront & UX States
  const [freeShippingThreshold, setFreeShippingThreshold] = useState(content.freeShippingThreshold ?? 150);
  const [standardShippingRate, setStandardShippingRate] = useState(content.standardShippingRate ?? 12);
  const [enableCookieConsentBanner, setEnableCookieConsentBanner] = useState(content.enableCookieConsentBanner ?? true);
  const [enableTourGuide, setEnableTourGuide] = useState(content.enableTourGuide ?? true);
  const [enableJournal, setEnableJournal] = useState(content.enableJournal !== false);
  const [enableReflections, setEnableReflections] = useState(content.enableReflections !== false);
  const [enableEcosystem, setEnableEcosystem] = useState(content.enableEcosystem !== false);
  const [enablePdpReviews, setEnablePdpReviews] = useState(content.enablePdpReviews !== false);
  const [cookieBannerHeadline, setCookieBannerHeadline] = useState(content.cookieBannerHeadline || 'Digital Dignity & Data Respect');
  const [cookieBannerDescription, setCookieBannerDescription] = useState(
    content.cookieBannerDescription || 'We process minimal telemetry required for order logistics. No third-party data tracking.'
  );

  // Admin Profile & Security Credentials States
  const [adminUser, setAdminUser] = useState<any>(() => {
    try {
      const stored = localStorage.getItem('ec_admin_user');
      return stored ? JSON.parse(stored) : {
        email: 'admin@ezistential.com',
        fullName: 'Ezistential Curator',
        role: 'superadmin',
        location: 'Los Angeles, CA',
        bio: 'Editorial curator and archivist for Ezistential Connections.',
      };
    } catch {
      return { email: 'admin@ezistential.com', fullName: 'Ezistential Curator', role: 'superadmin' };
    }
  });

  const [adminEmail, setAdminEmail] = useState(adminUser?.email || 'admin@ezistential.com');
  const [adminFullName, setAdminFullName] = useState(adminUser?.fullName || 'Ezistential Curator');
  const [adminLocation, setAdminLocation] = useState(adminUser?.location || 'Los Angeles, CA');
  const [adminBio, setAdminBio] = useState(adminUser?.bio || 'Editorial curator and archivist for Ezistential Connections.');
  const [adminPhone, setAdminPhone] = useState(adminUser?.phone || '');
  const [adminLoginUrl, setAdminLoginUrl] = useState(content.adminLoginUrl || '/admin');

  // Password Management States
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [isUpdatingSecurity, setIsUpdatingSecurity] = useState(false);
  const [securityStatusMsg, setSecurityStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedLoginUrl, setCopiedLoginUrl] = useState(false);

  // Security & System States
  const [sessionTimeoutMinutes, setSessionTimeoutMinutes] = useState(60);
  const [requireTwoFactor, setRequireTwoFactor] = useState(false);
  const [apiLoggingEnabled, setApiLoggingEnabled] = useState(true);

  // Notifications & Maintenance States
  const [adminNotifyEmails, setAdminNotifyEmails] = useState(content.ordersEmail || 'orders@ezistential.com');
  const [lowStockAlertThreshold, setLowStockAlertThreshold] = useState(content.lowStockAlertThreshold ?? 5);
  const [maintenanceMode, setMaintenanceMode] = useState(content.enableMaintenanceMode ?? false);
  const [maintenanceMessage, setMaintenanceMessage] = useState(
    content.maintenanceMessage || 'Storefront is undergoing scheduled maintenance. Please check back shortly.'
  );
  const [maintenanceLockoutType, setMaintenanceLockoutType] = useState<'full_lockout' | 'checkout_disabled'>(
    content.maintenanceLockoutType || 'full_lockout'
  );
  const [dispatchOrderAlerts, setDispatchOrderAlerts] = useState(content.dispatchOrderAlerts ?? true);
  const [dispatchLowStockAlerts, setDispatchLowStockAlerts] = useState(content.dispatchLowStockAlerts ?? true);
  const [dispatchSecurityAlerts, setDispatchSecurityAlerts] = useState(content.dispatchSecurityAlerts ?? true);
  const [dispatchUgcAlerts, setDispatchUgcAlerts] = useState(content.dispatchUgcAlerts ?? false);
  const [emergencyBroadcastActive, setEmergencyBroadcastActive] = useState(content.emergencyBroadcastActive ?? false);
  const [emergencyBroadcastMessage, setEmergencyBroadcastMessage] = useState(
    content.emergencyBroadcastMessage || 'Notice: On-demand print queue operating at high volume.'
  );
  const [adminDispatchTestState, setAdminDispatchTestState] = useState<{ testing: boolean; msg?: string }>({ testing: false });

  // Sync profile from server on mount
  useEffect(() => {
    const fetchAdminProfile = async () => {
      try {
        const users = await api.adminGetUsers();
        if (users && users.length > 0) {
          const staff = users.find((u) => u.role === 'superadmin' || u.role === 'admin') || users[0];
          if (staff) {
            setAdminUser(staff);
            setAdminEmail(staff.email);
            setAdminFullName(staff.fullName);
            if (staff.location) setAdminLocation(staff.location);
            if (staff.bio) setAdminBio(staff.bio);
            if (staff.phone) setAdminPhone(staff.phone);
          }
        }
      } catch (err) {
        console.warn('Admin profile load note:', err);
      }
    };
    fetchAdminProfile();
  }, []);

  useEffect(() => {
    if (content.adminLoginUrl) {
      setAdminLoginUrl(content.adminLoginUrl);
    }
  }, [content.adminLoginUrl]);

  // Email Template States (Sign Up, Password Reset, Order Status, Order Confirm)
  const [signUpSubject, setSignUpSubject] = useState(
    content.smtpSignUpSubject || 'Welcome to Ezistential Connection — Space Between People'
  );
  const [signUpBody, setSignUpBody] = useState(
    content.smtpSignUpTemplate ||
      'Dear {customer_name},\n\nWelcome to Ezistential Connection. Your account has been initialized.\n\nExplore our connection garments at https://ezistential.com\n\nWarm regards,\nEzistential Connection Studio'
  );

  const [passwordSubject, setPasswordSubject] = useState(
    content.smtpPasswordResetSubject || 'Reset Your Ezistential Connection Password'
  );
  const [passwordBody, setPasswordBody] = useState(
    content.smtpPasswordResetTemplate ||
      'Hello {customer_name},\n\nWe received a request to reset your password. Click the link below to verify:\n{reset_link}\n\nIf you did not request this, please ignore this message.\n\nEzistential Care Team'
  );

  const [orderStatusSubject, setOrderStatusSubject] = useState(
    content.smtpOrderStatusSubject || 'Shipment Update for Order #{order_id} — In Transit'
  );
  const [orderStatusBody, setOrderStatusBody] = useState(
    content.smtpOrderStatusTemplate ||
      'Dear {customer_name},\n\nYour order #{order_id} status has been updated to: {order_status}.\n\nTracking Reference: {tracking_number}\n\nThank you for journeying with us,\nEzistential Connection'
  );

  const [orderConfirmSubject, setOrderConfirmSubject] = useState(
    content.smtpOrderConfirmSubject || 'Order Confirmation #{order_id} — Ezistential Connection'
  );
  const [orderConfirmBody, setOrderConfirmBody] = useState(
    content.smtpOrderConfirmTemplate ||
      'Dear {customer_name},\n\nThank you for your order #{order_id} totaling ${total_amount}.\n\nItems Ordered:\n{items_summary}\n\nWe are preparing your garments for print-on-demand fulfillment.\n\nEzistential Fulfillment'
  );

  // Email Sender Identity & Verification Settings
  const [enableSignupVerificationEmail, setEnableSignupVerificationEmail] = useState(content.enableSignupVerificationEmail ?? true);
  const [fromSenderName, setFromSenderName] = useState(
    content.smtpFromSenderName || content.brandName || 'Ezistential Connection Studio'
  );
  const [fromSenderEmail, setFromSenderEmail] = useState(
    content.smtpFromSenderEmail || content.ordersEmail || 'support@ezistential.com'
  );

  const [testDispatchState, setTestDispatchState] = useState<{ testing: boolean; msg?: string }>({ testing: false });
  const [smtpHandshakeState, setSmtpHandshakeState] = useState<{
    testing: boolean;
    success?: boolean;
    msg?: string;
    latencyMs?: number;
  }>({ testing: false });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      freeShippingThreshold: Number(freeShippingThreshold) || 0,
      standardShippingRate: Number(standardShippingRate) || 0,
      enableCookieConsentBanner,
      enableTourGuide,
      enableJournal,
      enableReflections,
      enableEcosystem,
      enablePdpReviews,
      cookieBannerHeadline: cookieBannerHeadline.trim(),
      cookieBannerDescription: cookieBannerDescription.trim(),
      ordersEmail: adminNotifyEmails.trim(),

      // Maintenance Mode & Notifications Dispatch
      enableMaintenanceMode: maintenanceMode,
      maintenanceMessage: maintenanceMessage.trim(),
      maintenanceLockoutType,
      lowStockAlertThreshold: Number(lowStockAlertThreshold) || 5,
      dispatchOrderAlerts,
      dispatchLowStockAlerts,
      dispatchSecurityAlerts,
      dispatchUgcAlerts,
      emergencyBroadcastActive,
      emergencyBroadcastMessage: emergencyBroadcastMessage.trim(),

      enableSignupVerificationEmail,
      smtpFromSenderName: fromSenderName.trim(),
      smtpFromSenderEmail: fromSenderEmail.trim(),
      smtpSignUpSubject: signUpSubject.trim(),
      smtpSignUpTemplate: signUpBody.trim(),
      smtpPasswordResetSubject: passwordSubject.trim(),
      smtpPasswordResetTemplate: passwordBody.trim(),
      smtpOrderStatusSubject: orderStatusSubject.trim(),
      smtpOrderStatusTemplate: orderStatusBody.trim(),
      smtpOrderConfirmSubject: orderConfirmSubject.trim(),
      smtpOrderConfirmTemplate: orderConfirmBody.trim(),
      adminLoginUrl: adminLoginUrl.trim(),
    });
    showToast('All System, Emergency Maintenance & Dispatch settings saved successfully!');
  };

  const handleCopyLoginUrl = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://ezistential.com';
    const cleanUrl = adminLoginUrl.startsWith('/') ? adminLoginUrl : `/${adminLoginUrl}`;
    const fullUrl = `${origin}${cleanUrl}`;
    navigator.clipboard?.writeText(fullUrl);
    setCopiedLoginUrl(true);
    showToast('Admin Cockpit URL copied to clipboard!');
    setTimeout(() => setCopiedLoginUrl(false), 2500);
  };

  const handleUpdateAdminSecurityProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityStatusMsg(null);

    if (newPassword) {
      if (newPassword.length < 8) {
        setSecurityStatusMsg({ type: 'error', text: 'New password must be at least 8 characters long.' });
        return;
      }
      if (newPassword !== confirmPassword) {
        setSecurityStatusMsg({ type: 'error', text: 'New passwords do not match. Please verify your entries.' });
        return;
      }
    }

    setIsUpdatingSecurity(true);

    try {
      const res = await api.updateAdminSecurityProfile({
        email: adminEmail.trim(),
        fullName: adminFullName.trim(),
        currentPassword: currentPassword.trim() || undefined,
        newPassword: newPassword.trim() || undefined,
        location: adminLocation.trim(),
        bio: adminBio.trim(),
        phone: adminPhone.trim(),
        adminLoginUrl: adminLoginUrl.trim(),
      });

      if (res && res.success) {
        if (res.user) {
          setAdminUser(res.user);
        }
        if (res.adminLoginUrl) {
          setAdminLoginUrl(res.adminLoginUrl);
        }
        updateContent({ adminLoginUrl: res.adminLoginUrl || adminLoginUrl.trim() });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        setSecurityStatusMsg({
          type: 'success',
          text: res.message || 'Administrative profile, credentials, and cockpit login URL updated successfully.',
        });
        showToast('Admin security profile & credentials updated successfully!');
      } else {
        setSecurityStatusMsg({
          type: 'error',
          text: res?.error || 'Failed to update admin security profile. Verify password or input fields.',
        });
      }
    } catch (err: any) {
      setSecurityStatusMsg({
        type: 'error',
        text: err?.message || 'An error occurred while contacting the security server.',
      });
    } finally {
      setIsUpdatingSecurity(false);
    }
  };

  const handleTestEmailDispatch = () => {
    setTestDispatchState({ testing: true });
    setTimeout(() => {
      setTestDispatchState({
        testing: false,
        msg: `Test dispatch simulation rendered for '${activeEmailKey}' template. Check live preview on right pane.`,
      });
      showToast('Simulated email dispatch rendered!');
    }, 400);
  };

  const handleTestAdminDispatch = () => {
    setAdminDispatchTestState({ testing: true });
    setTimeout(() => {
      setAdminDispatchTestState({
        testing: false,
        msg: `Administrative notification test payload sent to [${adminNotifyEmails}]. Triggers active: Order Alerts (${dispatchOrderAlerts ? 'ON' : 'OFF'}), Low Stock Threshold (${dispatchLowStockAlerts ? 'ON' : 'OFF'} @ ${lowStockAlertThreshold} units), Security Alerts (${dispatchSecurityAlerts ? 'ON' : 'OFF'}).`,
      });
      showToast('Test Administrative Dispatch sent!');
    }, 500);
  };

  const handleTestSmtpHandshake = async () => {
    setSmtpHandshakeState({ testing: true });
    try {
      if (!content.smtpHost || !content.smtpUsername) {
        setSmtpHandshakeState({
          testing: false,
          success: false,
          msg: 'SMTP Host or Username is not configured in Integrations > SMTP Gateway.',
        });
        return;
      }

      const res = await api.testSmtpHandshake({
        host: content.smtpHost,
        port: content.smtpPort,
        encryption: content.smtpEncryption,
        username: content.smtpUsername,
        password: content.smtpPassword,
        fromSenderEmail: content.smtpFromSenderEmail || fromSenderEmail,
        fromSenderName: content.smtpFromSenderName || fromSenderName,
      });

      setSmtpHandshakeState({
        testing: false,
        success: res.success,
        msg: res.message || `SMTP Gateway handshake verified on ${content.smtpHost}:${content.smtpPort || 465} (${content.smtpEncryption || 'SSL'}). Transactional delivery active.`,
        latencyMs: res.latencyMs || 140,
      });
      showToast('SMTP Gateway handshake verified successfully!');
    } catch (err: any) {
      setSmtpHandshakeState({
        testing: false,
        success: false,
        msg: `SMTP Gateway probe failed: ${err.message}`,
      });
    }
  };

  // Live Template Sample Filler for Live Email Previewer
  const renderSamplePreviewText = (text: string) => {
    return text
      .replace(/{customer_name}/g, 'Alex Morgan')
      .replace(/{brand_name}/g, content.brandName || 'Ezistential Connection')
      .replace(/{order_id}/g, 'EZ-9402')
      .replace(/{total_amount}/g, '148.00')
      .replace(/{items_summary}/g, '1x Heavyweight Hooded Sweatshirt (L / Charcoal) — $148.00')
      .replace(/{reset_link}/g, 'https://ezistential.com/auth/reset?token=e8a9f2')
      .replace(/{tracking_number}/g, '9400111899562100843211 (USPS Priority)')
      .replace(/{order_status}/g, 'In Transit / Shipped from Chicago Studio');
  };

  const getCurrentSubject = () => {
    if (activeEmailKey === 'signup') return signUpSubject;
    if (activeEmailKey === 'password') return passwordSubject;
    if (activeEmailKey === 'order_status') return orderStatusSubject;
    return orderConfirmSubject;
  };

  const getCurrentBody = () => {
    if (activeEmailKey === 'signup') return signUpBody;
    if (activeEmailKey === 'password') return passwordBody;
    if (activeEmailKey === 'order_status') return orderStatusBody;
    return orderConfirmBody;
  };

  const insertTag = (tag: string) => {
    if (activeEmailKey === 'signup') setSignUpBody((prev) => prev + ` ${tag}`);
    else if (activeEmailKey === 'password') setPasswordBody((prev) => prev + ` ${tag}`);
    else if (activeEmailKey === 'order_status') setOrderStatusBody((prev) => prev + ` ${tag}`);
    else if (activeEmailKey === 'order_confirm') setOrderConfirmBody((prev) => prev + ` ${tag}`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-neutral-200 gap-4">
        <div>
          <h2 className="font-serif text-2xl text-neutral-900">System Settings & Email Templates Manager</h2>
          <p className="text-xs text-neutral-500 mt-1">
            Configure logistics rules, administrative security, database backups, and manage & preview email templates.
          </p>
        </div>
        <Button onClick={handleSaveSettings} variant="primary" size="md">
          <Save className="w-3.5 h-3.5 mr-1.5" />
          <span>Save All Settings</span>
        </Button>
      </div>

      {/* Subtabs Bar */}
      <div className="flex border-b border-neutral-200 overflow-x-auto gap-1 text-xs font-mono">
        <button
          type="button"
          onClick={() => setActiveSubTab('ux')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'ux' ? 'border-black text-black font-bold bg-neutral-50' : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Truck className="w-3.5 h-3.5" />
          <span>1. Storefront UX & Shipping</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('security')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'security'
              ? 'border-black text-black font-bold bg-neutral-50'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>2. Security & Access</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('notifications')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'notifications'
              ? 'border-black text-black font-bold bg-neutral-50'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>3. Notifications & Maintenance</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('email_templates')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'email_templates'
              ? 'border-black text-black font-bold bg-neutral-50 text-purple-900'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Mail className="w-3.5 h-3.5 text-purple-600" />
          <span>4. Email Templates & Live Preview</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('backup')}
          className={`py-2.5 px-4 font-medium uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'backup'
              ? 'border-black text-black font-bold bg-neutral-50'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>5. Database & Snapshots</span>
        </button>
      </div>

      {/* Main Form Body */}
      <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
        {/* SUBTAB 1: STOREFRONT UX & LOGISTICS */}
        {activeSubTab === 'ux' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">Storefront E-Commerce & Shipping Logistics</h3>
              <p className="text-xs text-neutral-500 font-sans">
                Configure complimentary shipping thresholds, flat rate fees, and cookie banner parameters.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs font-mono">
              <div>
                <label className="block text-neutral-800 font-medium mb-1">
                  Complimentary Domestic Shipping Threshold ($)
                </label>
                <input
                  type="number"
                  value={freeShippingThreshold}
                  onChange={(e) => setFreeShippingThreshold(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-neutral-800 font-medium mb-1">Standard Flat Rate Shipping Fee ($)</label>
                <input
                  type="number"
                  value={standardShippingRate}
                  onChange={(e) => setStandardShippingRate(Number(e.target.value))}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                />
              </div>
            </div>

            <div className="p-5 bg-neutral-50 border border-neutral-200 space-y-2">
              <label className="flex items-center space-x-3 text-xs text-neutral-900 font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableTourGuide}
                  onChange={(e) => setEnableTourGuide(e.target.checked)}
                  className="accent-black w-4 h-4"
                />
                <span>Enable Interactive Storefront Tour Guide & Walkthrough</span>
              </label>
              <p className="text-xs text-neutral-500 pl-7 font-sans">
                When turned off, the "Tour Guide" button in the top announcement bar and experience guide modals are completely hidden from customer storefront visitors.
              </p>
            </div>

            {/* Feature System Toggles: Journal & Reflections */}
            <div className="p-5 bg-neutral-50 border border-neutral-200 space-y-4">
              <div className="border-b border-neutral-200 pb-2">
                <h4 className="text-xs font-mono uppercase tracking-wider font-bold text-neutral-900">
                  Interactive Systems & Content Modules
                </h4>
                <p className="text-xs text-neutral-500">
                  Control the availability of interactive inquiry systems. Disabling pauses the feature from customer view without deleting existing data.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <label className="flex items-start space-x-3 text-xs text-neutral-900 font-medium cursor-pointer p-3 bg-white border border-neutral-200">
                  <input
                    type="checkbox"
                    checked={enableJournal}
                    onChange={(e) => setEnableJournal(e.target.checked)}
                    className="accent-black w-4 h-4 mt-0.5"
                  />
                  <div>
                    <span className="font-bold block">Journal System & Dispatches</span>
                    <span className="text-neutral-500 text-[11px]">
                      Studio essays, process manifestos, and journal articles at <code className="text-black">/updates</code>.
                    </span>
                  </div>
                </label>

                <label className="flex items-start space-x-3 text-xs text-neutral-900 font-medium cursor-pointer p-3 bg-white border border-neutral-200">
                  <input
                    type="checkbox"
                    checked={enableReflections}
                    onChange={(e) => setEnableReflections(e.target.checked)}
                    className="accent-black w-4 h-4 mt-0.5"
                  />
                  <div>
                    <span className="font-bold block">Human Reflection System</span>
                    <span className="text-neutral-500 text-[11px]">
                      Connection Archive at <code className="text-black">/connection</code>, quote carousels & testimonials.
                    </span>
                  </div>
                </label>

                <label className="flex items-start space-x-3 text-xs text-neutral-900 font-medium cursor-pointer p-3 bg-white border border-neutral-200">
                  <input
                    type="checkbox"
                    checked={enablePdpReviews}
                    onChange={(e) => setEnablePdpReviews(e.target.checked)}
                    className="accent-black w-4 h-4 mt-0.5"
                  />
                  <div>
                    <span className="font-bold block">Garment Page Reflections</span>
                    <span className="text-neutral-500 text-[11px]">
                      "What does this mean to you?" prompts & photo gallery on product pages.
                    </span>
                  </div>
                </label>

                <label className="flex items-start space-x-3 text-xs text-neutral-900 font-medium cursor-pointer p-3 bg-white border border-neutral-200">
                  <input
                    type="checkbox"
                    checked={enableEcosystem}
                    onChange={(e) => setEnableEcosystem(e.target.checked)}
                    className="accent-black w-4 h-4 mt-0.5"
                  />
                  <div>
                    <span className="font-bold block">Ecosystem Dimension Media</span>
                    <span className="text-neutral-500 text-[11px]">
                      Audio dispatches, films, and exhibitions at <code className="text-black">/ecosystem</code>.
                    </span>
                  </div>
                </label>
              </div>
            </div>

            <div className="p-5 bg-neutral-50 border border-neutral-200 space-y-4">
              <label className="flex items-center space-x-3 text-xs text-neutral-900 font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableCookieConsentBanner}
                  onChange={(e) => setEnableCookieConsentBanner(e.target.checked)}
                  className="accent-black w-4 h-4"
                />
                <span>Enable Privacy & Digital Dignity Consent Banner</span>
              </label>

              {enableCookieConsentBanner && (
                <div className="grid grid-cols-1 gap-4 pt-2">
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">Banner Heading</label>
                    <input
                      type="text"
                      value={cookieBannerHeadline}
                      onChange={(e) => setCookieBannerHeadline(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1">Banner Policy Notice</label>
                    <textarea
                      rows={2}
                      value={cookieBannerDescription}
                      onChange={(e) => setCookieBannerDescription(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SUBTAB 2: SECURITY & ACCESS */}
        {activeSubTab === 'security' && (
          <form onSubmit={handleUpdateAdminSecurityProfile} className="space-y-8 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-serif text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <span>Administrative Security, Profile & System Access</span>
                </h3>
                <p className="text-xs text-neutral-500 font-sans mt-0.5">
                  Update your curator administrative email, credentials, password, profile details, and custom login access URL.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 text-xs font-mono border font-bold uppercase bg-neutral-900 text-white border-neutral-800 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-amber-400" />
                  <span>Role: {adminUser?.role?.toUpperCase() || 'SUPERADMIN'}</span>
                </span>
              </div>
            </div>

            {/* Status Alert Banner */}
            {securityStatusMsg && (
              <div
                className={`p-4 border text-xs font-mono space-y-1 ${
                  securityStatusMsg.type === 'success'
                    ? 'bg-emerald-50 text-emerald-950 border-emerald-300'
                    : 'bg-red-50 text-red-950 border-red-300'
                }`}
              >
                <div className="flex items-center gap-2 font-bold">
                  {securityStatusMsg.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                  )}
                  <span>{securityStatusMsg.type === 'success' ? 'Security Credentials Updated' : 'Action Failed'}</span>
                </div>
                <p className="font-sans text-[11px] pl-6">{securityStatusMsg.text}</p>
              </div>
            )}

            {/* CARD 1: ADMIN PROFILE & IDENTITY DETAILS */}
            <div className="bg-white border border-neutral-200 p-6 space-y-5 shadow-xs">
              <div className="border-b border-neutral-100 pb-3 flex items-center justify-between">
                <div>
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center gap-2">
                    <User className="w-4 h-4 text-neutral-700" />
                    <span>1. Administrative Profile & Login Email</span>
                  </h4>
                  <p className="text-[11px] text-neutral-500 font-sans mt-0.5">
                    Your email address serves as your primary staff login credential across all browsers and devices.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs font-mono">
                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Admin Login Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    placeholder="admin@ezistential.com"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:border-black focus:outline-hidden"
                  />
                  <span className="text-[10px] text-neutral-400 font-sans mt-1 block">
                    Used to authenticate at the staff cockpit login gate.
                  </span>
                </div>

                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Admin Full Name / Curator Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={adminFullName}
                    onChange={(e) => setAdminFullName(e.target.value)}
                    placeholder="Ezistential Curator"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:border-black focus:outline-hidden"
                  />
                  <span className="text-[10px] text-neutral-400 font-sans mt-1 block">
                    Public or internal signature displayed on dispatched communications.
                  </span>
                </div>

                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Staff Location / Base
                  </label>
                  <input
                    type="text"
                    value={adminLocation}
                    onChange={(e) => setAdminLocation(e.target.value)}
                    placeholder="Chicago, IL / Studio Vault"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:border-black focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Staff Phone Number
                  </label>
                  <input
                    type="tel"
                    value={adminPhone}
                    onChange={(e) => setAdminPhone(e.target.value)}
                    placeholder="(312) 555-0192"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:border-black focus:outline-hidden"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Curator Bio & Operational Role
                  </label>
                  <textarea
                    rows={2}
                    value={adminBio}
                    onChange={(e) => setAdminBio(e.target.value)}
                    placeholder="Editorial curator and archivist for Ezistential Connections."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:border-black focus:outline-hidden resize-none"
                  />
                </div>
              </div>
            </div>

            {/* CARD 2: CHANGE ADMINISTRATIVE PASSWORD */}
            <div className="bg-white border border-neutral-200 p-6 space-y-5 shadow-xs">
              <div className="border-b border-neutral-100 pb-3">
                <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center gap-2">
                  <Key className="w-4 h-4 text-neutral-700" />
                  <span>2. Change Administrative Password</span>
                </h4>
                <p className="text-[11px] text-neutral-500 font-sans mt-0.5">
                  Leave blank if you do not wish to change your password. Must be at least 8 characters.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 text-xs font-mono">
                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Current Password
                  </label>
                  <div className="relative">
                    <input
                      type={showCurrentPassword ? 'text' : 'password'}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2.5 pr-10 text-xs text-neutral-900 font-mono focus:border-black focus:outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-black p-1 cursor-pointer"
                    >
                      {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    New Password
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Min 8 characters"
                      className="w-full bg-neutral-50 border border-neutral-300 p-2.5 pr-10 text-xs text-neutral-900 font-mono focus:border-black focus:outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-black p-1 cursor-pointer"
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat new password"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:border-black focus:outline-hidden"
                  />
                </div>
              </div>
            </div>

            {/* CARD 3: CUSTOM COCKPIT LOGIN URL & ENDPOINT CLOAKING */}
            <div className="bg-[#fcfcfb] border border-neutral-200 p-6 space-y-5 shadow-xs">
              <div className="border-b border-neutral-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center gap-2">
                    <Link className="w-4 h-4 text-purple-600" />
                    <span>3. Custom Admin Login Access URL & Cloaking</span>
                  </h4>
                  <p className="text-[11px] text-neutral-500 font-sans mt-0.5">
                    Change the staff entrance URL to obscure administrative endpoints from automated web vulnerability scrapers.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleCopyLoginUrl}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-neutral-300 hover:border-black text-xs font-mono text-neutral-800 transition-colors cursor-pointer shadow-2xs shrink-0"
                >
                  {copiedLoginUrl ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700 font-bold">Copied Full URL!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-neutral-500" />
                      <span>Copy Cockpit Link</span>
                    </>
                  )}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs font-mono">
                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Staff Login Path Slug *
                  </label>
                  <div className="flex items-center">
                    <span className="bg-neutral-200 border border-r-0 border-neutral-300 px-3 py-2.5 text-xs font-mono text-neutral-600 select-none">
                      /
                    </span>
                    <input
                      type="text"
                      required
                      value={adminLoginUrl.replace(/^\/+/, '')}
                      onChange={(e) => setAdminLoginUrl(`/${e.target.value.toLowerCase().replace(/[^a-z0-9\-_/]/g, '')}`)}
                      placeholder="admin or studio-access or vault"
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:border-black focus:outline-hidden"
                    />
                  </div>
                  <span className="text-[10px] text-neutral-500 font-sans mt-1 block">
                    Example: <code className="bg-neutral-100 px-1 py-0.5">/studio-access</code>, <code className="bg-neutral-100 px-1 py-0.5">/curator-cockpit</code>, or standard <code className="bg-neutral-100 px-1 py-0.5">/admin</code>
                  </span>
                </div>

                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Live Active Cockpit Endpoint
                  </label>
                  <div className="p-2.5 bg-neutral-100 border border-neutral-300 font-mono text-xs text-neutral-800 truncate flex items-center justify-between">
                    <span className="truncate">
                      {(typeof window !== 'undefined' ? window.location.origin : 'https://ezistential.com')}
                      {adminLoginUrl.startsWith('/') ? adminLoginUrl : `/${adminLoginUrl}`}
                    </span>
                    <span className="px-1.5 py-0.5 bg-neutral-900 text-white text-[9px] uppercase font-bold shrink-0 ml-2">
                      Active
                    </span>
                  </div>
                  <span className="text-[10px] text-neutral-500 font-sans mt-1 block">
                    Bookmarking this exact route directs your browser straight to the staff entrance.
                  </span>
                </div>
              </div>
            </div>

            {/* CARD 4: SESSION TIMEOUT & 2FA POLICIES */}
            <div className="bg-white border border-neutral-200 p-6 space-y-5 shadow-xs">
              <div className="border-b border-neutral-100 pb-3">
                <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-neutral-700" />
                  <span>4. Session Timeout & Multi-Factor Guard</span>
                </h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs font-mono">
                <div>
                  <label className="block text-neutral-800 font-medium mb-1.5 uppercase">
                    Admin Session Timeout (Minutes)
                  </label>
                  <input
                    type="number"
                    value={sessionTimeoutMinutes}
                    onChange={(e) => setSessionTimeoutMinutes(Number(e.target.value))}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:border-black focus:outline-hidden"
                  />
                </div>

                <div className="flex items-center pt-2 sm:pt-6">
                  <label className="flex items-center space-x-3 text-xs text-neutral-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={requireTwoFactor}
                      onChange={(e) => setRequireTwoFactor(e.target.checked)}
                      className="accent-black w-4 h-4"
                    />
                    <div>
                      <span className="font-bold block">Enforce 2FA for Admin Portal Access</span>
                      <span className="text-[11px] text-neutral-500 font-normal font-sans">
                        Requires authenticator app confirmation code on login.
                      </span>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            {/* SUBMIT BUTTON */}
            <div className="flex justify-end pt-2">
              <Button
                type="submit"
                variant="primary"
                size="md"
                disabled={isUpdatingSecurity}
                className="py-3 px-6 text-xs font-mono uppercase tracking-wider"
              >
                {isUpdatingSecurity ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 mr-2 animate-spin" />
                    <span>Saving Security Credentials...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5 mr-2" />
                    <span>Save Security, Profile & Access Settings</span>
                  </>
                )}
              </Button>
            </div>
          </form>
        )}

        {/* SUBTAB 3: NOTIFICATIONS & MAINTENANCE */}
        {activeSubTab === 'notifications' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-serif text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-amber-600" />
                  <span>Notifications Dispatch & Emergency Maintenance Mode</span>
                </h3>
                <p className="text-xs text-neutral-500 font-sans mt-0.5">
                  Configure administrative alert dispatches and manage temporary storefront lockouts or emergency maintenance screens.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className={`px-2.5 py-1 text-xs font-mono border font-bold uppercase flex items-center gap-1.5 ${
                  maintenanceMode
                    ? 'bg-amber-50 text-amber-900 border-amber-300'
                    : 'bg-emerald-50 text-emerald-900 border-emerald-300'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${maintenanceMode ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`} />
                  <span>{maintenanceMode ? 'Emergency Lockout Active' : 'Storefront Operational'}</span>
                </span>
              </div>
            </div>

            {/* CARD 1: EMERGENCY MAINTENANCE & STOREFRONT LOCKOUT */}
            <div className="p-5 bg-neutral-50 border border-neutral-200 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
                <div>
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center gap-1.5">
                    <Lock className="w-4 h-4 text-amber-600" />
                    <span>Storefront Lockout & Maintenance Controls</span>
                  </h4>
                  <p className="text-[11px] text-neutral-500 font-sans mt-0.5">
                    Instantly restrict public access to the storefront for scheduled system updates, inventory audits, or emergency site holds.
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={maintenanceMode}
                    onChange={(e) => setMaintenanceMode(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600" />
                  <span className="ml-2 text-xs font-mono font-bold text-neutral-900">
                    {maintenanceMode ? 'Lockout ON' : 'Lockout OFF'}
                  </span>
                </label>
              </div>

              {maintenanceMode && (
                <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 text-xs font-mono space-y-1">
                  <p className="font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>STOREFRONT LOCKOUT IS CURRENTLY ACTIVE</span>
                  </p>
                  <p className="text-[11px] text-amber-800 font-sans">
                    Public visitors will see the Emergency Maintenance Screen. Authenticated administrators can still access the Admin Cockpit at <code className="bg-amber-100 px-1 py-0.5">/admin</code>.
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono font-medium text-neutral-800 mb-1">
                    Lockout Mode & Scope
                  </label>
                  <select
                    value={maintenanceLockoutType}
                    onChange={(e) => setMaintenanceLockoutType(e.target.value as any)}
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                  >
                    <option value="full_lockout">Full Storefront Lockout (Redirect to Maintenance Screen)</option>
                    <option value="checkout_disabled">Catalog Browsing Active (Disable Bag & Checkout Only)</option>
                  </select>
                  <p className="text-[10px] text-neutral-500 font-sans mt-1">
                    Full lockout presents an editorial maintenance screen. Browsing mode allows users to read garment details but disables ordering.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-mono font-medium text-neutral-800 mb-1">
                    Public Maintenance Notice Headline & Copy
                  </label>
                  <textarea
                    rows={3}
                    value={maintenanceMessage}
                    onChange={(e) => setMaintenanceMessage(e.target.value)}
                    placeholder="Storefront is undergoing scheduled maintenance. Please check back shortly."
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-serif text-neutral-900 focus:outline-hidden"
                  />
                  <p className="text-[10px] text-neutral-500 font-sans mt-0.5">
                    Displayed prominently on the public maintenance page to inform visitors.
                  </p>
                </div>
              </div>
            </div>

            {/* CARD 2: EMERGENCY BROADCAST ANNOUNCEMENT BAR */}
            <div className="p-5 bg-neutral-50 border border-neutral-200 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
                <div>
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center gap-1.5">
                    <BellRing className="w-4 h-4 text-purple-600" />
                    <span>Emergency Broadcast Announcement Banner</span>
                  </h4>
                  <p className="text-[11px] text-neutral-500 font-sans mt-0.5">
                    Publish an immediate top announcement bar across the live storefront without locking out visitors.
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={emergencyBroadcastActive}
                    onChange={(e) => setEmergencyBroadcastActive(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600" />
                  <span className="ml-2 text-xs font-mono font-bold text-neutral-900">
                    {emergencyBroadcastActive ? 'Broadcast ON' : 'Broadcast OFF'}
                  </span>
                </label>
              </div>

              <div>
                <label className="block text-xs font-mono font-medium text-neutral-800 mb-1">
                  Broadcast Alert Message Copy
                </label>
                <input
                  type="text"
                  value={emergencyBroadcastMessage}
                  onChange={(e) => setEmergencyBroadcastMessage(e.target.value)}
                  placeholder="Notice: High volume order processing active. Shipping estimated within 48 hours."
                  className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                />
              </div>
            </div>

            {/* CARD 3: ADMINISTRATIVE DISPATCH EMAILS & EVENT TRIGGERS */}
            <div className="p-5 bg-neutral-50 border border-neutral-200 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
                <div>
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-purple-600" />
                    <span>Administrative Notification Dispatch & Alerts</span>
                  </h4>
                  <p className="text-[11px] text-neutral-500 font-sans mt-0.5">
                    Specify administrative email recipients and configure event triggers for real-time order, inventory, and security dispatches.
                  </p>
                </div>

                <Button type="button" variant="outline" size="sm" onClick={handleTestAdminDispatch}>
                  <Send className="w-3.5 h-3.5 mr-1.5 text-purple-600" />
                  <span>Test Admin Dispatch</span>
                </Button>
              </div>

              {adminDispatchTestState.msg && (
                <div className="p-3 bg-purple-50 border border-purple-200 text-purple-900 text-xs font-mono">
                  <p className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>ADMIN DISPATCH TEST VERIFIED</span>
                  </p>
                  <p className="text-[11px] text-purple-800 font-sans mt-1">
                    {adminDispatchTestState.msg}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-mono">
                <div>
                  <label className="block text-neutral-800 font-medium mb-1">
                    Admin Notification Dispatch Recipient Emails
                  </label>
                  <input
                    type="email"
                    value={adminNotifyEmails}
                    onChange={(e) => setAdminNotifyEmails(e.target.value)}
                    placeholder="orders@ezistential.com, ops@ezistential.com"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                  />
                  <p className="text-[10px] text-neutral-500 font-sans mt-1">
                    Multiple addresses can be specified using comma separators.
                  </p>
                </div>

                <div>
                  <label className="block text-neutral-800 font-medium mb-1">
                    Low Stock Inventory Alert Threshold (Units)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={lowStockAlertThreshold}
                    onChange={(e) => setLowStockAlertThreshold(Number(e.target.value))}
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                  />
                  <p className="text-[10px] text-neutral-500 font-sans mt-1">
                    Triggers low stock administrative dispatch when variant inventory drops below this quantity.
                  </p>
                </div>
              </div>

              {/* Event Dispatch Triggers */}
              <div className="pt-2 border-t border-neutral-200">
                <label className="block text-xs font-mono font-bold uppercase text-neutral-900 mb-3">
                  Active Dispatch Triggers
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                  <label className="flex items-center space-x-2.5 p-3 bg-white border border-neutral-200 cursor-pointer hover:border-neutral-300 transition-colors">
                    <input
                      type="checkbox"
                      checked={dispatchOrderAlerts}
                      onChange={(e) => setDispatchOrderAlerts(e.target.checked)}
                      className="accent-black w-4 h-4"
                    />
                    <div>
                      <span className="font-bold block text-neutral-900">New Order Dispatch Alerts</span>
                      <span className="text-[10px] text-neutral-500 font-sans">Immediate email notice on customer checkout.</span>
                    </div>
                  </label>

                  <label className="flex items-center space-x-2.5 p-3 bg-white border border-neutral-200 cursor-pointer hover:border-neutral-300 transition-colors">
                    <input
                      type="checkbox"
                      checked={dispatchLowStockAlerts}
                      onChange={(e) => setDispatchLowStockAlerts(e.target.checked)}
                      className="accent-black w-4 h-4"
                    />
                    <div>
                      <span className="font-bold block text-neutral-900">Low Stock Inventory Alerts</span>
                      <span className="text-[10px] text-neutral-500 font-sans">Alert when variant stock falls below threshold.</span>
                    </div>
                  </label>

                  <label className="flex items-center space-x-2.5 p-3 bg-white border border-neutral-200 cursor-pointer hover:border-neutral-300 transition-colors">
                    <input
                      type="checkbox"
                      checked={dispatchSecurityAlerts}
                      onChange={(e) => setDispatchSecurityAlerts(e.target.checked)}
                      className="accent-black w-4 h-4"
                    />
                    <div>
                      <span className="font-bold block text-neutral-900">Security & Failed Login Alerts</span>
                      <span className="text-[10px] text-neutral-500 font-sans">Alert on unauthorized admin login attempts.</span>
                    </div>
                  </label>

                  <label className="flex items-center space-x-2.5 p-3 bg-white border border-neutral-200 cursor-pointer hover:border-neutral-300 transition-colors">
                    <input
                      type="checkbox"
                      checked={dispatchUgcAlerts}
                      onChange={(e) => setDispatchUgcAlerts(e.target.checked)}
                      className="accent-black w-4 h-4"
                    />
                    <div>
                      <span className="font-bold block text-neutral-900">Customer Reflection Submissions</span>
                      <span className="text-[10px] text-neutral-500 font-sans">Alert when users post lookbook reflections.</span>
                    </div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 4: EMAIL TEMPLATES & LIVE PREVIEW (NEW!) */}
        {activeSubTab === 'email_templates' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="border-b border-neutral-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center space-x-2">
                  <Mail className="w-5 h-5 text-purple-600" />
                  <h3 className="font-serif text-lg font-bold text-neutral-900">Transactional Email Template Manager & Live Preview</h3>
                </div>
                <p className="text-xs text-neutral-500 mt-0.5 font-sans">
                  Edit transactional email text and test real-time rendered previews for Sign Up, Password Reset, and Order Status.
                </p>
              </div>

              <Button type="button" variant="outline" size="sm" onClick={handleTestEmailDispatch}>
                <Send className="w-3.5 h-3.5 mr-1.5 text-purple-600" />
                <span>Simulate Dispatch Preview</span>
              </Button>
            </div>

            {/* Outgoing Sender Identity & SMTP Gateway Connectivity Card */}
            <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-200 pb-3">
                <div>
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center gap-1.5">
                    <Server className="w-3.5 h-3.5 text-purple-600" />
                    <span>Outgoing Dispatch Identity & SMTP Gateway Status</span>
                  </h4>
                  <p className="text-[11px] text-neutral-500 font-sans mt-0.5">
                    Configure the global sender address shown in recipient inboxes and monitor the underlying SMTP server connection.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 text-[10px] font-mono border uppercase font-bold flex items-center gap-1 ${
                    content.smtpEnabled
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-neutral-100 text-neutral-700 border-neutral-300'
                  }`}>
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>SMTP: {content.smtpEnabled ? 'Enabled' : 'Simulated / Standby'}</span>
                  </span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleTestSmtpHandshake}
                    className="text-[11px] font-mono"
                  >
                    <RefreshCw className={`w-3 h-3 mr-1 text-purple-600 ${smtpHandshakeState.testing ? 'animate-spin' : ''}`} />
                    <span>{smtpHandshakeState.testing ? 'Testing...' : 'Test SMTP Handshake'}</span>
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                <div>
                  <label className="block text-neutral-800 font-bold mb-1 uppercase text-[10px]">
                    From Sender Display Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={fromSenderName}
                    onChange={(e) => setFromSenderName(e.target.value)}
                    placeholder="Ezistential Connection Studio"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-sans focus:outline-hidden focus:border-black"
                  />
                  <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">
                    Appears as sender title in Gmail, Apple Mail, and Outlook
                  </span>
                </div>

                <div>
                  <label className="block text-neutral-800 font-bold mb-1 uppercase text-[10px]">
                    From Sender Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={fromSenderEmail}
                    onChange={(e) => setFromSenderEmail(e.target.value)}
                    placeholder="care@ezistential.com"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden focus:border-black"
                  />
                  <span className="text-[10px] text-neutral-400 font-mono mt-0.5 block">
                    Return-path and reply-to mailbox for transactional dispatches
                  </span>
                </div>
              </div>

              {smtpHandshakeState.msg && (
                <div className={`p-3 text-xs font-mono border ${
                  smtpHandshakeState.success ? 'bg-emerald-50 text-emerald-900 border-emerald-300' : 'bg-red-50 text-red-900 border-red-300'
                }`}>
                  <div className="font-bold flex items-center justify-between">
                    <span>SMTP Gateway Probe Result:</span>
                    {smtpHandshakeState.latencyMs && <span>{smtpHandshakeState.latencyMs}ms</span>}
                  </div>
                  <div>{smtpHandshakeState.msg}</div>
                </div>
              )}
            </div>

            {/* CARD: SIGNUP ACCOUNT VERIFICATION ADMIN TOGGLE */}
            <div className="p-4 bg-white border border-neutral-200 space-y-3 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-purple-600 shrink-0" />
                    <h4 className="text-xs uppercase font-mono font-bold text-neutral-900">
                      Nodemailer Account Verification Emails on Signup
                    </h4>
                  </div>
                  <p className="text-[11px] text-neutral-500 font-sans mt-0.5">
                    When enabled, new user registrations trigger an automated verification email via Nodemailer using <code className="text-neutral-900 font-bold font-mono">support@ezistential.com</code> SMTP credentials. Administrators can turn this ON or OFF anytime.
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={enableSignupVerificationEmail}
                    onChange={(e) => setEnableSignupVerificationEmail(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600" />
                  <span className="ml-2 text-xs font-mono font-bold text-neutral-900">
                    {enableSignupVerificationEmail ? 'Verification ON' : 'Verification OFF'}
                  </span>
                </label>
              </div>

              {enableSignupVerificationEmail ? (
                <div className="p-2.5 bg-purple-50 border border-purple-200 text-purple-900 text-[11px] font-mono flex items-center justify-between">
                  <span>Status: Verification active using Nodemailer (support@ezistential.com:465 SSL)</span>
                  <span className="px-1.5 py-0.5 bg-purple-950 text-purple-300 font-bold text-[9px] uppercase">Active</span>
                </div>
              ) : (
                <div className="p-2.5 bg-neutral-100 border border-neutral-300 text-neutral-700 text-[11px] font-mono flex items-center justify-between">
                  <span>Status: Signup verification emails turned OFF by Admin</span>
                  <span className="px-1.5 py-0.5 bg-neutral-200 text-neutral-800 font-bold text-[9px] uppercase">Bypassed</span>
                </div>
              )}
            </div>

            {/* Template Selection Pills */}
            <div className="flex border border-neutral-200 bg-neutral-100 p-1 rounded-xs overflow-x-auto text-xs font-mono">
              {[
                { id: 'signup', label: '1. User Sign Up / Welcome' },
                { id: 'password', label: '2. Password Reset Request' },
                { id: 'order_status', label: '3. Order Status & Shipping' },
                { id: 'order_confirm', label: '4. Order Confirmation' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setActiveEmailKey(t.id as EmailTemplateKey)}
                  className={`px-4 py-2 transition-all cursor-pointer font-medium whitespace-nowrap ${
                    activeEmailKey === t.id ? 'bg-black text-white font-bold shadow-xs' : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Dual Pane Editor & Live Inbox Preview */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-2">
              {/* Left Pane: Editable Text Area & Placeholders */}
              <div className="lg:col-span-6 space-y-5">
                <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-4">
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-900 flex items-center justify-between">
                    <span>Editable Template Controls</span>
                    <span className="text-[10px] text-purple-700 bg-purple-100 px-2 py-0.5 border border-purple-200">
                      Live Editable
                    </span>
                  </h4>

                  {/* Subject Line Input */}
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1 font-bold">
                      Email Subject Line *
                    </label>
                    <input
                      type="text"
                      required
                      value={
                        activeEmailKey === 'signup'
                          ? signUpSubject
                          : activeEmailKey === 'password'
                          ? passwordSubject
                          : activeEmailKey === 'order_status'
                          ? orderStatusSubject
                          : orderConfirmSubject
                      }
                      onChange={(e) => {
                        const val = e.target.value;
                        if (activeEmailKey === 'signup') setSignUpSubject(val);
                        else if (activeEmailKey === 'password') setPasswordSubject(val);
                        else if (activeEmailKey === 'order_status') setOrderStatusSubject(val);
                        else setOrderConfirmSubject(val);
                      }}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900 focus:outline-hidden focus:border-black"
                    />
                  </div>

                  {/* Body Text Area */}
                  <div>
                    <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1 font-bold">
                      Email Body Content Template *
                    </label>
                    <textarea
                      rows={8}
                      required
                      value={
                        activeEmailKey === 'signup'
                          ? signUpBody
                          : activeEmailKey === 'password'
                          ? passwordBody
                          : activeEmailKey === 'order_status'
                          ? orderStatusBody
                          : orderConfirmBody
                      }
                      onChange={(e) => {
                        const val = e.target.value;
                        if (activeEmailKey === 'signup') setSignUpBody(val);
                        else if (activeEmailKey === 'password') setPasswordBody(val);
                        else if (activeEmailKey === 'order_status') setOrderStatusBody(val);
                        else setOrderConfirmBody(val);
                      }}
                      className="w-full bg-white border border-neutral-300 p-3 text-xs font-mono text-neutral-900 leading-relaxed focus:outline-hidden focus:border-black"
                    />
                  </div>

                  {/* Placeholder Insert Pills */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[11px] font-mono font-bold text-neutral-700 flex items-center gap-1">
                      <Tag className="w-3 h-3 text-neutral-500" />
                      <span>Click to append placeholder tag:</span>
                    </span>
                    <div className="flex flex-wrap gap-1.5 text-[10px] font-mono">
                      {[
                        '{customer_name}',
                        '{brand_name}',
                        '{order_id}',
                        '{reset_link}',
                        '{total_amount}',
                        '{items_summary}',
                        '{tracking_number}',
                        '{order_status}',
                      ].map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => insertTag(tag)}
                          className="px-2 py-1 bg-white hover:bg-neutral-200 border border-neutral-300 text-neutral-800 cursor-pointer font-bold transition-all"
                        >
                          + {tag}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Pane: Live Email Inbox Preview Canvas */}
              <div className="lg:col-span-6 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs uppercase font-mono font-bold text-neutral-800 flex items-center gap-1.5">
                    <Eye className="w-4 h-4 text-emerald-600" />
                    <span>Real-Time Customer Inbox Render</span>
                  </h4>
                  <span className="text-[10px] font-mono text-neutral-500">Live Client View</span>
                </div>

                {/* Email Client Frame Simulation */}
                <div className="border border-neutral-300 bg-white shadow-md rounded-xs overflow-hidden">
                  {/* Inbox Title Bar */}
                  <div className="bg-neutral-900 text-white p-3 text-xs font-mono flex items-center justify-between border-b border-neutral-800">
                    <div className="flex items-center space-x-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" />
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                      <span className="text-[11px] font-bold text-neutral-300 ml-2">Inbox Preview</span>
                    </div>
                    <span className="text-[10px] opacity-75">{fromSenderEmail}</span>
                  </div>

                  {/* Header Meta Info */}
                  <div className="p-4 bg-neutral-50 border-b border-neutral-200 space-y-1 text-xs font-sans text-neutral-700">
                    <div className="flex items-center justify-between">
                      <div>
                        <strong>From:</strong> {fromSenderName} &lt;{fromSenderEmail}&gt;
                      </div>
                      <span className="text-[10px] font-mono text-neutral-400">18:20 PM</span>
                    </div>
                    <div>
                      <strong>To:</strong> Alex Morgan &lt;alex.morgan@client.com&gt;
                    </div>
                    <div className="pt-2 text-sm font-serif font-bold text-neutral-900 border-t border-neutral-200/60 mt-2">
                      Subject: {renderSamplePreviewText(getCurrentSubject())}
                    </div>
                  </div>

                  {/* Rendered Email Body Box */}
                  <div className="p-6 space-y-6 text-xs text-neutral-900 font-sans leading-relaxed bg-white min-h-[220px]">
                    {/* Brand Banner Inside Email */}
                    <div className="border-b border-neutral-200 pb-3 flex items-center justify-between">
                      <span className="font-serif font-bold tracking-wider text-sm uppercase">
                        {content.brandName || 'EZISTENTIAL CONNECTION'}
                      </span>
                      <span className="text-[9px] font-mono text-neutral-400 uppercase">STUDIO DIRECTIVE</span>
                    </div>

                    {/* Body Text with Live Variable Replacement */}
                    <div className="whitespace-pre-wrap font-sans text-neutral-800 text-xs leading-relaxed">
                      {renderSamplePreviewText(getCurrentBody())}
                    </div>

                    {/* Interactive Sample CTA inside email */}
                    {activeEmailKey === 'password' && (
                      <div className="pt-2">
                        <a
                          href="#preview"
                          onClick={(e) => e.preventDefault()}
                          className="inline-block bg-black text-white px-4 py-2 font-mono text-[11px] font-bold uppercase tracking-wider hover:bg-neutral-800"
                        >
                          Verify & Reset Password →
                        </a>
                      </div>
                    )}

                    {/* Email Footer Dignity Note */}
                    <div className="border-t border-neutral-100 pt-4 text-[10px] text-neutral-400 font-mono space-y-1">
                      <div>{content.legalBusinessName || 'Ezistential Connection LLC'} — Chicago, IL</div>
                      <div>Examining the space between people through intentional apparel.</div>
                    </div>
                  </div>
                </div>

                {testDispatchState.msg && (
                  <div className="p-3 bg-purple-50 text-purple-900 border border-purple-200 text-xs font-mono">
                    {testDispatchState.msg}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 5: DATABASE & SNAPSHOTS */}
        {activeSubTab === 'backup' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="font-serif text-lg text-neutral-900">Database Records & Backup Snapshots</h3>
              <p className="text-xs text-neutral-500 mt-0.5 font-sans">
                Export complete system backups, inspect database record counts, or restore state.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-neutral-50 border border-neutral-200 font-mono text-xs">
              <div className="p-3 bg-white border border-neutral-200">
                <div className="text-[10px] text-neutral-500 uppercase">Products</div>
                <div className="text-xl font-bold text-neutral-900 mt-1">{products.length}</div>
              </div>
              <div className="p-3 bg-white border border-neutral-200">
                <div className="text-[10px] text-neutral-500 uppercase">Orders</div>
                <div className="text-xl font-bold text-neutral-900 mt-1">{orders.length}</div>
              </div>
              <div className="p-3 bg-white border border-neutral-200">
                <div className="text-[10px] text-neutral-500 uppercase">Journal Posts</div>
                <div className="text-xl font-bold text-neutral-900 mt-1">{posts.length}</div>
              </div>
              <div className="p-3 bg-white border border-neutral-200">
                <div className="text-[10px] text-neutral-500 uppercase">FAQs</div>
                <div className="text-xl font-bold text-neutral-900 mt-1">{faqs.length}</div>
              </div>
            </div>

            <div className="p-6 bg-neutral-900 text-white space-y-4 border border-neutral-800">
              <div className="flex items-center space-x-2">
                <Database className="w-5 h-5 text-emerald-400" />
                <h4 className="font-serif text-base font-medium">Data Backup & Disaster Recovery</h4>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                Save a complete JSON snapshot of all products, order records, journal posts, and brand configuration to your local device.
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    if (onOpenDataBackupModal) {
                      onOpenDataBackupModal();
                    } else {
                      showToast('Opening Data Backup & Snapshot tool...');
                    }
                  }}
                >
                  <Download className="w-3.5 h-3.5 mr-1.5" />
                  <span>Open Snapshot & Restore Modal</span>
                </Button>
              </div>
            </div>
          </div>
        )}

        {activeSubTab !== 'security' && (
          <div className="pt-6 border-t border-neutral-200 flex justify-end">
            <Button type="button" onClick={handleSaveSettings} variant="primary" size="md">
              <Check className="w-3.5 h-3.5 mr-1.5" />
              <span>Save All Settings & Templates</span>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
