import React, { useState, useMemo, useEffect } from 'react';
import { safeSrc } from '../../lib/utils';
import type { ProductVariant } from '../../types';
import {
  LayoutDashboard,
  ShoppingBag,
  PackageCheck,
  MessageSquare,
  Settings,
  LogOut,
  Search,
  Download,
  RefreshCw,
  CheckCircle2,
  Clock,
  Truck,
  ExternalLink,
  Shield,
  ShieldCheck,
  AlertCircle,
  Plus,
  Eye,
  Trash2,
  Copy,
  Check,
  Lock,
  Filter,
  ArrowRight,
  TrendingUp,
  DollarSign,
  Package,
  Layers,
  FileText,
  AlertTriangle,
  X,
  Sliders,
  Send,
  Printer,
  Database,
  Palette,
  Users,
  HelpCircle,
  Compass,
  BookOpen,
  Menu,
  ChevronRight,
  ChevronLeft,
  PanelLeftClose,
  PanelLeft,
  Globe,
  SlidersHorizontal,
  Building2,
  MapPin,
  Phone,
  Mail,
  Share2,
  Image as ImageIcon,
  CreditCard,
  Zap
} from 'lucide-react';
import { Logo } from '../brand/Logo';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { api } from '../../lib/api';
import { autoAdjustFaviconForPWA } from '../../lib/pwaIconGenerator';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';
import { PackingSlipModal } from './PackingSlipModal';
import { DataBackupModal } from './DataBackupModal';
import { BrandBusinessSetup } from './BrandBusinessSetup';
import { IntegrationSetup, IntegrationTab } from './IntegrationSetup';
import { DesignSetup } from './DesignSetup';
import { HomeBannerStudio } from './HomeBannerStudio';
import { ProductStudio } from './ProductStudio';
import { ApliiqDesignSyncModal } from './ApliiqDesignSyncModal';
import { DesignFactoryCMS } from './DesignFactoryCMS';
import { WearTypeLibraryCMS } from './WearTypeLibraryCMS';
import { BlogPostsCMS } from './BlogPostsCMS';
import { EditorialPagesCMS, PageCmsTab } from './EditorialPagesCMS';
import { PageSeoMetadataCMS } from './PageSeoMetadataCMS';
import { MenuNavigationCMS } from './MenuNavigationCMS';
import { DesignAndNavigationCMS } from './DesignAndNavigationCMS';
import { JournalAndReflectionsCMS } from './JournalAndReflectionsCMS';
import { SettingsSetup } from './SettingsSetup';
import { UserVerificationCMS } from './UserVerificationCMS';
import { UserManagementCMS } from './UserManagementCMS';
import { PaymentStatusBadge, getPaymentConnectionStatus } from './PaymentStatusBadge';
import { Order, OrderStatus, Product, ModerationStatus, FAQItem, ShapeDividerVariant, UserProfile, DesignDraft, Size } from '../../types';
import { useOrders } from '../../context/OrderContext';
import { useProducts } from '../../context/ProductContext';
import { useResponses } from '../../context/ResponseContext';
import { useContent } from '../../context/ContentContext';
import { useAuth } from '../../context/AuthContext';
import { useServerSync } from '../../lib/serverSync';
import { formatPrice, FREE_SHIPPING_THRESHOLD, STANDARD_SHIPPING_FLAT_RATE } from '../../lib/utils';
import { DEFAULT_VERIFICATION_RULES } from '../../lib/verification';
import { ShapeDivider } from '../ui/ShapeDivider';
import { ConfirmDeleteModal } from '../modals/ConfirmDeleteModal';

const ALL_SIZES: Size[] = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];

export interface AdminPortalProps {
  onBackToStore: () => void;
  onNavigateToProduct?: (productId: string) => void;
  onNavigateToView?: (view: any) => void;
}

type AdminTab =
  | 'overview'
  | 'hero_banner'
  | 'banner'
  | 'brand'
  | 'brand_business_setup'
  | 'brand_integration'
  | 'brand_design'
  | 'menu_navigation'
  | 'design_and_navigation'
  | 'journal_reflections'
  | 'orders'
  | 'products'
  | 'design_factory'
  | 'variants'
  | 'moderation'
  | 'frontend'
  | 'content'
  | 'content_editorial'
  | 'content_updates'
  | 'ux'
  | 'users'
  | 'verification'
  | 'seo'
  | 'settings';

export function evaluateModuleAccess(user: { role?: string; effectiveCapabilities?: string[]; customPermissions?: string[] } | null) {
  const role = (user?.role || 'customer').toLowerCase().trim();
  const effectiveCaps = user?.effectiveCapabilities || (user as any)?.effective_capabilities || [];
  const isSuper = role === 'superadmin' || role === 'admin';
  const hasCap = (cap: string) => isSuper || effectiveCaps.includes(cap);

  return {
    isSuperadminActor: isSuper,
    canViewOverview: isSuper || hasCap('catalog.view') || hasCap('orders.view') || hasCap('content.view'),
    canViewOrders: hasCap('orders.view'),
    canViewCatalog: hasCap('catalog.view'),
    canViewContent: hasCap('content.view'),
    canViewCommunity: hasCap('community.view'),
    canViewUsers: isSuper || hasCap('users.view'),
    canViewIntegrations: isSuper || hasCap('integrations.edit'),
    canManageSettings: isSuper || hasCap('settings.manage'),
    canManageSeo: isSuper || hasCap('settings.manage') || hasCap('content.edit'),
    canManageBackup: isSuper || hasCap('backup.manage'),
    canEditOrders: isSuper || hasCap('orders.edit'),
    canFulfillOrders: isSuper || hasCap('orders.fulfill'),
    canExportOrders: isSuper || hasCap('orders.export'),
    canEditCatalog: isSuper || hasCap('catalog.edit'),
    canEditContent: isSuper || hasCap('content.edit'),
    canModerateCommunity: isSuper || hasCap('community.moderate'),
  };
}

export function getDefaultTabForRole(user: { role?: string; effectiveCapabilities?: string[]; customPermissions?: string[] } | null): AdminTab {
  if (!user) return 'overview';
  const role = (user.role || '').toLowerCase();
  if (role === 'fulfillment') return 'orders';
  if (role === 'editor') return 'content_updates';
  if (role === 'moderator') return 'moderation';
  if (role === 'manager' || role === 'superadmin' || role === 'admin') return 'overview';

  const caps = user.effectiveCapabilities || (user as any)?.effective_capabilities || [];
  if (caps.includes('orders.view')) return 'orders';
  if (caps.includes('catalog.view')) return 'products';
  if (caps.includes('content.view')) return 'content_updates';
  if (caps.includes('community.view')) return 'moderation';
  if (caps.includes('users.view')) return 'users';
  return 'overview';
}

export const AdminPortal: React.FC<AdminPortalProps> = ({ onBackToStore, onNavigateToProduct, onNavigateToView }) => {
  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('ec_admin_auth_v1') === 'true' && !!localStorage.getItem('ec_admin_token');
  });
  const [adminEmailInput, setAdminEmailInput] = useState('admin@ezistential.com');
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Sidebar & Navigation State - Defaults to role-appropriate workspace
  const [activeTab, setActiveTab] = useState<AdminTab>(() => {
    try {
      const stored = localStorage.getItem('ec_admin_user');
      if (stored) return getDefaultTabForRole(JSON.parse(stored));
    } catch {}
    return 'overview';
  });
  const [integrationInitialTab, setIntegrationInitialTab] = useState<IntegrationTab>('payment');
  const [editorialInitialTab, setEditorialInitialTab] = useState<PageCmsTab>('home');
  const [sidebarOpenMobile, setSidebarOpenMobile] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('ec_admin_sidebar_collapsed') === 'true';
    } catch {
      return false;
    }
  });

  const toggleSidebarCollapsed = () => {
    setIsSidebarCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('ec_admin_sidebar_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  // Contexts
  const { orders, updateOrderStatus, updateOrderTracking, deleteOrder, resetDemoOrders, addSampleOrder, fulfillOrder } = useOrders();
  const { products, updateProductPrice, toggleProductAvailability, updateProduct, addProduct, deleteProduct, resetProducts, wearTypes, refreshProducts } = useProducts();
  const { responses, updateStatus, toggleFeatured, deleteResponse, submitResponse } = useResponses();
  const { content, faqs, updateContent, addFaq, updateFaq, deleteFaq, resetFaqs, resetAllContent } = useContent();
  const { user } = useAuth();
  const { isOnline, isSyncing, syncNow } = useServerSync();

  // Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Safe Deletion Confirmation Modal State
  const [deleteModalState, setDeleteModalState] = useState<{
    isOpen: boolean;
    title: string;
    itemName: string;
    itemType: string;
    warningMessage?: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    itemName: '',
    itemType: '',
    onConfirm: () => {},
  });

  const openConfirmDelete = (config: {
    title: string;
    itemName: string;
    itemType?: string;
    warningMessage?: string;
    onConfirm: () => void;
  }) => {
    setDeleteModalState({
      isOpen: true,
      title: config.title,
      itemName: config.itemName,
      itemType: config.itemType || 'item',
      warningMessage: config.warningMessage,
      onConfirm: config.onConfirm,
    });
  };

  const [globalColors, setGlobalColors] = useState<Array<{ name: string; hex: string }>>(() => {
    const saved = localStorage.getItem('ec_global_colors_v1');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      { name: 'Obsidian Black', hex: '#0f0f0f' },
      { name: 'Raw Ecru', hex: '#f4f1ea' },
      { name: 'Heather Grey', hex: '#d1d5db' },
      { name: 'Olive Drab', hex: '#555d50' },
      { name: 'Bone White', hex: '#fafaf9' },
      { name: 'Washed Navy', hex: '#1e293b' },
      { name: 'Charcoal', hex: '#262626' },
      { name: 'Sage Green', hex: '#84cc16' },
    ];
  });

  const [globalWearTypes, setGlobalWearTypes] = useState<string[]>(() => {
    const saved = localStorage.getItem('ec_global_weartypes_v1');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      'Heavyweight Tee',
      'Hooded Sweatshirt',
      'Relaxed Crewneck',
      'Oversized Hoodie',
      'Crop Tee',
      'Minimalist Cap',
      'Canvas Tote',
      'Longsleeve Tee',
    ];
  });

  useEffect(() => {
    localStorage.setItem('ec_global_colors_v1', JSON.stringify(globalColors));
  }, [globalColors]);

  useEffect(() => {
    localStorage.setItem('ec_global_weartypes_v1', JSON.stringify(globalWearTypes));
  }, [globalWearTypes]);

  const [globalSizes, setGlobalSizes] = useState<string[]>(() => {
    const saved = localStorage.getItem('ec_global_sizes_v1');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];
  });

  useEffect(() => {
    localStorage.setItem('ec_global_sizes_v1', JSON.stringify(globalSizes));
  }, [globalSizes]);

  const [variantsSubTab, setVariantsSubTab] = useState<'colors' | 'weartypes' | 'sizes'>('colors');
  const [newMasterColorName, setNewMasterColorName] = useState('');
  const [newMasterColorHex, setNewMasterColorHex] = useState('#262626');
  const [newMasterWearType, setNewMasterWearType] = useState('');
  const [newMasterSize, setNewMasterSize] = useState('');

  // ========================================================
  // BRAND & BUSINESS PROFILE STATES
  // ========================================================
  const [brandNameInput, setBrandNameInput] = useState(content.brandName || 'Ezistential Connection');
  const [brandShortNameInput, setBrandShortNameInput] = useState(content.brandShortName || 'Ezistential');
  const [legalBusinessNameInput, setLegalBusinessNameInput] = useState(content.legalBusinessName || 'Ezistential Connection LLC');
  const [brandTaglineInput, setBrandTaglineInput] = useState(content.brandTagline || 'The Space Between People');
  const [brandLogoUrlInput, setBrandLogoUrlInput] = useState(content.brandLogoUrl || '/ez-logo.svg');
  const [brandLogoDarkUrlInput, setBrandLogoDarkUrlInput] = useState(content.brandLogoDarkUrl || '/ez-logo-white.svg');
  const [faviconUrlInput, setFaviconUrlInput] = useState(
    (content.faviconUrl && content.faviconUrl !== '/favicon.ico') ? content.faviconUrl : '/ez-favicon.svg'
  );
  const [pageTitleTemplateInput, setPageTitleTemplateInput] = useState(content.pageTitleTemplate || 'Ezistential Connection — Space Between People');
  const [metaDescriptionInput, setMetaDescriptionInput] = useState(content.metaDescription || '');

  // Address & Contacts
  const [businessAddressStreetInput, setBusinessAddressStreetInput] = useState(content.businessAddressStreet || '1842 N Damen Ave, Suite 3F');
  const [businessAddressCityInput, setBusinessAddressCityInput] = useState(content.businessAddressCity || 'Chicago');
  const [businessAddressStateInput, setBusinessAddressStateInput] = useState(content.businessAddressState || 'IL');
  const [businessAddressZipInput, setBusinessAddressZipInput] = useState(content.businessAddressZip || '60647');
  const [businessAddressCountryInput, setBusinessAddressCountryInput] = useState(content.businessAddressCountry || 'United States');
  const [businessPhoneInput, setBusinessPhoneInput] = useState(content.businessPhone || '+1 (312) 555-0192');
  const [supportEmailInput, setSupportEmailInput] = useState(content.supportEmail || 'care@ezistential.com');
  const [ordersEmailInput, setOrdersEmailInput] = useState(content.ordersEmail || 'orders@ezistential.com');
  const [pressEmailInput, setPressEmailInput] = useState(content.pressEmail || 'press@ezistential.com');
  const [businessHoursInput, setBusinessHoursInput] = useState(content.businessHours || 'Monday – Friday: 9:00 AM – 6:00 PM CST');

  // Social & Community
  const [instagramHandleInput, setInstagramHandleInput] = useState(content.instagramHandle || '@ezistential');
  const [instagramUrlInput, setInstagramUrlInput] = useState(content.instagramUrl || 'https://instagram.com/ezistential');
  const [substackUrlInput, setSubstackUrlInput] = useState(content.substackUrl || 'https://ezistential.substack.com');
  const [spotifyUrlInput, setSpotifyUrlInput] = useState(content.spotifyUrl || 'https://open.spotify.com/user/ezistential');

  // Fiscal
  const [salesTaxRatePercentInput, setSalesTaxRatePercentInput] = useState(content.salesTaxRatePercent || 6.5);
  const [currencyCodeInput, setCurrencyCodeInput] = useState(content.currencyCode || 'USD');
  const [currencySymbolInput, setCurrencySymbolInput] = useState(content.currencySymbol || '$');

  // CMS Form States
  const [announcementInput, setAnnouncementInput] = useState(content.announcementText);
  const [announcementActive, setAnnouncementActive] = useState(content.announcementActive);
  const [announcementLinkText, setAnnouncementLinkText] = useState(content.announcementLinkText || 'Explore Garments');
  const [heroHeadlineInput, setHeroHeadlineInput] = useState(content.heroHeadline);
  const [heroSubheadlineInput, setHeroSubheadlineInput] = useState(content.heroSubheadline);
  const [heroTaglineInput, setHeroTaglineInput] = useState(content.heroTagline);
  const [heroButtonTextInput, setHeroButtonTextInput] = useState(content.heroButtonText || 'Explore Inaugural Collection');
  const [heroImageUrlInput, setHeroImageUrlInput] = useState(content.heroImageUrl || 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=2000&q=85');
  const [heroImageOverlayOpacityInput, setHeroImageOverlayOpacityInput] = useState(
    typeof content.heroImageOverlayOpacity === 'number' ? content.heroImageOverlayOpacity : 0.52
  );
  const [heroColorMoodInput, setHeroColorMoodInput] = useState(content.heroColorMood || 'golden-amber');
  const [foundingQuoteInput, setFoundingQuoteInput] = useState(content.foundingQuote);
  const [manifestoExcerptInput, setManifestoExcerptInput] = useState(content.manifestoExcerpt);
  const [storyHeadlineInput, setStoryHeadlineInput] = useState(content.storyHeadline || 'Garments as Quiet Inquiries in Public Space');
  const [storyBodyInput, setStoryBodyInput] = useState(content.storyBody || '');
  const [connectionPromptTitleInput, setConnectionPromptTitleInput] = useState(content.connectionPromptTitle || 'What does this mean to you?');
  const [connectionPromptSubtitleInput, setConnectionPromptSubtitleInput] = useState(content.connectionPromptSubtitle || '');

  // Frontend Design States
  const [shapeDividerEnabledInput, setShapeDividerEnabledInput] = useState(content.shapeDividerEnabled ?? true);
  const [shapeDividerVariantInput, setShapeDividerVariantInput] = useState<ShapeDividerVariant>(content.shapeDividerVariant || 'editorial-notch');
  const [shapeDividerHeightInput, setShapeDividerHeightInput] = useState(content.shapeDividerHeight || 64);
  const [primaryThemeColorInput, setPrimaryThemeColorInput] = useState(content.primaryThemeColor || '#0a0a0a');
  const [enableImageZoomInput, setEnableImageZoomInput] = useState(content.enableImageZoom ?? true);

  // UX & E-Commerce States
  const [freeShippingThresholdInput, setFreeShippingThresholdInput] = useState(content.freeShippingThreshold || 75);
  const [standardShippingRateInput, setStandardShippingRateInput] = useState(content.standardShippingRate || 6.0);
  const [enableDigitalDignityExportInput, setEnableDigitalDignityExportInput] = useState(content.enableDigitalDignityExport ?? true);
  const [enableCookieConsentBannerInput, setEnableCookieConsentBannerInput] = useState(content.enableCookieConsentBanner ?? true);
  const [enableTourGuideInput, setEnableTourGuideInput] = useState(content.enableTourGuide ?? false);
  const [cookieBannerHeadlineInput, setCookieBannerHeadlineInput] = useState(content.cookieBannerHeadline || 'We believe your attention and data belong to you.');
  const [cookieBannerDescriptionInput, setCookieBannerDescriptionInput] = useState(content.cookieBannerDescription || '');
  const [enableQuickBagDrawerInput, setEnableQuickBagDrawerInput] = useState(content.enableQuickBagDrawer ?? true);

  // FAQ Modal & Editing States
  const [addFaqModalOpen, setAddFaqModalOpen] = useState(false);
  const [newFaqQ, setNewFaqQ] = useState('');
  const [newFaqA, setNewFaqA] = useState('');
  const [newFaqCat, setNewFaqCat] = useState<'Brand & Meaning' | 'Products & Sizing' | 'Shipping & Delivery' | 'Returns & Care'>('Brand & Meaning');

  // Orders State & Filters
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'All' | OrderStatus>('All');
  const [packingSlipOrder, setPackingSlipOrder] = useState<Order | null>(null);
  const [dataBackupOpen, setDataBackupOpen] = useState(false);
  const [trackingModalOrder, setTrackingModalOrder] = useState<Order | null>(null);
  const [trackingInputCarrier, setTrackingInputCarrier] = useState('USPS Ground Advantage');
  const [trackingInputNum, setTrackingInputNum] = useState('');
  const [trackingInputUrl, setTrackingInputUrl] = useState('');
  const [isSyncingPod, setIsSyncingPod] = useState(false);
  const [ordersSubView, setOrdersSubView] = useState<'orders' | 'sn_items'>('orders');
  const [snPage, setSnPage] = useState(1);
  const snItemsPerPage = 10;
  const [dispatchingOrderId, setDispatchingOrderId] = useState<string | null>(null);

  const handleDispatchOrderNow = async (orderNumber: string) => {
    setDispatchingOrderId(orderNumber);
    try {
      const res = await api.dispatchOrderNow(orderNumber);
      if (res && res.success) {
        updateOrderStatus(orderNumber, 'In Production');
        showToast(res.message || `Order #${orderNumber} submitted to Apliiq production queue.`);
      } else {
        showToast(res?.message || 'Failed to dispatch order to Apliiq.');
      }
    } catch (err: any) {
      showToast(`Dispatch failed: ${err.message}`);
    } finally {
      setDispatchingOrderId(null);
    }
  };

  const getRemainingGraceMinutes = (scheduledDispatchAt?: string) => {
    if (!scheduledDispatchAt) return 0;
    const diffMs = new Date(scheduledDispatchAt).getTime() - Date.now();
    return Math.max(0, Math.ceil(diffMs / 60000));
  };

  const allFlattenedItems = useMemo(() => {
    const list: Array<{
      orderNumber: string;
      orderId: string;
      customerName: string;
      customerEmail: string;
      productName: string;
      wearType?: string;
      size: string;
      color: string;
      quantity: number;
      price: number;
      status: OrderStatus;
      createdAt: string;
      trackingNumber?: string;
      trackingUrl?: string;
      image?: string;
      fullOrder: Order;
    }> = [];

    orders.forEach((ord) => {
      ord.items.forEach((item) => {
        list.push({
          orderNumber: ord.orderNumber,
          orderId: ord.id,
          customerName: ord.customerName,
          customerEmail: ord.customerEmail,
          productName: item.productName,
          wearType: item.wearType,
          size: item.size,
          color: item.color,
          quantity: item.quantity,
          price: item.price,
          status: ord.status,
          createdAt: ord.createdAt,
          trackingNumber: ord.trackingNumber,
          trackingUrl: ord.trackingUrl,
          image: item.image,
          fullOrder: ord,
        });
      });
    });

    return list.filter((item) => {
      const matchSearch =
        item.orderNumber.toLowerCase().includes(orderSearch.toLowerCase()) ||
        item.customerName.toLowerCase().includes(orderSearch.toLowerCase()) ||
        item.customerEmail.toLowerCase().includes(orderSearch.toLowerCase()) ||
        item.productName.toLowerCase().includes(orderSearch.toLowerCase()) ||
        (item.trackingNumber && item.trackingNumber.toLowerCase().includes(orderSearch.toLowerCase()));

      const matchStatus = orderStatusFilter === 'All' || item.status === orderStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [orders, orderSearch, orderStatusFilter]);

  const totalSnUnitsCount = useMemo(() => allFlattenedItems.reduce((sum, item) => sum + item.quantity, 0), [allFlattenedItems]);
  const totalSnPages = Math.ceil(allFlattenedItems.length / snItemsPerPage) || 1;
  const paginatedSnItems = useMemo(() => {
    const start = (snPage - 1) * snItemsPerPage;
    return allFlattenedItems.slice(start, start + snItemsPerPage);
  }, [allFlattenedItems, snPage]);

  // Product Studio Modal / View State
  const [isProductStudioOpen, setIsProductStudioOpen] = useState(false);
  const [isApliiqSyncModalOpen, setIsApliiqSyncModalOpen] = useState(false);
  const [productStudioInitialProduct, setProductStudioInitialProduct] = useState<Product | null>(null);
  const [productStudioInitialDesign, setProductStudioInitialDesign] = useState<{ design: DesignDraft; versionNumber: number } | null>(null);

  // Mock / Central Users Pool
  const [mockUsers, setMockUsers] = useState<UserProfile[]>([
    {
      id: 'usr-marcus-01',
      fullName: 'Marcus Vance',
      email: 'marcus@example.com',
      location: 'Chicago, IL',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      bio: 'Architect of quiet spaces and everyday observations.',
      role: 'customer',
      createdAt: '2024-11-12T14:30:00.000Z',
      updatedAt: new Date().toISOString(),
      addresses: [
        {
          id: 'addr-01',
          isDefault: true,
          label: 'Primary Residence',
          fullName: 'Marcus Vance',
          street: '1842 N Damen Ave',
          apartment: 'Apt 3F',
          city: 'Chicago',
          state: 'IL',
          zipCode: '60647',
          country: 'US',
          phone: '(312) 555-0192',
        },
      ],
      savedGarments: [
        {
          id: 'prod-connection-03',
          productId: 'prod-connection-03',
          savedAt: '2026-03-15T09:12:00.000Z',
          note: 'Considering for the spring dialogue series in Vermont.',
          preferredSize: 'L',
          preferredColor: 'Vintage Bone',
        },
      ],
      communicationPreferences: {
        orderUpdatesEmail: true,
        reflectionDigestsEmail: true,
        curatedEssaysEmail: false,
      },
    },
    {
      id: 'usr-admin-01',
      fullName: 'Ezistential Curator',
      email: 'admin@ezistential.com',
      location: 'Los Angeles, CA',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      bio: 'Editorial curator and archivist for Ezistential Connection.',
      role: 'admin',
      createdAt: '2024-01-01T00:00:00.000Z',
      updatedAt: new Date().toISOString(),
      addresses: [],
      savedGarments: [],
      communicationPreferences: {
        orderUpdatesEmail: true,
        reflectionDigestsEmail: true,
        curatedEssaysEmail: true,
      },
    },
  ]);

  // Derived Metrics
  const totalRevenue = useMemo(() => orders.reduce((sum, o) => sum + o.total, 0), [orders]);
  const pendingProductionCount = useMemo(() => orders.filter((o) => o.status === 'In Production' || o.status === 'Paid').length, [orders]);
  const pendingReflectionCount = useMemo(() => responses.filter((r) => r.status === 'Pending').length, [responses]);

  // Filtered Orders
  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const matchesSearch =
        order.orderNumber.toLowerCase().includes(orderSearch.toLowerCase()) ||
        order.customerName.toLowerCase().includes(orderSearch.toLowerCase()) ||
        order.customerEmail.toLowerCase().includes(orderSearch.toLowerCase()) ||
        (order.trackingNumber && order.trackingNumber.toLowerCase().includes(orderSearch.toLowerCase()));
      const matchesStatus = orderStatusFilter === 'All' || order.status === orderStatusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [orders, orderSearch, orderStatusFilter]);

  const [adminUser, setAdminUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem('ec_admin_user');
      if (stored) return JSON.parse(stored);
    } catch {}
    return null;
  });

  const {
    isSuperadminActor,
    canViewOverview,
    canViewOrders,
    canViewCatalog,
    canViewContent,
    canViewCommunity,
    canViewUsers,
    canViewIntegrations,
    canManageSettings,
    canManageSeo,
    canManageBackup,
    canEditOrders,
    canFulfillOrders,
    canExportOrders,
    canEditCatalog,
    canEditContent,
    canModerateCommunity,
  } = useMemo(() => evaluateModuleAccess(adminUser), [adminUser]);

  const handleOpenAddProductPad = () => {
    if (!canEditCatalog) {
      showToast('Requires catalog.edit capability to launch Product Studio.');
      return;
    }
    setProductStudioInitialProduct(null);
    setProductStudioInitialDesign(null);
    setIsProductStudioOpen(true);
  };

  const handleOpenEditProductPad = (prod: Product) => {
    if (!canEditCatalog) {
      showToast('Requires catalog.edit capability to edit garment specifications.');
      return;
    }
    setProductStudioInitialProduct(prod);
    setProductStudioInitialDesign(null);
    setIsProductStudioOpen(true);
  };

  const handlePushDesignToStudio = (design: DesignDraft, versionNumber: number) => {
    if (!canEditCatalog) {
      showToast('Requires catalog.edit capability to commercialize creative designs.');
      return;
    }
    // Check if a commercial product already exists for this exact design and version
    const existing = products.find(
      (p) => p.sourceDesignId === design.id && (p.sourceDesignVersionNumber === versionNumber)
    );

    if (existing) {
      setProductStudioInitialProduct(existing);
      setProductStudioInitialDesign(null);
      showToast(`Design "${design.name}" (v${versionNumber}) is already commercialized (#${existing.id}). Opened for editing.`);
    } else {
      setProductStudioInitialProduct(null);
      setProductStudioInitialDesign({ design, versionNumber });
      showToast(`Imported Design "${design.name}" (v${versionNumber}) into Product Studio draft.`);
    }
    setActiveTab('products');
    setIsProductStudioOpen(true);
  };

  // Reusable Access Restricted Security Boundary Card
  const renderAccessRestricted = (moduleName: string, requiredCapability: string) => (
    <div className="bg-[#111111] border border-[#222222] p-8 text-center space-y-4 max-w-lg mx-auto my-12 rounded-sm shadow-sm animate-in fade-in duration-200">
      <div className="w-12 h-12 rounded-full bg-red-950/40 border border-red-800 text-red-400 flex items-center justify-center mx-auto">
        <Shield className="w-6 h-6" />
      </div>
      <div className="space-y-1">
        <h3 className="text-base font-serif text-white">Access Restricted: {moduleName}</h3>
        <p className="text-xs text-neutral-400 font-sans">
          Your staff role (<span className="font-mono text-purple-300">{adminUser?.role || 'staff'}</span>) does not possess the{' '}
          <code className="text-neutral-200 font-mono bg-[#1c1c1c] px-1.5 py-0.5 rounded border border-[#333333]">
            {requiredCapability}
          </code>{' '}
          capability required to access this workspace.
        </p>
      </div>
      <div className="pt-2">
        <button
          type="button"
          onClick={() => setActiveTab(getDefaultTabForRole(adminUser))}
          className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs font-mono rounded cursor-pointer transition-colors"
        >
          Return to Permitted Workspace
        </button>
      </div>
      <p className="text-[11px] font-mono text-neutral-500">
        Please contact a platform Superadmin if your operational duties require elevated permissions.
      </p>
    </div>
  );

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setAuthError('');
    try {
      const res = await api.adminLogin(adminEmailInput.trim(), passwordInput);
      if (res.success && res.token) {
        setIsAuthenticated(true);
        setAuthError('');
        if (res.user) {
          setAdminUser(res.user);
          setActiveTab(getDefaultTabForRole(res.user));
        }
      } else {
        setAuthError(res.error || 'Invalid credentials or staff privileges required.');
      }
    } catch (err: any) {
      setAuthError(err?.message || 'Authentication error occurred.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAdminUser(null);
    api.adminLogout();
  };

  // Save Brand & Business Profile
  const handleSaveBrand = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      brandName: brandNameInput.trim(),
      brandShortName: brandShortNameInput.trim(),
      legalBusinessName: legalBusinessNameInput.trim(),
      brandTagline: brandTaglineInput.trim(),
      brandLogoUrl: brandLogoUrlInput.trim(),
      brandLogoDarkUrl: brandLogoDarkUrlInput.trim(),
      faviconUrl: faviconUrlInput.trim(),
      pageTitleTemplate: pageTitleTemplateInput.trim(),
      metaDescription: metaDescriptionInput.trim(),
      businessAddressStreet: businessAddressStreetInput.trim(),
      businessAddressCity: businessAddressCityInput.trim(),
      businessAddressState: businessAddressStateInput.trim(),
      businessAddressZip: businessAddressZipInput.trim(),
      businessAddressCountry: businessAddressCountryInput.trim(),
      businessPhone: businessPhoneInput.trim(),
      supportEmail: supportEmailInput.trim(),
      ordersEmail: ordersEmailInput.trim(),
      pressEmail: pressEmailInput.trim(),
      businessHours: businessHoursInput.trim(),
      instagramHandle: instagramHandleInput.trim(),
      instagramUrl: instagramUrlInput.trim(),
      substackUrl: substackUrlInput.trim(),
      spotifyUrl: spotifyUrlInput.trim(),
      salesTaxRatePercent: Number(salesTaxRatePercentInput),
      currencyCode: currencyCodeInput.trim(),
      currencySymbol: currencySymbolInput.trim(),
    });
    if (faviconUrlInput && faviconUrlInput.trim() && faviconUrlInput !== '/favicon.ico') {
      autoAdjustFaviconForPWA(faviconUrlInput.trim()).catch(() => {});
    }
    showToast('Brand & Business Profile updated! Page title, logos, and studio contacts synced across the storefront.');
  };

  // Save Editorial CMS
  const handleSaveCMS = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      announcementText: announcementInput,
      announcementActive: announcementActive,
      announcementLinkText: announcementLinkText,
      heroHeadline: heroHeadlineInput,
      heroSubheadline: heroSubheadlineInput,
      heroTagline: heroTaglineInput,
      heroButtonText: heroButtonTextInput,
      heroImageUrl: heroImageUrlInput,
      heroImageOverlayOpacity: heroImageOverlayOpacityInput,
      heroColorMood: heroColorMoodInput,
      foundingQuote: foundingQuoteInput,
      manifestoExcerpt: manifestoExcerptInput,
      storyHeadline: storyHeadlineInput,
      storyBody: storyBodyInput,
      connectionPromptTitle: connectionPromptTitleInput,
      connectionPromptSubtitle: connectionPromptSubtitleInput,
    });
    showToast('Editorial Content & Manifestos updated successfully across all visitor views!');
  };

  // Save Frontend Design Settings
  const handleSaveFrontend = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      shapeDividerEnabled: shapeDividerEnabledInput,
      shapeDividerVariant: shapeDividerVariantInput,
      shapeDividerHeight: shapeDividerHeightInput,
      primaryThemeColor: primaryThemeColorInput,
      enableImageZoom: enableImageZoomInput,
    });
    showToast('Frontend visual theme & Shape Divider configuration saved globally!');
  };

  // Save UX & E-Commerce Settings
  const handleSaveUX = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      freeShippingThreshold: Number(freeShippingThresholdInput),
      standardShippingRate: Number(standardShippingRateInput),
      enableDigitalDignityExport: enableDigitalDignityExportInput,
      enableCookieConsentBanner: enableCookieConsentBannerInput,
      enableTourGuide: enableTourGuideInput,
      cookieBannerHeadline: cookieBannerHeadlineInput,
      cookieBannerDescription: cookieBannerDescriptionInput,
      enableQuickBagDrawer: enableQuickBagDrawerInput,
    });
    showToast('User Experience, Shipping rates, and Privacy controls updated!');
  };

  // Save New FAQ
  const handleAddFaqSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFaqQ.trim() || !newFaqA.trim()) return;
    addFaq({
      category: newFaqCat,
      question: newFaqQ.trim(),
      answer: newFaqA.trim(),
    });
    setNewFaqQ('');
    setNewFaqA('');
    setAddFaqModalOpen(false);
    showToast('New FAQ item published to the public Care & Inquiries guide!');
  };

  // Apliiq POD Dispatch Batch (Guarded against duplicate submissions)
  const handleTriggerApliiqBatch = async () => {
    setIsSyncingPod(true);
    let submittedCount = 0;
    let duplicateCount = 0;

    for (const o of orders) {
      if (o.status === 'Paid') {
        const res = await fulfillOrder(o.orderNumber, 'apliiq');
        if (res.alreadyFulfilled) {
          duplicateCount++;
        } else if (res.success) {
          submittedCount++;
        }
      }
    }

    setIsSyncingPod(false);
    showToast(
      submittedCount > 0
        ? `Dispatched ${submittedCount} order${submittedCount === 1 ? '' : 's'} to Apliiq POD production queue.`
        : duplicateCount > 0
        ? `All paid orders already submitted to POD. Duplicate submission prevented.`
        : 'No pending paid orders required dispatch.'
    );
  };

  // Export CSV
  const handleExportCSV = () => {
    if (!canExportOrders) {
      showToast('Requires orders.export capability to export customer orders.');
      return;
    }
    const headers = [
      'Order Number',
      'Created At',
      'Customer Name',
      'Customer Email',
      'Address Street',
      'City',
      'State',
      'ZIP',
      'Items Count',
      'Subtotal',
      'Shipping',
      'Tax',
      'Total',
      'Status',
      'Carrier',
      'Tracking Number',
    ];

    const rows = orders.map((o) => [
      `"${o.orderNumber}"`,
      `"${o.createdAt}"`,
      `"${o.customerName}"`,
      `"${o.customerEmail}"`,
      `"${o.shippingAddress.street} ${o.shippingAddress.apartment || ''}"`,
      `"${o.shippingAddress.city}"`,
      `"${o.shippingAddress.state}"`,
      `"${o.shippingAddress.zipCode}"`,
      o.items.reduce((sum, it) => sum + it.quantity, 0),
      o.subtotal.toFixed(2),
      o.shippingCost.toFixed(2),
      o.taxCost.toFixed(2),
      o.total.toFixed(2),
      `"${o.status}"`,
      `"${o.carrier || ''}"`,
      `"${o.trackingNumber || ''}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ezistential-orders-export-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Orders exported to CSV!');
  };

  // Download SQL Schema & Data Dump for Step 10
  const handleDownloadSQLDump = () => {
    if (!canManageBackup) {
      showToast('Requires backup.manage capability to download database dump.');
      return;
    }
    const sqlContent = `-- EZISTENTIAL CONNECTIONS PRODUCTION MYSQL DUMP
-- Exported on: ${new Date().toISOString()}

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Products
${products
  .map(
    (p) =>
      `INSERT INTO products (id, slug, name, tagline, description, philosophical_note, price, in_stock, is_featured, primary_image, collection_slug) VALUES ('${p.id}', '${p.slug}', '${p.name.replace(/'/g, "''")}', '${p.tagline.replace(/'/g, "''")}', '${p.storyA.thesis.replace(/'/g, "''")}', '${p.storyA.question.replace(/'/g, "''")}', ${p.price}, ${p.isAvailable ? 1 : 0}, ${p.isFeatured ? 1 : 0}, '${p.primaryImage}', '${p.collectionId}') ON DUPLICATE KEY UPDATE price=VALUES(price), in_stock=VALUES(in_stock);`
  )
  .join('\n')}

-- Orders
${orders
  .map(
    (o) =>
      `INSERT INTO orders (id, order_number, customer_name, customer_email, subtotal, shipping_fee, tax, total, status, payment_method, shipping_full_name, shipping_street, shipping_city, shipping_state, shipping_zip, shipping_country, tracking_number) VALUES ('${o.id}', '${o.orderNumber}', '${o.customerName.replace(/'/g, "''")}', '${o.customerEmail.replace(/'/g, "''")}', ${o.subtotal}, ${o.shippingCost}, ${o.taxCost}, ${o.total}, '${o.status}', '${o.paymentMethod}', '${o.shippingAddress.fullName.replace(/'/g, "''")}', '${o.shippingAddress.street.replace(/'/g, "''")}', '${o.shippingAddress.city.replace(/'/g, "''")}', '${o.shippingAddress.state}', '${o.shippingAddress.zipCode}', '${o.shippingAddress.country}', '${o.trackingNumber || ''}') ON DUPLICATE KEY UPDATE status=VALUES(status), tracking_number=VALUES(tracking_number);`
  )
  .join('\n')}

SET FOREIGN_KEY_CHECKS = 1;
`;

    const blob = new Blob([sqlContent], { type: 'text/sql' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ezistential-production-schema-data-${new Date().toISOString().slice(0, 10)}.sql`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('SQL Migration & Data Dump downloaded for Step 10 PHP/MySQL backend!');
  };

  // If not authenticated, render Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-[#fbfbf9] flex flex-col justify-center items-center px-4 sm:px-6 py-12">
        <div className="w-full max-w-md bg-[#141414] border border-[#262626] p-8 sm:p-10 shadow-2xl space-y-8">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <Logo variant="white" className="h-8 w-auto" />
            </div>
            <div className="pt-2">
              <span className="text-[10px] uppercase tracking-widest text-neutral-400 font-mono block">
                Internal Operations Portal
              </span>
              <h1 className="font-serif text-2xl text-white mt-1">Administrative Gateway</h1>
            </div>
          </div>

          <div className="bg-[#1f1f1f] border border-[#333333] p-4 text-xs text-neutral-300 space-y-2">
            <div className="flex items-center space-x-2 text-white font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Operations Cockpit Security</span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              Cryptographically validated access to catalog inventory, designs, order fulfillment, transactional relays, and database management.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-[11px] uppercase tracking-wider text-neutral-400 mb-1.5 font-medium">
                Admin Email Address
              </label>
              <input
                type="email"
                required
                value={adminEmailInput}
                onChange={(e) => setAdminEmailInput(e.target.value)}
                placeholder="admin@ezistential.com"
                className="w-full bg-[#0a0a0a] border border-[#333333] px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-hidden focus:border-white font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] uppercase tracking-wider text-neutral-400 mb-1.5 font-medium">
                Administrative Password
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-[#0a0a0a] border border-[#333333] px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-hidden focus:border-white font-mono"
                />
                <Lock className="w-4 h-4 text-neutral-500 absolute right-3 top-3" />
              </div>
              {authError && <p className="text-xs text-red-400 mt-1.5">{authError}</p>}
            </div>

            <Button type="submit" variant="secondary" size="md" fullWidth disabled={isLoggingIn}>
              {isLoggingIn ? 'Verifying Credentials...' : 'Sign In to Operations Cockpit'}
            </Button>
          </form>

          <div className="pt-4 border-t border-[#262626] flex items-center justify-between text-xs text-neutral-500">
            <button
              onClick={onBackToStore}
              className="hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
            >
              ← Back to Storefront
            </button>
            <span className="font-mono text-[10px]">v3.0 • Brand & Business Setup</span>
          </div>
        </div>
      </div>
    );
  }

  // Render Authenticated Admin Portal with SIDEBAR
  return (
    <div className="h-screen overflow-hidden bg-[#f5f4f0] text-[#0a0a0a] flex flex-col md:flex-row font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#0a0a0a] text-white border border-neutral-700 px-5 py-3 shadow-2xl flex items-center space-x-3 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-mono tracking-wide">{toastMessage}</span>
        </div>
      )}

      {/* Mobile Top Header */}
      <div className="md:hidden shrink-0 bg-[#0a0a0a] text-white p-4 flex items-center justify-between z-40 border-b border-[#262626]">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSidebarOpenMobile(!sidebarOpenMobile)}
            className="p-1.5 text-neutral-300 hover:text-white"
            aria-label="Toggle Navigation Sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>
          <Logo variant="white" className="h-5 w-auto" />
          <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400">Admin</span>
        </div>
        <button
          onClick={onBackToStore}
          className="text-xs uppercase tracking-wider font-mono text-neutral-300 hover:text-white flex items-center gap-1"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Live Store</span>
        </button>
      </div>

      {/* ========================================================
          LEFT SIDEBAR NAVIGATION (DESKTOP & MOBILE DRAWER)
          ======================================================== */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 bg-[#0c0c0c] text-neutral-300 flex flex-col border-r border-[#222222] transition-all duration-200 ease-in-out md:translate-x-0 md:static md:h-full md:shrink-0 ${
          sidebarOpenMobile ? 'translate-x-0 w-60' : '-translate-x-full'
        } ${isSidebarCollapsed ? 'md:w-16' : 'md:w-60'}`}
      >
        {/* Sidebar Brand Header */}
        <div
          className={`border-b border-[#222222] flex items-center justify-between shrink-0 ${
            isSidebarCollapsed ? 'p-2.5 flex-col gap-2' : 'px-3.5 py-3'
          }`}
        >
          {isSidebarCollapsed ? (
            <>
              <button
                onClick={onBackToStore}
                title="Return to Public Storefront"
                className="hover:opacity-80 transition-opacity cursor-pointer flex items-center justify-center"
              >
                <div className="w-8 h-8 rounded-xs bg-white text-black font-serif font-bold flex items-center justify-center text-sm shadow-xs">
                  E
                </div>
              </button>
              <button
                onClick={toggleSidebarCollapsed}
                title="Expand sidebar"
                className="p-1.5 rounded-xs hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
              >
                <PanelLeft className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <div className="flex items-center gap-2 min-w-0">
                <button
                  onClick={onBackToStore}
                  title="Return to Public Storefront"
                  className="hover:opacity-80 transition-opacity cursor-pointer flex items-center shrink-0"
                >
                  <Logo variant="white" className="h-4.5 w-auto" />
                </button>
                <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-400 border-l border-neutral-800 pl-2">
                  Admin
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={toggleSidebarCollapsed}
                  title="Collapse sidebar"
                  className="hidden md:flex p-1 rounded-xs hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                >
                  <PanelLeftClose className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSidebarOpenMobile(false)}
                  className="md:hidden p-1 text-neutral-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </>
          )}
        </div>

        {/* Navigation Categories */}
        <div className={`flex-1 overflow-y-auto ${isSidebarCollapsed ? 'px-1.5 py-2 space-y-1.5' : 'px-2 py-2.5 space-y-3.5'} text-xs`}>
          {/* Section 1: CORE OPERATIONS */}
          {(canViewOverview || canViewOrders) && (
            <div className="space-y-0.5">
              {!isSidebarCollapsed && (
                <div className="px-2 pt-1 pb-1 text-[9px] uppercase font-mono tracking-widest text-neutral-400 font-semibold select-none">
                  Core
                </div>
              )}

              {canViewOverview && (
                <button
                  onClick={() => {
                    setActiveTab('overview');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Overview' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'overview'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <LayoutDashboard className="w-3.5 h-3.5 shrink-0" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Overview</span>}
                  </div>
                </button>
              )}

              {canViewOrders && (
                <button
                  onClick={() => {
                    setActiveTab('orders');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? `Orders ${pendingProductionCount > 0 ? `(${pendingProductionCount} pending)` : ''}` : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer relative ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'orders'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <PackageCheck className="w-3.5 h-3.5 shrink-0" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Orders</span>}
                  </div>
                  {pendingProductionCount > 0 && (
                    isSidebarCollapsed ? (
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 absolute top-1.5 right-1.5" />
                    ) : (
                      <span className="text-[10px] font-mono font-semibold text-amber-400">
                        {pendingProductionCount}
                      </span>
                    )
                  )}
                </button>
              )}
            </div>
          )}

          {/* Section 2: GARMENTS & STUDIO */}
          {canViewCatalog && (
            <div className={`space-y-0.5 ${isSidebarCollapsed ? 'pt-1 border-t border-[#1a1a1a]' : 'pt-1 border-t border-[#1a1a1a]'}`}>
              {!isSidebarCollapsed && (
                <div className="px-2 pt-1 pb-1 text-[9px] uppercase font-mono tracking-widest text-neutral-400 font-semibold select-none">
                  Catalog
                </div>
              )}

              <button
                onClick={() => {
                  setActiveTab('products');
                  setSidebarOpenMobile(false);
                }}
                title={isSidebarCollapsed ? `Products (${products.length})` : undefined}
                className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                } ${
                  activeTab === 'products'
                    ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                    : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                }`}
              >
                <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                  <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
                  {!isSidebarCollapsed && <span className="text-[12px] truncate">Products</span>}
                </div>
                {!isSidebarCollapsed && (
                  <span className="text-[10px] font-mono text-neutral-400">{products.length}</span>
                )}
              </button>

              <button
                onClick={() => {
                  setActiveTab('design_factory');
                  setSidebarOpenMobile(false);
                }}
                title={isSidebarCollapsed ? 'Design Factory' : undefined}
                className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                } ${
                  activeTab === 'design_factory'
                    ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                    : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                }`}
              >
                <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                  <Palette className="w-3.5 h-3.5 shrink-0 text-neutral-400" />
                  {!isSidebarCollapsed && <span className="text-[12px] truncate">Design Factory</span>}
                </div>
              </button>

              <button
                onClick={() => {
                  setActiveTab('variants');
                  setSidebarOpenMobile(false);
                }}
                title={isSidebarCollapsed ? 'Wear Types' : undefined}
                className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                } ${
                  activeTab === 'variants'
                    ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                    : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                }`}
              >
                <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                  <Layers className="w-3.5 h-3.5 shrink-0 text-amber-400/80" />
                  {!isSidebarCollapsed && <span className="text-[12px] truncate">Wear Types</span>}
                </div>
              </button>
            </div>
          )}

          {/* Section 3: CONTENT & EDITORIAL */}
          {(canViewContent || canViewCommunity || canManageSettings) && (
            <div className={`space-y-0.5 ${isSidebarCollapsed ? 'pt-1 border-t border-[#1a1a1a]' : 'pt-1 border-t border-[#1a1a1a]'}`}>
              {!isSidebarCollapsed && (
                <div className="px-2 pt-1 pb-1 text-[9px] uppercase font-mono tracking-widest text-neutral-400 font-semibold select-none">
                  Content
                </div>
              )}

              {/* Journal & Reflections Archive */}
              {(canViewContent || canViewCommunity) && (
                <button
                  onClick={() => {
                    setActiveTab('journal_reflections');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? `Journal & Archive ${pendingReflectionCount > 0 ? `(${pendingReflectionCount} pending)` : ''}` : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer relative ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'journal_reflections' || activeTab === 'moderation' || activeTab === 'content_updates'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <BookOpen className="w-3.5 h-3.5 shrink-0 text-amber-400/80" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Journal & Archive</span>}
                  </div>
                  {pendingReflectionCount > 0 && (
                    isSidebarCollapsed ? (
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 absolute top-1.5 right-1.5" />
                    ) : (
                      <span className="text-[10px] font-mono font-semibold text-amber-400">
                        {pendingReflectionCount}
                      </span>
                    )
                  )}
                </button>
              )}

              {/* Design & Navigation */}
              {canManageSettings && (
                <button
                  onClick={() => {
                    setActiveTab('design_and_navigation');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Design & Menus' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'design_and_navigation' || activeTab === 'brand_design' || activeTab === 'menu_navigation' || activeTab === 'frontend'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <SlidersHorizontal className="w-3.5 h-3.5 shrink-0 text-emerald-400/80" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Design & Menus</span>}
                  </div>
                </button>
              )}

              {/* Page CMS */}
              {canViewContent && (
                <button
                  onClick={() => {
                    setEditorialInitialTab('home');
                    setActiveTab('content_editorial');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Page CMS' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'content_editorial' || activeTab === 'content' || activeTab === 'hero_banner' || activeTab === 'banner'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <FileText className="w-3.5 h-3.5 shrink-0 text-cyan-400/80" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Page CMS</span>}
                  </div>
                </button>
              )}

              {/* Page SEO & Metadata */}
              {canViewContent && (
                <button
                  onClick={() => {
                    setActiveTab('seo');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Page SEO' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'seo'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <Globe className="w-3.5 h-3.5 shrink-0 text-purple-400/80" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Page SEO</span>}
                  </div>
                </button>
              )}
            </div>
          )}

          {/* Section 4: BRAND & INTEGRATION */}
          {(canManageSettings || canViewIntegrations) && (
            <div className={`space-y-0.5 ${isSidebarCollapsed ? 'pt-1 border-t border-[#1a1a1a]' : 'pt-1 border-t border-[#1a1a1a]'}`}>
              {!isSidebarCollapsed && (
                <div className="px-2 pt-1 pb-1 text-[9px] uppercase font-mono tracking-widest text-neutral-400 font-semibold select-none">
                  Brand
                </div>
              )}

              {canManageSettings && (
                <button
                  onClick={() => {
                    setActiveTab('brand_business_setup');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Business Setup' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'brand_business_setup' || activeTab === 'brand'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <Building2 className="w-3.5 h-3.5 shrink-0 text-amber-400/80" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Business Setup</span>}
                  </div>
                </button>
              )}

              {canViewIntegrations && (
                <button
                  onClick={() => {
                    setIntegrationInitialTab('payment');
                    setActiveTab('brand_integration');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Integrations' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'brand_integration'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <Zap className="w-3.5 h-3.5 shrink-0 text-blue-400/80" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Integrations</span>}
                  </div>
                </button>
              )}
            </div>
          )}

          {/* Section 5: SYSTEM & SECURITY */}
          {(canViewUsers || canManageSettings) && (
            <div className={`space-y-0.5 ${isSidebarCollapsed ? 'pt-1 border-t border-[#1a1a1a]' : 'pt-1 border-t border-[#1a1a1a]'}`}>
              {!isSidebarCollapsed && (
                <div className="px-2 pt-1 pb-1 text-[9px] uppercase font-mono tracking-widest text-neutral-400 font-semibold select-none">
                  System
                </div>
              )}

              {canViewUsers && (
                <button
                  onClick={() => {
                    setActiveTab('users');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Staff & Roles' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'users'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <Users className="w-3.5 h-3.5 shrink-0 text-purple-400/80" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Staff & Roles</span>}
                  </div>
                </button>
              )}

              {(canViewUsers || canViewCommunity) && (
                <button
                  onClick={() => {
                    setActiveTab('verification');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Verification' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'verification'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0 text-emerald-400/80" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Verification</span>}
                  </div>
                  {!isSidebarCollapsed && (
                    <span className="text-[9px] font-mono text-neutral-400">
                      {content.enableMemberVerification !== false ? 'On' : 'Off'}
                    </span>
                  )}
                </button>
              )}

              {canManageSettings && (
                <button
                  onClick={() => {
                    setActiveTab('settings');
                    setSidebarOpenMobile(false);
                  }}
                  title={isSidebarCollapsed ? 'Settings' : undefined}
                  className={`w-full flex items-center rounded-xs transition-colors cursor-pointer ${
                    isSidebarCollapsed ? 'justify-center p-2' : 'justify-between px-2.5 py-1.5'
                  } ${
                    activeTab === 'settings' || activeTab === 'ux'
                      ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                      : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isSidebarCollapsed ? '' : 'space-x-2.5 min-w-0'}`}>
                    <Settings className="w-3.5 h-3.5 shrink-0 text-neutral-400" />
                    {!isSidebarCollapsed && <span className="text-[12px] truncate">Settings</span>}
                  </div>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Sidebar Footer */}
        <div className={`border-t border-[#222222] bg-[#090909] shrink-0 ${isSidebarCollapsed ? 'p-2 flex flex-col items-center gap-2' : 'p-2.5 space-y-2'}`}>
          {isSidebarCollapsed ? (
            <>
              {adminUser && (
                <div
                  title={`${adminUser.fullName || adminUser.email} (${adminUser.role || 'Superadmin'})`}
                  className="w-7 h-7 rounded-xs bg-[#141414] border border-[#262626] flex items-center justify-center text-[11px] font-mono font-bold text-white cursor-default"
                >
                  {(adminUser.fullName || adminUser.email || 'A').charAt(0).toUpperCase()}
                </div>
              )}
              <button
                onClick={onBackToStore}
                title="View Public Storefront"
                className="p-1.5 rounded-xs hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
              >
                <Eye className="w-4 h-4" />
              </button>
              <button
                onClick={handleLogout}
                title="Sign Out of Cockpit"
                className="p-1.5 rounded-xs hover:bg-red-950/40 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              {adminUser && (
                <div className="flex items-center justify-between px-2 py-1.5 bg-[#121212] border border-[#222222] rounded-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-5 h-5 rounded-xs bg-neutral-800 border border-neutral-700 flex items-center justify-center text-[10px] font-mono font-bold text-white shrink-0">
                      {(adminUser.fullName || adminUser.email || 'A').charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <div className="text-[11px] font-medium text-white truncate max-w-[100px] leading-tight">
                        {adminUser.fullName || adminUser.email}
                      </div>
                    </div>
                  </div>
                  <span className="text-[9px] font-mono uppercase text-neutral-400">
                    {adminUser.role || 'Superadmin'}
                  </span>
                </div>
              )}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={onBackToStore}
                  title="View Public Storefront"
                  className="flex-1 flex items-center justify-center gap-1.5 py-1 px-2 bg-[#161616] hover:bg-neutral-800 text-neutral-300 hover:text-white text-[11px] font-mono tracking-wider transition-colors cursor-pointer border border-[#262626] rounded-xs"
                >
                  <Eye className="w-3.5 h-3.5 text-neutral-400" />
                  <span>Store</span>
                </button>
                <button
                  onClick={handleLogout}
                  title="Sign Out of Cockpit"
                  className="flex items-center justify-center gap-1 py-1 px-2 text-neutral-400 hover:text-red-400 hover:bg-neutral-900 text-[11px] font-mono transition-colors cursor-pointer rounded-xs"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Exit</span>
                </button>
              </div>
            </>
          )}
        </div>
      </aside>

      {/* ========================================================
          MAIN ADMIN CONTENT AREA
          ======================================================== */}
      <main className="flex-1 min-w-0 min-h-0 h-full overflow-y-auto p-3 sm:p-6 lg:p-10 space-y-8">
        {/* Top Breadcrumb Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-neutral-200 pb-6">
          <div>
            <div className="flex items-center space-x-2 text-neutral-500 text-xs font-mono uppercase tracking-widest">
              <span>Admin Cockpit</span>
              <span>/</span>
              <span className="text-neutral-900 font-semibold uppercase">{activeTab}</span>
              {adminUser && (
                <span className="ml-2 px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-purple-950 text-purple-300 border border-purple-800">
                  {adminUser.role || 'Superadmin'}
                </span>
              )}
            </div>
            <h1 className="font-serif text-2xl sm:text-3xl text-neutral-900 mt-1 capitalize">
              {activeTab === 'overview' && 'Executive Operations Dashboard'}
              {activeTab === 'brand_business_setup' && 'Brand & Business Setup (Logos, Title, Studio & Contacts)'}
              {activeTab === 'brand' && 'Brand & Business Setup (Logos, Title, Studio & Contacts)'}
              {activeTab === 'orders' && 'Orders, Tracking & POD Dispatch'}
              {activeTab === 'products' && 'Product Studio & Garment Catalog'}
              {activeTab === 'design_factory' && 'Design Factory (Master Garment Drafts)'}
              {activeTab === 'variants' && 'Master Wear Types, Base Blanks & Color Library'}
              {activeTab === 'journal_reflections' && 'Journal & Reflections Archive Hub'}
              {activeTab === 'moderation' && 'Journal & Reflections Archive Hub'}
              {activeTab === 'design_and_navigation' && 'Design & Menu Navigation Controls'}
              {activeTab === 'brand_design' && 'Design & Menu Navigation Controls'}
              {activeTab === 'menu_navigation' && 'Design & Menu Navigation Controls'}
              {activeTab === 'frontend' && 'Design & Menu Navigation Controls'}
              {activeTab === 'content_editorial' && 'Page CMS (Storefront Copy Controller)'}
              {activeTab === 'content' && 'Page CMS (Storefront Copy Controller)'}
              {activeTab === 'hero_banner' && 'Page CMS — Home Banner Studio'}
              {activeTab === 'banner' && 'Page CMS — Home Banner Studio'}
              {activeTab === 'ux' && 'User Experience, Shipping & Privacy Controls'}
              {activeTab === 'users' && 'Staff Roles & System User Accounts (RBAC)'}
              {activeTab === 'verification' && 'Member Verification & Badge Studio'}
              {activeTab === 'seo' && 'Search Optimization & Social Graph'}
            </h1>
          </div>

          <div className="flex items-center space-x-2.5 sm:space-x-3">
            {/* Live Database Sync Indicator */}
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1.5 bg-white border border-neutral-200 shadow-2xs text-[11px] font-mono">
              <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
              <div className="flex flex-col text-left">
                <span className="font-semibold text-neutral-800 leading-tight">
                  {isOnline ? 'MySQL Central DB' : 'Offline Cache'}
                </span>
                <span className="text-[9px] text-neutral-500 leading-tight">
                  {isSyncing ? 'Synchronizing...' : 'Live Synced'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  syncNow();
                  showToast('Revalidating all data against Central Server Database...');
                }}
                disabled={isSyncing}
                title="Force sync data with central MySQL database"
                className="ml-1 p-1 hover:bg-neutral-100 rounded-xs text-neutral-600 hover:text-black cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin text-emerald-600' : ''}`} />
              </button>
            </div>

            <Button
              variant="outline"
              size="sm"
              disabled={!canManageBackup}
              onClick={() => {
                if (!canManageBackup) {
                  showToast('Requires backup.manage capability to export database snapshot.');
                  return;
                }
                setDataBackupOpen(true);
              }}
              className={`text-xs ${!canManageBackup ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
              title={!canManageBackup ? 'Requires backup.manage capability' : 'Export Snapshot'}
            >
              <Download className="w-3.5 h-3.5 mr-1.5" />
              <span>Export Snapshot</span>
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={onBackToStore}
              className="text-xs"
            >
              <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
              <span>Live Store</span>
            </Button>
          </div>
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          canViewOverview ? (
          <div className="space-y-8 animate-in fade-in duration-200">
            {/* Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="bg-white border border-neutral-200 p-6 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-neutral-500">
                  <span className="text-[11px] uppercase font-mono tracking-wider">Gross Sales</span>
                  <DollarSign className="w-4 h-4 text-neutral-400" />
                </div>
                <div className="font-serif text-3xl text-neutral-900 font-medium">
                  {formatPrice(totalRevenue)}
                </div>
                <div className="text-[11px] text-emerald-600 flex items-center font-mono">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  <span>100% US Domestic Orders</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-neutral-500">
                  <span className="text-[11px] uppercase font-mono tracking-wider">Active Orders</span>
                  <Package className="w-4 h-4 text-neutral-400" />
                </div>
                <div className="font-serif text-3xl text-neutral-900 font-medium">
                  {orders.length}
                </div>
                <div className="text-[11px] text-neutral-500 font-mono">
                  <span>{pendingProductionCount} in manufacturing queue</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-neutral-500">
                  <span className="text-[11px] uppercase font-mono tracking-wider">Active Catalog</span>
                  <ShoppingBag className="w-4 h-4 text-neutral-400" />
                </div>
                <div className="font-serif text-3xl text-neutral-900 font-medium">
                  {products.length}
                </div>
                <div className="text-[11px] text-neutral-500 font-mono">
                  <span>6.5oz Heavyweight Cotton Blanks</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-neutral-500">
                  <span className="text-[11px] uppercase font-mono tracking-wider">Field Reflections</span>
                  <MessageSquare className="w-4 h-4 text-neutral-400" />
                </div>
                <div className="font-serif text-3xl text-neutral-900 font-medium">
                  {responses.length}
                </div>
                <div className="text-[11px] text-amber-600 font-mono">
                  <span>{pendingReflectionCount} awaiting moderation</span>
                </div>
              </div>
            </div>

            {/* Quick Actions & Recent Orders Table */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-white border border-neutral-200 p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
                  <h3 className="font-serif text-lg text-neutral-900">Recent Customer Transits</h3>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs font-mono uppercase text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer"
                  >
                    <span>View All Orders ({orders.length})</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-neutral-100 text-neutral-400 uppercase font-mono text-[10px]">
                        <th className="py-2.5">Order</th>
                        <th className="py-2.5">Customer</th>
                        <th className="py-2.5">Status</th>
                        <th className="py-2.5 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100">
                      {orders.slice(0, 5).map((ord) => (
                        <tr key={ord.id} className="hover:bg-neutral-50/50">
                          <td className="py-3 font-mono font-medium text-neutral-900">{ord.orderNumber}</td>
                          <td className="py-3 text-neutral-600">{ord.customerName}</td>
                          <td className="py-3">
                            <Badge
                              variant={
                                ord.status === 'Delivered'
                                  ? 'success'
                                  : ord.status === 'Shipped'
                                  ? 'info'
                                  : ord.status === 'In Production'
                                  ? 'warning'
                                  : 'neutral'
                              }
                              size="sm"
                            >
                              {ord.status}
                            </Badge>
                          </td>
                          <td className="py-3 text-right font-medium text-neutral-900">
                            {formatPrice(ord.total)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Manufacturing & Database Health */}
              <div className="space-y-6">
                <div className="bg-[#141414] text-white p-6 border border-[#262626] space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400">
                      Brand Foundation
                    </span>
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  </div>
                  <h4 className="font-serif text-lg text-white">{content.brandName}</h4>
                  <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                    Legal Entity: <span className="text-white font-mono">{content.legalBusinessName}</span><br />
                    Studio: <span className="text-white">{content.businessAddressCity}, {content.businessAddressState}</span>
                  </p>
                  <Button
                    variant="secondary"
                    size="sm"
                    fullWidth
                    onClick={() => setActiveTab('brand')}
                  >
                    Configure Brand & Business Setup
                  </Button>
                </div>

                {/* Payment Integrations Health Status */}
                <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
                  <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                    <div className="flex items-center space-x-2">
                      <CreditCard className="w-4 h-4 text-neutral-800" />
                      <h4 className="font-serif text-sm font-bold text-neutral-900">Payment Integrations Status</h4>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold">
                      {[
                        content.stripeEnabled !== false && content.stripePublishableKey && content.stripeSecretKey,
                        content.paypalEnabled !== false && content.paypalClientId && content.paypalSecretKey,
                        content.applePayEnabled !== false && content.applePayMerchantId,
                        content.googlePayEnabled !== false && content.googlePayMerchantId,
                        content.klarnaEnabled !== false && content.klarnaClientId,
                        content.afterpayEnabled !== false && content.afterpayMerchantId,
                        content.cashAppPayEnabled !== false && content.cashAppCashtag,
                        content.shopPayEnabled !== false && content.shopPayStorefrontToken,
                      ].filter(Boolean).length} / 8 Active
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {[
                      { id: 'stripe', name: 'Stripe Cards (Visa, MC, Amex)', icon: '💳' },
                      { id: 'paypal', name: 'PayPal & Pay in 4', icon: '🅿️' },
                      { id: 'apple_pay', name: ' Apple Pay Biometric', icon: '' },
                      { id: 'google_pay', name: 'Google Pay Tokenizer', icon: 'G' },
                      { id: 'klarna', name: 'Klarna BNPL', icon: 'K' },
                      { id: 'afterpay', name: 'Afterpay Installments', icon: '▲' },
                      { id: 'cashapp', name: 'Cash App Direct QR', icon: '$' },
                      { id: 'shoppay', name: 'Shop Pay 1-Click', icon: '🛍️' },
                    ].map((gw) => (
                      <div
                        key={gw.id}
                        className="flex items-center justify-between p-2 rounded-xs bg-neutral-50 hover:bg-neutral-100/70 border border-neutral-200/60 transition-colors text-xs"
                      >
                        <span className="font-mono text-neutral-800 flex items-center gap-2 text-[11px] font-medium">
                          <span className="text-xs">{gw.icon}</span>
                          <span>{gw.name}</span>
                        </span>
                        <PaymentStatusBadge provider={gw.id as any} content={content} size="sm" showSublabel={false} />
                      </div>
                    ))}
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    fullWidth
                    onClick={() => {
                      setIntegrationInitialTab('payment');
                      setActiveTab('brand_integration');
                    }}
                    className="flex items-center justify-center gap-1 text-xs cursor-pointer"
                  >
                    <span>Manage Integration Keys & Toggle Gateways</span>
                    <ArrowRight className="w-3 h-3" />
                  </Button>
                </div>

                <div className="bg-white border border-neutral-200 p-6 space-y-3">
                  <div className="flex items-center space-x-2 text-xs font-mono uppercase text-neutral-500">
                    <Sliders className="w-4 h-4 text-amber-600" />
                    <span>Home Banner & Hero Studio</span>
                  </div>
                  <p className="text-xs text-neutral-600">
                    Full control over opening visuals, darkroom scrim overlay colors, typography, CTA buttons, and seamless shape divider blending.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    fullWidth
                    onClick={() => setActiveTab('hero_banner')}
                    className="flex items-center justify-center gap-1 text-xs"
                  >
                    <span>Launch Banner Studio</span>
                    <ArrowRight className="w-3 h-3" />
                  </Button>
                </div>

                <div className="bg-white border border-neutral-200 p-6 space-y-3">
                  <div className="flex items-center space-x-2 text-xs font-mono uppercase text-neutral-500">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Cross-Device Cloud State</span>
                  </div>
                  <p className="text-xs text-neutral-600">
                    Cross-device data synchronization active. Changes made in this portal write to the database and sync across all visitor devices.
                  </p>
                  <button
                    onClick={() => setDataBackupOpen(true)}
                    className="text-xs font-mono text-neutral-900 hover:underline flex items-center gap-1 cursor-pointer font-medium"
                  >
                    <span>Export or Restore Data Snapshot</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                {/* Static Site Deployment / dist.zip Package */}
                <div className="bg-neutral-900 text-white border border-neutral-700 p-6 space-y-3 shadow-md">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-xs font-mono uppercase text-emerald-400 font-bold">
                      <Download className="w-4 h-4" />
                      <span>Static Site Package (dist.zip)</span>
                    </div>
                    <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5">
                      Ready
                    </span>
                  </div>
                  <p className="text-xs text-neutral-300 font-sans leading-relaxed">
                    Pre-compiled, standalone production distribution package. Ready for instant upload to any web host (Netlify, Vercel, cPanel, Apache, Cloudflare Pages, S3).
                  </p>
                  <a
                    href="/dist.zip"
                    download="dist.zip"
                    className="w-full py-2.5 px-4 bg-white hover:bg-neutral-200 text-black text-xs font-mono uppercase font-bold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer text-center block shadow-sm"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download dist.zip (Static Web Build)</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
          ) : renderAccessRestricted('Executive Operations Dashboard', 'catalog.view, orders.view, or content.view')
        )}

        {/* BRAND CONTROL TABS */}
        {(activeTab === 'brand_business_setup' || activeTab === 'brand') && (
          canManageSettings ? <BrandBusinessSetup /> : renderAccessRestricted('Brand & Business Setup', 'settings.manage')
        )}
        {activeTab === 'brand_integration' && (
          canViewIntegrations ? (
            <IntegrationSetup
              initialTab={integrationInitialTab}
              key={integrationInitialTab}
              showToast={showToast}
            />
          ) : renderAccessRestricted('Gateways & Integrations', 'integrations.edit')
        )}

        {/* COMBINED DESIGN WITH MENU & NAVIGATION (SINGLE MENU, TABS FOR EACH CONTROL) */}
        {(activeTab === 'design_and_navigation' || activeTab === 'brand_design' || activeTab === 'menu_navigation') && (
          canManageSettings ? (
            <DesignAndNavigationCMS
              initialTab={activeTab === 'menu_navigation' ? 'navigation' : 'design'}
              showToast={showToast}
              onNavigateToView={onNavigateToView}
            />
          ) : renderAccessRestricted('Design with Menu & Navigation Controls', 'settings.manage')
        )}

        {/* COMBINED JOURNAL & REFLECTIONS ARCHIVE (SINGLE MENU, TABS FOR EACH CONTROL + FRONTEND & ACCOUNT TOGGLES) */}
        {(activeTab === 'journal_reflections' || activeTab === 'moderation') && (
          (canViewContent || canViewCommunity) ? (
            <JournalAndReflectionsCMS
              initialTab={activeTab === 'moderation' ? 'reflections' : 'journal'}
              showToast={showToast}
              onNavigateToView={onNavigateToView}
              canModerateCommunity={canModerateCommunity}
              canEditContent={canEditContent}
              openConfirmDelete={openConfirmDelete}
            />
          ) : renderAccessRestricted('Journal & Reflections Archive Hub', 'content.view or community.view')
        )}

        {/* HOME BANNER STUDIO (Direct or via Page CMS) */}
        {(activeTab === 'hero_banner' || activeTab === 'banner') && (
          canViewContent ? (
            <HomeBannerStudio onBackToStore={onBackToStore} showToast={showToast} />
          ) : renderAccessRestricted('Home Banner Studio', 'content.view')
        )}

        {/* JOURNAL PAGE CMS (Direct Access routed to combined component) */}
        {activeTab === 'content_updates' && (
          canViewContent ? (
            <JournalAndReflectionsCMS
              initialTab="journal"
              showToast={showToast}
              onNavigateToView={onNavigateToView}
              canModerateCommunity={canModerateCommunity}
              canEditContent={canEditContent}
              openConfirmDelete={openConfirmDelete}
            />
          ) : renderAccessRestricted('Journal Page CMS', 'content.view')
        )}

        {/* TAB 3: ORDERS & FULFILLMENT */}
        {activeTab === 'orders' && (
          canViewOrders ? (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Title & Header Banner */}
            <div className="bg-white border border-neutral-200 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-serif text-xl font-bold text-neutral-900">Orders & Fulfilment Management</h3>
                <p className="text-xs text-neutral-500 font-sans mt-1">
                  Commercial order fulfillment table with clean order references (e.g. EC-94821-01), sequential row numbering, and line-item tracking.
                </p>
              </div>
              <div className="flex items-center space-x-2 bg-neutral-100 p-1 border border-neutral-200 shrink-0">
                <button
                  type="button"
                  onClick={() => setOrdersSubView('sn_items')}
                  className={`px-3 py-1.5 text-xs font-mono font-medium transition-colors cursor-pointer ${
                    ordersSubView === 'sn_items' ? 'bg-black text-white shadow-xs' : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  Fulfilment Line Items ({allFlattenedItems.length})
                </button>
                <button
                  type="button"
                  onClick={() => setOrdersSubView('orders')}
                  className={`px-3 py-1.5 text-xs font-mono font-medium transition-colors cursor-pointer ${
                    ordersSubView === 'orders' ? 'bg-black text-white shadow-xs' : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  Aggregated Orders ({orders.length})
                </button>
              </div>
            </div>

            {/* Global Search & Action Controls */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-4 border border-neutral-200">
              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-80">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => {
                      setOrderSearch(e.target.value);
                      setSnPage(1);
                    }}
                    placeholder="Search by Order Ref (e.g. EC-94821-01), customer, garment..."
                    className="w-full bg-neutral-50 border border-neutral-200 pl-9 pr-3 py-2 text-xs text-neutral-900 placeholder-neutral-400 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>
                <select
                  value={orderStatusFilter}
                  onChange={(e) => {
                    setOrderStatusFilter(e.target.value as any);
                    setSnPage(1);
                  }}
                  className="bg-neutral-50 border border-neutral-200 px-3 py-2 text-xs text-neutral-700 font-mono focus:outline-hidden"
                >
                  <option value="All">All Statuses</option>
                  <option value="Grace Period">Grace Period (Holding Window)</option>
                  <option value="Ready for Review">Ready for Review (Manual Queue)</option>
                  <option value="Paid">Paid (Pending Production)</option>
                  <option value="In Production">In Production (Apliiq / POD)</option>
                  <option value="Shipped">Shipped (In Transit)</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={!canExportOrders}
                  onClick={handleExportCSV}
                  className={!canExportOrders ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}
                  title={!canExportOrders ? 'Requires orders.export capability' : undefined}
                >
                  <Download className="w-3.5 h-3.5 mr-1.5" />
                  <span>Export CSV</span>
                </Button>
                {canFulfillOrders && (
                  <Button
                    variant="primary"
                    size="sm"
                    disabled={isSyncingPod}
                    onClick={handleTriggerApliiqBatch}
                    className="cursor-pointer bg-black text-white hover:bg-neutral-800 text-xs font-mono"
                    title="Send pending paid orders to Apliiq POD manufacturing queue"
                  >
                    <PackageCheck className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
                    <span>
                      {isSyncingPod
                        ? 'Dispatching...'
                        : `Dispatch to Apliiq (${orders.filter((o) => o.status === 'Paid' && !o.podOrderId).length})`}
                    </span>
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  disabled={!canEditOrders}
                  onClick={() => {
                    if (!canEditOrders) {
                      showToast('Requires orders.edit capability to create test orders.');
                      return;
                    }
                    addSampleOrder();
                  }}
                  className={!canEditOrders ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}
                  title={!canEditOrders ? 'Requires orders.edit capability' : undefined}
                >
                  <Plus className="w-3.5 h-3.5 mr-1.5" />
                  <span>+ Test Order</span>
                </Button>
              </div>
            </div>

            {/* VIEW 1: FULFILMENT LINE ITEMS (EXACT LAYOUT FROM USER IMAGE) */}
            {ordersSubView === 'sn_items' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                {/* Counting Metric Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-white p-4 border border-neutral-200 shadow-xs">
                    <span className="text-[10px] uppercase font-mono text-neutral-500">Total Fulfilment Entries</span>
                    <div className="text-2xl font-mono font-bold text-neutral-900 mt-1">{allFlattenedItems.length}</div>
                  </div>
                  <div className="bg-white p-4 border border-neutral-200 shadow-xs">
                    <span className="text-[10px] uppercase font-mono text-neutral-500">Total Garment Units</span>
                    <div className="text-2xl font-mono font-bold text-emerald-700 mt-1">{totalSnUnitsCount}</div>
                  </div>
                  <div className="bg-white p-4 border border-neutral-200 shadow-xs">
                    <span className="text-[10px] uppercase font-mono text-neutral-500">Pagination Overview</span>
                    <div className="text-sm font-mono font-bold text-neutral-900 mt-1">
                      Page {snPage} of {totalSnPages} (Showing {paginatedSnItems.length} entries)
                    </div>
                  </div>
                </div>

                {/* Primary Fulfilment Table */}
                <div className="bg-white border border-neutral-200 overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 uppercase font-mono text-[11px]">
                        <tr>
                          <th className="py-3 px-4 w-12 text-center font-bold border-r border-neutral-200">SN</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">ORDER REF</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Customer</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">GARMENT</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">SIZE / COLOR</th>
                          <th className="py-3 px-4 text-center font-bold border-r border-neutral-200 w-16">QTY</th>
                          <th className="py-3 px-4 text-right font-bold border-r border-neutral-200">UNIT PRICE</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">STATUS</th>
                          <th className="py-3 px-4 text-right font-bold">ACTIONS</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-100">
                        {paginatedSnItems.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="py-12 text-center text-neutral-500 font-serif text-sm">
                              No fulfilment line items found matching your criteria.
                            </td>
                          </tr>
                        ) : (
                          paginatedSnItems.map((item, idx) => {
                            const rowSerialNumber = (snPage - 1) * snItemsPerPage + idx + 1;
                            return (
                              <tr key={`${item.orderId}-${idx}`} className="hover:bg-neutral-50/70 transition-colors">
                                {/* SN: Row numbering */}
                                <td className="py-3.5 px-4 text-center font-mono font-bold text-neutral-700 bg-neutral-50/60 border-r border-neutral-100">
                                  {rowSerialNumber}
                                </td>

                                {/* ORDER REF: Clean, e.g. EC-94821-01 */}
                                <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 border-r border-neutral-100 whitespace-nowrap">
                                  {item.orderNumber}
                                </td>

                                {/* Customer */}
                                <td className="py-3.5 px-4 text-neutral-900 border-r border-neutral-100">
                                  <div className="font-medium">{item.customerName}</div>
                                  <div className="text-[10px] text-neutral-400 font-mono line-clamp-1">{item.customerEmail}</div>
                                </td>

                                {/* GARMENT */}
                                <td className="py-3.5 px-4 text-neutral-900 border-r border-neutral-100 font-medium">
                                  <div className="flex items-center gap-2">
                                    {item.image && (
                                      <img
                                        src={safeSrc(item.image)}
                                        alt={item.productName}
                                        className="w-8 h-8 object-cover rounded-xs border border-neutral-200 bg-neutral-100 shrink-0"
                                      />
                                    )}
                                    <div>
                                      <span className="block leading-tight">{item.productName}</span>
                                      {item.wearType && (
                                        <span className="text-[10px] font-mono text-neutral-500 block">
                                          {item.wearType}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                </td>

                                {/* SIZE / COLOR */}
                                <td className="py-3.5 px-4 font-mono text-neutral-700 text-xs border-r border-neutral-100 whitespace-nowrap">
                                  <span className="font-bold text-neutral-900">{item.size}</span>
                                  <span className="text-neutral-400 mx-1.5">/</span>
                                  <span>{item.color}</span>
                                </td>

                                {/* QTY */}
                                <td className="py-3.5 px-4 text-center font-mono font-bold text-neutral-900 border-r border-neutral-100">
                                  {item.quantity}
                                </td>

                                {/* UNIT PRICE */}
                                <td className="py-3.5 px-4 text-right font-mono font-medium text-neutral-900 border-r border-neutral-100">
                                  {formatPrice(item.price)}
                                </td>

                                {/* STATUS */}
                                <td className="py-3.5 px-4 border-r border-neutral-100">
                                  <div className="space-y-1">
                                    <select
                                      disabled={!canFulfillOrders}
                                      value={item.status}
                                      onChange={(e) => updateOrderStatus(item.orderNumber, e.target.value as OrderStatus)}
                                      className={`text-xs px-2.5 py-1 font-mono rounded-xs border focus:outline-hidden ${
                                        !canFulfillOrders
                                          ? 'bg-neutral-100 text-neutral-400 border-neutral-200 cursor-not-allowed'
                                          : item.status === 'Grace Period'
                                          ? 'bg-amber-50 text-amber-900 border-amber-300 font-semibold cursor-pointer'
                                          : item.status === 'Ready for Review'
                                          ? 'bg-blue-50 text-blue-900 border-blue-300 font-semibold cursor-pointer'
                                          : item.status === 'Delivered'
                                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-semibold cursor-pointer'
                                          : item.status === 'Shipped'
                                          ? 'bg-blue-50 text-blue-800 border-blue-300 font-semibold cursor-pointer'
                                          : item.status === 'In Production'
                                          ? 'bg-purple-50 text-purple-800 border-purple-300 font-semibold cursor-pointer'
                                          : item.status === 'Paid'
                                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-semibold cursor-pointer'
                                          : 'bg-neutral-100 text-neutral-700 border-neutral-300 cursor-pointer'
                                      }`}
                                      title={!canFulfillOrders ? 'Requires orders.fulfill capability' : undefined}
                                    >
                                      <option value="Grace Period">Grace Period</option>
                                      <option value="Ready for Review">Ready for Review</option>
                                      <option value="Paid">Paid</option>
                                      <option value="In Production">In Production</option>
                                      <option value="Shipped">Shipped</option>
                                      <option value="Delivered">Delivered</option>
                                      <option value="Cancelled">Cancelled</option>
                                    </select>

                                    {item.status === 'Grace Period' && canFulfillOrders && (
                                      <div className="pt-0.5">
                                        <button
                                          type="button"
                                          disabled={dispatchingOrderId === item.orderNumber}
                                          onClick={() => handleDispatchOrderNow(item.orderNumber)}
                                          className="text-[10px] font-mono text-black hover:text-amber-800 underline flex items-center gap-1 cursor-pointer font-bold"
                                        >
                                          {dispatchingOrderId === item.orderNumber ? (
                                            <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                                          ) : (
                                            <Zap className="w-2.5 h-2.5 text-amber-600" />
                                          )}
                                          <span>Dispatch Now</span>
                                        </button>
                                      </div>
                                    )}

                                    {item.status === 'Ready for Review' && canFulfillOrders && (
                                      <div className="pt-0.5">
                                        <button
                                          type="button"
                                          disabled={dispatchingOrderId === item.orderNumber}
                                          onClick={() => handleDispatchOrderNow(item.orderNumber)}
                                          className="text-[10px] font-mono text-white bg-black hover:bg-neutral-800 px-1.5 py-0.5 flex items-center gap-1 cursor-pointer font-bold"
                                        >
                                          <Check className="w-2.5 h-2.5 text-emerald-400" />
                                          <span>Approve</span>
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                </td>

                                {/* ACTIONS */}
                                <td className="py-3.5 px-4 text-right space-x-1.5 whitespace-nowrap">
                                  <button
                                    onClick={() => setPackingSlipOrder(item.fullOrder)}
                                    title="Print Commercial Packing Slip"
                                    className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded-xs cursor-pointer inline-flex items-center gap-1 text-[11px] font-mono"
                                  >
                                    <Printer className="w-3.5 h-3.5" />
                                    <span className="hidden lg:inline">Slip</span>
                                  </button>
                                  {item.trackingNumber ? (
                                    <a
                                      href={item.trackingUrl || '#'}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-xs inline-flex items-center gap-1 text-[11px] font-mono"
                                      title={`Track: ${item.trackingNumber}`}
                                    >
                                      <Truck className="w-3.5 h-3.5" />
                                      <span className="hidden lg:inline">USPS</span>
                                    </a>
                                  ) : (
                                    <button
                                      disabled={!canFulfillOrders}
                                      onClick={() => {
                                        if (!canFulfillOrders) return;
                                        setTrackingModalOrder(item.fullOrder);
                                        setTrackingInputNum(
                                          `9400 1118 9956 ${Math.floor(1000 + Math.random() * 9000)} ${Math.floor(
                                            1000 + Math.random() * 9000
                                          )} 00`
                                        );
                                      }}
                                      className={`p-1.5 rounded-xs inline-flex items-center gap-1 text-[11px] font-mono ${
                                        !canFulfillOrders
                                          ? 'text-neutral-300 cursor-not-allowed'
                                          : 'text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer'
                                      }`}
                                      title={!canFulfillOrders ? 'Requires orders.fulfill capability' : 'Add Carrier Tracking'}
                                    >
                                      <Truck className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                  {canEditOrders && (
                                    <button
                                      onClick={() => {
                                        openConfirmDelete({
                                          title: 'Delete Order Record',
                                          itemName: `Order #${item.orderNumber} (${item.customerName})`,
                                          itemType: 'order',
                                          warningMessage: 'Permanently removing this order will erase all fulfillment tracking and historical payment records.',
                                          onConfirm: () => {
                                            deleteOrder(item.orderNumber);
                                            showToast(`Order #${item.orderNumber} deleted.`);
                                          },
                                        });
                                      }}
                                      title="Delete Order"
                                      className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-xs cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Pagination Controls */}
                  {totalSnPages > 1 && (
                    <div className="p-4 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between">
                      <span className="text-xs font-mono text-neutral-500">
                        Showing {(snPage - 1) * snItemsPerPage + 1} to {Math.min(snPage * snItemsPerPage, allFlattenedItems.length)} of {allFlattenedItems.length} entries
                      </span>
                      <div className="flex items-center space-x-1">
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={snPage === 1}
                          onClick={() => setSnPage((p) => Math.max(1, p - 1))}
                          className="text-xs"
                        >
                          Previous
                        </Button>
                        {Array.from({ length: totalSnPages }, (_, i) => i + 1).map((pageNum) => (
                          <button
                            key={pageNum}
                            type="button"
                            onClick={() => setSnPage(pageNum)}
                            className={`w-7 h-7 text-xs font-mono transition-colors cursor-pointer border ${
                              snPage === pageNum
                                ? 'bg-black text-white border-black font-bold'
                                : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                            }`}
                          >
                            {pageNum}
                          </button>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={snPage === totalSnPages}
                          onClick={() => setSnPage((p) => Math.min(totalSnPages, p + 1))}
                          className="text-xs"
                        >
                          Next
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* VIEW 2: AGGREGATED ORDERS TABLE */}
            {ordersSubView === 'orders' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="bg-white border border-neutral-200 overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 uppercase font-mono text-[11px]">
                        <tr>
                          <th className="py-3 px-4 w-12 text-center font-bold border-r border-neutral-200">SN</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">ORDER REF</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Date & Time</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Customer</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Garments</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200 text-right">Total</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Fulfillment Status</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Tracking (USPS)</th>
                          <th className="py-3 px-4 text-right font-bold">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-100">
                        {filteredOrders.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="py-12 text-center text-neutral-500 font-serif text-sm">
                              No customer orders match the current filter criteria.
                            </td>
                          </tr>
                        ) : (
                          filteredOrders.map((ord, idx) => (
                            <tr key={ord.id} className="hover:bg-neutral-50/70 transition-colors">
                              <td className="py-3.5 px-4 text-center font-mono font-bold text-neutral-700 bg-neutral-50/60 border-r border-neutral-100">
                                {idx + 1}
                              </td>
                              <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 border-r border-neutral-100 whitespace-nowrap">
                                {ord.orderNumber}
                              </td>
                              <td className="py-3.5 px-4 text-neutral-500 font-mono text-[11px] border-r border-neutral-100 whitespace-nowrap">
                                {new Date(ord.createdAt).toLocaleDateString()}
                              </td>
                              <td className="py-3.5 px-4 border-r border-neutral-100">
                                <div className="font-medium text-neutral-900">{ord.customerName}</div>
                                <div className="text-[10px] text-neutral-500 font-mono">{ord.customerEmail}</div>
                              </td>
                              <td className="py-3.5 px-4 text-neutral-700 border-r border-neutral-100">
                                {ord.items.map((i) => `${i.quantity}x ${i.productName} (${i.size})`).join(', ')}
                              </td>
                              <td className="py-3.5 px-4 font-medium text-neutral-900 font-mono text-right border-r border-neutral-100">
                                {formatPrice(ord.total)}
                              </td>
                              <td className="py-3.5 px-4 border-r border-neutral-100">
                                <div className="space-y-1.5">
                                  <select
                                    disabled={!canFulfillOrders}
                                    value={ord.status}
                                    onChange={(e) => updateOrderStatus(ord.orderNumber, e.target.value as OrderStatus)}
                                    className={`border text-xs px-2 py-1 font-mono rounded-xs focus:outline-hidden ${
                                      !canFulfillOrders
                                        ? 'bg-neutral-100 text-neutral-400 border-neutral-200 cursor-not-allowed'
                                        : ord.status === 'Grace Period'
                                        ? 'bg-amber-50 text-amber-900 border-amber-300 font-semibold cursor-pointer'
                                        : ord.status === 'Ready for Review'
                                        ? 'bg-blue-50 text-blue-900 border-blue-300 font-semibold cursor-pointer'
                                        : ord.status === 'In Production'
                                        ? 'bg-purple-50 text-purple-900 border-purple-300 font-semibold cursor-pointer'
                                        : ord.status === 'Paid'
                                        ? 'bg-emerald-50 text-emerald-900 border-emerald-300 font-semibold cursor-pointer'
                                        : 'bg-neutral-50 border-neutral-300 cursor-pointer'
                                    }`}
                                    title={!canFulfillOrders ? 'Requires orders.fulfill capability' : undefined}
                                  >
                                    <option value="Grace Period">Grace Period</option>
                                    <option value="Ready for Review">Ready for Review</option>
                                    <option value="Paid">Paid</option>
                                    <option value="In Production">In Production</option>
                                    <option value="Shipped">Shipped</option>
                                    <option value="Delivered">Delivered</option>
                                    <option value="Cancelled">Cancelled</option>
                                  </select>

                                  {ord.status === 'Grace Period' && (
                                    <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                                      <span className="text-[10px] font-mono text-amber-800 bg-amber-50 px-1.5 py-0.5 border border-amber-300">
                                        <Clock className="w-2.5 h-2.5 inline mr-1" />
                                        {getRemainingGraceMinutes(ord.scheduledDispatchAt)}m left
                                      </span>
                                      {canFulfillOrders && (
                                        <button
                                          type="button"
                                          disabled={dispatchingOrderId === ord.orderNumber}
                                          onClick={() => handleDispatchOrderNow(ord.orderNumber)}
                                          className="text-[10px] font-mono text-black hover:text-amber-800 underline flex items-center gap-1 cursor-pointer font-bold"
                                          title="Bypass grace period and push to Apliiq immediately"
                                        >
                                          {dispatchingOrderId === ord.orderNumber ? (
                                            <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                                          ) : (
                                            <Zap className="w-2.5 h-2.5 text-amber-600" />
                                          )}
                                          <span>Dispatch Now</span>
                                        </button>
                                      )}
                                    </div>
                                  )}

                                  {ord.status === 'Ready for Review' && canFulfillOrders && (
                                    <div className="pt-0.5">
                                      <button
                                        type="button"
                                        disabled={dispatchingOrderId === ord.orderNumber}
                                        onClick={() => handleDispatchOrderNow(ord.orderNumber)}
                                        className="text-[10px] font-mono text-white bg-black hover:bg-neutral-800 px-2 py-0.5 flex items-center gap-1 cursor-pointer font-bold shadow-2xs"
                                      >
                                        {dispatchingOrderId === ord.orderNumber ? (
                                          <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                                        ) : (
                                          <Check className="w-2.5 h-2.5 text-emerald-400" />
                                        )}
                                        <span>Approve &amp; Dispatch</span>
                                      </button>
                                    </div>
                                  )}

                                  {ord.podOrderId ? (
                                    <div className="text-[10px] font-mono text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded-xs border border-purple-200 inline-block">
                                      Apliiq: {ord.podOrderId}
                                    </div>
                                  ) : (ord.status === 'Paid' || ord.status === 'In Production') && !ord.podOrderId && canFulfillOrders ? (
                                    <button
                                      type="button"
                                      onClick={async () => {
                                        const res = await fulfillOrder(ord.orderNumber, 'apliiq');
                                        showToast(res.message);
                                      }}
                                      className="text-[10px] font-mono text-black hover:text-neutral-700 underline flex items-center gap-1 cursor-pointer"
                                    >
                                      <PackageCheck className="w-3 h-3 text-amber-600" />
                                      <span>Send to Apliiq</span>
                                    </button>
                                  ) : null}
                                </div>
                              </td>
                              <td className="py-3.5 px-4 font-mono text-[11px] border-r border-neutral-100">
                                {ord.trackingNumber ? (
                                  <a
                                    href={ord.trackingUrl || '#'}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="text-blue-600 hover:underline flex items-center gap-1"
                                  >
                                    <span>{ord.trackingNumber.slice(0, 12)}...</span>
                                    <ExternalLink className="w-3 h-3" />
                                  </a>
                                ) : (
                                  <button
                                    disabled={!canFulfillOrders}
                                    onClick={() => {
                                      if (!canFulfillOrders) return;
                                      setTrackingModalOrder(ord);
                                      setTrackingInputNum(
                                        `9400 1118 9956 ${Math.floor(1000 + Math.random() * 9000)} ${Math.floor(
                                          1000 + Math.random() * 9000
                                        )} 00`
                                      );
                                    }}
                                    className={`text-xs underline ${
                                      !canFulfillOrders
                                        ? 'text-neutral-400 cursor-not-allowed'
                                        : 'text-neutral-500 hover:text-black cursor-pointer'
                                    }`}
                                    title={!canFulfillOrders ? 'Requires orders.fulfill capability' : undefined}
                                  >
                                    + Add Tracking
                                  </button>
                                )}
                              </td>
                              <td className="py-3.5 px-4 text-right space-x-2 whitespace-nowrap">
                                <button
                                  onClick={() => setPackingSlipOrder(ord)}
                                  title="Print Commercial Packing Slip"
                                  className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded-sm cursor-pointer"
                                >
                                  <Printer className="w-3.5 h-3.5" />
                                </button>
                                {canEditOrders && (
                                  <button
                                    onClick={() => {
                                      openConfirmDelete({
                                        title: 'Delete Order Record',
                                        itemName: `Order #${ord.orderNumber} (${ord.customerName} - ${formatPrice(ord.total)})`,
                                        itemType: 'order',
                                        warningMessage: 'Permanently removing this order will erase all fulfillment tracking and historical payment records.',
                                        onConfirm: () => {
                                          deleteOrder(ord.orderNumber);
                                          showToast(`Order #${ord.orderNumber} deleted.`);
                                        },
                                      });
                                    }}
                                    title="Cancel / Delete Order"
                                    className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-sm cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
          ) : renderAccessRestricted('Orders & Fulfillment', 'orders.view')
        )}

        {/* TAB 4: GARMENT CATALOG & PRODUCT STUDIO */}
        {activeTab === 'products' && (
          canViewCatalog ? (
          isProductStudioOpen ? (
            <ProductStudio
              initialProduct={productStudioInitialProduct}
              initialFromDesign={productStudioInitialDesign}
              onClose={() => {
                setIsProductStudioOpen(false);
                setProductStudioInitialProduct(null);
                setProductStudioInitialDesign(null);
              }}
              onSuccess={(saved) => {
                setIsProductStudioOpen(false);
                setProductStudioInitialProduct(null);
                setProductStudioInitialDesign(null);
                showToast(`Saved and published ${saved.name}!`);
              }}
              showToast={showToast}
            />
          ) : (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-white p-5 border border-neutral-200 gap-4 shadow-xs">
                <div>
                  <h3 className="font-serif text-xl font-bold text-neutral-900">Commercial Garments & Product Studio</h3>
                  <p className="text-xs text-neutral-500 font-sans mt-0.5">
                    Multi-silhouette products, DTF print specs, real-time inventory modes, and direct Apliiq POD fulfillment.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={!canEditCatalog}
                    onClick={() => setIsApliiqSyncModalOpen(true)}
                    className="text-xs font-mono bg-amber-50 hover:bg-amber-100 text-amber-950 border-amber-300 cursor-pointer flex items-center gap-1.5"
                    title="Browse and import designs from your Apliiq store"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-700" />
                    <span>Sync from Apliiq</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab('design_factory')}
                    className="text-xs font-mono text-purple-900 bg-purple-50 hover:bg-purple-100 border-purple-300 cursor-pointer"
                  >
                    <Palette className="w-3.5 h-3.5 mr-1.5 text-purple-700" />
                    <span>Design Factory</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab('variants')}
                    className="text-xs font-mono cursor-pointer"
                  >
                    <Layers className="w-3.5 h-3.5 mr-1.5 text-neutral-700" />
                    <span>Wear Types & Blanks ({wearTypes.length})</span>
                  </Button>
                  <Button
                    variant="primary"
                    size="sm"
                    disabled={!canEditCatalog}
                    onClick={handleOpenAddProductPad}
                    className={`text-xs font-mono bg-black text-white hover:bg-neutral-800 ${
                      !canEditCatalog ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'
                    }`}
                    title={!canEditCatalog ? 'Requires catalog.edit capability' : undefined}
                  >
                    <Plus className="w-3.5 h-3.5 mr-1.5" />
                    <span>+ Launch Product Studio</span>
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((prod) => (
                  <div key={prod.id} className="bg-white border border-neutral-200 overflow-hidden shadow-xs flex flex-col justify-between hover:border-neutral-400 transition-all">
                    <div>
                      <div className="aspect-4/3 relative bg-neutral-100 overflow-hidden">
                        <img src={safeSrc(prod.primaryImage)} alt={prod.name} className="w-full h-full object-cover" />
                        <div className="absolute top-3 right-3 flex flex-col gap-1 items-end">
                          <Badge variant={prod.isAvailable ? 'success' : 'neutral'} size="sm">
                            {prod.isAvailable ? 'In Stock' : 'Archived'}
                          </Badge>
                          {prod.sourceDesignId && (
                            <span className="px-1.5 py-0.5 text-[9px] font-mono bg-purple-100/90 text-purple-900 border border-purple-300 backdrop-blur-xs">
                              Design #{prod.sourceDesignId}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="p-5 space-y-3">
                        <div>
                          <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400">
                            {prod.collectionId}
                          </span>
                          <h4 className="font-serif text-lg font-bold text-neutral-900">{prod.name}</h4>
                          <p className="text-xs text-neutral-600 italic mt-0.5 font-serif line-clamp-1">"{prod.tagline}"</p>
                        </div>

                        <div className="pt-2 border-t border-neutral-100 space-y-2 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="text-neutral-500 font-mono">Retail Base:</span>
                            <div className="flex items-center space-x-1.5">
                              <span className="font-mono text-neutral-400">$</span>
                              <input
                                type="number"
                                disabled={!canEditCatalog}
                                defaultValue={prod.price}
                                onBlur={(e) => {
                                  if (!canEditCatalog) return;
                                  const newP = parseFloat(e.target.value);
                                  if (!isNaN(newP) && newP > 0) {
                                    updateProductPrice(prod.id, newP);
                                    showToast(`Updated ${prod.name} price to $${newP}`);
                                  }
                                }}
                                className={`w-20 border px-2 py-1 text-xs font-mono font-bold text-right ${
                                  !canEditCatalog
                                    ? 'bg-neutral-100 text-neutral-400 border-neutral-200 cursor-not-allowed'
                                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                                }`}
                                title={!canEditCatalog ? 'Requires catalog.edit capability' : undefined}
                              />
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-[11px] font-mono">
                            <span className="text-neutral-500">Silhouettes:</span>
                            <span className="text-neutral-800 font-medium truncate max-w-40">
                              {(prod.availableWearTypes || ['Heavyweight Tee']).join(', ')}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-[11px] font-mono">
                            <span className="text-neutral-500">Variants:</span>
                            <span className="text-neutral-800 font-bold">
                              {prod.variants?.length || 0} configured SKUs
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between text-xs gap-2">
                      <button
                        disabled={!canEditCatalog}
                        onClick={() => handleOpenEditProductPad(prod)}
                        className={`text-xs font-mono font-bold uppercase flex items-center gap-1 ${
                          !canEditCatalog ? 'text-neutral-400 cursor-not-allowed' : 'text-black hover:underline cursor-pointer'
                        }`}
                        title={!canEditCatalog ? 'Requires catalog.edit capability' : undefined}
                      >
                        <span>Edit Studio</span>
                      </button>
                      <button
                        disabled={!canEditCatalog}
                        onClick={() => toggleProductAvailability(prod.id)}
                        className={`text-xs font-mono uppercase ${
                          !canEditCatalog ? 'text-neutral-400 cursor-not-allowed' : 'text-neutral-600 hover:text-black cursor-pointer'
                        }`}
                        title={!canEditCatalog ? 'Requires catalog.edit capability' : undefined}
                      >
                        {prod.isAvailable ? 'Mark Sold Out' : 'Mark Available'}
                      </button>
                      {onNavigateToProduct && (
                        <button
                          onClick={() => onNavigateToProduct(prod.id)}
                          className="text-xs font-mono text-black hover:underline cursor-pointer flex items-center gap-1"
                        >
                          <span>View</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                      {canEditCatalog && (
                        <button
                          type="button"
                          onClick={() => {
                            openConfirmDelete({
                              title: 'Delete Catalog Garment',
                              itemName: `${prod.name} (${prod.slug})`,
                              itemType: 'garment product',
                              warningMessage: 'This will permanently remove this commercial garment, its variants, prices, and editorial specifications from the catalog. This action cannot be undone.',
                              onConfirm: () => {
                                deleteProduct(prod.id);
                                showToast(`Garment "${prod.name}" permanently deleted.`);
                              },
                            });
                          }}
                          className="text-xs font-mono uppercase text-neutral-400 hover:text-red-600 cursor-pointer flex items-center gap-1 p-1 hover:bg-red-50 rounded-xs"
                          title="Delete Garment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Delete</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
          ) : renderAccessRestricted('Product Studio & Garment Catalog', 'catalog.view')
        )}

        {/* TAB: DESIGN FACTORY (CREATIVE LAB & DRAFTS) */}
        {activeTab === 'design_factory' && (
          canViewCatalog ? (
            <DesignFactoryCMS
              onPushToProduct={handlePushDesignToStudio}
              showToast={showToast}
            />
          ) : renderAccessRestricted('Design Factory (Creative Lab)', 'catalog.view')
        )}

        {/* TAB: MASTER WEAR TYPES & BASE BLANKS LIBRARY */}
        {activeTab === 'variants' && (
          canViewCatalog ? (
            <WearTypeLibraryCMS showToast={showToast} />
          ) : renderAccessRestricted('Master Wear Types & Base Blanks Library', 'catalog.view')
        )}

        {/* TAB 5: REFLECTIONS MODERATION */}
        {activeTab === 'moderation' && (
          canViewCommunity ? (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-white p-4 border border-neutral-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg text-neutral-900">Human Connection Archive Moderation</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  Review, approve, and feature customer answers to "What does this mean to you?".
                </p>
              </div>
              <Badge variant="neutral" size="sm">
                {responses.length} Total Submissions
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {responses.map((ref) => (
                <div
                  key={ref.id}
                  className={`bg-white border p-6 space-y-4 shadow-xs transition-colors ${
                    ref.status === 'Approved'
                      ? 'border-emerald-200'
                      : ref.status === 'Rejected'
                      ? 'border-red-200 opacity-60'
                      : 'border-amber-200 bg-amber-50/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-500">
                      {ref.productName || 'General Reflection'}
                    </span>
                    <Badge
                      variant={
                        ref.status === 'Approved'
                          ? 'success'
                          : ref.status === 'Rejected'
                          ? 'error'
                          : 'warning'
                      }
                      size="sm"
                    >
                      {ref.status}
                    </Badge>
                  </div>

                  <p className="font-serif italic text-sm text-neutral-900 leading-relaxed">
                    "{ref.response}"
                  </p>

                  <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500 font-mono">
                    <span>
                      {ref.authorName} · {ref.authorLocation}
                    </span>
                    <span className="text-[10px]">{new Date(ref.createdAt).toLocaleDateString()}</span>
                  </div>

                  <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs">
                    <div className="space-x-2">
                      <button
                        disabled={!canModerateCommunity}
                        onClick={() => {
                          if (!canModerateCommunity) return;
                          updateStatus(ref.id, 'Approved');
                          showToast('Reflection approved for storefront display');
                        }}
                        className={`px-2.5 py-1 text-[11px] font-mono rounded-xs ${
                          !canModerateCommunity
                            ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                            : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 cursor-pointer'
                        }`}
                        title={!canModerateCommunity ? 'Requires community.moderate capability' : undefined}
                      >
                        Approve
                      </button>
                      <button
                        disabled={!canModerateCommunity}
                        onClick={() => {
                          if (!canModerateCommunity) return;
                          updateStatus(ref.id, 'Rejected');
                          showToast('Reflection hidden from public view');
                        }}
                        className={`px-2.5 py-1 text-[11px] font-mono rounded-xs ${
                          !canModerateCommunity
                            ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                            : 'bg-red-100 text-red-800 hover:bg-red-200 cursor-pointer'
                        }`}
                        title={!canModerateCommunity ? 'Requires community.moderate capability' : undefined}
                      >
                        Reject
                      </button>
                    </div>

                    <button
                      disabled={!canModerateCommunity}
                      onClick={() => {
                        if (!canModerateCommunity) return;
                        openConfirmDelete({
                          title: 'Delete Reflection Submission',
                          itemName: `Reflection by ${ref.authorName}: "${ref.response.slice(0, 36)}..."`,
                          itemType: 'reflection',
                          warningMessage: 'This submission will be permanently removed from the community archive database.',
                          onConfirm: () => {
                            deleteResponse(ref.id);
                            showToast('Reflection permanently deleted.');
                          },
                        });
                      }}
                      className={`p-1 rounded-xs ${
                        !canModerateCommunity
                          ? 'text-neutral-300 cursor-not-allowed'
                          : 'text-neutral-400 hover:text-red-600 hover:bg-red-50 cursor-pointer'
                      }`}
                      title={!canModerateCommunity ? 'Requires community.moderate capability' : 'Permanently Delete Reflection'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          ) : renderAccessRestricted('Human Connection Archive Moderation', 'community.view')
        )}

        {/* TAB 6: FRONTEND DESIGN & SHAPE DIVIDERS */}
        {activeTab === 'frontend' && (
          canManageSettings ? (
          <form onSubmit={handleSaveFrontend} className="space-y-8 animate-in fade-in duration-200">
            <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs">
              <div className="border-b border-neutral-100 pb-4">
                <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
                  Design System & Layout Architecture
                </span>
                <h3 className="font-serif text-xl text-neutral-900 mt-1">
                  Architectural Shape Divider & Theme Settings
                </h3>
                <p className="text-xs text-neutral-600 mt-1">
                  Administer the universal diagonal and contour shape dividers that extend across all storefront pages.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-neutral-50 border border-neutral-200">
                    <div>
                      <label className="text-xs font-semibold text-neutral-900 block">
                        Enable Universal Shape Dividers
                      </label>
                      <p className="text-[11px] text-neutral-500">
                        Renders architectural section cutaways and footer dividers.
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={shapeDividerEnabledInput}
                      onChange={(e) => setShapeDividerEnabledInput(e.target.checked)}
                      className="w-4 h-4 accent-black cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-xs uppercase font-mono text-neutral-700 mb-2">
                      Shape Divider Contour Variant
                    </label>
                    <select
                      value={shapeDividerVariantInput}
                      onChange={(e) => setShapeDividerVariantInput(e.target.value as ShapeDividerVariant)}
                      className="w-full bg-neutral-50 border border-neutral-300 px-3 py-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                    >
                      <option value="editorial-notch">Editorial Notch (Architectural Diagonal Cut)</option>
                      <option value="parabolic-arch">Parabolic Arch (Smooth Curved Dome Arch)</option>
                      <option value="organic-swell">Organic Swell (Natural Fluid Contour)</option>
                      <option value="subtle-crest">Subtle Crest (Soft Convex Architectural Rise)</option>
                      <option value="zebra-contour">Zebra Contour (Organic Dual Topography)</option>
                      <option value="textile-seam">Textile Seam (Tactile Stitch Line)</option>
                      <option value="horizon-converge">Horizon Converge (Geometric Horizon Step)</option>
                      <option value="asymmetric-slash">Asymmetric Slash (High Tension Angle)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs uppercase font-mono text-neutral-700 mb-2">
                      Divider Height in Pixels ({shapeDividerHeightInput}px)
                    </label>
                    <input
                      type="range"
                      min={40}
                      max={120}
                      step={4}
                      value={shapeDividerHeightInput}
                      onChange={(e) => setShapeDividerHeightInput(Number(e.target.value))}
                      className="w-full accent-black cursor-pointer"
                    />
                  </div>
                </div>

                {/* Live Preview Box */}
                <div className="bg-[#141414] text-white p-6 border border-[#262626] space-y-4 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 block mb-2">
                      Live Shape Divider Preview
                    </span>
                    <div className="w-full bg-[#fbfbf9] text-neutral-900 p-4 text-xs font-serif italic text-center">
                      Storefront Page Content Above
                    </div>
                    <div className="w-full overflow-hidden -mt-[1px] -mb-[1px]">
                      <ShapeDivider
                        variant={shapeDividerVariantInput}
                        fillColor="#141414"
                        bgColor="transparent"
                        height={shapeDividerHeightInput}
                        position="bottom"
                      />
                    </div>
                    <div className="w-full bg-[#141414] text-neutral-400 p-4 text-xs font-mono text-center">
                      Global Charcoal Footer (#141414) Below
                    </div>
                  </div>

                  <p className="text-[11px] text-neutral-400">
                    Active on: Home, Garments, Product Details, Customer Dashboard, Manifesto, FAQs, and Policies.
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-100 flex justify-end">
                <Button
                  type="submit"
                  variant="primary"
                  size="md"
                  disabled={!canManageSettings}
                  className={!canManageSettings ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}
                  title={!canManageSettings ? 'Requires settings.manage capability' : undefined}
                >
                  Save Frontend Design Settings
                </Button>
              </div>
            </div>
          </form>
          ) : renderAccessRestricted('Frontend Design & Theme Settings', 'settings.manage')
        )}

        {/* TAB 7: EDITORIAL PAGES CMS */}
        {(activeTab === 'content_editorial' || activeTab === 'content') && (
          canViewContent ? (
            <EditorialPagesCMS initialTab={editorialInitialTab} canEditContent={canEditContent} onNavigateToView={onNavigateToView} />
          ) : renderAccessRestricted('Editorial Pages CMS', 'content.view')
        )}

        {/* SETTINGS TAB */}
        {(activeTab === 'settings' || activeTab === 'ux') && (
          canManageSettings ? (
            <SettingsSetup onOpenDataBackupModal={() => setDataBackupOpen(true)} />
          ) : renderAccessRestricted('System & Admin Settings', 'settings.manage')
        )}

        {/* TAB 10: USER & STAFF MANAGEMENT (RBAC) */}
        {activeTab === 'users' && (
          canViewUsers ? (
            <div className="space-y-8 animate-in fade-in duration-200">
              <UserManagementCMS currentUser={adminUser} showToast={showToast} />
            </div>
          ) : renderAccessRestricted('Staff & User Roles Management', 'users.view')
        )}

        {/* TAB 10B: MEMBER VERIFICATION & BADGE STUDIO */}
        {activeTab === 'verification' && (
          (canViewUsers || canViewCommunity) ? (
            <div className="animate-in fade-in duration-200">
              <UserVerificationCMS
                contentRules={content.memberVerificationRules}
                onUpdateRules={(rules) => updateContent({
                  memberVerificationRules: rules,
                  enableMemberVerification: rules.enabled,
                })}
                orders={orders}
                responses={responses}
                currentUser={user}
                showToast={showToast}
                isSystemEnabled={content.enableMemberVerification !== false && content.memberVerificationRules?.enabled !== false}
                onToggleSystemEnabled={(enabled) => updateContent({
                  enableMemberVerification: enabled,
                  memberVerificationRules: {
                    ...DEFAULT_VERIFICATION_RULES,
                    ...(content.memberVerificationRules || {}),
                    enabled,
                  },
                })}
              />
            </div>
          ) : renderAccessRestricted('Member Verification & Badges', 'users.view or community.view')
        )}

        {/* TAB 11: SEO & SOCIAL GRAPH */}
        {activeTab === 'seo' && (
          canManageSeo ? (
            <PageSeoMetadataCMS showToast={showToast} />
          ) : renderAccessRestricted('Search Engine Optimization & Social Graph', 'settings.manage or content.edit')
        )}
      </main>

      {/* Modals */}
      {packingSlipOrder && (
        <PackingSlipModal
          order={packingSlipOrder}
          onClose={() => setPackingSlipOrder(null)}
        />
      )}

      {dataBackupOpen && (
        <DataBackupModal
          isOpen={dataBackupOpen}
          onClose={() => setDataBackupOpen(false)}
          onDataRestored={() => showToast('Database snapshot restored successfully!')}
        />
      )}

      {/* Tracking Modal */}
      {trackingModalOrder && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-white max-w-md w-full p-6 space-y-4 border border-neutral-300 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-base text-neutral-900">Add USPS Tracking</h3>
              <button onClick={() => setTrackingModalOrder(null)} className="text-neutral-400 hover:text-black">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Carrier</label>
              <input
                type="text"
                value={trackingInputCarrier}
                onChange={(e) => setTrackingInputCarrier(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Tracking Number</label>
              <input
                type="text"
                value={trackingInputNum}
                onChange={(e) => setTrackingInputNum(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setTrackingModalOrder(null)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  updateOrderTracking(
                    trackingModalOrder.orderNumber,
                    trackingInputNum,
                    trackingInputCarrier,
                    trackingInputUrl || undefined
                  );

                  // Dispatch transactional shipping update email
                  if (trackingModalOrder.customerEmail) {
                    api.sendEmail({
                      to: trackingModalOrder.customerEmail,
                      subject: `Shipment Update: Order #${trackingModalOrder.orderNumber} is In Transit`,
                      html: `
                        <div style="font-family: serif; max-width: 600px; margin: auto; padding: 24px; border: 1px solid #e5e5e5; background: #fbfbf9; color: #0a0a0a;">
                          <h2>Your Order #${trackingModalOrder.orderNumber} Has Shipped!</h2>
                          <p style="font-style: italic; color: #555;">"We are not the same. That's the point."</p>
                          <p>Dear ${trackingModalOrder.customerName},</p>
                          <p>Your made-to-order connection garments have been crafted and dispatched via <strong>${trackingInputCarrier}</strong>.</p>
                          <div style="padding: 16px; background: #ffffff; border: 1px solid #e0e0e0; margin: 16px 0;">
                            <p style="margin: 0; font-family: monospace;"><strong>Carrier:</strong> ${trackingInputCarrier}</p>
                            <p style="margin: 4px 0 0 0; font-family: monospace;"><strong>Tracking Number:</strong> ${trackingInputNum}</p>
                          </div>
                          <p style="font-size: 12px; color: #666;">Thank you for journeying with us,</p>
                          <p style="font-size: 12px; color: #888;">Ezistential Connection Studio</p>
                        </div>
                      `,
                      templateKey: 'order_shipped',
                      provider: content.emailProvider,
                      apiKey: content.emailApiKey,
                      fromEmail: content.emailFromSenderEmail || content.ordersEmail || 'orders@ezistential.com',
                      fromName: content.emailFromSenderName || 'Ezistential Connection',
                    }).catch((e) => console.warn('Tracking dispatch email notice:', e));
                  }

                  setTrackingModalOrder(null);
                  showToast('Tracking saved & order status updated to Shipped!');
                }}
              >
                Save & Dispatch
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Add FAQ Modal */}
      {addFaqModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <form onSubmit={handleAddFaqSubmit} className="bg-white max-w-lg w-full p-6 space-y-4 border border-neutral-300 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-base text-neutral-900">Publish New FAQ Directive</h3>
              <button type="button" onClick={() => setAddFaqModalOpen(false)} className="text-neutral-400 hover:text-black">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Category</label>
              <select
                value={newFaqCat}
                onChange={(e) => setNewFaqCat(e.target.value as any)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
              >
                <option value="Brand & Meaning">Brand & Meaning</option>
                <option value="Products & Sizing">Products & Sizing</option>
                <option value="Shipping & Delivery">Shipping & Delivery</option>
                <option value="Returns & Care">Returns & Care</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Question</label>
              <input
                type="text"
                required
                value={newFaqQ}
                onChange={(e) => setNewFaqQ(e.target.value)}
                placeholder="e.g. How does the garment fit across different builds?"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Answer</label>
              <textarea
                rows={4}
                required
                value={newFaqA}
                onChange={(e) => setNewFaqA(e.target.value)}
                placeholder="Provide comprehensive, brand-aligned answer..."
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs leading-relaxed"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setAddFaqModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="sm">
                Publish FAQ
              </Button>
            </div>
          </form>
        </div>
      )}


      {/* Unified Confirm Delete Modal with TYPE 'DELETE' verification */}
      <ConfirmDeleteModal
        isOpen={deleteModalState.isOpen}
        title={deleteModalState.title}
        itemName={deleteModalState.itemName}
        itemType={deleteModalState.itemType}
        warningMessage={deleteModalState.warningMessage}
        expectedWord="DELETE"
        onConfirm={deleteModalState.onConfirm}
        onClose={() => setDeleteModalState((prev) => ({ ...prev, isOpen: false }))}
      />

    </div>
  );
};
