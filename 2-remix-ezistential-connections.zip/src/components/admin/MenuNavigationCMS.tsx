import React, { useState } from 'react';
import {
  Menu,
  Eye,
  EyeOff,
  Check,
  CheckCircle2,
  RotateCcw,
  Plus,
  Trash2,
  ArrowUpDown,
  MoveUp,
  MoveDown,
  Layout,
  Sliders,
  ExternalLink,
  Shield,
  HelpCircle,
  SlidersHorizontal
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { NavigationMenuItem, MenuLocation } from '../../types';
import { Button } from '../ui/Button';

// Available store views that have corresponding pages/modals
const AVAILABLE_VIEWS: { id: string; defaultLabel: string; category: 'primary' | 'secondary' | 'legal' | 'custom'; description: string }[] = [
  { id: 'home', defaultLabel: 'Home', category: 'primary', description: 'Main storefront landing & hero experience' },
  { id: 'shop', defaultLabel: 'Garments', category: 'primary', description: 'Product catalog & heavyweight collection grid' },
  { id: 'collections', defaultLabel: 'Collections', category: 'primary', description: 'Curated editorial garment editions' },
  { id: 'why-we-exist', defaultLabel: 'Why We Exist', category: 'primary', description: 'Founding thesis & philosophical mission' },
  { id: 'our-story', defaultLabel: 'Our Story', category: 'primary', description: 'Chicago studio origins & brand narrative' },
  { id: 'manifesto', defaultLabel: 'The Manifesto', category: 'primary', description: 'Core principles of tactile human presence' },
  { id: 'faq', defaultLabel: 'FAQ', category: 'secondary', description: 'Frequently asked questions & washing directives' },
  { id: 'updates', defaultLabel: 'Journal', category: 'secondary', description: 'Studio essays, reflections & dispatches' },
  { id: 'contact', defaultLabel: 'Customer Care', category: 'secondary', description: 'Studio premises, email & WhatsApp care line' },
  { id: 'track-order', defaultLabel: 'Track Order', category: 'secondary', description: 'Real-time order lookup and USPS tracking' },
  { id: 'connection', defaultLabel: 'Connection Archive', category: 'primary', description: 'Community reflections on public apparel' },
  { id: 'ecosystem', defaultLabel: 'Ecosystem', category: 'primary', description: 'Films, audio dispatches and exhibitions' },
  { id: 'shipping-returns', defaultLabel: 'Shipping & Returns', category: 'legal', description: 'Logistics, delivery times & return covenant' },
  { id: 'privacy', defaultLabel: 'Digital Dignity / Privacy', category: 'legal', description: 'Minimal telemetry and privacy promise' },
  { id: 'terms', defaultLabel: 'Terms & Ethics', category: 'legal', description: 'Terms of service & community usage policies' },
];

export interface MenuNavigationCMSProps {
  showToast?: (msg: string) => void;
  onNavigateToView?: (viewId: string) => void;
}

export const MenuNavigationCMS: React.FC<MenuNavigationCMSProps> = ({ showToast, onNavigateToView }) => {
  const { content, updateContent, resetNavigationMenuItems } = useContent();

  const [items, setItems] = useState<NavigationMenuItem[]>(() => {
    return content.navigationMenuItems || [];
  });
  const [showHeaderMenu, setShowHeaderMenu] = useState<boolean>(content.showHeaderMenu !== false);
  const [showFooterMenu, setShowFooterMenu] = useState<boolean>(content.showFooterMenu !== false);
  const [enableJournal, setEnableJournal] = useState<boolean>(content.enableJournal !== false);
  const [enableReflections, setEnableReflections] = useState<boolean>(content.enableReflections !== false);
  const [enableEcosystem, setEnableEcosystem] = useState<boolean>(content.enableEcosystem !== false);
  const [filterMode, setFilterMode] = useState<'all' | 'header' | 'footer' | 'hidden'>('all');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState<boolean>(false);

  // Sync if content changes from outside
  React.useEffect(() => {
    if (content.navigationMenuItems) {
      setItems(content.navigationMenuItems);
    }
    if (content.showHeaderMenu !== undefined) {
      setShowHeaderMenu(content.showHeaderMenu);
    }
    if (content.showFooterMenu !== undefined) {
      setShowFooterMenu(content.showFooterMenu);
    }
    if (content.enableJournal !== undefined) {
      setEnableJournal(content.enableJournal);
    }
    if (content.enableReflections !== undefined) {
      setEnableReflections(content.enableReflections);
    }
    if (content.enableEcosystem !== undefined) {
      setEnableEcosystem(content.enableEcosystem);
    }
  }, [content.navigationMenuItems, content.showHeaderMenu, content.showFooterMenu, content.enableJournal, content.enableReflections, content.enableEcosystem]);

  const handleToggleHeader = (id: string) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const newShowHeader = !item.showInHeader;
        let newLocation: MenuLocation = 'hidden';
        if (newShowHeader && item.showInFooter) newLocation = 'both';
        else if (newShowHeader) newLocation = 'header';
        else if (item.showInFooter) newLocation = 'footer';
        return {
          ...item,
          showInHeader: newShowHeader,
          location: newLocation,
        };
      })
    );
    setHasUnsavedChanges(true);
  };

  const handleToggleFooter = (id: string) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const newShowFooter = !item.showInFooter;
        let newLocation: MenuLocation = 'hidden';
        if (item.showInHeader && newShowFooter) newLocation = 'both';
        else if (newShowFooter) newLocation = 'footer';
        else if (item.showInHeader) newLocation = 'header';
        return {
          ...item,
          showInFooter: newShowFooter,
          location: newLocation,
        };
      })
    );
    setHasUnsavedChanges(true);
  };

  const handleToggleMobileDrawer = (id: string) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        return {
          ...item,
          showInMobileDrawer: item.showInMobileDrawer === false ? true : false,
        };
      })
    );
    setHasUnsavedChanges(true);
  };

  const handleLocationPreset = (id: string, location: MenuLocation) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        return {
          ...item,
          location,
          showInHeader: location === 'header' || location === 'both',
          showInFooter: location === 'footer' || location === 'both',
          showInMobileDrawer: location !== 'hidden',
        };
      })
    );
    setHasUnsavedChanges(true);
  };

  const handleLabelChange = (id: string, newLabel: string) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        return { ...item, customLabel: newLabel };
      })
    );
    setHasUnsavedChanges(true);
  };

  const handleMoveOrder = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= items.length) return;
    const newItems = [...items];
    const [moved] = newItems.splice(index, 1);
    newItems.splice(targetIndex, 0, moved);

    // Re-index displayOrder
    const reindexed = newItems.map((item, idx) => ({ ...item, displayOrder: idx + 1 }));
    setItems(reindexed);
    setHasUnsavedChanges(true);
  };

  const handleSaveAll = () => {
    updateContent({
      navigationMenuItems: items,
      showHeaderMenu,
      showFooterMenu,
      enableJournal,
      enableReflections,
      enableEcosystem,
    });
    setHasUnsavedChanges(false);
    if (showToast) {
      showToast('Navigation menu & feature systems settings saved and published!');
    }
  };

  const handleResetToDefaults = () => {
    resetNavigationMenuItems();
    setHasUnsavedChanges(false);
    if (showToast) {
      showToast('Restored default header and footer navigation settings.');
    }
  };

  // Filter items for display
  const displayedItems = items.filter((item) => {
    if (filterMode === 'header') return item.showInHeader && item.location !== 'hidden';
    if (filterMode === 'footer') return item.showInFooter && item.location !== 'hidden';
    if (filterMode === 'hidden') return (!item.showInHeader && !item.showInFooter) || item.location === 'hidden';
    return true;
  });

  const headerActiveCount = items.filter((i) => i.showInHeader && i.location !== 'hidden').length;
  const footerActiveCount = items.filter((i) => i.showInFooter && i.location !== 'hidden').length;
  const hiddenCount = items.filter((i) => (!i.showInHeader && !i.showInFooter) || i.location === 'hidden').length;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-neutral-200 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Menu className="w-5 h-5 text-neutral-800" />
            <h2 className="font-serif text-2xl text-neutral-900 font-bold">
              Header & Footer Menu Control
            </h2>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            Choose exactly which pages appear in the top header menu, the footer sections, or mobile drawer.
            Hidden items remain fully published and accessible via their URLs.
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleResetToDefaults}
            className="text-xs font-mono"
            title="Restore default navigation structure"
          >
            <RotateCcw className="w-3.5 h-3.5 mr-1" />
            <span>Reset Defaults</span>
          </Button>

          <Button
            type="button"
            variant="primary"
            size="md"
            onClick={handleSaveAll}
            className="text-xs font-mono"
          >
            <Check className="w-4 h-4 mr-1.5" />
            <span>Publish Navigation Changes</span>
          </Button>
        </div>
      </div>

      {/* Feature Systems & Core Modules Visibility */}
      <div className="bg-neutral-50 border border-neutral-300 p-5 rounded-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-200 pb-3">
          <div>
            <span className="text-xs font-mono uppercase tracking-wider font-bold text-neutral-900 flex items-center gap-1.5">
              <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-800" />
              <span>Feature Systems & Core Modules (Option to Turn On / Off)</span>
            </span>
            <p className="text-xs text-neutral-500 mt-0.5">
              Toggle complete interactive systems on or off. When turned off, the feature is cleanly hidden from all storefront menus, mobile drawers, footer sections, and user account menus, while all content and submissions remain safely preserved.
            </p>
          </div>
          {hasUnsavedChanges && (
            <span className="text-[10px] font-mono text-amber-700 bg-amber-50 border border-amber-300 px-2 py-0.5 self-start sm:self-auto">
              Unpublished changes
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* 1. Journal System */}
          <div className={`p-4 border transition-all ${enableJournal ? 'bg-white border-neutral-300 shadow-xs' : 'bg-neutral-100/70 border-neutral-200 opacity-80'}`}>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono uppercase tracking-wider font-bold text-neutral-900">
                    Journal & Essays
                  </span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${enableJournal ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-neutral-200 text-neutral-600'}`}>
                    {enableJournal ? 'Active' : 'Turned Off'}
                  </span>
                </div>
                <p className="text-xs text-neutral-500 leading-relaxed">
                  Studio dispatches, editorial essays, and reader modal. Centralized under <strong className="text-neutral-700">Journal Page CMS</strong>.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer ml-3 shrink-0">
                <input
                  type="checkbox"
                  checked={enableJournal}
                  onChange={(e) => {
                    setEnableJournal(e.target.checked);
                    setHasUnsavedChanges(true);
                  }}
                  className="sr-only peer"
                />
                <div className="w-10 h-5 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
              </label>
            </div>
            <div className="mt-3 pt-2.5 border-t border-neutral-100 flex items-center justify-between text-[11px] font-mono text-neutral-500">
              <span>View Route: <code className="text-neutral-800">/updates</code></span>
              {onNavigateToView && (
                <button
                  type="button"
                  onClick={() => onNavigateToView('updates')}
                  className="text-black hover:underline cursor-pointer inline-flex items-center gap-0.5"
                >
                  Preview <ExternalLink className="w-2.5 h-2.5" />
                </button>
              )}
            </div>
          </div>

          {/* 2. Reflection System */}
          <div className={`p-4 border transition-all ${enableReflections ? 'bg-white border-neutral-300 shadow-xs' : 'bg-neutral-100/70 border-neutral-200 opacity-80'}`}>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono uppercase tracking-wider font-bold text-neutral-900">
                    Reflection System
                  </span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${enableReflections ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-neutral-200 text-neutral-600'}`}>
                    {enableReflections ? 'Active' : 'Turned Off'}
                  </span>
                </div>
                <p className="text-xs text-neutral-500 leading-relaxed">
                  Connection Archive, PDP reflection prompt, curated quote carousel & testimonials.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer ml-3 shrink-0">
                <input
                  type="checkbox"
                  checked={enableReflections}
                  onChange={(e) => {
                    setEnableReflections(e.target.checked);
                    setHasUnsavedChanges(true);
                  }}
                  className="sr-only peer"
                />
                <div className="w-10 h-5 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
              </label>
            </div>
            <div className="mt-3 pt-2.5 border-t border-neutral-100 flex items-center justify-between text-[11px] font-mono text-neutral-500">
              <span>View Route: <code className="text-neutral-800">/connection</code></span>
              {onNavigateToView && (
                <button
                  type="button"
                  onClick={() => onNavigateToView('connection')}
                  className="text-black hover:underline cursor-pointer inline-flex items-center gap-0.5"
                >
                  Preview <ExternalLink className="w-2.5 h-2.5" />
                </button>
              )}
            </div>
          </div>

          {/* 3. Collaborative Ecosystem */}
          <div className={`p-4 border transition-all ${enableEcosystem ? 'bg-white border-neutral-300 shadow-xs' : 'bg-neutral-100/70 border-neutral-200 opacity-80'}`}>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono uppercase tracking-wider font-bold text-neutral-900">
                    Ecosystem Media
                  </span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${enableEcosystem ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-neutral-200 text-neutral-600'}`}>
                    {enableEcosystem ? 'Active' : 'Turned Off'}
                  </span>
                </div>
                <p className="text-xs text-neutral-500 leading-relaxed">
                  Studio films, ambient soundscapes, exhibitions, and cross-discipline dialogue.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer ml-3 shrink-0">
                <input
                  type="checkbox"
                  checked={enableEcosystem}
                  onChange={(e) => {
                    setEnableEcosystem(e.target.checked);
                    setHasUnsavedChanges(true);
                  }}
                  className="sr-only peer"
                />
                <div className="w-10 h-5 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
              </label>
            </div>
            <div className="mt-3 pt-2.5 border-t border-neutral-100 flex items-center justify-between text-[11px] font-mono text-neutral-500">
              <span>View Route: <code className="text-neutral-800">/ecosystem</code></span>
              {onNavigateToView && (
                <button
                  type="button"
                  onClick={() => onNavigateToView('ecosystem')}
                  className="text-black hover:underline cursor-pointer inline-flex items-center gap-0.5"
                >
                  Preview <ExternalLink className="w-2.5 h-2.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Global Master Toggles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className={`p-4 border transition-all ${showHeaderMenu ? 'bg-white border-neutral-300 shadow-xs' : 'bg-neutral-50 border-neutral-200 opacity-75'}`}>
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono uppercase tracking-wider font-bold text-neutral-900">
                  Header Navigation Bar
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-700">
                  {headerActiveCount} Links Visible
                </span>
              </div>
              <p className="text-xs text-neutral-500">
                Display the centered top navigation menu bar across desktop storefront pages.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer ml-4">
              <input
                type="checkbox"
                checked={showHeaderMenu}
                onChange={(e) => {
                  setShowHeaderMenu(e.target.checked);
                  setHasUnsavedChanges(true);
                }}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
            </label>
          </div>
        </div>

        <div className={`p-4 border transition-all ${showFooterMenu ? 'bg-white border-neutral-300 shadow-xs' : 'bg-neutral-50 border-neutral-200 opacity-75'}`}>
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono uppercase tracking-wider font-bold text-neutral-900">
                  Footer Navigation Columns
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-700">
                  {footerActiveCount} Links Visible
                </span>
              </div>
              <p className="text-xs text-neutral-500">
                Display Explore and Information navigation links in the bottom studio footer.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer ml-4">
              <input
                type="checkbox"
                checked={showFooterMenu}
                onChange={(e) => {
                  setShowFooterMenu(e.target.checked);
                  setHasUnsavedChanges(true);
                }}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Status Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-mono">
          <button
            type="button"
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-sm border transition-colors cursor-pointer ${
              filterMode === 'all'
                ? 'bg-black text-white border-black font-semibold'
                : 'bg-white text-neutral-600 border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            All Items ({items.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('header')}
            className={`px-3 py-1.5 rounded-sm border transition-colors cursor-pointer ${
              filterMode === 'header'
                ? 'bg-black text-white border-black font-semibold'
                : 'bg-white text-neutral-600 border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            Header Menu ({headerActiveCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('footer')}
            className={`px-3 py-1.5 rounded-sm border transition-colors cursor-pointer ${
              filterMode === 'footer'
                ? 'bg-black text-white border-black font-semibold'
                : 'bg-white text-neutral-600 border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            Footer Menu ({footerActiveCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('hidden')}
            className={`px-3 py-1.5 rounded-sm border transition-colors cursor-pointer ${
              filterMode === 'hidden'
                ? 'bg-black text-white border-black font-semibold'
                : 'bg-white text-neutral-600 border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            Hidden from Menus ({hiddenCount})
          </button>
        </div>

        {hasUnsavedChanges && (
          <div className="flex items-center space-x-2 text-xs font-mono text-amber-700 bg-amber-50 px-3 py-1 rounded border border-amber-200 animate-pulse">
            <span>● Unsaved changes</span>
            <button
              onClick={handleSaveAll}
              className="underline font-bold text-black hover:text-neutral-700 ml-1 cursor-pointer"
            >
              Save Now
            </button>
          </div>
        )}
      </div>

      {/* Main Table of Menu Items */}
      <div className="bg-white border border-neutral-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead className="bg-[#f5f4f0] border-b border-neutral-200 text-neutral-600 font-mono text-[11px] uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4 w-12 text-center">Order</th>
                <th className="py-3 px-4">Menu Item & Target Page</th>
                <th className="py-3 px-4">Custom Display Label</th>
                <th className="py-3 px-4 text-center">Show in Header</th>
                <th className="py-3 px-4 text-center">Show in Footer</th>
                <th className="py-3 px-4 text-center">Mobile Drawer</th>
                <th className="py-3 px-4 text-center">Visibility State</th>
                <th className="py-3 px-4 text-right">Preview</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {displayedItems.map((item, index) => {
                const isHidden = (!item.showInHeader && !item.showInFooter) || item.location === 'hidden';
                const viewInfo = AVAILABLE_VIEWS.find((v) => v.id === item.id);

                return (
                  <tr
                    key={item.id}
                    className={`transition-colors ${
                      isHidden ? 'bg-neutral-50/60 text-neutral-500' : 'hover:bg-neutral-50/50'
                    }`}
                  >
                    {/* Order Controls */}
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center space-x-1">
                        <button
                          type="button"
                          disabled={index === 0}
                          onClick={() => handleMoveOrder(index, 'up')}
                          className="p-1 text-neutral-400 hover:text-black disabled:opacity-20 cursor-pointer disabled:cursor-not-allowed"
                          title="Move Up"
                        >
                          <MoveUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={index === displayedItems.length - 1}
                          onClick={() => handleMoveOrder(index, 'down')}
                          className="p-1 text-neutral-400 hover:text-black disabled:opacity-20 cursor-pointer disabled:cursor-not-allowed"
                          title="Move Down"
                        >
                          <MoveDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>

                    {/* Menu Item & Target Page */}
                    <td className="py-3 px-4">
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold text-neutral-900 text-sm">
                            {item.label}
                          </span>
                          <span className="font-mono text-[10px] text-neutral-400 bg-neutral-100 px-1.5 py-0.2 rounded">
                            #{item.id}
                          </span>
                          {((item.id === 'updates' && !enableJournal) || (item.id === 'connection' && !enableReflections) || (item.id === 'ecosystem' && !enableEcosystem)) && (
                            <span className="font-mono text-[9px] text-amber-800 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded">
                              System Deactivated (Hidden Everywhere)
                            </span>
                          )}
                        </div>
                        {viewInfo && (
                          <p className="text-[11px] text-neutral-500 leading-tight">
                            {viewInfo.description}
                          </p>
                        )}
                      </div>
                    </td>

                    {/* Custom Display Label */}
                    <td className="py-3 px-4">
                      <input
                        type="text"
                        value={item.customLabel !== undefined ? item.customLabel : item.label}
                        onChange={(e) => handleLabelChange(item.id, e.target.value)}
                        placeholder={item.label}
                        className="w-full max-w-[200px] bg-neutral-50 hover:bg-white focus:bg-white border border-neutral-300 focus:border-black px-2.5 py-1 text-xs font-sans text-neutral-900 rounded-xs transition-colors"
                      />
                    </td>

                    {/* Show in Header Checkbox */}
                    <td className="py-3 px-4 text-center">
                      <label className="inline-flex items-center justify-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={item.showInHeader && item.location !== 'hidden'}
                          onChange={() => handleToggleHeader(item.id)}
                          className="w-4 h-4 accent-black rounded cursor-pointer"
                        />
                      </label>
                    </td>

                    {/* Show in Footer Checkbox */}
                    <td className="py-3 px-4 text-center">
                      <label className="inline-flex items-center justify-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={item.showInFooter && item.location !== 'hidden'}
                          onChange={() => handleToggleFooter(item.id)}
                          className="w-4 h-4 accent-black rounded cursor-pointer"
                        />
                      </label>
                    </td>

                    {/* Show in Mobile Drawer Checkbox */}
                    <td className="py-3 px-4 text-center">
                      <label className="inline-flex items-center justify-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={item.showInMobileDrawer !== false}
                          onChange={() => handleToggleMobileDrawer(item.id)}
                          className="w-4 h-4 accent-black rounded cursor-pointer"
                        />
                      </label>
                    </td>

                    {/* Location Preset Quick Actions */}
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex rounded-xs border border-neutral-200 bg-neutral-50 p-0.5 text-[10px] font-mono">
                        <button
                          type="button"
                          onClick={() => handleLocationPreset(item.id, 'header')}
                          className={`px-2 py-0.5 rounded-xs transition-colors cursor-pointer ${
                            item.location === 'header'
                              ? 'bg-black text-white font-bold'
                              : 'text-neutral-600 hover:text-black'
                          }`}
                          title="Show exclusively in header"
                        >
                          Header
                        </button>
                        <button
                          type="button"
                          onClick={() => handleLocationPreset(item.id, 'footer')}
                          className={`px-2 py-0.5 rounded-xs transition-colors cursor-pointer ${
                            item.location === 'footer'
                              ? 'bg-black text-white font-bold'
                              : 'text-neutral-600 hover:text-black'
                          }`}
                          title="Show exclusively in footer"
                        >
                          Footer
                        </button>
                        <button
                          type="button"
                          onClick={() => handleLocationPreset(item.id, 'both')}
                          className={`px-2 py-0.5 rounded-xs transition-colors cursor-pointer ${
                            item.location === 'both'
                              ? 'bg-black text-white font-bold'
                              : 'text-neutral-600 hover:text-black'
                          }`}
                          title="Show in both header and footer"
                        >
                          Both
                        </button>
                        <button
                          type="button"
                          onClick={() => handleLocationPreset(item.id, 'hidden')}
                          className={`px-2 py-0.5 rounded-xs transition-colors cursor-pointer ${
                            isHidden
                              ? 'bg-neutral-800 text-white font-bold'
                              : 'text-neutral-500 hover:text-black'
                          }`}
                          title="Hide from navigation (content remains active)"
                        >
                          Hide
                        </button>
                      </div>
                    </td>

                    {/* Direct Page Preview Link */}
                    <td className="py-3 px-4 text-right">
                      {onNavigateToView ? (
                        <button
                          type="button"
                          onClick={() => onNavigateToView(item.id)}
                          className="inline-flex items-center gap-1 text-xs font-mono text-neutral-600 hover:text-black hover:underline cursor-pointer"
                        >
                          <span>Visit</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      ) : (
                        <a
                          href={`#${item.id}`}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-xs font-mono text-neutral-600 hover:text-black hover:underline cursor-pointer"
                        >
                          <span>Visit</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Helpful Explanatory Box */}
      <div className="bg-neutral-50 border border-neutral-200 p-5 rounded-xs space-y-3">
        <div className="flex items-center space-x-2 text-xs font-mono uppercase text-neutral-700 font-bold">
          <HelpCircle className="w-4 h-4 text-neutral-500" />
          <span>How Header & Footer Visibility Works</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-neutral-600 font-sans">
          <div className="space-y-1">
            <span className="font-semibold text-neutral-900 block font-mono">1. Header vs Footer Control</span>
            <p>
              Toggling an item's Header checkbox immediately places it in the top navigation bar. Toggling Footer places it in the footer link columns.
            </p>
          </div>
          <div className="space-y-1">
            <span className="font-semibold text-neutral-900 block font-mono">2. Content Remains Active</span>
            <p>
              When a menu item is marked <strong>Hide</strong>, its button is removed from menus, but the actual page and content remain live at its direct URL (e.g. <code>#manifesto</code>, <code>#why-we-exist</code>).
            </p>
          </div>
          <div className="space-y-1">
            <span className="font-semibold text-neutral-900 block font-mono">3. Custom Menu Labels</span>
            <p>
              You can customize the display text of any menu item without altering its underlying URL or route (e.g. rename "Garments" to "Shop Collection").
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
