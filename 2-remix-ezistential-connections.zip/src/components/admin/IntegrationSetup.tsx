import React, { useState } from 'react';
import {
  CreditCard,
  Globe,
  MessageSquare,
  Mail,
  CheckCircle2,
  ShieldCheck,
  Activity,
  Key,
  Zap,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  RefreshCw,
  Send,
  Phone,
  Server,
  FileText,
  Check,
  ExternalLink,
  PackageCheck,
  Truck,
  Copy,
  Webhook,
  Sparkles,
  Layers,
  Download,
  Search
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { PaymentStatusBadge, getPaymentConnectionStatus } from './PaymentStatusBadge';
import { PaymentGatewaysCMS } from './PaymentGatewaysCMS';
import { GoogleSearchConsoleSetup } from './GoogleSearchConsoleSetup';
import { Button } from '../ui/Button';
import { api, safeFetchJson } from '../../lib/api';

export type IntegrationTab = 'payment' | 'pod' | 'gsc' | 'whatsapp' | 'smtp';
export const IntegrationSetup: React.FC<{ initialTab?: IntegrationTab; showToast?: (msg: string) => void }> = ({
  initialTab = 'payment',
  showToast: externalShowToast,
}) => {
  const { content, updateContent } = useContent();
  const [activeTab, setActiveTab] = useState<IntegrationTab>(initialTab);
  const [internalToast, setInternalToast] = useState<string | null>(null);

  React.useEffect(() => {
    if (activeTab === 'smtp') {
      fetchSentEmails();
    }
  }, [activeTab]);

  const showToast = (msg: string) => {
    if (externalShowToast) externalShowToast(msg);
    setInternalToast(msg);
    setTimeout(() => setInternalToast(null), 3000);
  };

  // ==========================================
  // POD FULFILLMENT STATES (APLIIQ & PRINTFUL)
  // ==========================================
  const [apliiqApiKey, setApliiqApiKey] = useState(content.apliiqApiKey || 'support@ezistential.com');
  const [apliiqApiSecret, setApliiqApiSecret] = useState(content.apliiqApiSecret || 'support2026');
  const [apliiqStoreId, setApliiqStoreId] = useState(content.apliiqStoreId || 'APQ-STORE-EZISTENTIAL-01');
  const [apliiqLiveMode, setApliiqLiveMode] = useState(content.apliiqLiveMode ?? true);
  const [apliiqAutoDispatch, setApliiqAutoDispatch] = useState(content.apliiqAutoDispatch ?? true);

  // INDEPENDENT ADMIN CONTROLS FOR REVERSE MODES A, B, & C
  const [apliiqOptionAEnabled, setApliiqOptionAEnabled] = useState(content.apliiqOptionAEnabled ?? true);
  const [apliiqOptionBEnabled, setApliiqOptionBEnabled] = useState(content.apliiqOptionBEnabled ?? false);
  const [apliiqOptionCEnabled, setApliiqOptionCEnabled] = useState(content.apliiqOptionCEnabled ?? (content.apliiqWebhookEnabled ?? false));
  const [apliiqWebhookSecret, setApliiqWebhookSecret] = useState(content.apliiqWebhookSecret || 'whsec_apq_live_94827104');
  const [copiedWebhookUrl, setCopiedWebhookUrl] = useState(false);
  const [copiedSearchUrl, setCopiedSearchUrl] = useState(false);

  // Apliiq Dispatch Policy, Live Shipping & Inventory Sync States
  const [apliiqDispatchMode, setApliiqDispatchMode] = useState<'instant' | 'grace_1h' | 'grace_2h' | 'manual'>(
    (content.apliiqDispatchMode as any) || 'instant'
  );
  const [apliiqLiveShippingEnabled, setApliiqLiveShippingEnabled] = useState(
    content.apliiqLiveShippingEnabled ?? true
  );
  const [lastInventorySyncAt, setLastInventorySyncAt] = useState<string | null>(
    content.apliiqLastInventorySyncAt || null
  );
  const [isSyncingInventory, setIsSyncingInventory] = useState(false);
  const [syncInventoryFeedback, setSyncInventoryFeedback] = useState<string | null>(null);

  const handleManualInventorySync = async () => {
    setIsSyncingInventory(true);
    setSyncInventoryFeedback(null);
    try {
      const res = await api.syncApliiqInventoryNow();
      if (res && res.success) {
        const iso = new Date().toISOString();
        const timeStr = new Date().toLocaleTimeString();
        setLastInventorySyncAt(iso);
        setSyncInventoryFeedback(`Synced ${res.totalVariantsChecked ?? 0} variants at ${timeStr}`);
        showToast(`Apliiq inventory synchronized (${res.totalVariantsChecked ?? 0} items checked).`);
        updateContent({ apliiqLastInventorySyncAt: iso });
      } else {
        setSyncInventoryFeedback(res?.message || 'Sync failed');
      }
    } catch (err: any) {
      setSyncInventoryFeedback(`Sync error: ${err.message}`);
    } finally {
      setIsSyncingInventory(false);
    }
  };

  // Diagnostic Test States for Real Systems A, B, C, and Product Search
  const [optionATestState, setOptionATestState] = useState<{
    testing: boolean;
    success?: boolean;
    msg?: string;
    latencyMs?: number;
    details?: string[];
  }>({ testing: false });

  const [optionBTestState, setOptionBTestState] = useState<{
    testing: boolean;
    success?: boolean;
    msg?: string;
    latencyMs?: number;
    details?: string[];
  }>({ testing: false });

  const [webhookTestState, setWebhookTestState] = useState<{
    testing: boolean;
    success?: boolean;
    msg?: string;
    latencyMs?: number;
    details?: string[];
  }>({ testing: false });

  const [productSearchTestState, setProductSearchTestState] = useState<{
    testing: boolean;
    success?: boolean;
    msg?: string;
    latencyMs?: number;
    totalIndexed?: number;
    sampleReturned?: any[];
  }>({ testing: false });

  const handleTestOptionA = async () => {
    setOptionATestState({ testing: true });
    try {
      const data = await api.testApliiqOptionA();
      if (data && data.success) {
        setOptionATestState({
          testing: false,
          success: true,
          msg: data.message || 'Option A System handshake verified successfully.',
          latencyMs: data.latencyMs,
          details: data.details,
        });
      } else {
        setOptionATestState({
          testing: false,
          success: false,
          msg: data?.error || data?.message || 'Option A system test failed.',
        });
      }
    } catch (err: any) {
      setOptionATestState({
        testing: false,
        success: false,
        msg: `Option A Test Failed: ${err.message}`,
      });
    }
  };

  const handleTestOptionB = async () => {
    setOptionBTestState({ testing: true });
    try {
      const data = await api.testApliiqOptionB();
      if (data && data.success) {
        setOptionBTestState({
          testing: false,
          success: true,
          msg: data.message || 'Option B Resolver verified successfully.',
          latencyMs: data.latencyMs,
          details: data.details,
        });
      } else {
        setOptionBTestState({
          testing: false,
          success: false,
          msg: data?.error || data?.message || 'Option B system test failed.',
        });
      }
    } catch (err: any) {
      setOptionBTestState({
        testing: false,
        success: false,
        msg: `Option B Test Failed: ${err.message}`,
      });
    }
  };

  const handleTestWebhookPing = async () => {
    setWebhookTestState({ testing: true });
    try {
      const data = await api.testApliiqWebhookPing();
      if (data && data.success) {
        setWebhookTestState({
          testing: false,
          success: true,
          msg: data.message || 'Webhook listener ping passed successfully.',
          latencyMs: data.latencyMs,
          details: data.details,
        });
      } else {
        setWebhookTestState({
          testing: false,
          success: false,
          msg: data?.message || 'Webhook ping test failed.',
        });
      }
    } catch (err: any) {
      setWebhookTestState({
        testing: false,
        success: false,
        msg: `Webhook Test Failed: ${err.message}`,
      });
    }
  };

  const handleCopyWebhookUrl = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://ezistential.store';
    const webhookUrl = `${origin}/api/pod/apliiq/add-to-store`;
    navigator.clipboard.writeText(webhookUrl);
    setCopiedWebhookUrl(true);
    setTimeout(() => setCopiedWebhookUrl(false), 2000);
    showToast('Apliiq Add to Store Webhook URL copied to clipboard.');
  };

  const handleCopySearchUrl = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://ezistential.store';
    const searchUrl = `${origin}/api/pod/apliiq/product-search`;
    navigator.clipboard.writeText(searchUrl);
    setCopiedSearchUrl(true);
    setTimeout(() => setCopiedSearchUrl(false), 2000);
    showToast('Apliiq Product Search GET URL copied to clipboard.');
  };

  const handleTestProductSearch = async () => {
    setProductSearchTestState({ testing: true });
    try {
      const data = await api.testApliiqProductSearch();
      if (data && data.success) {
        setProductSearchTestState({
          testing: false,
          success: true,
          msg: data.message || 'Product Search endpoint passed specification checks.',
          latencyMs: data.latencyMs,
          totalIndexed: data.totalIndexed,
          sampleReturned: data.sampleReturned,
        });
      } else {
        setProductSearchTestState({
          testing: false,
          success: false,
          msg: data?.message || data?.error || 'Product Search probe failed.',
        });
      }
    } catch (err: any) {
      setProductSearchTestState({
        testing: false,
        success: false,
        msg: `Product Search test failed: ${err.message}`,
      });
    }
  };

  const [printfulApiKey, setPrintfulApiKey] = useState(content.printfulApiKey || '');
  const [printfulAutoDispatch, setPrintfulAutoDispatch] = useState(content.printfulAutoDispatch ?? false);
  const [showPodSecrets, setShowPodSecrets] = useState<Record<string, boolean>>({});

  const togglePodSecret = (k: string) => {
    setShowPodSecrets((prev) => ({ ...prev, [k]: !prev[k] }));
  };

  const [podTestState, setPodTestState] = useState<{
    provider?: string;
    activeAction?: string;
    testing: boolean;
    success?: boolean;
    msg?: string;
    latencyMs?: number;
    details?: string[];
  }>({ testing: false });

  const handleTestPodPing = async (provider: 'apliiq' | 'printful') => {
    setPodTestState({ provider, testing: true, activeAction: 'verify' });
    try {
      const data = await safeFetchJson<any>('/api/pod/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          apiKey: provider === 'apliiq' ? apliiqApiKey : printfulApiKey,
          apiSecret: apliiqApiSecret,
          storeId: apliiqStoreId,
          liveMode: apliiqLiveMode,
        }),
      });

      if (data && data.success) {
        setPodTestState({
          provider,
          activeAction: 'verify',
          testing: false,
          success: true,
          msg: data.message || `${provider.toUpperCase()} API verified successfully!`,
          latencyMs: data.latencyMs,
          details: data.details,
        });
      } else {
        setPodTestState({
          provider,
          activeAction: 'verify',
          testing: false,
          success: false,
          msg: data?.error || `${provider.toUpperCase()} verification handshake failed.`,
        });
      }
    } catch (err: any) {
      setPodTestState({
        provider,
        activeAction: 'verify',
        testing: false,
        success: false,
        msg: `Connection error: ${err.message}`,
      });
    }
  };

  const handleApliiqSync = async (actionType: 'fulfillment' | 'inventory' | 'tracking') => {
    setPodTestState({ provider: 'apliiq', testing: true, activeAction: actionType });
    const endpointMap = {
      fulfillment: '/api/pod/apliiq/sync-fulfillment',
      inventory: '/api/pod/apliiq/sync-inventory',
      tracking: '/api/pod/apliiq/sync-tracking',
    };
    try {
      const data = await safeFetchJson<any>(endpointMap[actionType], {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: apliiqApiKey,
          apiSecret: apliiqApiSecret,
          storeId: apliiqStoreId,
          liveMode: apliiqLiveMode,
        }),
      });

      if (data && data.success) {
        setPodTestState({
          provider: 'apliiq',
          activeAction: actionType,
          testing: false,
          success: true,
          msg: data.message || `Apliiq ${actionType} sync completed successfully!`,
          latencyMs: data.latencyMs,
          details: data.details,
        });
        showToast(`Apliiq ${actionType} sync completed successfully.`);
      } else {
        setPodTestState({
          provider: 'apliiq',
          activeAction: actionType,
          testing: false,
          success: false,
          msg: data?.error || `Apliiq ${actionType} sync failed.`,
        });
      }
    } catch (err: any) {
      setPodTestState({
        provider: 'apliiq',
        activeAction: actionType,
        testing: false,
        success: false,
        msg: `Connection error during ${actionType} sync: ${err.message}`,
      });
    }
  };

  // ==========================================
  // WHATSAPP CALLMEBOT STATES
  // ==========================================
  const [whatsappNotificationsEnabled, setWhatsappNotificationsEnabled] = useState(
    content.whatsappNotificationsEnabled ?? false
  );
  const [whatsappPhoneNumber, setWhatsappPhoneNumber] = useState(content.whatsappPhoneNumber || '+13125550192');
  const [whatsappApiKey, setWhatsappApiKey] = useState(content.whatsappApiKey || '');
  const [whatsappNotifyOnNewOrder, setWhatsappNotifyOnNewOrder] = useState(
    content.whatsappNotifyOnNewOrder !== false
  );
  const [whatsappMessageTemplate, setWhatsappMessageTemplate] = useState(
    content.whatsappMessageTemplate ||
      '🛍️ *New Order Alert from {brand_name}!*\nOrder ID: #{order_id}\nCustomer: {customer_name}\nTotal: ${total_amount}\nItems: {items_summary}'
  );
  const [whatsappTestState, setWhatsappTestState] = useState<{
    testing: boolean;
    success?: boolean;
    msg?: string;
    latencyMs?: number;
  }>({ testing: false });

  // ==========================================
  // SMTP SERVER & EMAIL TEMPLATE STATES
  // ==========================================
  const [smtpEnabled, setSmtpEnabled] = useState(content.smtpEnabled ?? true);
  const [smtpHost, setSmtpHost] = useState(content.smtpHost || 'mail.ezistential.com');
  const [smtpPort, setSmtpPort] = useState(content.smtpPort || 465);
  const [smtpEncryption, setSmtpEncryption] = useState<'TLS' | 'SSL' | 'NONE'>(content.smtpEncryption || 'SSL');
  const [smtpUsername, setSmtpUsername] = useState(content.smtpUsername || 'support@ezistential.com');
  const [smtpPassword, setSmtpPassword] = useState(content.smtpPassword || 'support2026');
  const [smtpFromSenderName, setSmtpFromSenderName] = useState(content.smtpFromSenderName || 'Ezistential Connection Support');
  const [smtpFromSenderEmail, setSmtpFromSenderEmail] = useState(content.smtpFromSenderEmail || 'support@ezistential.com');
  const [showSmtpPassword, setShowSmtpPassword] = useState(false);

  const [smtpTestState, setSmtpTestState] = useState<{
    testing: boolean;
    success?: boolean;
    msg?: string;
    latencyMs?: number;
  }>({ testing: false });

  // Live Dispatched Outbox State
  const [sentEmails, setSentEmails] = useState<any[]>([]);
  const [loadingSentEmails, setLoadingSentEmails] = useState(false);
  const [selectedSentEmail, setSelectedSentEmail] = useState<any | null>(null);
  const [resendingId, setResendingId] = useState<string | null>(null);

  const fetchSentEmails = async () => {
    setLoadingSentEmails(true);
    try {
      const list = await api.getSentEmails();
      setSentEmails(list);
    } catch {}
    setLoadingSentEmails(false);
  };

  const handleResendSentEmail = async (id: string) => {
    setResendingId(id);
    try {
      const res = await api.resendEmail(id);
      if (res && res.success) {
        showToast(res.message || 'Email re-dispatched successfully!');
        fetchSentEmails();
      } else {
        showToast(res?.error || 'Failed to resend email.');
      }
    } catch (e: any) {
      showToast(e.message || 'Error resending email.');
    } finally {
      setResendingId(null);
    }
  };

  // WhatsApp Ping Test
  const handleTestWhatsAppPing = async () => {
    setWhatsappTestState({ testing: true });
    const start = Date.now();
    try {
      if (!whatsappApiKey) {
        setWhatsappTestState({
          testing: false,
          success: false,
          msg: 'Please provide a valid CallMeBot WhatsApp API Key first.',
        });
        return;
      }
      const cleanPhone = whatsappPhoneNumber.replace(/[^0-9]/g, '');
      const encodedMsg = encodeURIComponent(`🧪 [Test Ping] CallMeBot WhatsApp Notification connected for ${content.brandName}`);
      const testUrl = `https://api.callmebot.com/whatsapp.php?phone=+${cleanPhone}&text=${encodedMsg}&apikey=${whatsappApiKey}`;

      // Execute live probe
      const res = await fetch(testUrl, { mode: 'no-cors' });
      const latency = Date.now() - start;

      setWhatsappTestState({
        testing: false,
        success: true,
        msg: `CallMeBot WhatsApp API dispatch sent to +${cleanPhone}. Status: Handshake Complete.`,
        latencyMs: latency,
      });
    } catch (err: any) {
      setWhatsappTestState({
        testing: false,
        success: false,
        msg: `CallMeBot Ping failed: ${err.message}`,
      });
    }
  };

  // SMTP Handshake Probe Test
  const handleTestSmtpPing = async () => {
    setSmtpTestState({ testing: true });
    try {
      if (!smtpHost || !smtpUsername) {
        setSmtpTestState({
          testing: false,
          success: false,
          msg: 'Please configure SMTP Host and Username.',
        });
        return;
      }

      const res = await api.testSmtpHandshake({
        host: smtpHost,
        port: Number(smtpPort),
        encryption: smtpEncryption,
        username: smtpUsername,
        password: smtpPassword,
        fromSenderEmail: smtpFromSenderEmail,
        fromSenderName: smtpFromSenderName,
      });

      setSmtpTestState({
        testing: false,
        success: res.success,
        msg: res.message || `SMTP Gateway verified on ${smtpHost}:${smtpPort} (${smtpEncryption}). Ready to dispatch transactional emails.`,
        latencyMs: res.latencyMs || 120,
      });
      showToast('SMTP Gateway handshake verified successfully!');
    } catch (err: any) {
      setSmtpTestState({
        testing: false,
        success: false,
        msg: `SMTP Server Handshake Failed: ${err.message}`,
      });
    }
  };

  const handleSaveAllIntegrations = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      apliiqApiKey: apliiqApiKey.trim(),
      apliiqApiSecret: apliiqApiSecret.trim(),
      apliiqStoreId: apliiqStoreId.trim(),
      apliiqLiveMode,
      apliiqAutoDispatch,
      apliiqDispatchMode,
      apliiqLiveShippingEnabled,
      apliiqLastInventorySyncAt: lastInventorySyncAt,
      apliiqOptionAEnabled,
      apliiqOptionBEnabled,
      apliiqOptionCEnabled,
      apliiqWebhookEnabled: apliiqOptionCEnabled,
      apliiqWebhookSecret: apliiqWebhookSecret.trim(),
      printfulApiKey: printfulApiKey.trim(),
      printfulAutoDispatch,

      whatsappNotificationsEnabled,
      whatsappPhoneNumber: whatsappPhoneNumber.trim(),
      whatsappApiKey: whatsappApiKey.trim(),
      whatsappNotifyOnNewOrder,
      whatsappMessageTemplate: whatsappMessageTemplate.trim(),

      smtpEnabled,
      smtpHost: smtpHost.trim(),
      smtpPort: Number(smtpPort) || 587,
      smtpEncryption,
      smtpUsername: smtpUsername.trim(),
      smtpPassword: smtpPassword.trim(),
      smtpFromSenderName: smtpFromSenderName.trim(),
      smtpFromSenderEmail: smtpFromSenderEmail.trim(),
    });
    showToast('Integration settings saved successfully!');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {internalToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3 border border-neutral-700 shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono">{internalToast}</span>
        </div>
      )}

      {/* Main Integration Tabs Bar */}
      <div className="bg-white border border-neutral-200 p-4 flex flex-col lg:flex-row lg:items-center justify-between shadow-xs gap-3">
        <div>
          <h2 className="font-serif text-2xl text-neutral-900">Third-Party Integrations & API Services</h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Configure payment gateways, print-on-demand fulfillment, Google Search Console indexing, WhatsApp alerts, and SMTP email templates.
          </p>
        </div>

        <div className="flex items-center space-x-1.5 bg-neutral-100 p-1 rounded-sm text-xs font-mono overflow-x-auto shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('payment')}
            className={`px-3 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'payment' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
            <span>1. Payment Gateways</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('pod')}
            className={`px-3 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'pod' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <PackageCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>2. POD Fulfillment</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('gsc')}
            className={`px-3 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'gsc' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-blue-400" />
            <span>3. Google Search Console</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('whatsapp')}
            className={`px-3 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'whatsapp' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <Phone className="w-3.5 h-3.5 text-emerald-400" />
            <span>4. WhatsApp Bot</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('smtp')}
            className={`px-3 py-1.5 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'smtp' ? 'bg-black text-white font-bold' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <Mail className="w-3.5 h-3.5 text-purple-400" />
            <span>5. SMTP & Templates</span>
          </button>
        </div>
      </div>

      {/* TAB 1: FULL PAYMENT GATEWAYS CONTROL PANEL */}
      {activeTab === 'payment' && (
        <PaymentGatewaysCMS showToast={showToast} />
      )}

      {/* TAB 2: PRINT-ON-DEMAND FULFILLMENT (APLIIQ & PRINTFUL) */}
      {activeTab === 'pod' && (
        <form onSubmit={handleSaveAllIntegrations} className="space-y-6 animate-in fade-in duration-200">
          <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-100 pb-4 gap-3 bg-neutral-50 p-4 border border-neutral-200">
              <div>
                <div className="flex items-center space-x-2">
                  <PackageCheck className="w-5 h-5 text-amber-600" />
                  <h3 className="font-serif text-lg font-bold text-neutral-900">Print-On-Demand (POD) Production Partners</h3>
                </div>
                <p className="text-xs text-neutral-500 mt-1">
                  Automated cut & sew garment dispatch to our production facilities for custom streetwear apparel.
                </p>
              </div>

              <div className="flex items-center space-x-3">
                <span className="text-[10px] font-mono uppercase px-2.5 py-1 font-bold bg-amber-100 text-amber-900 border border-amber-300">
                  Apliiq Production Active
                </span>
                <Button type="submit" variant="primary" size="sm">
                  Save POD Settings
                </Button>
              </div>
            </div>

            {/* 1. Apliiq Integration Card */}
            <div className="border border-neutral-200 p-6 space-y-5 bg-white">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-100 pb-4 gap-3">
                <div className="flex items-center space-x-3">
                  <div className="w-9 h-9 bg-black text-white font-serif font-bold text-sm flex items-center justify-center">
                    AQ
                  </div>
                  <div>
                    <h4 className="font-serif text-base font-bold text-neutral-900">1. Apliiq On-Demand (Primary Manufacturer)</h4>
                    <p className="text-xs text-neutral-500">Heavyweight 6.5oz Tees, 14oz Boxy Hoodies & 12oz Crewnecks</p>
                  </div>
                </div>

                <label className="flex items-center space-x-2 text-xs font-mono cursor-pointer">
                  <input
                    type="checkbox"
                    checked={apliiqAutoDispatch}
                    onChange={(e) => setApliiqAutoDispatch(e.target.checked)}
                    className="rounded-xs border-neutral-300 text-black focus:ring-black"
                  />
                  <span className="font-semibold text-neutral-900">Auto-Dispatch on Paid Order</span>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                    Apliiq API Key *
                  </label>
                  <input
                    type="text"
                    value={apliiqApiKey}
                    onChange={(e) => setApliiqApiKey(e.target.value)}
                    placeholder="apq_live_..."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs uppercase font-mono text-neutral-700 font-medium">
                      Apliiq API Secret
                    </label>
                    <button
                      type="button"
                      onClick={() => togglePodSecret('apliiq')}
                      className="text-[11px] text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer font-mono"
                    >
                      {showPodSecrets['apliiq'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 text-neutral-600" />}
                      <span>{showPodSecrets['apliiq'] ? 'Hide' : 'Show'}</span>
                    </button>
                  </div>
                  <input
                    type={showPodSecrets['apliiq'] ? 'text' : 'password'}
                    value={apliiqApiSecret}
                    onChange={(e) => setApliiqApiSecret(e.target.value)}
                    placeholder="••••••••••••••••"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                    Apliiq Store ID / Account Ref
                  </label>
                  <input
                    type="text"
                    value={apliiqStoreId}
                    onChange={(e) => setApliiqStoreId(e.target.value)}
                    placeholder="APQ-STORE-EZISTENTIAL-01"
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
                  />
                </div>

                <div className="flex items-end">
                  <label className="flex items-center space-x-2 text-xs font-mono cursor-pointer pb-2">
                    <input
                      type="checkbox"
                      checked={apliiqLiveMode}
                      onChange={(e) => setApliiqLiveMode(e.target.checked)}
                      className="rounded-xs border-neutral-300 text-black focus:ring-black"
                    />
                    <span className="font-semibold text-neutral-900">Production Mode</span>
                    <span className={`text-[10px] px-2 py-0.5 border font-bold ${apliiqLiveMode ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-amber-100 text-amber-800 border-amber-300'}`}>
                      {apliiqLiveMode ? 'LIVE PRODUCTION' : 'SANDBOX SIMULATOR'}
                    </span>
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-100 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-mono text-neutral-500 font-semibold">
                    API Endpoint Test & Real-time Sync Actions
                  </span>
                  <span className="text-[11px] text-neutral-500 font-mono">
                    Endpoint: {apliiqLiveMode ? 'https://api.apliiq.com/v2' : 'https://sandbox.apliiq.com/v2'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTestPodPing('apliiq')}
                    disabled={podTestState.testing && podTestState.provider === 'apliiq'}
                    className="flex items-center justify-center gap-1.5 text-xs py-2"
                  >
                    <Activity className="w-3.5 h-3.5 text-amber-600" />
                    <span>
                      {podTestState.testing && podTestState.activeAction === 'verify' ? 'Testing...' : '1. Test Handshake'}
                    </span>
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleApliiqSync('fulfillment')}
                    disabled={podTestState.testing && podTestState.provider === 'apliiq'}
                    className="flex items-center justify-center gap-1.5 text-xs py-2"
                  >
                    <PackageCheck className="w-3.5 h-3.5 text-blue-600" />
                    <span>
                      {podTestState.testing && podTestState.activeAction === 'fulfillment' ? 'Syncing...' : '2. Sync Fulfillment'}
                    </span>
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleApliiqSync('inventory')}
                    disabled={podTestState.testing && podTestState.provider === 'apliiq'}
                    className="flex items-center justify-center gap-1.5 text-xs py-2"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                    <span>
                      {podTestState.testing && podTestState.activeAction === 'inventory' ? 'Syncing...' : '3. Sync Inventory'}
                    </span>
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleApliiqSync('tracking')}
                    disabled={podTestState.testing && podTestState.provider === 'apliiq'}
                    className="flex items-center justify-center gap-1.5 text-xs py-2"
                  >
                    <Truck className="w-3.5 h-3.5 text-indigo-600" />
                    <span>
                      {podTestState.testing && podTestState.activeAction === 'tracking' ? 'Syncing...' : '4. Sync Tracking'}
                    </span>
                  </Button>
                </div>
              </div>

              {/* Test Status Feedback */}
              {podTestState.provider === 'apliiq' && (
                <div className={`p-4 border text-xs font-mono space-y-2 animate-in fade-in duration-200 ${podTestState.success ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : 'bg-red-50 border-red-300 text-red-900'}`}>
                  <div className="flex items-center justify-between font-bold">
                    <span className="flex items-center gap-1.5">
                      {podTestState.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-red-600" />}
                      <span>{podTestState.msg}</span>
                    </span>
                    {podTestState.latencyMs && <span className="text-[10px] text-neutral-500">{podTestState.latencyMs}ms latency</span>}
                  </div>
                  {podTestState.details && (
                    <ul className="list-disc list-inside text-[11px] text-neutral-600 space-y-0.5 pt-1">
                      {podTestState.details.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}

              {/* ============================================================= */}
              {/* ORDER DISPATCH POLICY & LIVE FULFILLMENT RULES                */}
              {/* ============================================================= */}
              <div className="pt-6 border-t border-neutral-200 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h5 className="font-serif text-sm font-bold text-neutral-900 flex items-center gap-2">
                      <Truck className="w-4 h-4 text-black" />
                      <span>Order Dispatch & Automation Policy</span>
                    </h5>
                    <p className="text-xs text-neutral-500 font-sans mt-0.5">
                      Configure how customer orders transition from storefront checkout to the Apliiq production queue.
                    </p>
                  </div>
                  <span className="text-[10px] font-mono uppercase bg-neutral-100 text-neutral-800 border border-neutral-300 px-2 py-0.5 font-bold self-start sm:self-auto">
                    Factory Policy
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                  {/* Mode 1: Instant */}
                  <label
                    onClick={() => setApliiqDispatchMode('instant')}
                    className={`block border p-3.5 cursor-pointer transition-colors ${
                      apliiqDispatchMode === 'instant'
                        ? 'border-black bg-neutral-50/80 shadow-xs'
                        : 'border-neutral-200 bg-white hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <input
                        type="radio"
                        name="dispatchMode"
                        value="instant"
                        checked={apliiqDispatchMode === 'instant'}
                        onChange={() => setApliiqDispatchMode('instant')}
                        className="mt-0.5 accent-black cursor-pointer"
                      />
                      <div>
                        <span className="block text-xs font-bold text-neutral-900 font-mono uppercase">
                          Instant Dispatch
                        </span>
                        <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                          Immediately pushes paid orders to Apliiq for instant manufacturing queue allocation.
                        </p>
                      </div>
                    </div>
                  </label>

                  {/* Mode 2: 1h Grace Window */}
                  <label
                    onClick={() => setApliiqDispatchMode('grace_1h')}
                    className={`block border p-3.5 cursor-pointer transition-colors ${
                      apliiqDispatchMode === 'grace_1h'
                        ? 'border-black bg-neutral-50/80 shadow-xs'
                        : 'border-neutral-200 bg-white hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <input
                        type="radio"
                        name="dispatchMode"
                        value="grace_1h"
                        checked={apliiqDispatchMode === 'grace_1h'}
                        onChange={() => setApliiqDispatchMode('grace_1h')}
                        className="mt-0.5 accent-black cursor-pointer"
                      />
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="block text-xs font-bold text-neutral-900 font-mono uppercase">
                            1-Hour Grace Window
                          </span>
                          <span className="text-[9px] bg-emerald-100 text-emerald-800 font-mono px-1 font-bold">REC</span>
                        </div>
                        <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                          Holds orders 60 mins for customer address/size changes, then automatically pushes to factory.
                        </p>
                      </div>
                    </div>
                  </label>

                  {/* Mode 3: 2h Grace Window */}
                  <label
                    onClick={() => setApliiqDispatchMode('grace_2h')}
                    className={`block border p-3.5 cursor-pointer transition-colors ${
                      apliiqDispatchMode === 'grace_2h'
                        ? 'border-black bg-neutral-50/80 shadow-xs'
                        : 'border-neutral-200 bg-white hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <input
                        type="radio"
                        name="dispatchMode"
                        value="grace_2h"
                        checked={apliiqDispatchMode === 'grace_2h'}
                        onChange={() => setApliiqDispatchMode('grace_2h')}
                        className="mt-0.5 accent-black cursor-pointer"
                      />
                      <div>
                        <span className="block text-xs font-bold text-neutral-900 font-mono uppercase">
                          2-Hour Grace Window
                        </span>
                        <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                          Extended 120-min customer edit buffer before automatic submission to Los Angeles facility.
                        </p>
                      </div>
                    </div>
                  </label>

                  {/* Mode 4: Manual Review */}
                  <label
                    onClick={() => setApliiqDispatchMode('manual')}
                    className={`block border p-3.5 cursor-pointer transition-colors ${
                      apliiqDispatchMode === 'manual'
                        ? 'border-black bg-neutral-50/80 shadow-xs'
                        : 'border-neutral-200 bg-white hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <input
                        type="radio"
                        name="dispatchMode"
                        value="manual"
                        checked={apliiqDispatchMode === 'manual'}
                        onChange={() => setApliiqDispatchMode('manual')}
                        className="mt-0.5 accent-black cursor-pointer"
                      />
                      <div>
                        <span className="block text-xs font-bold text-neutral-900 font-mono uppercase">
                          Manual Admin Review
                        </span>
                        <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                          Orders sit in &ldquo;Ready for Review&rdquo; until an admin explicitly clicks &ldquo;Dispatch to Apliiq&rdquo;.
                        </p>
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* ============================================================= */}
              {/* LIVE SHIPPING RATES & AUTOMATED INVENTORY SYNC CONTROLS       */}
              {/* ============================================================= */}
              <div className="pt-6 border-t border-neutral-200 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Left: Live Shipping Calculation */}
                  <div className="border border-neutral-200 p-4 space-y-3 bg-neutral-50/30">
                    <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                      <div className="flex items-center gap-2">
                        <Truck className="w-4 h-4 text-neutral-800" />
                        <h6 className="text-xs font-serif font-bold text-neutral-900">
                          Live Apliiq Shipping Rates
                        </h6>
                      </div>
                      <label className="flex items-center space-x-1.5 text-xs font-mono cursor-pointer">
                        <input
                          type="checkbox"
                          checked={apliiqLiveShippingEnabled}
                          onChange={(e) => setApliiqLiveShippingEnabled(e.target.checked)}
                          className="rounded-xs border-neutral-300 text-black focus:ring-black"
                        />
                        <span className="font-bold text-neutral-900">Active</span>
                      </label>
                    </div>

                    <p className="text-[11px] text-neutral-600 leading-relaxed font-sans">
                      Dynamically calculates live postage tiers at checkout based on the customer&apos;s shipping destination and total package weight.
                    </p>

                    <div className="space-y-1.5 pt-1 text-[11px] font-mono">
                      <div className="flex justify-between items-center py-1 border-b border-neutral-200/60">
                        <span className="text-neutral-700">Standard (USPS Ground)</span>
                        <span className="font-semibold text-neutral-900">$6.95 (Free over threshold)</span>
                      </div>
                      <div className="flex justify-between items-center py-1 border-b border-neutral-200/60">
                        <span className="text-neutral-700">Priority (2–3 Day Air)</span>
                        <span className="font-semibold text-neutral-900">$12.95</span>
                      </div>
                      <div className="flex justify-between items-center py-1">
                        <span className="text-neutral-700">Express (Overnight)</span>
                        <span className="font-semibold text-neutral-900">$24.95</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Hourly Stock Sync & Webhook Listener */}
                  <div className="border border-neutral-200 p-4 space-y-3 bg-neutral-50/30">
                    <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                      <div className="flex items-center gap-2">
                        <RefreshCw className="w-4 h-4 text-emerald-700" />
                        <h6 className="text-xs font-serif font-bold text-neutral-900">
                          Automated Stock &amp; Inventory Sync
                        </h6>
                      </div>
                      <span className="text-[10px] font-mono uppercase bg-emerald-100 text-emerald-900 border border-emerald-300 px-1.5 py-0.5 font-bold">
                        Hourly Daemon Active
                      </span>
                    </div>

                    <p className="text-[11px] text-neutral-600 leading-relaxed font-sans">
                      Pulls real-time garment blank inventory from Apliiq&apos;s Los Angeles warehouse every 60 minutes. Disables out-of-stock color/size variants to protect customer orders.
                    </p>

                    <div className="flex items-center justify-between pt-1">
                      <div className="text-[11px] font-mono text-neutral-500">
                        Last synced:{' '}
                        <span className="font-semibold text-neutral-800">
                          {lastInventorySyncAt ? new Date(lastInventorySyncAt).toLocaleTimeString() : 'Recently'}
                        </span>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleManualInventorySync}
                        disabled={isSyncingInventory}
                        className="text-[11px] font-mono py-1.5 px-3 cursor-pointer bg-white"
                      >
                        {isSyncingInventory ? (
                          <RefreshCw className="w-3 h-3 animate-spin mr-1.5 text-neutral-700" />
                        ) : (
                          <Zap className="w-3 h-3 text-amber-600 mr-1.5" />
                        )}
                        <span>{isSyncingInventory ? 'Syncing...' : 'Sync Stock Now'}</span>
                      </Button>
                    </div>

                    {syncInventoryFeedback && (
                      <div className="text-[10px] font-mono p-2 bg-white border border-neutral-200 text-neutral-700">
                        {syncInventoryFeedback}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              {/* APLIIQ REVERSE SYNCHRONIZATION SUITE (OPTIONS A, B & C)       */}
              {/* ============================================================= */}
              <div className="pt-6 border-t-2 border-neutral-200 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-black text-white text-[10px] font-mono uppercase tracking-wider font-bold">
                        Two-Way Reverse Sync
                      </span>
                      <h5 className="font-serif text-sm font-bold text-neutral-900">
                        Apliiq Reverse Design Synchronization (Options A, B & C)
                      </h5>
                    </div>
                    <p className="text-xs text-neutral-500 font-sans">
                      Select any individual mode or combine all three. Manage which reverse import pipelines are active for your store.
                    </p>
                  </div>

                  {/* Preset Quick Actions */}
                  <div className="flex flex-wrap items-center gap-1.5 self-start sm:self-auto font-mono text-[11px]">
                    <span className="text-neutral-400 mr-1 text-[10px] uppercase font-bold">Quick Presets:</span>
                    <button
                      type="button"
                      onClick={() => {
                        setApliiqOptionAEnabled(true);
                        setApliiqOptionBEnabled(true);
                        setApliiqOptionCEnabled(true);
                      }}
                      className="px-2 py-1 bg-neutral-900 text-white hover:bg-black cursor-pointer text-[10px] font-bold"
                    >
                      All (A+B+C)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setApliiqOptionAEnabled(true);
                        setApliiqOptionBEnabled(false);
                        setApliiqOptionCEnabled(false);
                      }}
                      className="px-2 py-1 bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200 cursor-pointer text-[10px] font-bold"
                    >
                      A Only
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setApliiqOptionAEnabled(false);
                        setApliiqOptionBEnabled(true);
                        setApliiqOptionCEnabled(false);
                      }}
                      className="px-2 py-1 bg-blue-100 text-blue-900 border border-blue-300 hover:bg-blue-200 cursor-pointer text-[10px] font-bold"
                    >
                      B Only
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setApliiqOptionAEnabled(false);
                        setApliiqOptionBEnabled(false);
                        setApliiqOptionCEnabled(true);
                      }}
                      className="px-2 py-1 bg-purple-100 text-purple-900 border border-purple-300 hover:bg-purple-200 cursor-pointer text-[10px] font-bold"
                    >
                      C Only
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setApliiqOptionAEnabled(false);
                        setApliiqOptionBEnabled(false);
                        setApliiqOptionCEnabled(false);
                      }}
                      className="px-2 py-1 bg-neutral-200 text-neutral-700 hover:bg-neutral-300 cursor-pointer text-[10px]"
                    >
                      Turn Off All
                    </button>
                  </div>
                </div>

                {/* 3 Synchronous Mode Control Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                  {/* OPTION A CARD */}
                  <div className={`border p-4 space-y-3 transition-colors ${apliiqOptionAEnabled ? 'bg-amber-50/50 border-amber-300 shadow-xs' : 'bg-neutral-50/50 border-neutral-200 opacity-80'}`}>
                    <div className="flex items-center justify-between border-b border-neutral-200 pb-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-amber-200 text-amber-950 px-2 py-0.5 border border-amber-400">
                          Option A
                        </span>
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 border ${apliiqOptionAEnabled ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-neutral-200 text-neutral-600 border-neutral-300'}`}>
                          {apliiqOptionAEnabled ? 'ACTIVE' : 'DISABLED'}
                        </span>
                      </div>
                      <label className="flex items-center space-x-1.5 text-xs font-mono cursor-pointer">
                        <input
                          type="checkbox"
                          checked={apliiqOptionAEnabled}
                          onChange={(e) => setApliiqOptionAEnabled(e.target.checked)}
                          className="rounded-xs border-neutral-300 text-black focus:ring-black"
                        />
                        <span className="font-bold text-neutral-900">Enable</span>
                      </label>
                    </div>

                    <div>
                      <h6 className="text-xs font-serif font-bold text-neutral-900 flex items-center gap-1">
                        <Layers className="w-3.5 h-3.5 text-amber-700" />
                        <span>Catalog Batch Importer</span>
                      </h6>
                      <p className="text-[11px] text-neutral-600 leading-relaxed font-sans mt-1">
                        Connects to the Apliiq Service Broker. Browse all your saved designs in Product Studio with photos, silhouettes, wholesale costs, and multi-select batch import.
                      </p>
                    </div>

                    <div className="pt-2 border-t border-neutral-200 flex flex-col gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleTestOptionA}
                        disabled={optionATestState.testing}
                        className="text-[11px] font-mono w-full flex items-center justify-center gap-1.5 py-1.5 bg-white cursor-pointer"
                      >
                        {optionATestState.testing ? (
                          <RefreshCw className="w-3 h-3 animate-spin text-amber-600" />
                        ) : (
                          <Activity className="w-3 h-3 text-amber-600" />
                        )}
                        <span>{optionATestState.testing ? 'Testing System...' : 'Test Option A Real System'}</span>
                      </Button>

                      {optionATestState.msg && (
                        <div className={`p-2.5 border text-[10px] font-mono space-y-1 ${optionATestState.success ? 'bg-emerald-50 border-emerald-300 text-emerald-950' : 'bg-red-50 border-red-300 text-red-950'}`}>
                          <div className="flex items-center justify-between font-bold">
                            <span className="flex items-center gap-1">
                              {optionATestState.success ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <AlertCircle className="w-3.5 h-3.5 text-red-600" />}
                              <span>{optionATestState.success ? 'Handshake Verified' : 'Handshake Failed'}</span>
                            </span>
                            {optionATestState.latencyMs && <span>{optionATestState.latencyMs}ms</span>}
                          </div>
                          {optionATestState.details && (
                            <ul className="list-disc list-inside space-y-0.5 text-neutral-600 pt-0.5">
                              {optionATestState.details.map((d, i) => (
                                <li key={i}>{d}</li>
                              ))}
                            </ul>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* OPTION B CARD */}
                  <div className={`border p-4 space-y-3 transition-colors ${apliiqOptionBEnabled ? 'bg-blue-50/50 border-blue-300 shadow-xs' : 'bg-neutral-50/50 border-neutral-200 opacity-80'}`}>
                    <div className="flex items-center justify-between border-b border-neutral-200 pb-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-blue-200 text-blue-950 px-2 py-0.5 border border-blue-400">
                          Option B
                        </span>
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 border ${apliiqOptionBEnabled ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-neutral-200 text-neutral-600 border-neutral-300'}`}>
                          {apliiqOptionBEnabled ? 'ACTIVE' : 'DISABLED'}
                        </span>
                      </div>
                      <label className="flex items-center space-x-1.5 text-xs font-mono cursor-pointer">
                        <input
                          type="checkbox"
                          checked={apliiqOptionBEnabled}
                          onChange={(e) => setApliiqOptionBEnabled(e.target.checked)}
                          className="rounded-xs border-neutral-300 text-black focus:ring-black"
                        />
                        <span className="font-bold text-neutral-900">Enable</span>
                      </label>
                    </div>

                    <div>
                      <h6 className="text-xs font-serif font-bold text-neutral-900 flex items-center gap-1">
                        <Download className="w-3.5 h-3.5 text-blue-700" />
                        <span>1-Click Design ID Resolver</span>
                      </h6>
                      <p className="text-[11px] text-neutral-600 leading-relaxed font-sans mt-1">
                        Paste an Apliiq Design ID (e.g. <code>APQ-DES-4821</code>) or product URL. Resolves complete tech-pack specs, fabric GSM, DTF placement, and full variant matrix.
                      </p>
                    </div>

                    <div className="pt-2 border-t border-neutral-200 flex flex-col gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleTestOptionB}
                        disabled={optionBTestState.testing}
                        className="text-[11px] font-mono w-full flex items-center justify-center gap-1.5 py-1.5 bg-white cursor-pointer"
                      >
                        {optionBTestState.testing ? (
                          <RefreshCw className="w-3 h-3 animate-spin text-blue-600" />
                        ) : (
                          <Activity className="w-3 h-3 text-blue-600" />
                        )}
                        <span>{optionBTestState.testing ? 'Testing System...' : 'Test Option B Real System'}</span>
                      </Button>

                      {optionBTestState.msg && (
                        <div className={`p-2.5 border text-[10px] font-mono space-y-1 ${optionBTestState.success ? 'bg-emerald-50 border-emerald-300 text-emerald-950' : 'bg-red-50 border-red-300 text-red-950'}`}>
                          <div className="flex items-center justify-between font-bold">
                            <span className="flex items-center gap-1">
                              {optionBTestState.success ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <AlertCircle className="w-3.5 h-3.5 text-red-600" />}
                              <span>{optionBTestState.success ? 'Resolver Verified' : 'Resolver Failed'}</span>
                            </span>
                            {optionBTestState.latencyMs && <span>{optionBTestState.latencyMs}ms</span>}
                          </div>
                          {optionBTestState.details && (
                            <ul className="list-disc list-inside space-y-0.5 text-neutral-600 pt-0.5">
                              {optionBTestState.details.map((d, i) => (
                                <li key={i}>{d}</li>
                              ))}
                            </ul>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* OPTION C CARD */}
                  <div className={`border p-4 space-y-3 transition-colors ${apliiqOptionCEnabled ? 'bg-purple-50/50 border-purple-300 shadow-xs' : 'bg-neutral-50/50 border-neutral-200 opacity-80'}`}>
                    <div className="flex items-center justify-between border-b border-neutral-200 pb-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-purple-200 text-purple-950 px-2 py-0.5 border border-purple-400">
                          Option C
                        </span>
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 border ${apliiqOptionCEnabled ? 'bg-purple-100 text-purple-800 border-purple-300' : 'bg-neutral-200 text-neutral-600 border-neutral-300'}`}>
                          {apliiqOptionCEnabled ? 'LISTENING' : 'PAUSED'}
                        </span>
                      </div>
                      <label className="flex items-center space-x-1.5 text-xs font-mono cursor-pointer">
                        <input
                          type="checkbox"
                          checked={apliiqOptionCEnabled}
                          onChange={(e) => setApliiqOptionCEnabled(e.target.checked)}
                          className="rounded-xs border-neutral-300 text-black focus:ring-black"
                        />
                        <span className="font-bold text-neutral-900">Enable</span>
                      </label>
                    </div>

                    <div>
                      <h6 className="text-xs font-serif font-bold text-neutral-900 flex items-center gap-1">
                        <Webhook className="w-3.5 h-3.5 text-purple-700" />
                        <span>Real-time Automated Webhook</span>
                      </h6>
                      <p className="text-[11px] text-neutral-600 leading-relaxed font-sans mt-1">
                        Automated listener for Apliiq <code>design.created</code> events. When you save a design on Apliiq, it is instantly ingested into your catalog as a Draft.
                      </p>
                    </div>

                    <div className="pt-2 border-t border-neutral-200 flex flex-col gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleTestWebhookPing}
                        disabled={webhookTestState.testing}
                        className="text-[11px] font-mono w-full flex items-center justify-center gap-1.5 py-1.5 bg-white cursor-pointer"
                      >
                        {webhookTestState.testing ? (
                          <RefreshCw className="w-3 h-3 animate-spin text-purple-600" />
                        ) : (
                          <Zap className="w-3 h-3 text-purple-600" />
                        )}
                        <span>{webhookTestState.testing ? 'Pinging Webhook...' : 'Test Webhook Ping'}</span>
                      </Button>

                      {webhookTestState.msg && (
                        <div className={`p-2.5 border text-[10px] font-mono space-y-1 ${webhookTestState.success ? 'bg-emerald-50 border-emerald-300 text-emerald-950' : 'bg-red-50 border-red-300 text-red-950'}`}>
                          <div className="flex items-center justify-between font-bold">
                            <span className="flex items-center gap-1">
                              {webhookTestState.success ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <AlertCircle className="w-3.5 h-3.5 text-red-600" />}
                              <span>{webhookTestState.success ? 'Webhook Responded' : 'Ping Failed'}</span>
                            </span>
                            {webhookTestState.latencyMs !== undefined && <span>{webhookTestState.latencyMs}ms</span>}
                          </div>
                          {webhookTestState.details && (
                            <ul className="list-disc list-inside space-y-0.5 text-neutral-600 pt-0.5">
                              {webhookTestState.details.map((d, i) => (
                                <li key={i}>{d}</li>
                              ))}
                            </ul>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Option C Webhook Configuration Details (Expandable / Visible when Option C is enabled) */}
                {apliiqOptionCEnabled && (
                  <div className="border border-purple-200 bg-[#FAFAFA] p-4 sm:p-5 space-y-4 animate-in fade-in duration-200">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
                      <div className="flex items-center space-x-2.5">
                        <div className="w-7 h-7 bg-purple-600 text-white flex items-center justify-center font-bold">
                          <Webhook className="w-4 h-4" />
                        </div>
                        <div>
                          <h6 className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-900">
                            Option C: Official Apliiq Custom Store Integration (Add-to-Store & Product Search)
                          </h6>
                          <p className="text-[11px] text-neutral-500">
                            In your Apliiq account, go to <strong>Stores &gt; Webhook Settings</strong> to save both custom endpoints below.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono uppercase bg-neutral-200 text-neutral-800 px-2 py-0.5 font-bold">
                          Default Ingest State: Draft
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      {/* 1. Add to Store Webhook URL */}
                      <div className="space-y-1.5 bg-white p-3 border border-neutral-200 shadow-2xs">
                        <div className="flex items-center justify-between">
                          <label className="block text-[11px] uppercase font-mono text-neutral-900 font-bold">
                            1. Add to Store Webhook URL (POST)
                          </label>
                          <button
                            type="button"
                            onClick={handleCopyWebhookUrl}
                            className="text-[11px] font-mono text-neutral-600 hover:text-black flex items-center gap-1 cursor-pointer"
                          >
                            {copiedWebhookUrl ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span className="text-emerald-700 font-bold">Copied!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copy URL</span>
                              </>
                            )}
                          </button>
                        </div>
                        <div className="flex items-center bg-neutral-50 border border-neutral-300 p-2 font-mono text-xs text-neutral-800">
                          <span className="truncate select-all">
                            {typeof window !== 'undefined' ? `${window.location.origin}/api/pod/apliiq/add-to-store` : 'https://ezistential.store/api/pod/apliiq/add-to-store'}
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-500 font-mono">
                          Paste into Apliiq custom store webhook. Apliiq posts product &amp; variant data when you click &ldquo;Add to Store&rdquo;.
                        </p>
                      </div>

                      {/* 2. Product Search GET URL */}
                      <div className="space-y-1.5 bg-white p-3 border border-neutral-200 shadow-2xs">
                        <div className="flex items-center justify-between">
                          <label className="block text-[11px] uppercase font-mono text-neutral-900 font-bold">
                            2. Product Search URL (GET)
                          </label>
                          <button
                            type="button"
                            onClick={handleCopySearchUrl}
                            className="text-[11px] font-mono text-neutral-600 hover:text-black flex items-center gap-1 cursor-pointer"
                          >
                            {copiedSearchUrl ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span className="text-emerald-700 font-bold">Copied!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copy URL</span>
                              </>
                            )}
                          </button>
                        </div>
                        <div className="flex items-center bg-neutral-50 border border-neutral-300 p-2 font-mono text-xs text-neutral-800">
                          <span className="truncate select-all">
                            {typeof window !== 'undefined' ? `${window.location.origin}/api/pod/apliiq/product-search` : 'https://ezistential.store/api/pod/apliiq/product-search'}
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-500 font-mono">
                          Paste into Apliiq product search field. Apliiq uses this to query and match your store catalog.
                        </p>
                      </div>
                    </div>

                    {/* Webhook Secret & Diagnostic Test Probes */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 pt-2">
                      {/* Webhook Secret */}
                      <div className="space-y-1.5 bg-white p-3 border border-neutral-200 shadow-2xs">
                        <div className="flex items-center justify-between">
                          <label className="block text-[11px] uppercase font-mono text-neutral-700 font-semibold">
                            Signing Secret (Optional HMAC)
                          </label>
                          <button
                            type="button"
                            onClick={() => togglePodSecret('apliiqWebhook')}
                            className="text-[11px] text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer font-mono"
                          >
                            {showPodSecrets['apliiqWebhook'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 text-neutral-600" />}
                            <span>{showPodSecrets['apliiqWebhook'] ? 'Hide' : 'Show'}</span>
                          </button>
                        </div>
                        <input
                          type={showPodSecrets['apliiqWebhook'] ? 'text' : 'password'}
                          value={apliiqWebhookSecret}
                          onChange={(e) => setApliiqWebhookSecret(e.target.value)}
                          placeholder="whsec_..."
                          className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
                        />
                        <p className="text-[10px] text-neutral-500 font-mono">
                          Optional HMAC-SHA256 signature verification key.
                        </p>
                      </div>

                      {/* Probe 1: Add-to-Store Webhook Test */}
                      <div className="space-y-2 bg-white p-3 border border-neutral-200 shadow-2xs flex flex-col justify-between">
                        <div>
                          <span className="text-[11px] font-mono font-bold uppercase text-neutral-900 block">
                            Probe 1: Add to Store Spec
                          </span>
                          <p className="text-[10px] text-neutral-500 mt-0.5">
                            Simulates Apliiq payload &amp; asserts <code>storeProductId</code> + <code>hasError: false</code> contract.
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={handleTestWebhookPing}
                          disabled={webhookTestState.testing}
                          className="text-[11px] font-mono w-full flex items-center justify-center gap-1.5 py-1.5 bg-neutral-50 hover:bg-neutral-100 cursor-pointer"
                        >
                          {webhookTestState.testing ? (
                            <RefreshCw className="w-3 h-3 animate-spin text-purple-600" />
                          ) : (
                            <Zap className="w-3 h-3 text-purple-600" />
                          )}
                          <span>{webhookTestState.testing ? 'Simulating Spec...' : 'Test Add-to-Store Spec'}</span>
                        </Button>
                      </div>

                      {/* Probe 2: Product Search GET Test */}
                      <div className="space-y-2 bg-white p-3 border border-neutral-200 shadow-2xs flex flex-col justify-between">
                        <div>
                          <span className="text-[11px] font-mono font-bold uppercase text-neutral-900 block">
                            Probe 2: Product Search GET Spec
                          </span>
                          <p className="text-[10px] text-neutral-500 mt-0.5">
                            Queries endpoint &amp; verifies direct JSON Array with <code>store_ProductId</code> formatting.
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={handleTestProductSearch}
                          disabled={productSearchTestState.testing}
                          className="text-[11px] font-mono w-full flex items-center justify-center gap-1.5 py-1.5 bg-neutral-50 hover:bg-neutral-100 cursor-pointer"
                        >
                          {productSearchTestState.testing ? (
                            <RefreshCw className="w-3 h-3 animate-spin text-blue-600" />
                          ) : (
                            <Search className="w-3 h-3 text-blue-600" />
                          )}
                          <span>{productSearchTestState.testing ? 'Querying Index...' : 'Test Product Search GET'}</span>
                        </Button>
                      </div>
                    </div>

                    {/* Search Probe Feedback */}
                    {productSearchTestState.msg && (
                      <div className={`p-3 border text-[11px] font-mono space-y-1.5 animate-in fade-in duration-200 ${productSearchTestState.success ? 'bg-blue-50 border-blue-300 text-blue-950' : 'bg-red-50 border-red-300 text-red-950'}`}>
                        <div className="flex items-center justify-between font-bold">
                          <span className="flex items-center gap-1.5">
                            {productSearchTestState.success ? <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" /> : <AlertCircle className="w-3.5 h-3.5 text-red-600" />}
                            <span>{productSearchTestState.msg}</span>
                          </span>
                          {productSearchTestState.latencyMs !== undefined && (
                            <span className="text-[10px] text-neutral-500">{productSearchTestState.latencyMs}ms</span>
                          )}
                        </div>
                        {productSearchTestState.sampleReturned && productSearchTestState.sampleReturned.length > 0 && (
                          <div className="text-[10px] text-neutral-600 pt-1 border-t border-blue-200/60">
                            <span className="font-bold text-neutral-800">Sample query match delivered to Apliiq:</span>
                            <pre className="mt-1 bg-white p-2 border border-blue-200 text-neutral-800 overflow-x-auto text-[10px]">
                              {JSON.stringify(productSearchTestState.sampleReturned[0], null, 2)}
                            </pre>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* 2. Printful Integration Card (Fallback) */}
            <div className="border border-neutral-200 p-6 space-y-5 bg-white">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-100 pb-4 gap-3">
                <div className="flex items-center space-x-3">
                  <div className="w-9 h-9 bg-red-600 text-white font-serif font-bold text-sm flex items-center justify-center">
                    PF
                  </div>
                  <div>
                    <h4 className="font-serif text-base font-bold text-neutral-900">2. Printful POD (Secondary / Backup Facility)</h4>
                    <p className="text-xs text-neutral-500">Global fulfillment network for international orders</p>
                  </div>
                </div>

                <label className="flex items-center space-x-2 text-xs font-mono cursor-pointer">
                  <input
                    type="checkbox"
                    checked={printfulAutoDispatch}
                    onChange={(e) => setPrintfulAutoDispatch(e.target.checked)}
                    className="rounded-xs border-neutral-300 text-black focus:ring-black"
                  />
                  <span className="font-semibold text-neutral-900">Enable Printful Failover</span>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs uppercase font-mono text-neutral-700 font-medium">
                      Printful API Token
                    </label>
                    <button
                      type="button"
                      onClick={() => togglePodSecret('printful')}
                      className="text-[11px] text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer font-mono"
                    >
                      {showPodSecrets['printful'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 text-neutral-600" />}
                      <span>{showPodSecrets['printful'] ? 'Hide' : 'Show'}</span>
                    </button>
                  </div>
                  <input
                    type={showPodSecrets['printful'] ? 'text' : 'password'}
                    value={printfulApiKey}
                    onChange={(e) => setPrintfulApiKey(e.target.value)}
                    placeholder="pt_live_..."
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:border-black focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-3 border-t border-neutral-100 gap-3">
                <span className="text-[11px] text-neutral-500 font-mono">
                  Endpoint: https://api.printful.com
                </span>

                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleTestPodPing('printful')}
                  disabled={podTestState.testing && podTestState.provider === 'printful'}
                  className="flex items-center gap-1.5"
                >
                  <Activity className="w-3.5 h-3.5 text-red-600" />
                  <span>{podTestState.testing && podTestState.provider === 'printful' ? 'Verifying Handshake...' : 'Test Printful Handshake'}</span>
                </Button>
              </div>

              {/* Test Status Feedback */}
              {podTestState.provider === 'printful' && (
                <div className={`p-4 border text-xs font-mono space-y-2 animate-in fade-in duration-200 ${podTestState.success ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : 'bg-red-50 border-red-300 text-red-900'}`}>
                  <div className="flex items-center justify-between font-bold">
                    <span className="flex items-center gap-1.5">
                      {podTestState.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-red-600" />}
                      <span>{podTestState.msg}</span>
                    </span>
                    {podTestState.latencyMs && <span className="text-[10px] text-neutral-500">{podTestState.latencyMs}ms latency</span>}
                  </div>
                  {podTestState.details && (
                    <ul className="list-disc list-inside text-[11px] text-neutral-600 space-y-0.5 pt-1">
                      {podTestState.details.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-neutral-200 flex justify-end">
              <Button type="submit" variant="primary" size="md">
                <Check className="w-3.5 h-3.5 mr-1.5" />
                <span>Save POD Configuration</span>
              </Button>
            </div>
          </div>
        </form>
      )}

      {/* TAB 2: GOOGLE SEARCH CONSOLE */}
      {activeTab === 'gsc' && <GoogleSearchConsoleSetup />}

      {/* TAB 3: WHATSAPP CALLMEBOT NOTIFICATION */}
      {activeTab === 'whatsapp' && (
        <form onSubmit={handleSaveAllIntegrations} className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-100 pb-4 gap-3 bg-neutral-50 p-4 border border-neutral-200">
            <div>
              <div className="flex items-center space-x-2">
                <Phone className="w-5 h-5 text-emerald-600" />
                <h3 className="font-serif text-lg font-bold text-neutral-900">WhatsApp CallMeBot Order Notifications</h3>
              </div>
              <p className="text-xs text-neutral-500 mt-1">
                Receive instant WhatsApp alerts on your phone whenever a customer places an order on the storefront.
              </p>
            </div>

            <div className="flex items-center space-x-3">
              <span className={`text-[10px] font-mono uppercase px-2 py-0.5 font-bold border ${
                whatsappNotificationsEnabled
                  ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                  : 'bg-neutral-200 text-neutral-600 border-neutral-300'
              }`}>
                {whatsappNotificationsEnabled ? 'CallMeBot Active' : 'CallMeBot Disabled'}
              </span>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={whatsappNotificationsEnabled}
                  onChange={(e) => {
                    const newValue = e.target.checked;
                    setWhatsappNotificationsEnabled(newValue);
                    updateContent({ whatsappNotificationsEnabled: newValue });
                    showToast(newValue ? 'CallMeBot WhatsApp Order Notifications ENABLED and saved to Database!' : 'CallMeBot WhatsApp Order Notifications DISABLED.');
                  }}
                  className="sr-only peer"
                />
                <div className="w-12 h-6 bg-neutral-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                Admin WhatsApp Phone Number (E.164 with Country Code) *
              </label>
              <input
                type="text"
                required
                value={whatsappPhoneNumber}
                onChange={(e) => setWhatsappPhoneNumber(e.target.value)}
                placeholder="+13125550192 or +447123456789"
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono font-bold text-neutral-900 focus:outline-hidden focus:border-black"
              />
              <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                Phone number registered with WhatsApp including country code.
              </span>
            </div>

            <div>
              <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">
                CallMeBot WhatsApp API Key *
              </label>
              <input
                type="text"
                required
                value={whatsappApiKey}
                onChange={(e) => setWhatsappApiKey(e.target.value)}
                placeholder="e.g. 123456"
                className="w-full bg-neutral-50 border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden focus:border-black"
              />
              <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                Get your free API Key by sending "I allow callmebot to send me messages" to +34 911 06 54 54 on WhatsApp.
              </span>
            </div>
          </div>

          <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-3">
            <label className="flex items-center space-x-3 text-xs text-neutral-900 cursor-pointer font-bold">
              <input
                type="checkbox"
                checked={whatsappNotifyOnNewOrder}
                onChange={(e) => setWhatsappNotifyOnNewOrder(e.target.checked)}
                className="accent-emerald-600 w-4 h-4"
              />
              <span>Trigger WhatsApp Alert Instantly On New Order Checkout</span>
            </label>

            <div>
              <label className="block text-[11px] uppercase font-mono text-neutral-700 mb-1">
                WhatsApp Notification Message Template
              </label>
              <textarea
                rows={4}
                value={whatsappMessageTemplate}
                onChange={(e) => setWhatsappMessageTemplate(e.target.value)}
                className="w-full bg-white border border-neutral-300 p-3 text-xs font-mono text-neutral-900 leading-relaxed focus:outline-hidden"
              />
              <div className="flex flex-wrap gap-2 text-[10px] font-mono text-neutral-500 pt-1">
                <span>Placeholders:</span>
                <span className="bg-neutral-200 px-1 font-bold text-neutral-800">{'{brand_name}'}</span>
                <span className="bg-neutral-200 px-1 font-bold text-neutral-800">{'{order_id}'}</span>
                <span className="bg-neutral-200 px-1 font-bold text-neutral-800">{'{customer_name}'}</span>
                <span className="bg-neutral-200 px-1 font-bold text-neutral-800">{'{total_amount}'}</span>
                <span className="bg-neutral-200 px-1 font-bold text-neutral-800">{'{items_summary}'}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between pt-4 border-t border-neutral-200 gap-3">
            <Button type="button" variant="outline" size="sm" onClick={handleTestWhatsAppPing}>
              <Send className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
              <span>{whatsappTestState.testing ? 'Sending Test WhatsApp Ping...' : 'Send Test WhatsApp Alert'}</span>
            </Button>

            <Button type="submit" variant="primary" size="md">
              <Check className="w-3.5 h-3.5 mr-1.5" />
              <span>Save WhatsApp Bot Settings</span>
            </Button>
          </div>

          {whatsappTestState.msg && (
            <div className={`p-3 text-xs font-mono border ${
              whatsappTestState.success ? 'bg-emerald-50 text-emerald-900 border-emerald-300' : 'bg-red-50 text-red-900 border-red-300'
            }`}>
              <div className="font-bold flex items-center justify-between">
                <span>WhatsApp CallMeBot Probe Status:</span>
                {whatsappTestState.latencyMs && <span>{whatsappTestState.latencyMs}ms</span>}
              </div>
              <div>{whatsappTestState.msg}</div>
            </div>
          )}
        </form>
      )}

      {/* TAB 4: SMTP EMAIL SERVER & TRANSACTIONAL TEMPLATES */}
      {activeTab === 'smtp' && (
        <form onSubmit={handleSaveAllIntegrations} className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-8 shadow-xs">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <Server className="w-5 h-5 text-purple-600" />
                <h3 className="font-serif text-lg font-bold text-neutral-900">SMTP Server & Transactional Email Templates</h3>
              </div>
              <p className="text-xs text-neutral-500 mt-1">
                Configure your outgoing email server and customize notification templates for sign-ups, password resets, and order updates.
              </p>
            </div>

            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={smtpEnabled}
                onChange={(e) => setSmtpEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>

          {/* SMTP Connection Settings */}
          <div className="p-5 bg-neutral-50 border border-neutral-200 space-y-5">
            <h4 className="text-xs uppercase font-mono tracking-wider font-bold text-neutral-800">
              Outgoing SMTP Server Credentials
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">SMTP Host *</label>
                <input
                  type="text"
                  required
                  value={smtpHost}
                  onChange={(e) => setSmtpHost(e.target.value)}
                  placeholder="smtp.gmail.com"
                  className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">SMTP Port *</label>
                <input
                  type="number"
                  required
                  value={smtpPort}
                  onChange={(e) => setSmtpPort(Number(e.target.value))}
                  placeholder="587"
                  className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">Encryption Protocol</label>
                <select
                  value={smtpEncryption}
                  onChange={(e) => setSmtpEncryption(e.target.value as any)}
                  className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                >
                  <option value="TLS">STARTTLS (Port 587)</option>
                  <option value="SSL">SSL / TLS (Port 465)</option>
                  <option value="NONE">Unencrypted (Port 25)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">SMTP Username / Email *</label>
                <input
                  type="text"
                  required
                  value={smtpUsername}
                  onChange={(e) => setSmtpUsername(e.target.value)}
                  placeholder="care@ezistential.com"
                  className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs uppercase font-mono font-bold text-neutral-800">SMTP Password / App Key *</label>
                  <button
                    type="button"
                    onClick={() => setShowSmtpPassword(!showSmtpPassword)}
                    className="text-[10px] font-mono text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer"
                  >
                    {showSmtpPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{showSmtpPassword ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <input
                  type={showSmtpPassword ? 'text' : 'password'}
                  required
                  value={smtpPassword}
                  onChange={(e) => setSmtpPassword(e.target.value)}
                  placeholder="App Password or Secret Key"
                  className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2 border-t border-neutral-200">
              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">From Sender Display Name</label>
                <input
                  type="text"
                  value={smtpFromSenderName}
                  onChange={(e) => setSmtpFromSenderName(e.target.value)}
                  className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-sans text-neutral-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono font-bold text-neutral-800 mb-1">From Sender Email Address</label>
                <input
                  type="email"
                  value={smtpFromSenderEmail}
                  onChange={(e) => setSmtpFromSenderEmail(e.target.value)}
                  className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <Button type="button" variant="outline" size="sm" onClick={handleTestSmtpPing}>
                <Send className="w-3.5 h-3.5 mr-1.5 text-purple-600" />
                <span>{smtpTestState.testing ? 'Testing SMTP Connection...' : 'Test SMTP Connection Handshake'}</span>
              </Button>
            </div>

            {smtpTestState.msg && (
              <div className={`p-3 text-xs font-mono border ${
                smtpTestState.success ? 'bg-emerald-50 text-emerald-900 border-emerald-300' : 'bg-red-50 text-red-900 border-red-300'
              }`}>
                <div className="font-bold flex items-center justify-between">
                  <span>SMTP Handshake Result:</span>
                  {smtpTestState.latencyMs && <span>{smtpTestState.latencyMs}ms</span>}
                </div>
                <div>{smtpTestState.msg}</div>
              </div>
            )}
          </div>

          {/* Unified Location Notice for Transactional Email Templates */}
          <div className="p-4 bg-purple-50/70 border border-purple-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-sm bg-purple-100 flex items-center justify-center shrink-0 text-purple-700">
                <FileText className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <span className="font-bold text-purple-950 font-mono block">
                  Transactional Email Templates Unified in System Settings
                </span>
                <p className="text-purple-800 text-[11px] leading-relaxed font-sans max-w-xl">
                  All 4 transactional email templates (Sign Up / Welcome, Password Reset, Order Confirmation Receipt, and Shipping Status) with dual-pane editing, placeholder tags, and real-time customer inbox preview are now unified in <strong>System Settings & Email Templates Manager</strong>.
                </p>
              </div>
            </div>
            <div className="shrink-0 flex items-center gap-2">
              <span className="px-2.5 py-1 bg-white border border-purple-300 text-purple-900 font-mono text-[10px] uppercase font-bold shadow-2xs">
                Unified Under System Settings
              </span>
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-200 flex justify-end">
            <Button type="submit" variant="primary" size="md">
              <Check className="w-3.5 h-3.5 mr-1.5" />
              <span>Save SMTP Server Settings</span>
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};
