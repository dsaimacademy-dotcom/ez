import React, { useState, useEffect } from 'react';
import {
  X,
  RefreshCw,
  Check,
  CheckSquare,
  Square,
  Search,
  ExternalLink,
  Layers,
  ArrowRight,
  Sparkles,
  AlertCircle,
  Package
} from 'lucide-react';
import { Button } from '../ui/Button';
import { api } from '../../lib/api';

interface ApliiqDesign {
  id: string;
  name: string;
  tagline: string;
  silhouette: string;
  wearTypeId: string;
  wholesaleCost: number;
  suggestedRetailPrice: number;
  primaryImage: string;
  galleryImages: { url: string; alt: string; viewType: string }[];
  colorways: { id: string; name: string; hex: string }[];
  sizes: string[];
  description: string;
  alreadyImported?: boolean;
}

interface ApliiqDesignSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportSuccess: (importedProducts: any[]) => void;
  showToast: (msg: string) => void;
}

export const ApliiqDesignSyncModal: React.FC<ApliiqDesignSyncModalProps> = ({
  isOpen,
  onClose,
  onImportSuccess,
  showToast,
}) => {
  const [designs, setDesigns] = useState<ApliiqDesign[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isImporting, setIsImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadDesigns();
    } else {
      setSelectedIds(new Set());
      setSearchQuery('');
      setError(null);
    }
  }, [isOpen]);

  const loadDesigns = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getApliiqDesigns();
      if (res.success && Array.isArray(res.designs)) {
        setDesigns(res.designs);
      } else {
        setError('Unable to retrieve saved designs from Apliiq.');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to connect to Apliiq catalog endpoint.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const filteredDesigns = designs.filter((d) => {
    const q = searchQuery.toLowerCase();
    return (
      d.name.toLowerCase().includes(q) ||
      d.silhouette.toLowerCase().includes(q) ||
      d.id.toLowerCase().includes(q) ||
      d.tagline.toLowerCase().includes(q)
    );
  });

  const toggleSelect = (id: string, alreadyImported?: boolean) => {
    if (alreadyImported) return;
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const handleSelectAll = () => {
    const importable = filteredDesigns.filter((d) => !d.alreadyImported);
    if (selectedIds.size === importable.length && importable.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(importable.map((d) => d.id)));
    }
  };

  const handleImport = async () => {
    if (selectedIds.size === 0) return;
    setIsImporting(true);
    try {
      const res = await api.importApliiqDesigns({
        designIds: Array.from(selectedIds),
        status: 'draft',
      });

      if (res.success) {
        showToast(`Imported ${res.count} design(s) from Apliiq as Drafts.`);
        onImportSuccess(res.products);
        onClose();
      } else {
        showToast(res.message || 'Import failed.');
      }
    } catch (err: any) {
      showToast(err.message || 'Network error during import.');
    } finally {
      setIsImporting(false);
    }
  };

  const importableCount = filteredDesigns.filter((d) => !d.alreadyImported).length;
  const allFilteredSelected =
    importableCount > 0 && selectedIds.size >= importableCount;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-5xl bg-white border border-neutral-300 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-start justify-between p-5 border-b border-neutral-200 bg-[#FBFBF9] shrink-0">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-600 rounded-full" />
              <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 font-bold">
                Apliiq Cut &amp; Sew Design Studio • Reverse Sync
              </span>
            </div>
            <h3 className="font-serif text-xl sm:text-2xl text-neutral-900 tracking-tight">
              Import Saved Designs from Apliiq
            </h3>
            <p className="text-xs text-neutral-600 font-sans">
              Select finished artwork pieces from your Apliiq catalog. Each piece imports with authentic wholesale costs and is staged as a <strong>Draft</strong> for pricing review.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-black hover:bg-neutral-200/60 rounded-xs transition-colors cursor-pointer"
            aria-label="Close sync modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar: Search, Select All, Refresh */}
        <div className="p-4 bg-white border-b border-neutral-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shrink-0">
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by silhouette, design name, or ID..."
              className="w-full bg-neutral-50 border border-neutral-200 pl-9 pr-3 py-2 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
            />
          </div>

          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleSelectAll}
              disabled={importableCount === 0 || loading}
              className="flex items-center gap-1.5 text-xs py-2"
            >
              {allFilteredSelected ? (
                <CheckSquare className="w-3.5 h-3.5 text-black" />
              ) : (
                <Square className="w-3.5 h-3.5 text-neutral-400" />
              )}
              <span>{allFilteredSelected ? 'Deselect All' : 'Select Available'}</span>
            </Button>

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={loadDesigns}
              disabled={loading}
              className="flex items-center gap-1.5 text-xs py-2"
              title="Refresh designs from Apliiq"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </Button>
          </div>
        </div>

        {/* Modal Body: Design Grid */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4 bg-neutral-50/50">
          {loading ? (
            <div className="py-20 text-center space-y-3">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto text-neutral-400" />
              <p className="text-xs font-mono text-neutral-500 uppercase tracking-wider">
                Connecting to Apliiq Design Catalog...
              </p>
            </div>
          ) : error ? (
            <div className="p-6 border border-red-200 bg-red-50 text-red-900 text-xs font-mono space-y-2 text-center">
              <AlertCircle className="w-6 h-6 mx-auto text-red-600" />
              <p className="font-bold">{error}</p>
              <p className="text-neutral-600">Ensure your Apliiq API Key and Secret are configured in Admin Portal → Integrations.</p>
              <Button onClick={loadDesigns} variant="outline" size="sm" className="mt-3">
                Try Again
              </Button>
            </div>
          ) : filteredDesigns.length === 0 ? (
            <div className="py-16 text-center space-y-2 border border-dashed border-neutral-300 bg-white p-6">
              <Package className="w-8 h-8 mx-auto text-neutral-400 stroke-1" />
              <h4 className="font-serif text-sm font-semibold text-neutral-800">No Matching Designs Found</h4>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                No designs match "{searchQuery}". Create new pieces in your Apliiq account or adjust your filter.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredDesigns.map((design) => {
                const isSelected = selectedIds.has(design.id);
                const isImported = design.alreadyImported;

                return (
                  <div
                    key={design.id}
                    onClick={() => toggleSelect(design.id, isImported)}
                    className={`relative border transition-all text-left flex flex-col bg-white ${
                      isImported
                        ? 'opacity-65 border-neutral-200 cursor-not-allowed bg-neutral-50/70'
                        : isSelected
                        ? 'border-black ring-1 ring-black shadow-md cursor-pointer'
                        : 'border-neutral-200 hover:border-neutral-400 cursor-pointer shadow-xs'
                    }`}
                  >
                    {/* Mockup Image Container */}
                    <div className="relative aspect-4/3 w-full bg-neutral-100 overflow-hidden border-b border-neutral-100">
                      <img
                        src={design.primaryImage}
                        alt={design.name}
                        className="w-full h-full object-cover"
                      />
                      {/* Selection Checkbox */}
                      <div className="absolute top-2.5 right-2.5 z-10">
                        {isImported ? (
                          <span className="px-2 py-0.5 bg-neutral-900 text-white text-[9px] font-mono uppercase tracking-wider font-semibold border border-neutral-700">
                            Already in Store
                          </span>
                        ) : (
                          <div
                            className={`w-6 h-6 rounded-xs flex items-center justify-center transition-colors ${
                              isSelected
                                ? 'bg-black text-white'
                                : 'bg-white/90 text-transparent border border-neutral-400 hover:border-black'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>

                      {/* ID tag */}
                      <div className="absolute bottom-2 left-2 z-10">
                        <span className="px-1.5 py-0.5 bg-black/80 text-white text-[10px] font-mono tracking-widest">
                          {design.id}
                        </span>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="text-[10px] font-mono uppercase text-neutral-500 font-semibold tracking-wider">
                          {design.silhouette}
                        </div>
                        <h4 className="font-serif text-sm font-bold text-neutral-900 mt-0.5 line-clamp-1">
                          {design.name}
                        </h4>
                        <p className="text-[11px] text-neutral-500 line-clamp-2 mt-1">
                          {design.tagline || design.description}
                        </p>
                      </div>

                      {/* Financial & Specifications Metadata */}
                      <div className="pt-3 border-t border-neutral-100 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between text-[11px] font-mono">
                          <span className="text-neutral-500">Wholesale Base:</span>
                          <span className="font-semibold text-neutral-900">
                            ${design.wholesaleCost.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] font-mono">
                          <span className="text-neutral-500">Suggested Retail:</span>
                          <span className="font-semibold text-emerald-800">
                            ${design.suggestedRetailPrice.toFixed(2)}
                          </span>
                        </div>

                        <div className="flex items-center justify-between pt-1 text-[10px] font-mono text-neutral-400">
                          <span>{design.colorways.length} Colors · {design.sizes.join(', ')}</span>
                          <span>DTF + Woven Tag</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-white border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-neutral-600 font-sans">
            <span className="font-mono font-bold text-neutral-900">{selectedIds.size}</span> design(s) selected for import. Pieces will stage as <strong>Drafts</strong>.
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Button
              type="button"
              variant="outline"
              size="md"
              onClick={onClose}
              disabled={isImporting}
              className="w-full sm:w-auto text-xs py-2.5"
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              size="md"
              onClick={handleImport}
              disabled={selectedIds.size === 0 || isImporting}
              className="w-full sm:w-auto text-xs py-2.5 bg-black text-white hover:bg-neutral-800 flex items-center justify-center gap-2"
            >
              {isImporting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
                  <span>Importing {selectedIds.size} Piece(s)...</span>
                </>
              ) : (
                <>
                  <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
                  <span>Import Selected ({selectedIds.size}) as Drafts</span>
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
