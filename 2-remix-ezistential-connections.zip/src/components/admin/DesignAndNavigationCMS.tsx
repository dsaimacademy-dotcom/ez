import React, { useState } from 'react';
import { Palette, Menu } from 'lucide-react';
import { DesignSetup } from './DesignSetup';
import { MenuNavigationCMS } from './MenuNavigationCMS';

export interface DesignAndNavigationCMSProps {
  initialTab?: 'design' | 'navigation';
  showToast?: (msg: string) => void;
  onNavigateToView?: (viewId: string) => void;
}

export const DesignAndNavigationCMS: React.FC<DesignAndNavigationCMSProps> = ({
  initialTab = 'design',
  showToast,
  onNavigateToView,
}) => {
  const [activeTab, setActiveTab] = useState<'design' | 'navigation'>(initialTab);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Unified Tab Header */}
      <div className="bg-white border border-neutral-200 p-2 shadow-xs flex items-center justify-between">
        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={() => setActiveTab('design')}
            className={`flex items-center space-x-2 px-4 py-2 text-xs font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
              activeTab === 'design'
                ? 'bg-black text-white shadow-xs'
                : 'text-neutral-600 hover:text-black hover:bg-neutral-100'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Design Studio & Theme</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('navigation')}
            className={`flex items-center space-x-2 px-4 py-2 text-xs font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
              activeTab === 'navigation'
                ? 'bg-black text-white shadow-xs'
                : 'text-neutral-600 hover:text-black hover:bg-neutral-100'
            }`}
          >
            <Menu className="w-3.5 h-3.5" />
            <span>Menu & Navigation</span>
          </button>
        </div>

        <div className="text-[11px] font-mono text-neutral-500 pr-3 hidden sm:block">
          Content & Editorial — Design with Menu & Navigation
        </div>
      </div>

      {/* Tab Panels */}
      {activeTab === 'design' && <DesignSetup />}
      {activeTab === 'navigation' && (
        <MenuNavigationCMS showToast={showToast} onNavigateToView={onNavigateToView} />
      )}
    </div>
  );
};
