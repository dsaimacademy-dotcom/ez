import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Check, CheckCircle2, SlidersHorizontal } from 'lucide-react';
import { Size } from '../../types';

export interface FitCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSize: (size: Size) => void;
  productName: string;
}

export const FitCalculatorModal: React.FC<FitCalculatorModalProps> = ({
  isOpen,
  onClose,
  onSelectSize,
  productName,
}) => {
  const [heightFeet, setHeightFeet] = useState<number>(5);
  const [heightInches, setHeightInches] = useState<number>(10);
  const [weightLbs, setWeightLbs] = useState<number>(165);
  const [fitPreference, setFitPreference] = useState<'tailored' | 'relaxed' | 'oversized'>('relaxed');
  const [calculatedSize, setCalculatedSize] = useState<Size | null>(null);
  const [reason, setReason] = useState<string | null>(null);

  const calculateRecommendation = (e: React.FormEvent) => {
    e.preventDefault();

    const totalHeightInches = heightFeet * 12 + heightInches;
    let baseSize: Size = 'M';

    if (weightLbs < 135) {
      baseSize = 'S';
    } else if (weightLbs <= 165) {
      baseSize = 'M';
    } else if (weightLbs <= 195) {
      baseSize = 'L';
    } else if (weightLbs <= 225) {
      baseSize = 'XL';
    } else {
      baseSize = '2XL';
    }

    // Adjust for height & fit preference
    if (fitPreference === 'oversized') {
      const sizeOrder: Size[] = ['S', 'M', 'L', 'XL', '2XL', '3XL'];
      const currentIndex = sizeOrder.indexOf(baseSize);
      if (currentIndex < sizeOrder.length - 1) {
        baseSize = sizeOrder[currentIndex + 1];
      }
    } else if (fitPreference === 'tailored' && totalHeightInches < 68 && weightLbs < 155) {
      if (baseSize === 'M') baseSize = 'S';
    }

    setCalculatedSize(baseSize);

    const fitNotes = {
      tailored: 'a cleaner, structured silhouette across shoulders and chest.',
      relaxed: 'our signature drop-shoulder architectural drape.',
      oversized: 'an expressive, relaxed street box silhouette with extended length.',
    };

    setReason(
      `For your build (${heightFeet}'${heightInches}", ${weightLbs} lbs), size ${baseSize} delivers ${fitNotes[fitPreference]}`
    );
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Garment Fit & Sizing Assistant" maxWidth="md">
      <div className="space-y-6">
        <div className="bg-[#fcfcfb] p-4 border border-neutral-200">
          <p className="text-xs text-neutral-600 leading-relaxed font-sans">
            Our garments feature a custom 11.5oz boxy heavyweight cut with dropped shoulders. Enter your proportions for an exact size suggestion tailored to <strong className="text-black">{productName}</strong>.
          </p>
        </div>

        <form onSubmit={calculateRecommendation} className="space-y-4 font-sans text-xs">
          {/* Height Inputs */}
          <div>
            <label className="block uppercase font-mono tracking-wider text-neutral-600 mb-1.5 font-bold text-[10px]">
              Your Height
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center space-x-2 bg-neutral-50 border border-neutral-300 p-2">
                <input
                  type="number"
                  min={4}
                  max={7}
                  value={heightFeet}
                  onChange={(e) => setHeightFeet(Number(e.target.value))}
                  className="w-full bg-transparent text-xs font-mono font-bold focus:outline-hidden"
                />
                <span className="text-neutral-500 font-mono text-[11px]">ft</span>
              </div>
              <div className="flex items-center space-x-2 bg-neutral-50 border border-neutral-300 p-2">
                <input
                  type="number"
                  min={0}
                  max={11}
                  value={heightInches}
                  onChange={(e) => setHeightInches(Number(e.target.value))}
                  className="w-full bg-transparent text-xs font-mono font-bold focus:outline-hidden"
                />
                <span className="text-neutral-500 font-mono text-[11px]">in</span>
              </div>
            </div>
          </div>

          {/* Weight Input */}
          <div>
            <label className="block uppercase font-mono tracking-wider text-neutral-600 mb-1.5 font-bold text-[10px]">
              Your Weight
            </label>
            <div className="flex items-center space-x-2 bg-neutral-50 border border-neutral-300 p-2 max-w-xs">
              <input
                type="number"
                min={80}
                max={350}
                value={weightLbs}
                onChange={(e) => setWeightLbs(Number(e.target.value))}
                className="w-full bg-transparent text-xs font-mono font-bold focus:outline-hidden"
              />
              <span className="text-neutral-500 font-mono text-[11px]">lbs</span>
            </div>
          </div>

          {/* Fit Preference */}
          <div>
            <label className="block uppercase font-mono tracking-wider text-neutral-600 mb-1.5 font-bold text-[10px]">
              Drape & Silhouette Preference
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setFitPreference('tailored')}
                className={`p-2.5 text-center border text-xs font-mono transition-colors cursor-pointer ${
                  fitPreference === 'tailored'
                    ? 'bg-black text-white border-black font-bold'
                    : 'bg-white text-neutral-700 border-neutral-300 hover:border-black'
                }`}
              >
                Tailored
              </button>

              <button
                type="button"
                onClick={() => setFitPreference('relaxed')}
                className={`p-2.5 text-center border text-xs font-mono transition-colors cursor-pointer ${
                  fitPreference === 'relaxed'
                    ? 'bg-black text-white border-black font-bold'
                    : 'bg-white text-neutral-700 border-neutral-300 hover:border-black'
                }`}
              >
                Signature Drape
              </button>

              <button
                type="button"
                onClick={() => setFitPreference('oversized')}
                className={`p-2.5 text-center border text-xs font-mono transition-colors cursor-pointer ${
                  fitPreference === 'oversized'
                    ? 'bg-black text-white border-black font-bold'
                    : 'bg-white text-neutral-700 border-neutral-300 hover:border-black'
                }`}
              >
                Boxy Oversized
              </button>
            </div>
          </div>

          <Button type="submit" variant="primary" size="md" fullWidth className="mt-2">
            <SlidersHorizontal className="w-3.5 h-3.5 mr-1.5" />
            <span>Calculate Recommended Size</span>
          </Button>
        </form>

        {/* Results Box */}
        {calculatedSize && (
          <div className="bg-emerald-50 border border-emerald-200 p-5 space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <span className="text-xs uppercase font-mono font-bold text-emerald-950 tracking-wider">
                  Recommended Fit
                </span>
              </div>
              <span className="px-3 py-1 bg-emerald-900 text-white font-mono text-sm font-bold">
                Size {calculatedSize}
              </span>
            </div>

            <p className="text-xs text-emerald-900 leading-relaxed font-sans">{reason}</p>

            <Button
              onClick={() => {
                onSelectSize(calculatedSize);
                onClose();
              }}
              variant="primary"
              size="sm"
              fullWidth
              className="bg-emerald-900 hover:bg-emerald-950 text-white border-emerald-950"
            >
              <Check className="w-3.5 h-3.5 mr-1.5" />
              <span>Select Size {calculatedSize} for Bag</span>
            </Button>
          </div>
        )}
      </div>
    </Modal>
  );
};
