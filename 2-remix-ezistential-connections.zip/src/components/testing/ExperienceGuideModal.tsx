import React from 'react';
import { X, ShoppingBag, Truck, MessageSquare, ShieldCheck, ArrowRight, Compass } from 'lucide-react';
import { Button } from '../ui/Button';
import { useContent } from '../../context/ContentContext';

export interface ExperienceGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string, param?: string) => void;
  onOpenManifesto: () => void;
  onOpenSizeGuide: () => void;
}

export const ExperienceGuideModal: React.FC<ExperienceGuideModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenManifesto,
  onOpenSizeGuide,
}) => {
  const { content } = useContent();
  const brand = content.brandName || 'Ezistential Connection';
  if (!isOpen) return null;

  const journeys = [
    {
      title: '1. Brand Narrative & Origin',
      desc: 'Explore the founding story born on election night in November 2008 and the core thesis that distance between people is man-made.',
      actionLabel: 'Read Our Story',
      onClick: () => {
        onNavigate('our-story');
        onClose();
      },
      icon: Compass,
    },
    {
      title: '2. The Brand Manifesto',
      desc: 'Read the full 5-stanza philosophical creed on why difference is not a defect, but where human consciousness awakens.',
      actionLabel: 'View Manifesto',
      onClick: () => {
        onOpenManifesto();
        onClose();
      },
      icon: Compass,
    },
    {
      title: '3. Garment Architecture & Two Stories',
      desc: 'Experience The Distance Tee with dual Story A (the philosophy) and Story B (heavyweight 6.5oz ring-spun cotton specs).',
      actionLabel: 'View The Distance Tee',
      onClick: () => {
        onNavigate('product', 'the-distance-tee');
        onClose();
      },
      icon: ShoppingBag,
    },
    {
      title: '4. Order Tracking Self-Service',
      desc: 'Look up live on-demand production and USPS transit stages with sample demo order #SN-EC-DEMO-2026 (Email: marcus@example.com) or custom placed orders.',
      actionLabel: 'Track Order #SN-EC-DEMO-2026',
      onClick: () => {
        onNavigate('track-order');
        onClose();
      },
      icon: Truck,
    },
    {
      title: '5. Community Reflection Archive',
      desc: 'Explore curated community reflections answering "What does this mean to you?" and submit your own reflection.',
      actionLabel: 'Explore Reflections',
      onClick: () => {
        onNavigate('connection');
        onClose();
      },
      icon: MessageSquare,
    },
    {
      title: '6. Operations & Admin Cockpit',
      desc: 'Access the merchant backend to manage on-demand Apliiq orders, print packing slips, edit CMS copy, and inspect SEO social cards.',
      actionLabel: 'Open Admin Cockpit',
      onClick: () => {
        onNavigate('admin');
        onClose();
      },
      icon: ShieldCheck,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-2xl bg-white border border-neutral-300 p-6 sm:p-8 space-y-6 shadow-2xl z-10 max-h-[90vh] overflow-y-auto animate-in fade-in duration-200">
        <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
          <div>
            <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
              Stage 9 • System Tour & Experience Guide
            </span>
            <h2 className="font-serif text-2xl text-neutral-900 tracking-tight">
              Interactive Storefront Pathways
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-black cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-neutral-600 leading-relaxed font-sans">
          Select any experiential pathway below to instantly explore the philosophical narrative, on-demand commercial features, or operational management tools built into {brand}.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {journeys.map((j, idx) => {
            const Icon = j.icon;
            return (
              <div
                key={idx}
                className="p-4 bg-[#fbfbf9] border border-neutral-200 hover:border-black transition-colors space-y-2 flex flex-col justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center space-x-2 text-neutral-800">
                    <Icon className="w-4 h-4 text-neutral-900 shrink-0" />
                    <h3 className="font-serif font-medium text-sm text-neutral-900">
                      {j.title}
                    </h3>
                  </div>
                  <p className="text-[11px] text-neutral-600 leading-relaxed font-sans">
                    {j.desc}
                  </p>
                </div>

                <div className="pt-2">
                  <button
                    onClick={j.onClick}
                    className="w-full text-left text-xs font-mono uppercase tracking-wider text-black font-semibold hover:underline flex items-center justify-between pt-1 border-t border-neutral-200 cursor-pointer"
                  >
                    <span>{j.actionLabel}</span>
                    <ArrowRight className="w-3 h-3 text-neutral-600" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="border-t border-neutral-200 pt-4 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 gap-2">
          <span>Admin Access Passcode: <code className="font-mono text-neutral-900 font-bold bg-neutral-100 px-1.5 py-0.5 border border-neutral-300">connections2008</code></span>
          <Button onClick={onClose} variant="primary" size="sm">
            Close Guide
          </Button>
        </div>
      </div>
    </div>
  );
};
