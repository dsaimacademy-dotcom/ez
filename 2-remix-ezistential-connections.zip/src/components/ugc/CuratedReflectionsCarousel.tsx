import React, { useState, useMemo } from 'react';
import { CustomerResponse } from '../../types';
import { safeSrc } from '../../lib/utils';
import {
  ChevronLeft,
  ChevronRight,
  MessageSquare,
  ArrowRight,
  MapPin,
  Calendar,
  CheckCircle2
} from 'lucide-react';

export interface CuratedReflectionsCarouselProps {
  responses: CustomerResponse[];
  onNavigateToProduct: (productId: string) => void;
  className?: string;
}

export const CuratedReflectionsCarousel: React.FC<CuratedReflectionsCarouselProps> = ({
  responses,
  onNavigateToProduct,
  className = '',
}) => {
  // Always sort approved reflections from latest to oldest
  const sortedResponses = useMemo(() => {
    return [...responses]
      .filter((r) => r.status === 'Approved' || r.permissionGranted)
      .sort((a, b) => {
        const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return timeB - timeA;
      });
  }, [responses]);

  const [currentIndex, setCurrentIndex] = useState(0);

  if (sortedResponses.length === 0) return null;

  const safeIndex = currentIndex % sortedResponses.length;
  const current = sortedResponses[safeIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + sortedResponses.length) % sortedResponses.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % sortedResponses.length);
  };

  // Format date helper
  const formatDate = (isoString?: string) => {
    if (!isoString) return 'Recent Encounter';
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return 'Recent Encounter';
    }
  };

  return (
    <div className={`w-full space-y-4 ${className}`}>
      {/* Carousel Top Bar: Title & Navigation Controls */}
      <div className="flex items-center justify-between gap-4 border-b border-neutral-300 pb-3">
        <div className="flex items-center space-x-2">
          <span className="w-1.5 h-1.5 rounded-full bg-neutral-900" />
          <span className="text-[11px] uppercase tracking-[0.2em] text-neutral-600 font-mono font-bold">
            Curated Reflections from the Field
          </span>
        </div>

        {/* Counter & Buttons */}
        <div className="flex items-center space-x-3">
          <span className="text-xs font-mono text-neutral-500 tracking-wider">
            <span className="font-bold text-neutral-900">
              {(safeIndex + 1).toString().padStart(2, '0')}
            </span>{' '}
            / {sortedResponses.length.toString().padStart(2, '0')}
          </span>

          <div className="flex items-center space-x-1">
            <button
              onClick={handlePrev}
              aria-label="Previous curated reflection"
              className="w-8 h-8 border border-neutral-300 hover:border-black bg-white hover:bg-neutral-100 flex items-center justify-center transition-colors cursor-pointer rounded-xs"
            >
              <ChevronLeft className="w-4 h-4 text-neutral-700" />
            </button>
            <button
              onClick={handleNext}
              aria-label="Next curated reflection"
              className="w-8 h-8 border border-neutral-300 hover:border-black bg-white hover:bg-neutral-100 flex items-center justify-center transition-colors cursor-pointer rounded-xs"
            >
              <ChevronRight className="w-4 h-4 text-neutral-700" />
            </button>
          </div>
        </div>
      </div>

      {/* Single Curated Reflection Card Display (1 per time, full width) */}
      <div className="w-full bg-white border border-neutral-300 shadow-sm overflow-hidden rounded-xs transition-all duration-300">
        <div className="grid grid-cols-1 md:grid-cols-12 items-stretch">
          {/* Left / Photo Column */}
          {current.photoUrl ? (
            <div className="md:col-span-5 relative bg-neutral-100 overflow-hidden min-h-[240px] md:min-h-[320px] border-b md:border-b-0 md:border-r border-neutral-200">
              <img
                src={safeSrc(current.photoUrl)}
                alt={`${current.authorName} wearing ${current.productName}`}
                className="w-full h-full object-cover filter contrast-105"
              />
              <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-xs text-white px-2.5 py-1 text-[9px] font-mono uppercase tracking-widest flex items-center gap-1.5 rounded-xs">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>Worn in Public</span>
              </div>
              <div className="absolute bottom-3 left-3 bg-black/75 backdrop-blur-xs text-white text-[10px] font-mono px-2.5 py-1 flex items-center gap-1.5 rounded-xs">
                <MapPin className="w-3 h-3 text-neutral-300" />
                <span>{current.authorLocation || 'Everyday Space'}</span>
              </div>
              {current.garmentOnBodySize && (
                <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-xs text-neutral-900 text-[10px] font-mono font-bold px-2 py-1 shadow-xs rounded-xs">
                  Size {current.garmentOnBodySize}
                </div>
              )}
            </div>
          ) : (
            <div className="md:col-span-4 bg-neutral-900 text-white p-6 md:p-8 flex flex-col justify-between border-b md:border-b-0 md:border-r border-neutral-800">
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 block">
                  Public Encounter #{safeIndex + 1}
                </span>
                <span className="font-serif italic text-lg text-neutral-200 block">
                  "Space Between People"
                </span>
              </div>
              <div className="pt-4 border-t border-neutral-800 font-mono text-xs text-neutral-400 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-neutral-500" />
                <span>{current.authorLocation || 'United States'}</span>
              </div>
            </div>
          )}

          {/* Right / Reflection Content Column */}
          <div className={`${current.photoUrl ? 'md:col-span-7' : 'md:col-span-8'} p-6 sm:p-8 flex flex-col justify-between space-y-6 text-left`}>
            <div className="space-y-4">
              {/* Top metadata tags */}
              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-neutral-500">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-neutral-900 text-xs">
                    {current.authorName || 'Anonymous Contemplator'}
                  </span>
                  <span>·</span>
                  <span>{current.authorLocation || 'Public Transit'}</span>
                </div>
                <div className="flex items-center space-x-1 text-neutral-400 text-[10px]">
                  <Calendar className="w-3 h-3" />
                  <span>{formatDate(current.createdAt)}</span>
                </div>
              </div>

              {/* Curated Response Quote in EB Garamond */}
              <blockquote className="font-serif italic text-base sm:text-lg md:text-xl text-neutral-900 leading-relaxed">
                "{current.response}"
              </blockquote>
            </div>

            {/* Bottom Card Footer: Product link & action */}
            <div className="pt-4 border-t border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono text-xs">
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">
                  Referenced Garment
                </span>
                <span className="font-semibold text-neutral-900">
                  {current.productName || 'The Signature Connection Tee'}
                </span>
              </div>

              {current.productId ? (
                <button
                  type="button"
                  onClick={() => onNavigateToProduct(current.productId!)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 text-white hover:bg-neutral-800 transition-colors uppercase font-mono text-[11px] tracking-wider rounded-xs cursor-pointer self-start sm:self-auto"
                >
                  <span>Examine Garment</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              ) : (
                <span className="text-neutral-500 text-[11px] uppercase tracking-wider">
                  Archival Piece
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Dot Indicators */}
      {sortedResponses.length > 1 && (
        <div className="flex items-center justify-center space-x-1.5 pt-1">
          {sortedResponses.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              aria-label={`Jump to reflection ${idx + 1}`}
              className={`h-1.5 transition-all duration-300 rounded-full cursor-pointer ${
                idx === safeIndex ? 'w-6 bg-neutral-900' : 'w-1.5 bg-neutral-300 hover:bg-neutral-500'
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
};
