import React, { useState } from 'react';
import {
  ShoppingBag,
  Menu,
  X,
  User as UserIcon,
  Package,
  Heart,
  MessageSquare,
  MapPin,
  LogOut,
  ChevronRight,
  LayoutDashboard,
  Settings,
  Film,
  FileText,
  HelpCircle,
  Truck,
  ShieldCheck,
  Building2
} from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { useContent } from '../../context/ContentContext';
import { Logo } from '../brand/Logo';
import { Drawer } from '../ui/Drawer';
import { cn } from '../../lib/utils';
import { FEATURE_FLAGS } from '../../config/featureFlags';

export interface HeaderProps {
  currentView: string;
  onNavigate: (view: string, param?: string) => void;
  onOpenAuth?: () => void;
  onOpenGuide?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentView, onNavigate, onOpenAuth }) => {
  const { content } = useContent();
  const { totalCount, openCart } = useCart();
  const { user, isAuthenticated, logout } = useAuth();
  const [siteMenuDrawerOpen, setSiteMenuDrawerOpen] = useState(false);
  const [accountDrawerOpen, setAccountDrawerOpen] = useState(false);
  const savedGarments = user?.savedGarments;

  // Extract Configurable Navigation Menu Items from ContentContext
  const allNavItems = content.navigationMenuItems || [];
  const showHeaderMenu = content.showHeaderMenu !== false;

  // Active status of systems
  const isJournalActive = content.enableJournal !== false && FEATURE_FLAGS.showJournal;
  const isReflectionsActive = content.enableReflections !== false && FEATURE_FLAGS.showHumanExchangeArchive;
  const isEcosystemActive = content.enableEcosystem !== false && FEATURE_FLAGS.showEcEcosystem;
  const isVerificationActive = content.enableMemberVerification !== false && content.memberVerificationRules?.enabled !== false;

  // Active Header Links (shown on desktop top bar and mobile drawer)
  const headerNavLinks = showHeaderMenu
    ? allNavItems
        .filter((item) => {
          if (!item.showInHeader || item.location === 'hidden') return false;
          if (item.id === 'updates' && !isJournalActive) return false;
          if (item.id === 'connection' && !isReflectionsActive) return false;
          if (item.id === 'ecosystem' && !isEcosystemActive) return false;
          return true;
        })
        .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0))
    : [];

  // Fallback if header menu has items or legacy fallback (including Our Story & FAQ)
  const primaryNavLinks = headerNavLinks.length > 0
    ? headerNavLinks.map((item) => {
        let label = item.customLabel || item.label;
        if (item.id === 'faq' && (label === 'FAQ & Care' || label === 'FAQ and Care')) {
          label = 'FAQ';
        }
        return { id: item.id, label };
      })
    : showHeaderMenu
    ? [
        { id: 'home', label: 'Home' },
        { id: 'shop', label: 'Garments' },
        { id: 'collections', label: 'Collections' },
        { id: 'our-story', label: 'Our Story' },
        ...(FEATURE_FLAGS.showFaqInTopNav ? [{ id: 'faq', label: 'FAQ' }] : []),
      ]
    : [];

  // Secondary Links for Mobile Drawer (items configured for mobile or not in primary header)
  const drawerLinks = allNavItems
    .filter((item) => {
      if (item.location === 'hidden' || item.showInMobileDrawer === false) return false;
      if (item.id === 'updates' && !isJournalActive) return false;
      if (item.id === 'connection' && !isReflectionsActive) return false;
      if (item.id === 'ecosystem' && !isEcosystemActive) return false;
      return true;
    })
    .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0))
    .map((item) => ({ id: item.id, label: item.customLabel || item.label }));


  const handleLinkClick = (viewId: string, param?: string) => {
    if (viewId === 'account' && !isAuthenticated) {
      if (onOpenAuth) {
        onOpenAuth();
      } else {
        onNavigate('account', param);
      }
      setSiteMenuDrawerOpen(false);
      setAccountDrawerOpen(false);
      return;
    }
    onNavigate(viewId, param);
    setSiteMenuDrawerOpen(false);
    setAccountDrawerOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getInitials = (name: string) => {
    if (!name) return 'EC';
    const parts = name.split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#fbfbf9]/95 backdrop-blur-md border-b border-[#e5e5e5] transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20 gap-4 sm:gap-6 lg:gap-8">
            {/* Left: Mobile Navigation Hamburger (Opens Site Top Menu ONLY) & Brand Logo */}
            <div className="flex items-center space-x-2.5 sm:space-x-3 shrink-0">
              <button
                onClick={() => setSiteMenuDrawerOpen(true)}
                className="lg:hidden p-2 -ml-2 text-neutral-800 hover:text-black focus:outline-hidden flex items-center justify-center rounded-xs transition-colors cursor-pointer"
                aria-label="Open site menu"
                title="Open navigation menu"
              >
                <Menu className="w-5 h-5 sm:w-6 sm:h-6 stroke-[1.5]" />
              </button>

              <button
                onClick={() => handleLinkClick('home')}
                className="group text-left focus:outline-hidden inline-flex items-center cursor-pointer"
              >
                <Logo variant="black" className="h-8 sm:h-11 w-auto" />
              </button>
            </div>

            {/* Desktop Top Bar Navigation with Centered Positioning and Ample Clearance */}
            <nav className="hidden lg:flex items-center justify-center space-x-5 xl:space-x-7 2xl:space-x-8 mx-auto px-4 lg:px-6">
              {primaryNavLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={cn(
                    'text-xs uppercase tracking-wider transition-colors py-1 cursor-pointer font-medium relative',
                    currentView === link.id
                      ? 'text-black font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[1.5px] after:bg-black'
                      : 'text-neutral-600 hover:text-black'
                  )}
                >
                  {link.label}
                </button>
              ))}
            </nav>

            {/* Right Utilities: Track Order, Member Account, Wishlist, Cart */}
            <div className="flex items-center space-x-1 sm:space-x-2.5 shrink-0">
              {/* Track Order Button: Close to account icon; on mobile, account comes after Track */}
              <button
                onClick={() => handleLinkClick('track-order')}
                className="flex items-center space-x-1 sm:space-x-1.5 py-1.5 px-2 sm:px-2.5 text-xs uppercase tracking-wider text-neutral-700 hover:text-black hover:bg-neutral-100/80 transition-colors cursor-pointer rounded-xs"
                aria-label="Track order"
                title="Track order"
              >
                <Truck className="w-4 h-4 sm:w-4 sm:h-4 stroke-[1.5] text-neutral-700 shrink-0" />
                <span className="hidden sm:inline font-mono text-[11px]">Track</span>
              </button>

              {/* Member Account Button (Opens User Account Drawer ONLY; responsive touch target & font size across all devices) */}
              <button
                onClick={() => setAccountDrawerOpen(true)}
                className="flex items-center space-x-1.5 sm:space-x-2 py-2 px-2 sm:px-3 text-xs sm:text-sm uppercase tracking-wider text-neutral-800 hover:text-black hover:bg-neutral-100 rounded-xs transition-colors cursor-pointer min-h-[44px] min-w-[44px] justify-center"
                aria-label="Member account menu"
                title="Member account & preferences"
              >
                {isAuthenticated && user ? (
                  <>
                    {user.avatarUrl ? (
                      <img
                        src={user.avatarUrl}
                        alt={user.fullName}
                        className="w-6 h-6 sm:w-7 sm:h-7 rounded-full object-cover border border-neutral-300 shrink-0"
                      />
                    ) : (
                      <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-black text-white font-serif text-xs flex items-center justify-center shrink-0">
                        {getInitials(user.fullName)}
                      </div>
                    )}
                    <span className="hidden sm:inline font-mono text-xs font-medium max-w-[70px] sm:max-w-none truncate">
                      {user.fullName.split(' ')[0]}
                    </span>
                  </>
                ) : (
                  <>
                    <UserIcon className="w-5 h-5 stroke-[1.5] text-neutral-800 shrink-0" />
                    <span className="hidden sm:inline font-mono text-xs font-medium">Account</span>
                  </>
                )}
              </button>

              {/* WISHLIST BUTTON */}
              <button
                onClick={() => handleLinkClick('account', 'wishlist')}
                className="relative p-2 text-neutral-800 hover:text-black transition-colors flex items-center justify-center min-h-[44px] min-w-[44px] focus:outline-hidden group cursor-pointer"
                aria-label="View contemplation wishlist"
                title="Wishlist"
              >
                <Heart className="w-5 h-5 stroke-[1.5] group-hover:scale-105 transition-transform" />
                {savedGarments && savedGarments.length > 0 && (
                  <span className="text-[10px] font-mono font-medium tracking-tight bg-neutral-900 text-white rounded-full min-w-4 h-4 px-1 inline-flex items-center justify-center absolute top-1 right-1">
                    {savedGarments.length}
                  </span>
                )}
              </button>

              {/* CART BUTTON */}
              <button
                onClick={openCart}
                className="relative p-2 text-neutral-900 hover:text-black transition-colors flex items-center justify-center space-x-1.5 min-h-[44px] min-w-[44px] focus:outline-hidden group cursor-pointer"
                aria-label="View bag"
              >
                <ShoppingBag className="w-5 h-5 stroke-[1.5] group-hover:scale-105 transition-transform" />
                <span className="text-xs font-mono font-medium tracking-tight bg-neutral-900 text-white rounded-full min-w-5 h-5 px-1.5 inline-flex items-center justify-center">
                  {totalCount}
                </span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* 1. LEFT HAMBURGER: SITE TOP MENU ONLY */}
      <Drawer
        isOpen={siteMenuDrawerOpen}
        onClose={() => setSiteMenuDrawerOpen(false)}
        position="left"
        widthClass="w-full sm:max-w-sm md:max-w-md"
        noPadding
      >
        <div className="flex flex-col h-full overflow-y-auto">
          {/* Drawer Top Header */}
          <div className="p-5 sm:p-6 bg-[#f5f4f0] border-b border-neutral-200 flex items-center justify-between">
            <button
              onClick={() => handleLinkClick('home')}
              className="text-left focus:outline-hidden inline-flex items-center cursor-pointer"
            >
              <Logo variant="black" className="h-9 sm:h-10 w-auto" />
            </button>
            <button
              onClick={() => setSiteMenuDrawerOpen(false)}
              className="p-2 text-neutral-500 hover:text-black transition-colors cursor-pointer"
              aria-label="Close navigation menu"
            >
              <X className="w-5 h-5 stroke-[1.5]" />
            </button>
          </div>

          {/* Site Top Menu Links Only */}
          <div className="p-5 sm:p-6 space-y-6 grow">
            <div className="space-y-1.5">
              <span className="text-xs font-mono uppercase tracking-widest text-neutral-400 font-bold block mb-3">
                Store Navigation
              </span>
              {primaryNavLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={cn(
                    'w-full py-3 px-3.5 text-left text-sm uppercase tracking-wider transition-colors flex items-center justify-between rounded-xs cursor-pointer min-h-[46px]',
                    currentView === link.id
                      ? 'bg-neutral-900 text-white font-bold'
                      : 'text-neutral-800 hover:bg-neutral-100 font-medium'
                  )}
                >
                  <span>{link.label}</span>
                  <ChevronRight className={cn('w-4 h-4', currentView === link.id ? 'text-white' : 'text-neutral-400')} />
                </button>
              ))}
            </div>

            {/* Additional Brand Explorations & Direct Pages */}
            <div className="pt-5 border-t border-neutral-200 space-y-1.5 text-sm">
              <span className="text-xs font-mono uppercase tracking-widest text-neutral-400 font-bold block mb-2.5">
                Brand Explorations
              </span>
              {[
                { id: 'why-we-exist', label: 'Why We Exist' },
                { id: 'manifesto', label: 'The Manifesto' },
                ...(isJournalActive ? [{ id: 'updates', label: 'Journal & Dispatches' }] : []),
                ...(isReflectionsActive ? [{ id: 'connection', label: 'Connection Archive' }] : []),
                { id: 'contact', label: 'Customer Care' },
              ]
                .filter((item) => !primaryNavLinks.some((p) => p.id === item.id))
                .map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleLinkClick(item.id)}
                    className={cn(
                      'w-full py-3 px-3.5 text-left transition-colors flex items-center justify-between rounded-xs cursor-pointer min-h-[44px]',
                      currentView === item.id
                        ? 'font-bold text-black bg-neutral-100'
                        : 'text-neutral-700 hover:text-black hover:bg-neutral-100/70'
                    )}
                  >
                    <span>{item.label}</span>
                    <ChevronRight className="w-4 h-4 text-neutral-400" />
                  </button>
                ))}
            </div>
          </div>

          {/* Quick Footer Shortcuts: Bag & Track Order */}
          <div className="p-5 sm:p-6 bg-[#f5f4f0] border-t border-neutral-200 space-y-3 shrink-0">
            <button
              onClick={() => {
                setSiteMenuDrawerOpen(false);
                openCart();
              }}
              className="w-full py-3.5 px-4 bg-black text-white hover:bg-neutral-800 text-xs sm:text-sm font-mono uppercase tracking-wider flex items-center justify-between transition-colors cursor-pointer min-h-[48px]"
            >
              <span className="flex items-center gap-2.5">
                <ShoppingBag className="w-4 h-4" />
                <span>Shopping Bag</span>
              </span>
              <span className="bg-white/20 px-2.5 py-0.5 rounded text-xs font-mono">
                {totalCount} items
              </span>
            </button>

            <button
              onClick={() => handleLinkClick('track-order')}
              className="w-full py-3 px-4 bg-white border border-neutral-300 hover:border-black text-xs sm:text-sm font-mono text-neutral-800 flex items-center justify-between transition-colors cursor-pointer min-h-[46px]"
            >
              <span className="flex items-center gap-2.5">
                <Truck className="w-4 h-4 text-neutral-600" />
                <span>Track My Order</span>
              </span>
              <ChevronRight className="w-4 h-4 text-neutral-400" />
            </button>
          </div>
        </div>
      </Drawer>

      {/* 2. RIGHT USER ICON: USER ACCOUNT LINKS ONLY - FULLY RESPONSIVE ACROSS ALL DEVICES */}
      <Drawer
        isOpen={accountDrawerOpen}
        onClose={() => setAccountDrawerOpen(false)}
        position="right"
        widthClass="w-full sm:max-w-md md:max-w-lg"
        noPadding
      >
        <div className="flex flex-col h-full h-[100dvh] overflow-y-auto divide-y divide-neutral-200">
          {/* Header / Member Profile or Sign In CTA */}
          <div className="p-5 sm:p-6 bg-[#f5f4f0] space-y-4 shrink-0">
            {isAuthenticated && user ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  {user.role === 'admin' || user.role === 'superadmin' ? (
                    <span className="text-xs font-mono uppercase tracking-widest bg-neutral-900 text-white px-2.5 py-1 border border-neutral-800 font-semibold">
                      Curator Admin
                    </span>
                  ) : (
                    <span className="text-xs font-mono uppercase tracking-widest bg-neutral-100 text-neutral-800 px-2.5 py-1 border border-neutral-300 font-semibold">
                      Member
                    </span>
                  )}
                  <button
                    onClick={() => setAccountDrawerOpen(false)}
                    className="p-2 -mr-2 text-neutral-600 hover:text-black transition-colors cursor-pointer rounded-xs min-h-[44px] min-w-[44px] flex items-center justify-center"
                    aria-label="Close account panel"
                  >
                    <X className="w-5 h-5 sm:w-6 sm:h-6" />
                  </button>
                </div>

                <div className="flex items-center space-x-3.5 sm:space-x-4">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.fullName}
                      className="w-13 h-13 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-neutral-300 shadow-xs shrink-0"
                    />
                  ) : (
                    <div className="w-13 h-13 sm:w-16 sm:h-16 rounded-full bg-black text-white font-serif text-lg sm:text-xl flex items-center justify-center shrink-0">
                      {getInitials(user.fullName)}
                    </div>
                  )}
                  <div className="space-y-1 min-w-0">
                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-neutral-900 truncate">
                      {user.fullName}
                    </h3>
                    <p className="text-xs sm:text-sm font-mono text-neutral-500 truncate">{user.email}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase tracking-widest text-neutral-500 font-bold">
                    Member Account
                  </span>
                  <button
                    onClick={() => setAccountDrawerOpen(false)}
                    className="p-2 -mr-2 text-neutral-600 hover:text-black transition-colors cursor-pointer rounded-xs min-h-[44px] min-w-[44px] flex items-center justify-center"
                    aria-label="Close account panel"
                  >
                    <X className="w-5 h-5 sm:w-6 sm:h-6" />
                  </button>
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-neutral-900 leading-tight">
                  Welcome to Your Account
                </h3>
                <p className="text-sm text-neutral-600 font-sans leading-relaxed">
                  Sign in to access your order history, saved garments
                  {isVerificationActive ? ', verified wearer status' : ''}
                  {isReflectionsActive ? ', and personal reflections.' : '.'}
                </p>
                {onOpenAuth && (
                  <button
                    onClick={() => {
                      setAccountDrawerOpen(false);
                      onOpenAuth();
                    }}
                    className="w-full py-3.5 px-4 bg-black text-white hover:bg-neutral-800 text-xs sm:text-sm font-mono uppercase tracking-wider flex items-center justify-center space-x-2 transition-colors cursor-pointer min-h-[48px]"
                  >
                    <UserIcon className="w-4 h-4" />
                    <span>Sign In or Create Account</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* User Account Links ONLY */}
          <div className="p-5 sm:p-6 space-y-3 bg-white grow">
            <h4 className="text-xs uppercase font-mono tracking-widest text-neutral-400 font-bold mb-3">
              Account Navigation
            </h4>

            <div className="space-y-2">
              <button
                onClick={() => handleLinkClick('account', 'overview')}
                className="w-full py-3.5 px-3.5 sm:px-4 text-left text-sm sm:text-base font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer min-h-[48px]"
              >
                <span className="flex items-center space-x-3">
                  <LayoutDashboard className="w-5 h-5 text-neutral-600 shrink-0" />
                  <span className="font-medium">Personal Dashboard Hub</span>
                </span>
                <ChevronRight className="w-4 h-4 text-neutral-400" />
              </button>

              {isVerificationActive && (
                <button
                  onClick={() => handleLinkClick('account', 'verification')}
                  className="w-full py-3 sm:py-3.5 px-3.5 sm:px-4 text-left text-sm sm:text-base font-sans text-neutral-800 hover:bg-amber-100/50 flex items-center justify-between transition-colors rounded-xs cursor-pointer bg-amber-50/70 border border-amber-200/80 min-h-[48px]"
                >
                  <span className="flex items-center space-x-3">
                    <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0" />
                    <span className="font-medium text-amber-950">Member Verification</span>
                  </span>
                  <ChevronRight className="w-4 h-4 text-amber-700" />
                </button>
              )}

              <button
                onClick={() => handleLinkClick('account', 'orders')}
                className="w-full py-3 sm:py-3.5 px-3.5 sm:px-4 text-left text-sm sm:text-base font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer min-h-[48px]"
              >
                <span className="flex items-center space-x-3">
                  <Package className="w-5 h-5 text-neutral-600 shrink-0" />
                  <span>Orders & POD Tracking</span>
                </span>
                <ChevronRight className="w-4 h-4 text-neutral-400" />
              </button>

              <button
                onClick={() => handleLinkClick('account', 'wishlist')}
                className="w-full py-3 sm:py-3.5 px-3.5 sm:px-4 text-left text-sm sm:text-base font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer min-h-[48px]"
              >
                <span className="flex items-center space-x-3">
                  <Heart className="w-5 h-5 text-neutral-600 shrink-0" />
                  <span>Wishlist (Saved Garments)</span>
                </span>
                {user && user.savedGarments && user.savedGarments.length > 0 && (
                  <span className="text-xs font-mono bg-neutral-100 text-neutral-800 px-2.5 py-0.5 border border-neutral-300 font-semibold">
                    {user.savedGarments.length}
                  </span>
                )}
              </button>

              {isReflectionsActive && (
                <button
                  onClick={() => handleLinkClick('account', 'reflections')}
                  className="w-full py-3 sm:py-3.5 px-3.5 sm:px-4 text-left text-sm sm:text-base font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer min-h-[48px]"
                >
                  <span className="flex items-center space-x-3">
                    <MessageSquare className="w-5 h-5 text-neutral-600 shrink-0" />
                    <span>My Reflections</span>
                  </span>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>
              )}

              <button
                onClick={() => handleLinkClick('account', 'addresses')}
                className="w-full py-3 sm:py-3.5 px-3.5 sm:px-4 text-left text-sm sm:text-base font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer min-h-[48px]"
              >
                <span className="flex items-center space-x-3">
                  <MapPin className="w-5 h-5 text-neutral-600 shrink-0" />
                  <span>Shipping Address Book</span>
                </span>
                {user && user.addresses && user.addresses.length > 0 && (
                  <span className="text-xs font-mono bg-neutral-100 text-neutral-800 px-2.5 py-0.5 border border-neutral-300 font-semibold">
                    {user.addresses.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => handleLinkClick('account', 'settings')}
                className="w-full py-3 sm:py-3.5 px-3.5 sm:px-4 text-left text-sm sm:text-base font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer min-h-[48px]"
              >
                <span className="flex items-center space-x-3">
                  <Settings className="w-5 h-5 text-neutral-600 shrink-0" />
                  <span>Account Settings</span>
                </span>
                <ChevronRight className="w-4 h-4 text-neutral-400" />
              </button>
            </div>

            {/* Admin Portal Quick Access (Admin Only) */}
            {isAuthenticated && user && (user.role === 'admin' || user.role === 'superadmin' || user.email.includes('admin')) && (
              <div className="pt-4 mt-4 border-t border-amber-200">
                <div className="p-3.5 bg-amber-50 border border-amber-200 space-y-2 rounded-xs">
                  <span className="text-[11px] font-mono uppercase tracking-widest text-amber-800 font-bold block">
                    Curator Access
                  </span>
                  <button
                    onClick={() => handleLinkClick('admin')}
                    className="w-full py-2.5 px-3.5 bg-black text-white hover:bg-neutral-800 text-xs sm:text-sm font-mono uppercase tracking-wider flex items-center justify-between transition-colors cursor-pointer min-h-[44px]"
                  >
                    <span>Open Admin Portal</span>
                    <ChevronRight className="w-4 h-4 text-amber-300" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Drawer Footer / Sign Out */}
          {isAuthenticated && (
            <div className="p-5 sm:p-7 bg-[#f5f4f0] shrink-0 border-t border-neutral-200">
              <button
                onClick={() => {
                  logout();
                  setAccountDrawerOpen(false);
                }}
                className="w-full py-3.5 px-4 text-left text-xs sm:text-sm font-mono text-red-700 hover:bg-red-50 hover:text-red-900 border border-red-200 flex items-center justify-center space-x-2 transition-colors cursor-pointer min-h-[48px]"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out of Personal Account</span>
              </button>
            </div>
          )}
        </div>
      </Drawer>
    </>
  );
};
