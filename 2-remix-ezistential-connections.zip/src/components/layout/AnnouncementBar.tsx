import React from 'react';
import { useContent } from '../../context/ContentContext';

export interface AnnouncementBarProps {
  onOpenGuide?: () => void;
}

export const AnnouncementBar: React.FC<AnnouncementBarProps> = () => {
  const { content } = useContent();

  if (!content.announcementActive) return null;

  return (
    <div className="bg-[#0a0a0a] text-[#fbfbf9] text-[10px] sm:text-[11px] uppercase tracking-wider sm:tracking-widest py-1.5 sm:py-2 px-3 sm:px-4 font-medium border-b border-[#262626] flex items-center justify-center relative select-none leading-snug sm:leading-normal">
      {/* Center Announcement Text - Guaranteed Max 2 lines on mobile */}
      <div className="flex items-center justify-center space-x-2 mx-auto max-w-md sm:max-w-none text-center">
        <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shrink-0" />
        <span className="line-clamp-2 sm:line-clamp-none">
          {content.announcementText || `${content.brandName || 'Ezistential Connection'} · Human Recognition Apparel`}
        </span>
      </div>
    </div>
  );
};
