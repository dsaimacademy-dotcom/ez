import React, { useState, useEffect } from 'react';
import { ShieldCheck, X, Sliders } from 'lucide-react';
import { Button } from '../ui/Button';
import { useContent } from '../../context/ContentContext';

export const COOKIE_CONSENT_KEY = 'ec_cookie_consent_v1';

export interface CookieConsentBannerProps {
  onNavigateToPrivacy?: () => void;
}

export const CookieConsentBanner: React.FC<CookieConsentBannerProps> = ({ onNavigateToPrivacy }) => {
  const { content } = useContent();
  const [isVisible, setIsVisible] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);

  const [analyticsConsent, setAnalyticsConsent] = useState(false);
  const [reflectionSyncConsent, setReflectionSyncConsent] = useState(true);

  useEffect(() => {
    try {
      const savedConsent = localStorage.getItem(COOKIE_CONSENT_KEY);
      if (!savedConsent && content.enableCookieConsentBanner !== false) {
        // Small delay for smooth entry
        const timer = setTimeout(() => setIsVisible(true), 600);
        return () => clearTimeout(timer);
      }
    } catch {
      // ignore
    }
  }, [content.enableCookieConsentBanner]);

  if (!isVisible || content.enableCookieConsentBanner === false) return null;

  const notifyConsentUpdated = () => {
    try {
      window.dispatchEvent(new Event('ec_cookie_consent_updated'));
    } catch {}
  };

  const handleAcceptAll = () => {
    try {
      localStorage.setItem(
        COOKIE_CONSENT_KEY,
        JSON.stringify({
          essential: true,
          reflectionSync: true,
          analytics: true,
          timestamp: new Date().toISOString(),
        })
      );
    } catch {}
    notifyConsentUpdated();
    setIsVisible(false);
  };

  const handleEssentialOnly = () => {
    try {
      localStorage.setItem(
        COOKIE_CONSENT_KEY,
        JSON.stringify({
          essential: true,
          reflectionSync: true,
          analytics: false,
          timestamp: new Date().toISOString(),
        })
      );
    } catch {}
    notifyConsentUpdated();
    setIsVisible(false);
  };

  const handleSaveCustom = () => {
    try {
      localStorage.setItem(
        COOKIE_CONSENT_KEY,
        JSON.stringify({
          essential: true,
          reflectionSync: reflectionSyncConsent,
          analytics: analyticsConsent,
          timestamp: new Date().toISOString(),
        })
      );
    } catch {}
    notifyConsentUpdated();
    setIsVisible(false);
  };

  return (
    <div
      role="region"
      aria-label="Privacy & Consent"
      className="fixed bottom-0 inset-x-0 z-50 p-2 sm:p-4 md:p-6 pb-[max(0.75rem,env(safe-area-inset-bottom))] pointer-events-none animate-in fade-in slide-in-from-bottom-4 duration-300"
    >
      <div className="max-w-3xl mx-auto w-full bg-[#141414] text-white border border-[#333333] shadow-2xl p-3.5 sm:p-5 pointer-events-auto relative max-h-[85vh] sm:max-h-[80vh] flex flex-col overflow-hidden">
        {/* Scrollable body on small mobile screens */}
        <div className="overflow-y-auto overscroll-contain pr-1 -mr-1 space-y-3 sm:space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start space-x-3 min-w-0">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-neutral-900 border border-neutral-700 flex items-center justify-center shrink-0 mt-0.5">
                <ShieldCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-neutral-300 stroke-[1.5]" />
              </div>
              <div className="space-y-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <span className="text-[9px] sm:text-[10px] uppercase font-mono tracking-widest text-neutral-400 truncate">
                    Digital Dignity & Privacy Covenant
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                </div>
                <h3 className="font-serif text-sm sm:text-base text-white tracking-tight leading-snug">
                  {content.cookieBannerHeadline || 'We believe your attention and data belong to you.'}
                </h3>
                <p className="text-[11px] sm:text-xs text-neutral-400 font-sans leading-relaxed">
                  {content.cookieBannerDescription ||
                    `${content.brandName || 'Ezistential Connection'} uses strictly essential session integrity to preserve your garment bag, customer account, and made-to-order inquiries. We categorically reject surveillance ad networks, data brokers, and third-party tracking pixels.`}
                </p>
              </div>
            </div>

            <button
              onClick={handleEssentialOnly}
              className="p-1.5 -mr-1 -mt-1 text-neutral-400 hover:text-white transition-colors cursor-pointer min-w-[36px] min-h-[36px] flex items-center justify-center shrink-0"
              aria-label="Dismiss banner with essential cookies only"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Customizable Preferences Accordion */}
          {showPreferences && (
            <div className="pt-3 border-t border-neutral-800 space-y-2.5 animate-in fade-in duration-200">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3 text-xs">
                <div className="bg-neutral-900/90 p-2.5 sm:p-3 border border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-white text-[12px]">Essential Session</span>
                    <span className="text-[9px] font-mono text-neutral-400 bg-neutral-800 px-1.5 py-0.5">Required</span>
                  </div>
                  <p className="text-[11px] text-neutral-400 leading-normal">
                    Preserves your garment bag, member sign-in, and made-to-order preferences.
                  </p>
                </div>

                <div className="bg-neutral-900/90 p-2.5 sm:p-3 border border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <label htmlFor="ref-sync" className="font-medium text-white text-[12px] cursor-pointer">
                      Community Reflections
                    </label>
                    <input
                      id="ref-sync"
                      type="checkbox"
                      checked={reflectionSyncConsent}
                      onChange={(e) => setReflectionSyncConsent(e.target.checked)}
                      className="accent-white cursor-pointer w-4 h-4"
                    />
                  </div>
                  <p className="text-[11px] text-neutral-400 leading-normal">
                    Enables contributing reflections to the public Human Connection archive.
                  </p>
                </div>

                <div className="bg-neutral-900/90 p-2.5 sm:p-3 border border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <label htmlFor="anon-telemetry" className="font-medium text-white text-[12px] cursor-pointer">
                      Anonymous Telemetry
                    </label>
                    <input
                      id="anon-telemetry"
                      type="checkbox"
                      checked={analyticsConsent}
                      onChange={(e) => setAnalyticsConsent(e.target.checked)}
                      className="accent-white cursor-pointer w-4 h-4"
                    />
                  </div>
                  <p className="text-[11px] text-neutral-400 leading-normal">
                    Aggregated performance metrics with zero cross-site tracking or profiling.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Controls Footer */}
        <div className="mt-3 pt-3 border-t border-neutral-800/80 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-neutral-400 text-[11px] sm:text-xs">
            <button
              type="button"
              onClick={() => setShowPreferences(!showPreferences)}
              className="text-neutral-300 hover:text-white underline underline-offset-2 flex items-center gap-1 cursor-pointer font-medium py-1"
            >
              <Sliders className="w-3 h-3" />
              <span>{showPreferences ? 'Hide Options' : 'Customize Preferences'}</span>
            </button>
            <span className="hidden xs:inline">•</span>
            {onNavigateToPrivacy && (
              <button
                type="button"
                onClick={onNavigateToPrivacy}
                className="text-neutral-400 hover:text-neutral-200 underline underline-offset-2 cursor-pointer py-1"
              >
                Read Digital Dignity Policy
              </button>
            )}
          </div>

          <div className="flex flex-col-reverse xs:flex-row items-stretch xs:items-center gap-2 w-full sm:w-auto shrink-0">
            {showPreferences ? (
              <Button
                onClick={handleSaveCustom}
                variant="primary"
                size="sm"
                className="w-full xs:w-auto bg-white text-black hover:bg-neutral-200 min-h-[40px] px-4 py-2 text-xs font-mono uppercase tracking-wider font-semibold justify-center"
              >
                Save Preferences
              </Button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={handleEssentialOnly}
                  className="w-full xs:w-auto px-4 py-2 border border-neutral-700 hover:border-neutral-500 text-neutral-300 hover:text-white transition-colors cursor-pointer text-xs font-mono uppercase tracking-wider text-center min-h-[40px] flex items-center justify-center active:scale-98"
                >
                  Essential Only
                </button>
                <Button
                  onClick={handleAcceptAll}
                  variant="primary"
                  size="sm"
                  className="w-full xs:w-auto bg-white text-black hover:bg-neutral-200 min-h-[40px] px-4 py-2 text-xs font-mono uppercase tracking-wider font-semibold justify-center active:scale-98"
                >
                  Accept & Continue
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
