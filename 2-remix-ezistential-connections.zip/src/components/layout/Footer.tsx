import React, { useState } from 'react';
import {
  ArrowRight,
  Check,
  MapPin,
  Mail,
  Phone,
  Instagram,
  Twitter,
  Youtube,
  Music,
  Bookmark,
  Share2,
  Facebook,
  Linkedin
} from 'lucide-react';
import { Logo } from '../brand/Logo';
import { ShapeDivider } from '../ui/ShapeDivider';
import { useContent } from '../../context/ContentContext';
import { FEATURE_FLAGS } from '../../config/featureFlags';

export interface FooterProps {
  onNavigate: (view: string) => void;
  onOpenGuide?: () => void;
  onOpenIntWaitlist?: () => void;
  currentView?: string;
  precedingBg?: string;
}

const getPrecedingBg = (view?: string, customBg?: string): string => {
  if (customBg) return customBg;
  switch (view) {
    case 'why-we-exist':
    case 'our-story':
      return '#f5f4f0';
    case 'home':
    case 'manifesto':
    case 'shop':
    case 'collections':
    case 'product':
    case 'cart':
    case 'checkout':
    case 'order-confirmation':
    case 'faq':
    case 'contact':
    case 'shipping-returns':
    case 'privacy':
    case 'terms':
    case 'account':
    case 'updates':
    case 'ecosystem':
    case 'connection':
    default:
      return '#fbfbf9';
  }
};

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenGuide,
  onOpenIntWaitlist,
  currentView = 'home',
  precedingBg,
}) => {
  const { content } = useContent();
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const effectiveBg = getPrecedingBg(currentView, precedingBg);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setIsSubscribed(true);
    setEmail('');
  };

  const handleLink = (view: string) => {
    onNavigate(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Active status of systems
  const isJournalActive = content.enableJournal !== false && FEATURE_FLAGS.showJournal;
  const isReflectionsActive = content.enableReflections !== false && FEATURE_FLAGS.showHumanExchangeArchive;
  const isEcosystemActive = content.enableEcosystem !== false && FEATURE_FLAGS.showEcEcosystem;

  // Extract Navigation Menu Items configured for Footer
  const allNavItems = content.navigationMenuItems || [];
  const footerItems = allNavItems
    .filter((item) => {
      if (!item.showInFooter || item.location === 'hidden') return false;
      // Per client request: hide the connection archive and journal in footer
      if (item.id === 'updates' || item.id === 'connection') return false;
      if (item.id === 'ecosystem' && !isEcosystemActive) return false;
      return true;
    })
    .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));

  // Partition into Explore (primary/brand) and Information (secondary/legal/care)
  const exploreLinks = footerItems.filter(
    (item) => item.category === 'primary' || ['shop', 'ecosystem', 'why-we-exist', 'our-story', 'manifesto', 'connection'].includes(item.id)
  );

  const infoLinks = footerItems.filter(
    (item) => !exploreLinks.some((e) => e.id === item.id)
  );

  // Active filled socials only
  const activeSocials = [
    { label: 'Instagram', url: content.instagramUrl, icon: Instagram },
    { label: 'Twitter / X', url: content.twitterUrl, icon: Twitter },
    { label: 'Spotify', url: content.spotifyUrl, icon: Music },
    { label: 'Substack', url: content.substackUrl, icon: Bookmark },
    { label: 'YouTube', url: content.youtubeUrl, icon: Youtube },
    { label: 'Facebook', url: content.facebookUrl, icon: Facebook },
    { label: 'LinkedIn', url: content.linkedinUrl, icon: Linkedin },
    { label: 'TikTok', url: content.tiktokUrl, icon: Share2 },
    { label: 'Pinterest', url: content.pinterestUrl, icon: Bookmark },
    { label: 'Discord', url: content.discordUrl, icon: Share2 },
  ].filter((s) => s.url && s.url.trim().length > 0);

  return (
    <div className="w-full relative z-20 overflow-hidden" style={{ backgroundColor: effectiveBg }}>
      {/* Universal Architectural Shape Divider for Footer */}
      {content.shapeDividerEnabled !== false && (
        <div className="w-full leading-none pointer-events-none -mb-[1px] relative z-10" style={{ backgroundColor: effectiveBg }}>
          <ShapeDivider
            variant={content.shapeDividerVariant || 'editorial-notch'}
            fillColor="#0a0a0a"
            bgColor={effectiveBg}
            height={content.shapeDividerHeight || 54}
            position="bottom"
            className="w-full block"
          />
        </div>
      )}

      <footer className="w-full bg-[#0a0a0a] text-[#fbfbf9] pt-10 sm:pt-14 pb-12 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {/* Main 4-Column Footer Navigation Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12">
            {/* Column 1: Brand Philosophy & Statement */}
            <div className="md:col-span-4 space-y-6">
              <div>
                <Logo variant="white" className="h-10 sm:h-12 w-auto" />
              </div>
              <p className="text-neutral-400 text-sm leading-relaxed max-w-md font-sans">
                {content.heroSubheadline}
              </p>
              
              <div className="pt-2 space-y-1">
                <span className="text-[11px] uppercase tracking-widest text-neutral-500 block font-mono font-bold">
                  Founding Philosophy
                </span>
                <p className="font-serif italic text-neutral-300 text-base">
                  "{content.foundingQuote}"
                </p>
              </div>
            </div>

            {/* Column 2: Quick Navigation (Explore) */}
            {(content.showFooterMenu !== false && exploreLinks.length > 0) && (
              <div className="col-span-1 sm:col-span-1 md:col-span-2 space-y-4">
                <h4 className="text-xs uppercase tracking-widest text-neutral-400 font-mono font-bold text-left">
                  Explore
                </h4>
                <ul className="space-y-2.5 text-xs uppercase tracking-wider text-neutral-300 font-sans text-left">
                  {exploreLinks.map((item) => (
                    <li key={item.id} className="text-left">
                      <button
                        type="button"
                        onClick={() => handleLink(item.id)}
                        className="text-left inline-block hover:text-white transition-colors cursor-pointer leading-snug py-0.5"
                      >
                        {item.customLabel || item.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Column 3: Practical Customer Information */}
            {(content.showFooterMenu !== false && infoLinks.length > 0) && (
              <div className="col-span-1 sm:col-span-1 md:col-span-3 space-y-4">
                <h4 className="text-xs uppercase tracking-widest text-neutral-400 font-mono font-bold text-left">
                  Information
                </h4>
                <ul className="space-y-2.5 text-xs uppercase tracking-wider text-neutral-300 font-sans text-left">
                  {infoLinks.map((item) => (
                    <li key={item.id} className="text-left">
                      <button
                        type="button"
                        onClick={() => handleLink(item.id)}
                        className="text-left inline-block hover:text-white transition-colors cursor-pointer leading-snug py-0.5"
                      >
                        {item.customLabel || item.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Column 4: Newsletter Subscription */}
            <div className="md:col-span-3 space-y-4">
              <h4 className="text-xs uppercase tracking-widest text-neutral-400 font-medium font-mono font-bold">
                Quiet Reflections
              </h4>
              <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                Occasional dispatches on human connection, garment releases, and community stories. No noise.
              </p>

              {isSubscribed ? (
                <div className="bg-[#1f1f1f] border border-[#262626] p-3 text-xs text-neutral-300 flex items-center space-x-2 font-sans">
                  <Check className="w-4 h-4 text-white" />
                  <span>You are on the list. Thank you for connecting.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="space-y-2">
                  <div className="relative">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email"
                      required
                      className="w-full bg-[#141414] border border-[#262626] px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-hidden focus:border-neutral-400 transition-colors font-sans"
                    />
                    <button
                      type="submit"
                      className="absolute right-1.5 top-1.5 bottom-1.5 px-2.5 bg-[#262626] text-white hover:bg-neutral-700 transition-colors flex items-center justify-center cursor-pointer"
                      aria-label="Subscribe to newsletter"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-[10px] text-neutral-500 font-sans">
                    By joining, you respect our privacy covenant. Unsubscribe anytime.
                  </p>
                </form>
              )}
            </div>
          </div>

          {/* Dedicated 3-Column Contact & Social Row */}
          <div className="pt-8 border-t border-[#262626] grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs text-neutral-400">
            {/* Column 1: Studio Address */}
            <div className="flex items-start space-x-3 bg-[#121212] p-4 border border-[#222222] rounded-xs">
              <MapPin className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-mono font-bold block">
                  Studio Address
                </span>
                <span className="text-neutral-300 block">
                  {content.businessAddressStreet ? `${content.businessAddressStreet}, ` : ''}
                  {content.businessAddressCity}, {content.businessAddressState} · {content.businessAddressCountry}
                </span>
              </div>
            </div>

            {/* Column 2: Contact (Email + Call & WhatsApp) */}
            <div className="flex items-start space-x-3 bg-[#121212] p-4 border border-[#222222] rounded-xs">
              <Mail className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-mono font-bold block">
                  Direct Contact & Care
                </span>
                <div className="space-y-1">
                  <a
                    href={`mailto:${content.supportEmail}`}
                    className="text-neutral-200 hover:text-white transition-colors underline decoration-neutral-600 underline-offset-4 block"
                  >
                    {content.supportEmail}
                  </a>
                  <div className="flex items-center space-x-2 text-[11px] text-neutral-300 pt-0.5">
                    <Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                    <span>
                      Call / WhatsApp:{' '}
                      <a
                        href={`https://wa.me/${(content.businessPhone || '+13125550192').replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-neutral-200 hover:text-white font-mono underline decoration-neutral-600 underline-offset-2"
                      >
                        {content.businessPhone || '+1 (312) 555-0192'}
                      </a>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Column 3: Social Channels */}
            <div className="flex items-start space-x-3 bg-[#121212] p-4 border border-[#222222] rounded-xs">
              <Share2 className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
              <div className="space-y-1.5 w-full">
                <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-mono font-bold block">
                  Social & Channels
                </span>
                {activeSocials.length > 0 ? (
                  <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                    {activeSocials.map((soc) => {
                      const IconComp = soc.icon;
                      return (
                        <a
                          key={soc.label}
                          href={soc.url}
                          target="_blank"
                          rel="noreferrer"
                          title={soc.label}
                          className="p-1.5 bg-[#1c1c1c] hover:bg-neutral-800 text-neutral-300 hover:text-white border border-[#2a2a2a] rounded-xs transition-colors cursor-pointer inline-flex items-center justify-center"
                        >
                          <IconComp className="w-3.5 h-3.5" />
                        </a>
                      );
                    })}
                  </div>
                ) : (
                  <span className="text-neutral-400 text-xs font-mono">@ezistential</span>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Credits & Policies */}
          <div className="pt-8 flex flex-col md:flex-row items-center justify-between text-xs text-neutral-500 gap-4 font-sans">
            <div className="text-center md:text-left">
              <p>© {new Date().getFullYear()} {content.legalBusinessName || content.brandName || 'Ezistential Connection LLC'}. All rights reserved.</p>
            </div>
            <div className="flex flex-wrap items-center justify-center md:justify-end gap-x-6 gap-y-2 text-xs">
              <button
                type="button"
                onClick={() => handleLink('contact')}
                className="hover:text-neutral-300 transition-colors cursor-pointer py-1"
              >
                Studio Directory
              </button>
              <button
                type="button"
                onClick={() => handleLink('privacy')}
                className="hover:text-neutral-300 transition-colors cursor-pointer py-1 font-medium text-neutral-400"
              >
                Digital Dignity / Privacy
              </button>
              <button
                type="button"
                onClick={() => handleLink('terms')}
                className="hover:text-neutral-300 transition-colors cursor-pointer py-1"
              >
                Terms of Service
              </button>
              {onOpenIntWaitlist ? (
                <button
                  type="button"
                  onClick={onOpenIntWaitlist}
                  className="text-neutral-400 hover:text-white transition-colors cursor-pointer font-mono text-[11px] underline underline-offset-4 py-1"
                >
                  US Fulfillment (Global Waitlist 🌐)
                </button>
              ) : (
                <span className="text-neutral-600 font-mono py-1">US Domestic Fulfillment</span>
              )}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
