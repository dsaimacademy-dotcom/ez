/**
 * Ezistential Connection - Universal Domain Models
 * Structured for Stages 1 through 10 (Frontend & PHP/MySQL backend parity)
 */

export type Size = 'XS' | 'S' | 'M' | 'L' | 'XL' | '2XL' | '3XL' | string;

export interface MasterSizeItem {
  id: string;
  name: string;
  label: string;
  category?: 'Standard Adult' | 'Oversized / Boxy' | 'Unisex / Accessories' | 'Custom' | string;
  chestInch?: string;
  lengthInch?: string;
  active: boolean;
  sortOrder?: number;
}

export interface ColorItem {
  id: string;
  name: string;
  hex: string;
  category?: 'Monochrome' | 'Earth / Neutral' | 'Deep Tone' | 'Warm Tone' | 'Vibrant' | string;
  active: boolean;
}

export interface WearType {
  id: string;
  name: string;
  category: 'tee' | 'hoodie' | 'crewneck' | 'fleece' | 'accessory' | 'pant' | 'other';
  baseCost: number; // Estimated POD wholesale cost
  defaultRetailPrice: number;
  fabric: string;
  weight: string;
  fit: string;
  origin?: string;
  printTechnique?: string;
  imageTemplateUrl?: string;
  supplierSku?: string;
  active: boolean;
  supportedSizes?: Size[];
  supportedColorIds?: string[];
}

export interface ProductVariant {
  id: string;
  sku: string;
  wearTypeId: string;
  wearTypeName: string; // e.g. "6.5oz Heavyweight Boxy Tee"
  size: Size;
  sizeId?: string;
  colorId: string;
  colorName: string;
  colorHex: string;
  inStock: boolean;
  isAvailable?: boolean;
  status?: 'active' | 'inactive' | 'unsupported';
  inventoryMode?: 'pod' | 'made_to_order' | 'stocked';
  quantity?: number; // Integer quantity strictly if stocked; undefined for POD/made_to_order
  priceOverride?: number;
  podProvider?: 'apliiq' | 'printful' | 'custom';
  podProductId?: string;
  podVariantId?: string; // Apliiq / Printful variant mapping
  supplierSku?: string;
}

export interface DesignVersion {
  id: string;
  designId: string;
  versionNumber: number;
  title?: string;
  artworkUrl: string;
  mockupUrl?: string;
  conceptNotes?: string;
  suggestedWearTypeIds?: string[];
  suggestedWearTypes: string[];
  suggestedColorIds?: string[];
  suggestedColors: string[];
  suggestedSizes: Size[];
  placement?: string; // e.g. "Center Chest 12x14 DTF soft-hand"
  status?: 'draft' | 'testing' | 'approved' | 'archived';
  createdAt: string;
}

export interface DesignDraft {
  id: string;
  name: string;
  thesis: string;
  concept: string;
  status: 'draft' | 'in_testing' | 'approved' | 'pushed_to_product';
  activeVersionNumber: number;
  versions: DesignVersion[];
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface GarmentStoryA {
  headline: string;
  question: string;
  thesis: string;
  wearerRole: string;
}

export interface GarmentStoryB {
  fabric: string;
  weight: string;
  fit: string;
  origin: string;
  printTechnique: string;
  careInstructions: string[];
  productionNotes: string;
  estimatedDeliveryDays: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  price: number;
  compareAtPrice?: number;
  collectionId: string;
  isFeatured: boolean;
  isAvailable: boolean;
  sourceDesignId?: string; // Bridge to Design Factory
  sourceDesignVersionId?: string; // Bridge to Design Factory Version ID
  sourceDesignVersionNumber?: number; // Bridge to Design Factory Version Number
  readinessStatus?: 'draft' | 'ready' | 'published';
  wholesaleCost?: number;
  podProvider?: 'apliiq' | 'printful' | 'custom';
  podProductId?: string;
  importedFromApliiqAt?: string;
  storyA: GarmentStoryA; // The Idea / The Question
  storyB: GarmentStoryB; // The Practical Info
  primaryImage: string;
  galleryImages: {
    url: string;
    alt: string;
    viewType: 'front' | 'rear' | 'detail' | 'fabric' | 'editorial' | 'on-body';
  }[];
  availableWearTypeIds?: string[]; // Authoritative stable IDs
  availableWearTypes?: string[]; // Display name snapshots for backward compatibility
  variants: ProductVariant[];
  availableColorIds?: string[]; // Authoritative stable IDs
  availableColors: {
    id?: string;
    name: string;
    hex: string;
  }[];
  availableSizes: Size[];
  createdAt: string;
  updatedAt?: string;
}

export interface Collection {
  id: string;
  slug: string;
  name: string;
  subtitle: string;
  description: string;
  heroImage: string;
  isFeatured: boolean;
  displayOrder: number;
}

export interface CartItem {
  id: string; // Unique cart item ID (product.id + variant.id)
  productId: string;
  productSlug: string;
  productName: string;
  wearTypeId?: string;
  wearType?: string; // e.g. "Heavyweight Tee", "Boxy Hoodie"
  price: number;
  image: string;
  variantId: string;
  size: Size;
  sizeId?: string;
  colorId?: string;
  color: string;
  colorHex: string;
  sku?: string;
  podVariantId?: string;
  quantity: number;
}

export interface CartState {
  items: CartItem[];
  subtotal: number;
  shippingEstimate: number;
  freeShippingThreshold: number;
  isFreeShipping: boolean;
  remainingForFreeShipping: number;
}

export type OrderStatus =
  | 'Pending Payment'
  | 'Paid'
  | 'Processing'
  | 'Grace Period'
  | 'Ready for Review'
  | 'Submitted to POD'
  | 'In Production'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled'
  | 'Refunded';

export interface ShippingTier {
  id: 'standard' | 'priority' | 'express';
  name: string;
  carrier: string;
  estimatedDays: string;
  rate: number;
  isFree?: boolean;
  description: string;
}

export interface OrderItem {
  id: string;
  productId: string;
  variantId?: string;
  productName: string;
  wearTypeId?: string;
  wearTypeName?: string;
  wearType?: string; // Backward compatibility
  size: Size;
  sizeId?: string;
  colorId?: string;
  color: string;
  colorHex?: string;
  price: number;
  quantity: number;
  subtotal: number;
  image: string;
  sku?: string;
  podVariantId?: string;
}

export interface ShippingAddress {
  fullName: string;
  email: string;
  phone?: string;
  street: string;
  apartment?: string;
  city: string;
  state: string;
  zipCode: string;
  country: 'US'; // Launch is US-only as per specification
}

export interface Order {
  id: string;
  orderNumber: string;
  customerEmail: string;
  customerName: string;
  shippingAddress: ShippingAddress;
  items: OrderItem[];
  subtotal: number;
  shippingCost: number;
  shippingTier?: 'standard' | 'priority' | 'express';
  shippingMethodName?: string;
  taxCost: number;
  total: number;
  status: OrderStatus;
  paymentMethod: 'card' | 'apple_pay' | 'google_pay' | 'paypal' | 'klarna' | 'afterpay' | 'cashapp';
  paymentTransactionId?: string;
  paymentDetails?: {
    brand?: string;
    last4?: string;
    wallet?: string;
    gateway?: string;
  };
  podProvider?: 'apliiq' | 'printful';
  podOrderId?: string;
  dispatchMode?: 'instant' | 'grace_1h' | 'grace_2h' | 'manual';
  scheduledDispatchAt?: string;
  idempotencyKey?: string;
  submittedToPodAt?: string;
  carrier?: string;
  trackingNumber?: string;
  trackingUrl?: string;
  estimatedDeliveryDate?: string;
  createdAt: string;
  updatedAt: string;
}

export type ModerationStatus = 'Pending' | 'Approved' | 'Rejected';

export interface CustomerResponse {
  id: string;
  productId?: string;
  productName?: string;
  authorName?: string;
  authorLocation?: string;
  email?: string;
  response: string; // The answer to "What does this mean to you?"
  photoUrl?: string; // Phase 2: User-Generated Photo
  photoCaption?: string;
  garmentOnBodySize?: Size;
  status: ModerationStatus;
  permissionGranted: boolean;
  featuredQuote?: boolean;
  createdAt: string;
}

export type EcosystemMediaType = 'film' | 'conversation' | 'exhibition';

export interface EcosystemItem {
  id: string;
  slug: string;
  type: EcosystemMediaType;
  title: string;
  subtitle: string;
  description: string;
  thumbnailUrl: string;
  mediaUrl?: string;
  duration?: string;
  releaseDate: string;
  tags: string[];
  speakers?: string[];
  location?: string;
  isFeatured?: boolean;
  transcript?: string;
  relatedGarmentId?: string;
}

export interface SizeMeasurement {
  size: Size;
  chestInches: string;
  lengthInches: string;
  sleeveInches: string;
  chestCm: string;
  lengthCm: string;
  sleeveCm: string;
}

export interface FAQItem {
  id: string;
  category: 'Brand & Meaning' | 'Products & Sizing' | 'Shipping & Delivery' | 'Returns & Care';
  question: string;
  answer: string;
}

export type BadgeIconType =
  | 'shield'
  | 'award'
  | 'star'
  | 'compass'
  | 'medal'
  | 'flame'
  | 'crown'
  | 'gem'
  | 'heart'
  | 'checkCircle';

export type BadgeColorTheme =
  | 'emerald'
  | 'amber'
  | 'blue'
  | 'purple'
  | 'rose'
  | 'gold'
  | 'neutral';

export interface BadgeCriteria {
  minOrders: number;
  minReflections: number;
  minSpend: number;
  requirePhoto: boolean;
  requireLocation: boolean;
  minAccountAgeDays: number;
}

export interface MemberBadgeConfig {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: BadgeIconType;
  colorTheme: BadgeColorTheme;
  criteria: BadgeCriteria;
  isActive: boolean;
  isSystemDefault?: boolean;
  priority?: number;
  createdAt: string;
}

export interface MemberVerificationRules {
  enabled?: boolean; // Master toggle: turn ON/OFF member verification system
  requirePurchase: boolean;
  minPurchasesCount: number;
  minSpendAmount?: number;
  requireReflection: boolean;
  minReflectionsCount?: number;
  requirePhoto: boolean;
  requireProfileLocation: boolean;
  minAccountAgeDays?: number;
  allowManualOverride: boolean;
  autoGrantDefaultBadge?: boolean;
  customBadges?: MemberBadgeConfig[];
}

export interface SiteSettings {
  brandName: string;
  contactEmail: string;
  freeShippingThreshold: number;
  standardShippingRate: number;
  returnWindowDays: number;
  shippingCountryRestriction: string;
  announcementText: string;
  enableAnnouncement: boolean;
  memberVerificationRules?: MemberVerificationRules;
  apliiqDispatchMode?: 'instant' | 'grace_1h' | 'grace_2h' | 'manual';
  apliiqLiveShippingEnabled?: boolean;
  apliiqLastInventorySyncAt?: string;
}

export interface UserAddress {
  id: string;
  isDefault: boolean;
  label: string; // e.g. "Primary Residence", "Studio", "Work"
  fullName: string;
  street: string;
  apartment?: string;
  city: string;
  state: string;
  zipCode: string;
  country: 'US';
  phone?: string;
}

export interface SavedGarment {
  id: string; // product ID or slug
  productId: string;
  savedAt: string;
  note?: string;
  preferredSize?: Size;
  preferredColor?: string;
}

export type UserRole =
  | 'superadmin'
  | 'manager'
  | 'fulfillment'
  | 'editor'
  | 'moderator'
  | 'customer'
  | 'admin';

export type AccountStatus = 'active' | 'suspended';

export type UserCapability =
  | 'catalog.view'
  | 'catalog.edit'
  | 'catalog.publish'
  | 'catalog.delete'
  | 'orders.view'
  | 'orders.fulfill'
  | 'orders.edit'
  | 'orders.export'
  | 'content.view'
  | 'content.edit'
  | 'content.publish'
  | 'community.view'
  | 'community.moderate'
  | 'users.view'
  | 'users.create'
  | 'users.edit'
  | 'users.roles'
  | 'users.reset_pwd'
  | 'integrations.view'
  | 'integrations.edit'
  | 'payments.view'
  | 'payments.edit'
  | 'backup.manage'
  | 'settings.manage'
  | 'audit.view'
  | 'customer.profile'
  | 'customer.orders';

export interface AdminActivityLog {
  id: string;
  actorUserId?: string;
  actorEmail: string;
  actorRole: UserRole;
  action: string;
  targetType?: string;
  targetId?: string;
  details?: Record<string, any>;
  ipAddress?: string;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  location?: string;
  phone?: string;
  avatarUrl?: string;
  bio?: string;
  role?: UserRole;
  status?: AccountStatus;
  tokenVersion?: number;
  customPermissions?: string[];
  effectiveCapabilities?: string[];
  lastLoginAt?: string;
  createdAt: string;
  updatedAt: string;
  addresses: UserAddress[];
  savedGarments: SavedGarment[];
  reflectionInterests?: string[];
  isVerifiedManualOverride?: boolean;
  verifiedAt?: string;
  verificationNotes?: string;
  manualBadges?: string[];
  revokedBadges?: string[];
  communicationPreferences: {
    orderUpdatesEmail: boolean;
    reflectionDigestsEmail: boolean;
    curatedEssaysEmail: boolean;
  };
}

export type ShapeDividerVariant =
  | 'editorial-notch'
  | 'zebra-contour'
  | 'textile-seam'
  | 'horizon-converge'
  | 'asymmetric-slash'
  | 'parabolic-arch'
  | 'organic-swell'
  | 'subtle-crest';

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: string;
  authorName: string;
  authorRole?: string;
  publishedAt: string;
  updatedAt?: string;
  isPublished: boolean;
  isFeatured?: boolean;
  readTimeMinutes: number;
  tags: string[];
}

export interface HeroSlide {
  id: string;
  chapterNumber: string;
  chapterLabel: string;
  tagline: string;
  headline: string;
  subheadline: string;
  primaryCtaText: string;
  primaryCtaTarget: string;
  secondaryCtaText?: string;
  secondaryCtaTarget?: string;
  showSecondaryCta?: boolean;
  imageUrl: string;
  colorMood: 'noir-black' | 'golden-amber' | 'terracotta-sunset' | 'twilight-indigo' | 'emerald-moss' | 'natural-monochrome';
  overlayOpacity: number;
  accentHex?: string;
  overlayColor?: string;
  gradientStyle?: 'soft' | 'cinematic' | 'minimal' | 'none';
  active?: boolean;
}

export interface PageSeoConfig {
  id: string;
  pageName: string;
  title: string;
  description: string;
  keywords?: string;
  ogImage?: string;
  ogType?: string;
  canonicalPath?: string;
  robotsDirective?: string;
  schemaType?: string;
}

export type MenuLocation = 'header' | 'footer' | 'both' | 'hidden';

export interface NavigationMenuItem {
  id: string; // matches route view ID e.g. 'home', 'shop', 'collections', 'faq', 'why-we-exist', etc.
  label: string;
  customLabel?: string;
  path?: string;
  location: MenuLocation; // 'header' | 'footer' | 'both' | 'hidden'
  showInHeader: boolean;
  showInFooter: boolean;
  showInMobileDrawer?: boolean;
  displayOrder?: number;
  category?: 'primary' | 'secondary' | 'legal' | 'custom';
  isSystem?: boolean;
}

