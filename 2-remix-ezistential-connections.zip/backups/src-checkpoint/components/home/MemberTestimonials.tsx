import React, { useState, useMemo, useEffect } from 'react';
import {
  Quote,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Sparkles,
  MapPin,
  MessageSquare,
  Share2,
  Check,
  Tag,
  Layers,
  Heart
} from 'lucide-react';
import { useResponses } from '../../context/ResponseContext';
import { CustomerResponse } from '../../types';
import { Button } from '../ui/Button';
import { safeSrc } from '../../lib/utils';
import { api } from '../../lib/api';

export interface MemberTestimonialsProps {
  onNavigate: (view: string, param?: string) => void;
  onOpenReflectionModal?: () => void;
}

type TestimonialFilter = 'all' | 'encounters' | 'philosophy' | 'quality';

const DEFAULT_LIFESTYLE_PHOTOS = [
  'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80',
];

export const MemberTestimonials: React.FC<MemberTestimonialsProps> = ({
  onNavigate,
  onOpenReflectionModal,
}) => {
  const { approvedResponses, responses } = useResponses();
  const [activeFilter, setActiveFilter] = useState<TestimonialFilter>('all');
  const [activeIndex, setActiveIndex] = useState(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [serverFetched, setServerFetched] = useState<CustomerResponse[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch latest approved reflections on mount from API to ensure live data
  useEffect(() => {
    let isMounted = true;
    const fetchLatest = async () => {
      try {
        setIsLoading(true);
        const data = await api.getReflections('approved');
        if (isMounted && data && data.length > 0) {
          setServerFetched(data);
        }
      } catch {
        // Fallback to context
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };
    fetchLatest();
    return () => {
      isMounted = false;
    };
  }, []);

  // Merge server fetched with context approved responses
  const allApproved = useMemo(() => {
    const map = new Map<string, CustomerResponse>();
    // Context items first
    approvedResponses.forEach((r) => map.set(r.id, r));
    // Server items
    serverFetched.forEach((r) => map.set(r.id, r));
    const list = Array.from(map.values());
    return list.length > 0 ? list : responses;
  }, [approvedResponses, serverFetched, responses]);

  // Categorize reflections based on keywords, ensuring broad matches
  const filteredTestimonials = useMemo(() => {
    if (activeFilter === 'all') return allApproved;
    if (activeFilter === 'encounters') {
      const match = allApproved.filter((t) =>
        /stranger|train|transit|bakery|sidewalk|commute|nodded|met my eyes|exchange|met|subway|street|counter|crowded/i.test(t.response)
      );
      return match.length >= 3 ? match : allApproved;
    }
    if (activeFilter === 'philosophy') {
      const match = allApproved.filter((t) =>
        /difference|distance|curiosity|intellectually|slogan|not the same|assumptions|conversation|curious|room|mind|thesis/i.test(t.response)
      );
      return match.length >= 3 ? match : allApproved;
    }
    if (activeFilter === 'quality') {
      const match = allApproved.filter((t) =>
        /cotton|weight|fabric|substantial|collar|washes|heavyweight|drape|6\.5oz|patina|wear|lived-in/i.test(t.response)
      );
      return match.length >= 3 ? match : allApproved;
    }
    return allApproved;
  }, [allApproved, activeFilter]);

  // Ensure index stays in bounds
  const currentList = filteredTestimonials.length > 0 ? filteredTestimonials : allApproved;
  const safeIndex = activeIndex % (currentList.length || 1);
  const activeQuote = currentList[safeIndex];

  // Guaranteed 3 items for thumbnail grid
  const stripItems = useMemo(() => {
    const items = [...currentList];
    if (items.length < 3) {
      for (const item of allApproved) {
        if (!items.some((i) => i.id === item.id)) {
          items.push(item);
        }
        if (items.length >= 3) break;
      }
    }
    return items.slice(0, 3);
  }, [currentList, allApproved]);

  // Auto-play interval
  useEffect(() => {
    if (isPaused || currentList.length <= 1) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % currentList.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [isPaused, currentList.length]);

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % currentList.length);
  };

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + currentList.length) % currentList.length);
  };

  const handleShareQuote = async (item: CustomerResponse) => {
    const text = `"${item.response}" — ${item.authorName || 'Anonymous'}, ${item.authorLocation || ''} (Ezistential Connections)`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Member Reflection · Ezistential Connections',
          text,
          url: window.location.href,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }
    navigator.clipboard?.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  if (!activeQuote) return null;

  return (
    <section
      aria-label="Member Testimonials & Encounters"
      className="bg-[#fbfbf9] text-neutral-900 py-24 sm:py-32 px-4 sm:px-6 lg:px-8 border-t border-neutral-200 relative overflow-hidden"
    >
      {/* Background Decorative Graphic (Subtle Organic Watermark) */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/3 pointer-events-none opacity-[0.025] select-none text-[320px] font-serif font-black leading-none">
        EC
      </div>

      <div className="max-w-7xl mx-auto space-y-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-neutral-200">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center space-x-2 text-[10px] uppercase font-mono tracking-[0.25em] text-neutral-500">
              <span className="w-1.5 h-1.5 rounded-full bg-neutral-900" />
              <span>Voices from the Threshold · Member Reflections</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-neutral-900 tracking-tight font-normal text-balance">
              The Impact of Wearing an Idea
            </h2>
            <p className="text-sm text-neutral-600 font-sans leading-relaxed font-light text-balance">
              Unfiltered accounts from people who wear our heavyweight garments into public transit, family dinners, and city sidewalks. Not endorsements — genuine human encounters.
            </p>
          </div>

          {/* Perspective Filter Pills */}
          <div className="flex flex-wrap gap-1.5 pt-2 md:pt-0">
            {[
              { id: 'all', label: 'All Encounters' },
              { id: 'encounters', label: 'Strangers & Public' },
              { id: 'philosophy', label: 'Philosophy' },
              { id: 'quality', label: 'Tactile Weight' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveFilter(tab.id as TestimonialFilter);
                  setActiveIndex(0);
                }}
                className={`text-xs font-mono uppercase px-3 py-1.5 border transition-all cursor-pointer ${
                  activeFilter === tab.id
                    ? 'bg-neutral-900 text-white border-neutral-900 font-semibold'
                    : 'bg-white text-neutral-600 border-neutral-300 hover:border-neutral-500'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Testimonial Hero Showcase */}
        <div
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          className="bg-white border border-neutral-300 shadow-xs relative transition-all duration-300"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[420px]">
            {/* Left: Wearer Photo / Editorial Canvas */}
            <div className="lg:col-span-4 bg-neutral-100 border-b lg:border-b-0 lg:border-r border-neutral-200 relative overflow-hidden flex items-center justify-center min-h-[280px] lg:min-h-full">
              {(() => {
                const heroPhoto = activeQuote.photoUrl || DEFAULT_LIFESTYLE_PHOTOS[safeIndex % DEFAULT_LIFESTYLE_PHOTOS.length];
                return (
                  <div className="w-full h-full relative group min-h-[280px]">
                    <img
                      src={safeSrc(
                        heroPhoto,
                        DEFAULT_LIFESTYLE_PHOTOS[0]
                      )}
                      alt={`${activeQuote.authorName || 'Member'} wearing ${activeQuote.productName || 'Garment'}`}
                      className="w-full h-full object-cover object-center filter grayscale contrast-105 group-hover:filter-none transition-all duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
                    <div className="absolute bottom-3 left-3 right-3 text-white text-[11px] font-mono flex items-center justify-between">
                      <span className="truncate">{activeQuote.authorLocation || 'Public Transit'}</span>
                      {activeQuote.garmentOnBodySize && (
                        <span className="bg-black/60 px-2 py-0.5 border border-white/20">
                          Size {activeQuote.garmentOnBodySize}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Verified Wearer Badge */}
              <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs border border-neutral-300 px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider text-neutral-800 flex items-center gap-1.5 shadow-xs">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verified Wearer</span>
              </div>
            </div>

            {/* Right: The Human Quote & Narrative */}
            <div className="lg:col-span-8 p-6 sm:p-10 lg:p-12 flex flex-col justify-between space-y-8">
              <div className="space-y-6">
                {/* Meta details */}
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-neutral-500">
                  <div className="flex items-center gap-2">
                    <Quote className="w-5 h-5 text-neutral-400 rotate-180" />
                    <span className="uppercase tracking-widest text-[11px] text-neutral-700 font-semibold">
                      Public Reflection #{activeQuote.id.slice(-3) || '001'}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleShareQuote(activeQuote)}
                      title="Share quote"
                      className="inline-flex items-center gap-1.5 text-neutral-500 hover:text-black transition-colors cursor-pointer"
                    >
                      {copiedId === activeQuote.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-[10px] text-emerald-600">Copied</span>
                        </>
                      ) : (
                        <>
                          <Share2 className="w-3.5 h-3.5" />
                          <span className="text-[10px]">Share Reflection</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* The Quotation */}
                <blockquote className="font-serif text-xl sm:text-2xl md:text-3xl text-neutral-900 leading-relaxed font-normal italic tracking-tight">
                  "{activeQuote.response}"
                </blockquote>

                {/* Product Context Ribbon */}
                {activeQuote.productName && (
                  <div className="pt-2 flex flex-wrap items-center gap-2">
                    <span className="text-[11px] font-mono uppercase text-neutral-400">Garment in Context:</span>
                    <button
                      onClick={() => {
                        if (activeQuote.productId) {
                          onNavigate('product', activeQuote.productId);
                        } else {
                          onNavigate('shop');
                        }
                      }}
                      className="inline-flex items-center gap-1 text-xs font-mono bg-neutral-100 hover:bg-neutral-200 text-neutral-800 px-2.5 py-1 border border-neutral-300 transition-colors cursor-pointer"
                    >
                      <span>{activeQuote.productName}</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>

              {/* Author Attribution & Footer */}
              <div className="pt-6 border-t border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-0.5">
                  <div className="font-serif text-lg font-bold text-neutral-900">
                    {activeQuote.authorName || 'Anonymous Contemplator'}
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono text-neutral-500">
                    {activeQuote.authorLocation && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-neutral-400" />
                        {activeQuote.authorLocation}
                      </span>
                    )}
                    <span>•</span>
                    <span>Worn in Public Space</span>
                  </div>
                </div>

                {/* Navigation Chevrons */}
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono text-neutral-500 mr-2">
                    <span className="font-bold text-neutral-900">
                      {(safeIndex + 1).toString().padStart(2, '0')}
                    </span>{' '}
                    / {currentList.length.toString().padStart(2, '0')}
                  </span>
                  <button
                    onClick={handlePrev}
                    aria-label="Previous member quote"
                    className="w-9 h-9 border border-neutral-300 hover:border-black bg-white hover:bg-neutral-100 flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4 text-neutral-700" />
                  </button>
                  <button
                    onClick={handleNext}
                    aria-label="Next member quote"
                    className="w-9 h-9 border border-neutral-300 hover:border-black bg-white hover:bg-neutral-100 flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4 text-neutral-700" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Multi-Quote Thumbnail Strip (3 Encounters with Images) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
          {stripItems.map((item, idx) => {
            const isSelected = item.id === activeQuote.id;
            const photoSrc = item.photoUrl || DEFAULT_LIFESTYLE_PHOTOS[idx % DEFAULT_LIFESTYLE_PHOTOS.length];
            return (
              <div
                key={item.id}
                onClick={() => {
                  const targetIdx = currentList.findIndex((t) => t.id === item.id);
                  if (targetIdx !== -1) setActiveIndex(targetIdx);
                }}
                className={`p-5 border transition-all cursor-pointer flex flex-col justify-between space-y-4 group overflow-hidden ${
                  isSelected
                    ? 'border-black bg-white shadow-md ring-1 ring-black'
                    : 'border-neutral-200 bg-white hover:border-neutral-400 hover:shadow-xs'
                }`}
              >
                <div>
                  <div className="aspect-16/10 -mx-5 -mt-5 mb-4 bg-neutral-100 overflow-hidden relative border-b border-neutral-200">
                    <img
                      src={safeSrc(photoSrc)}
                      alt={`${item.authorName} wearing ${item.productName}`}
                      className="w-full h-full object-cover filter contrast-105 group-hover:scale-103 transition-transform duration-500"
                    />
                    <div className="absolute top-2 left-2 bg-black/75 backdrop-blur-xs text-white px-2 py-0.5 text-[9px] font-mono uppercase tracking-widest flex items-center gap-1">
                      <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                      <span>Encounter #{idx + 1}</span>
                    </div>
                    <div className="absolute bottom-2 left-2 bg-black/70 backdrop-blur-xs text-white text-[9px] font-mono px-2 py-0.5">
                      {item.authorLocation || 'Public Space'}
                    </div>
                    {item.garmentOnBodySize && (
                      <div className="absolute bottom-2 right-2 bg-white/90 backdrop-blur-xs text-black text-[9px] font-mono font-bold px-1.5 py-0.5">
                        Size {item.garmentOnBodySize}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-mono text-neutral-500">
                      <span className="font-semibold text-neutral-900">{item.authorName}</span>
                      <span>{item.authorLocation}</span>
                    </div>
                    <p className="font-serif italic text-sm text-neutral-800 line-clamp-3">
                      "{item.response}"
                    </p>
                  </div>
                </div>

                <div className="text-[10px] font-mono uppercase tracking-wider text-neutral-500 flex items-center justify-between pt-3 border-t border-neutral-100">
                  <span className="truncate text-neutral-600 font-medium">{item.productName || 'Heavyweight Garment'}</span>
                  <span className="text-neutral-900 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                    <span>Examine</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Call to Action: Contribute an Encounter */}
        <div className="p-8 bg-neutral-900 text-white flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1.5 text-center md:text-left">
            <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400">
              Co-Creating The Human Archive
            </span>
            <h3 className="font-serif text-xl sm:text-2xl font-normal tracking-tight text-white">
              Have you experienced a moment of recognition while wearing our garments?
            </h3>
            <p className="text-xs text-neutral-400 max-w-xl font-sans">
              Share what happened on your morning commute, during a double-take on the street, or across an unexpected conversation.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <Button
              onClick={() => onNavigate('connection')}
              variant="secondary"
              size="md"
              className="bg-white text-black hover:bg-neutral-200 border-transparent text-xs font-mono uppercase tracking-wider cursor-pointer"
            >
              <span>Submit a Reflection</span>
              <ArrowRight className="w-3.5 h-3.5 ml-2" />
            </Button>
            <Button
              onClick={() => onNavigate('connection')}
              variant="outline"
              size="md"
              className="border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-800 text-xs font-mono uppercase tracking-wider cursor-pointer"
            >
              Explore Full Archive
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
