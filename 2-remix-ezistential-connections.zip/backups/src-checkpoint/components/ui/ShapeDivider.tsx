import React from 'react';

export type ShapeDividerVariant =
  | 'zebra-contour'
  | 'editorial-notch'
  | 'textile-seam'
  | 'horizon-converge'
  | 'asymmetric-slash';

export interface ShapeDividerProps {
  variant: ShapeDividerVariant;
  /** Fill color of the shape (matches the section it points into or emerges from) */
  fillColor?: string;
  /** Background color of the parent container or underlying canvas */
  bgColor?: string;
  /** Top or bottom edge of the section */
  position?: 'top' | 'bottom';
  /** Flip horizontally for visual rhythm alternation */
  flipX?: boolean;
  /** Height in pixels or custom Tailwind height */
  height?: number;
  className?: string;
}

export const ShapeDivider: React.FC<ShapeDividerProps> = ({
  variant,
  fillColor = '#f5f4f0',
  bgColor = 'transparent',
  position = 'bottom',
  flipX = false,
  height = 56,
  className = '',
}) => {
  const isTop = position === 'top';

  // Transform for orientation & flip
  const transform = [
    isTop ? 'rotate(180deg)' : '',
    flipX ? 'scaleX(-1)' : '',
  ]
    .filter(Boolean)
    .join(' ');

  const renderShape = () => {
    switch (variant) {
      case 'zebra-contour':
        // Dual-tiered organic contour inspired by zebra striping and topographical distance
        return (
          <svg
            viewBox="0 0 1440 90"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block"
            preserveAspectRatio="none"
          >
            {/* Subtle secondary ghost contour line */}
            <path
              d="M0,45 C280,75 520,20 840,55 C1120,85 1320,35 1440,50 L1440,90 L0,90 Z"
              fill={fillColor}
              opacity="0.35"
            />
            {/* Primary organic wave contour */}
            <path
              d="M0,30 C240,65 480,10 760,45 C1040,80 1260,25 1440,38 L1440,90 L0,90 Z"
              fill={fillColor}
            />
          </svg>
        );

      case 'editorial-notch':
        // Architectural diagonal cut with a precise offset notch and tension step
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block"
            preserveAspectRatio="none"
          >
            {/* Geometric angled facet */}
            <path
              d="M0,0 L680,48 L720,32 L1440,78 L1440,80 L0,80 Z"
              fill={fillColor}
            />
            {/* Accent hairline on the fault edge */}
            <path
              d="M0,0 L680,48 L720,32 L1440,78"
              stroke={fillColor === '#0a0a0a' || fillColor === '#141414' ? '#333333' : '#d4d2cc'}
              strokeWidth="1.5"
            />
          </svg>
        );

      case 'textile-seam':
        // Soft sculpted cloth crest with a tactile stitch thread line
        return (
          <svg
            viewBox="0 0 1440 70"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block"
            preserveAspectRatio="none"
          >
            {/* Soft cloth crest fill */}
            <path
              d="M0,35 Q360,70 720,35 T1440,35 L1440,70 L0,70 Z"
              fill={fillColor}
            />
            {/* Tactile running stitch thread */}
            <path
              d="M0,31 Q360,66 720,31 T1440,31"
              stroke={fillColor === '#0a0a0a' || fillColor === '#141414' ? '#ffffff' : '#0a0a0a'}
              strokeWidth="1.5"
              strokeDasharray="6 8"
              opacity="0.3"
            />
          </svg>
        );

      case 'horizon-converge':
        // Perspective convergence plane tapering toward center vanishing point
        return (
          <svg
            viewBox="0 0 1440 60"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block"
            preserveAspectRatio="none"
          >
            <path
              d="M0,0 L720,48 L1440,0 L1440,60 L0,60 Z"
              fill={fillColor}
            />
            {/* Central focal needle */}
            <line
              x1="720"
              y1="48"
              x2="720"
              y2="60"
              stroke={fillColor === '#0a0a0a' || fillColor === '#141414' ? '#555555' : '#b8b6af'}
              strokeWidth="1"
            />
          </svg>
        );

      case 'asymmetric-slash':
      default:
        // Asymmetric brutalist diagonal slash
        return (
          <svg
            viewBox="0 0 1440 60"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block"
            preserveAspectRatio="none"
          >
            <polygon points="0,60 1440,12 1440,60" fill={fillColor} />
          </svg>
        );
    }
  };

  return (
    <div
      className={`relative w-full overflow-hidden select-none pointer-events-none z-10 ${className}`}
      style={{
        backgroundColor: bgColor,
        height: `${height}px`,
        transform: transform || undefined,
        transformOrigin: 'center center',
      }}
      aria-hidden="true"
    >
      {renderShape()}
    </div>
  );
};
