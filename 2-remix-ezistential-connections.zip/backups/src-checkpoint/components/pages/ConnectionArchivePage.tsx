import React, { useState, useMemo } from 'react';
import { MessageSquare, Search, Filter, Check, ArrowRight, Send, Heart, Camera, Upload } from 'lucide-react';
import { useResponses } from '../../context/ResponseContext';
import { Button } from '../ui/Button';
import { CommunityPhotoGallery } from '../ugc/CommunityPhotoGallery';
import { Size } from '../../types';

export interface ConnectionArchivePageProps {
  onNavigateToProduct: (productId: string) => void;
  onNavigateToShop: () => void;
}

export const ConnectionArchivePage: React.FC<ConnectionArchivePageProps> = ({
  onNavigateToProduct,
  onNavigateToShop,
}) => {
  const { approvedResponses, submitResponse } = useResponses();

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [productFilter, setProductFilter] = useState('All');

  // Submit reflection state
  const [formText, setFormText] = useState('');
  const [formAuthor, setFormAuthor] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formProduct, setFormProduct] = useState('The Distance Tee');
  const [formPhotoUrl, setFormPhotoUrl] = useState('');
  const [formSize, setFormSize] = useState<Size>('L');
  const [formPermission, setFormPermission] = useState(true);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formText.trim()) return;

    submitResponse({
      productName: formProduct,
      authorName: formAuthor.trim() || 'Anonymous',
      authorLocation: formLocation.trim() || 'Undisclosed Location',
      email: formEmail.trim() || undefined,
      response: formText.trim(),
      photoUrl: formPhotoUrl.trim() || undefined,
      garmentOnBodySize: formSize,
      permissionGranted: formPermission,
    });

    setFormSubmitted(true);
    setFormText('');
    setFormAuthor('');
    setFormLocation('');
    setFormEmail('');
    setFormPhotoUrl('');
  };

  // Filtered Reflections
  const filtered = useMemo(() => {
    return approvedResponses.filter((res) => {
      if (productFilter !== 'All' && res.productName !== productFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const mText = res.response.toLowerCase().includes(q);
        const mAuthor = (res.authorName || '').toLowerCase().includes(q);
        const mLocation = (res.authorLocation || '').toLowerCase().includes(q);
        if (!mText && !mAuthor && !mLocation) return false;
      }
      return true;
    });
  }, [approvedResponses, productFilter, searchQuery]);

  const featuredQuotes = useMemo(() => {
    return approvedResponses.filter((r) => r.featuredQuote);
  }, [approvedResponses]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 space-y-20">
      {/* Header */}
      <div className="max-w-4xl mx-auto text-center space-y-5 border-b border-neutral-200 pb-12">
        <div className="inline-flex items-center space-x-2 text-neutral-600 text-xs uppercase tracking-widest font-mono">
          <MessageSquare className="w-3.5 h-3.5" />
          <span>The Human Exchange Archive</span>
        </div>
        <h1 className="font-serif text-4xl sm:text-6xl text-neutral-900 tracking-tight">
          What does this mean to you?
        </h1>
        <p className="font-serif italic text-lg sm:text-xl text-neutral-600 max-w-2xl mx-auto leading-relaxed">
          "Ideas do not end when ink touches cotton. They begin when a passerby looks twice."
        </p>
        <p className="text-xs sm:text-sm text-neutral-600 max-w-xl mx-auto leading-relaxed font-sans font-light">
          We don't maintain algorithmic comment feeds or unmoderated noise. We curate genuine observations from people who have encountered, worn, or paused before our garments in public space.
        </p>
      </div>

      {/* Featured Quote Highlight */}
      {featuredQuotes.length > 0 && (
        <div className="bg-[#141414] text-white p-8 sm:p-12 border border-[#262626] relative overflow-hidden">
          <div className="max-w-3xl mx-auto text-center space-y-6 relative z-10">
            <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 block">
              ★ Featured Reflection from the Field
            </span>
            <blockquote className="font-serif italic text-xl sm:text-2xl text-[#fbfbf9] leading-relaxed">
              "{featuredQuotes[0].response}"
            </blockquote>
            <div className="text-xs uppercase font-mono tracking-wider text-neutral-400 pt-2 border-t border-neutral-800">
              <span>{featuredQuotes[0].authorName} · {featuredQuotes[0].authorLocation}</span>
              <span className="mx-2">•</span>
              <span className="text-neutral-300">{featuredQuotes[0].productName}</span>
            </div>
          </div>
        </div>
      )}

      {/* Search & Filter Toolbar */}
      <div className="bg-white border border-neutral-300 p-4 sm:p-6 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 shadow-xs">
        <div className="flex flex-wrap items-center gap-2">
          {[
            'All',
            'Signature EC Tee — “The Connection”',
            'Distance Tee — “The Distance Between Us Is Man-Made”',
            'Difference Tee — Marquee Flagship Edition',
            'Connection Tee — “The Space Between Us”',
          ].map((garment) => (
            <button
              key={garment}
              onClick={() => setProductFilter(garment)}
              className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer border ${
                productFilter === garment
                  ? 'bg-black text-white border-black font-semibold'
                  : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-400'
              }`}
            >
              {garment}
            </button>
          ))}
        </div>

        <div className="relative min-w-[260px]">
          <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search reflections, cities, themes..."
            className="w-full bg-[#fbfbf9] border border-neutral-300 pl-9 pr-3 py-2 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
          />
        </div>
      </div>

      {/* Reflections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.length === 0 ? (
          <div className="col-span-full py-16 text-center text-neutral-500 bg-white border border-neutral-200 p-8 space-y-2">
            <p className="font-serif text-lg text-neutral-800">No reflections found</p>
            <p className="text-xs text-neutral-500">Try adjusting your search terms or filter selection.</p>
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              className="bg-white border border-neutral-300 p-6 flex flex-col justify-between space-y-6 shadow-xs hover:border-black transition-colors"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between text-[10px] uppercase font-mono tracking-wider text-neutral-400 border-b border-neutral-100 pb-2">
                  <span>{item.productName || 'Garment Inquiry'}</span>
                  <span>{new Date(item.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</span>
                </div>
                <blockquote className="font-serif italic text-sm sm:text-base text-neutral-900 leading-relaxed">
                  "{item.response}"
                </blockquote>
              </div>

              <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs">
                <div>
                  <span className="font-medium text-neutral-900 block">{item.authorName}</span>
                  <span className="text-[11px] text-neutral-500 font-sans">{item.authorLocation}</span>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-500" title="Verified Curated Response" />
              </div>
            </div>
          ))
        )}
      </div>

      {/* Community Photo Gallery (Phase 2 & Ecosystem) */}
      <div className="pt-8 border-t border-neutral-200">
        <CommunityPhotoGallery
          responses={approvedResponses}
          onNavigateToProduct={onNavigateToProduct}
        />
      </div>

      {/* Contribution Form Section */}
      <div className="bg-[#f5f4f0] border border-neutral-300 p-8 sm:p-12 max-w-3xl mx-auto shadow-xs space-y-8">
        <div className="text-center space-y-2">
          <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-mono block">
            Add Your Voice
          </span>
          <h2 className="font-serif text-3xl text-neutral-900 tracking-tight">
            Submit a Public Space Observation
          </h2>
          <p className="text-xs text-neutral-600 max-w-md mx-auto leading-relaxed">
            Reflect on an encounter, an unspoken distance, or what carrying these statements means in your daily life.
          </p>
        </div>

        {formSubmitted ? (
          <div className="bg-white border border-neutral-300 p-8 text-center space-y-4 animate-in fade-in duration-300">
            <div className="w-12 h-12 rounded-full bg-black text-white flex items-center justify-center mx-auto">
              <Check className="w-6 h-6 stroke-[1.5]" />
            </div>
            <h3 className="font-serif text-2xl text-neutral-900">Your Reflection Is in Review</h3>
            <p className="text-xs text-neutral-600 max-w-md mx-auto leading-relaxed">
              Thank you for contributing to the archive. Every submission is individually read by our editorial team prior to potential feature inclusion.
            </p>
            <Button onClick={() => setFormSubmitted(false)} variant="outline" size="sm">
              Submit Another Thought
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-white border border-neutral-300 p-6 sm:p-8 space-y-5">
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1.5">
                Related Garment Concept
              </label>
              <select
                value={formProduct}
                onChange={(e) => setFormProduct(e.target.value)}
                className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs text-neutral-900 cursor-pointer focus:outline-hidden focus:border-black font-sans"
              >
                <option value="Signature EC Tee — “The Connection”">Signature EC Tee — “The Connection”</option>
                <option value="Distance Tee — “The Distance Between Us Is Man-Made”">Distance Tee — “The Distance Between Us Is Man-Made”</option>
                <option value="Difference Tee — Marquee Flagship Edition">Difference Tee — Marquee Flagship Edition</option>
                <option value="Connection Tee — “The Space Between Us”">Connection Tee — “The Space Between Us”</option>
              </select>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1.5">
                Your Reflection / Encounter <span className="text-neutral-400">*</span>
              </label>
              <textarea
                required
                rows={4}
                value={formText}
                onChange={(e) => setFormText(e.target.value)}
                placeholder="Describe a moment where distance was interrupted, or what this idea awakened for you..."
                className="w-full bg-[#fbfbf9] border border-neutral-300 p-3 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans leading-relaxed"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1.5">
                  Name / Initials (Optional)
                </label>
                <input
                  type="text"
                  value={formAuthor}
                  onChange={(e) => setFormAuthor(e.target.value)}
                  placeholder="e.g. Maya R."
                  className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1.5">
                  City / State (Optional)
                </label>
                <input
                  type="text"
                  value={formLocation}
                  onChange={(e) => setFormLocation(e.target.value)}
                  placeholder="e.g. Chicago, IL"
                  className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1.5">
                Private Email (For verification only; never published)
              </label>
              <input
                type="email"
                value={formEmail}
                onChange={(e) => setFormEmail(e.target.value)}
                placeholder="your@email.com"
                className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1.5 flex items-center gap-1">
                  <Camera className="w-3 h-3 text-neutral-600" />
                  <span>On-Body Photo URL (Optional Phase 2)</span>
                </label>
                <input
                  type="text"
                  value={formPhotoUrl}
                  onChange={(e) => setFormPhotoUrl(e.target.value)}
                  placeholder="Paste photo link or image URL"
                  className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1.5">
                  Garment Size Worn (Optional)
                </label>
                <select
                  value={formSize}
                  onChange={(e) => setFormSize(e.target.value as Size)}
                  className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans cursor-pointer"
                >
                  <option value="XS">XS</option>
                  <option value="S">S</option>
                  <option value="M">M</option>
                  <option value="L">L</option>
                  <option value="XL">XL</option>
                  <option value="2XL">2XL</option>
                  <option value="3XL">3XL</option>
                </select>
              </div>
            </div>

            <div className="flex items-start space-x-2 pt-1">
              <input
                type="checkbox"
                id="archivePermCheck"
                checked={formPermission}
                onChange={(e) => setFormPermission(e.target.checked)}
                className="mt-1"
              />
              <label htmlFor="archivePermCheck" className="text-xs text-neutral-600 cursor-pointer">
                I grant permission for Ezistential Connections to respectfully feature this reflection in public curated editorial.
              </label>
            </div>

            <Button type="submit" variant="primary" size="md" fullWidth>
              <Send className="w-3.5 h-3.5 mr-2" />
              <span>Submit for Moderation</span>
            </Button>
          </form>
        )}
      </div>
    </div>
  );
};
