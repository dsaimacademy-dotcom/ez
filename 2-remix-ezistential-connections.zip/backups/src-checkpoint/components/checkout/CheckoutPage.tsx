import React, { useState } from 'react';
import { ShieldCheck, Truck, ArrowLeft, Lock, CheckCircle2, ChevronRight, Zap, ExternalLink } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useOrders } from '../../context/OrderContext';
import { useContent } from '../../context/ContentContext';
import { Logo } from '../brand/Logo';
import { Button } from '../ui/Button';
import { Order, OrderItem, ShippingAddress } from '../../types';
import { formatPrice, FREE_SHIPPING_THRESHOLD, STANDARD_SHIPPING_FLAT_RATE } from '../../lib/utils';
import { PaymentGatewayEngine, SelectedPaymentMethod } from './PaymentGatewayEngine';

export interface CheckoutPageProps {
  onBackToCart: () => void;
  onOrderComplete: (order: Order) => void;
}

const US_STATES = [
  { code: 'AL', name: 'Alabama' },
  { code: 'AK', name: 'Alaska' },
  { code: 'AZ', name: 'Arizona' },
  { code: 'AR', name: 'Arkansas' },
  { code: 'CA', name: 'California' },
  { code: 'CO', name: 'Colorado' },
  { code: 'CT', name: 'Connecticut' },
  { code: 'DE', name: 'Delaware' },
  { code: 'FL', name: 'Florida' },
  { code: 'GA', name: 'Georgia' },
  { code: 'HI', name: 'Hawaii' },
  { code: 'ID', name: 'Idaho' },
  { code: 'IL', name: 'Illinois' },
  { code: 'IN', name: 'Indiana' },
  { code: 'IA', name: 'Iowa' },
  { code: 'KS', name: 'Kansas' },
  { code: 'KY', name: 'Kentucky' },
  { code: 'LA', name: 'Louisiana' },
  { code: 'ME', name: 'Maine' },
  { code: 'MD', name: 'Maryland' },
  { code: 'MA', name: 'Massachusetts' },
  { code: 'MI', name: 'Michigan' },
  { code: 'MN', name: 'Minnesota' },
  { code: 'MS', name: 'Mississippi' },
  { code: 'MO', name: 'Missouri' },
  { code: 'MT', name: 'Montana' },
  { code: 'NE', name: 'Nebraska' },
  { code: 'NV', name: 'Nevada' },
  { code: 'NH', name: 'New Hampshire' },
  { code: 'NJ', name: 'New Jersey' },
  { code: 'NM', name: 'New Mexico' },
  { code: 'NY', name: 'New York' },
  { code: 'NC', name: 'North Carolina' },
  { code: 'ND', name: 'North Dakota' },
  { code: 'OH', name: 'Ohio' },
  { code: 'OK', name: 'Oklahoma' },
  { code: 'OR', name: 'Oregon' },
  { code: 'PA', name: 'Pennsylvania' },
  { code: 'RI', name: 'Rhode Island' },
  { code: 'SC', name: 'South Carolina' },
  { code: 'SD', name: 'South Dakota' },
  { code: 'TN', name: 'Tennessee' },
  { code: 'TX', name: 'Texas' },
  { code: 'UT', name: 'Utah' },
  { code: 'VT', name: 'Vermont' },
  { code: 'VA', name: 'Virginia' },
  { code: 'WA', name: 'Washington' },
  { code: 'WV', name: 'West Virginia' },
  { code: 'WI', name: 'Wisconsin' },
  { code: 'WY', name: 'Wyoming' },
  { code: 'DC', name: 'District of Columbia' },
];

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  onBackToCart,
  onOrderComplete,
}) => {
  const { items, subtotal, isFreeShipping, clearCart } = useCart();
  const { createOrder } = useOrders();
  const { content } = useContent();

  // Contact Form State
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');

  // Shipping Address State (Strictly US only as per spec)
  const [street, setStreet] = useState('');
  const [apartment, setApartment] = useState('');
  const [city, setCity] = useState('');
  const [stateCode, setStateCode] = useState('IL');
  const [zipCode, setZipCode] = useState('');

  // Payment State
  const [paymentMethod, setPaymentMethod] = useState<SelectedPaymentMethod>('card');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExp, setCardExp] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [cardName, setCardName] = useState('');

  // Express authorized wallet details
  const [authorizedWallet, setAuthorizedWallet] = useState<{
    method: SelectedPaymentMethod;
    transactionId: string;
    last4?: string;
    brand?: string;
  } | null>(null);

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Financial calculations
  const taxRate = (content.salesTaxRatePercent || 6.5) / 100;
  const estimatedTax = Math.round(subtotal * taxRate * 100) / 100;
  const shippingThreshold = content.freeShippingThreshold ?? FREE_SHIPPING_THRESHOLD;
  const standardRate = content.standardShippingRate ?? STANDARD_SHIPPING_FLAT_RATE;
  const calculatedFreeShipping = subtotal >= shippingThreshold;
  const shippingCost = calculatedFreeShipping ? 0 : standardRate;
  const orderTotal = Math.round((subtotal + shippingCost + estimatedTax) * 100) / 100;

  // Handle fast express 1-click trigger
  const handleExpressQuickPay = (provider: SelectedPaymentMethod) => {
    setPaymentMethod(provider);
    if (!email) setEmail('customer@example.com');
    if (!fullName) setFullName('Valued Patron');
    if (!street) setStreet('1842 N Damen Ave');
    if (!city) setCity('Chicago');
    if (!zipCode) setZipCode('60647');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Form validation
    if (!email || !email.includes('@')) {
      setErrorMessage('Please enter a valid email address for your order confirmation.');
      return;
    }
    if (!fullName.trim() || !street.trim() || !city.trim() || !zipCode.trim()) {
      setErrorMessage('Please complete all required shipping address fields.');
      return;
    }
    if (!/^\d{5}(-\d{4})?$/.test(zipCode.trim())) {
      setErrorMessage('Please enter a valid 5-digit US ZIP code.');
      return;
    }

    if (paymentMethod === 'card') {
      const cleanCard = cardNumber.replace(/\s/g, '');
      if (cleanCard.length < 15) {
        setErrorMessage('Please enter a valid credit or debit card number.');
        return;
      }
      if (!cardExp || cardExp.length < 5) {
        setErrorMessage('Please enter card expiration in MM/YY format.');
        return;
      }
      if (!cardCvc || cardCvc.length < 3) {
        setErrorMessage('Please enter a valid security code (CVC).');
        return;
      }
    }

    setIsProcessing(true);

    try {
      // Simulate payment gateway authorization & backend ingestion
      await new Promise((resolve) => setTimeout(resolve, 1400));

      const orderItems: OrderItem[] = items.map((it) => ({
        id: `it-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        productId: it.productId,
        variantId: it.variantId,
        productName: it.productName,
        wearTypeId: it.wearTypeId,
        wearTypeName: it.wearType,
        wearType: it.wearType,
        size: it.size,
        colorId: it.colorId,
        color: it.color,
        colorHex: it.colorHex,
        sku: it.sku,
        podVariantId: it.podVariantId,
        price: it.price,
        quantity: it.quantity,
        subtotal: it.price * it.quantity,
        image: it.image,
      }));

      const shippingAddress: ShippingAddress = {
        fullName,
        email,
        phone: phone.trim() || undefined,
        street,
        apartment: apartment.trim() || undefined,
        city,
        state: stateCode,
        zipCode,
        country: 'US',
      };

      const generatedTxnId = authorizedWallet?.transactionId || `txn_${paymentMethod}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;

      const newOrder = createOrder({
        customerName: fullName,
        customerEmail: email,
        shippingAddress,
        items: orderItems,
        paymentMethod: paymentMethod === 'shoppay' ? 'card' : paymentMethod,
        paymentTransactionId: generatedTxnId,
        paymentDetails: {
          brand: paymentMethod === 'card' ? (cardNumber.startsWith('4') ? 'Visa' : cardNumber.startsWith('5') ? 'Mastercard' : 'Stripe Card') : paymentMethod,
          last4: paymentMethod === 'card' ? cardNumber.slice(-4) : '8821',
          wallet: paymentMethod !== 'card' ? paymentMethod.replace('_', ' ') : undefined,
          gateway: paymentMethod === 'paypal' ? 'PayPal Checkout' : 'Stripe Engine',
        },
      });

      clearCart();
      onOrderComplete(newOrder);
    } catch {
      setErrorMessage('Payment processing was interrupted. Please check your information and try again.');
      setIsProcessing(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-24 text-center space-y-4">
        <h2 className="font-serif text-3xl text-neutral-900">Your Bag Is Empty</h2>
        <p className="text-xs text-neutral-500">Add garments to your bag before proceeding to checkout.</p>
        <Button onClick={onBackToCart} variant="primary" size="md">
          Return to Bag
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      {/* Top Breadcrumb & Security Note */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-6 mb-10">
        <div className="flex items-center space-x-6">
          <button
            onClick={onBackToCart}
            className="text-xs uppercase tracking-wider text-neutral-500 hover:text-black flex items-center gap-1.5 cursor-pointer font-medium"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Bag</span>
          </button>
          <span className="text-neutral-300 hidden sm:inline">|</span>
          <Logo variant="black" className="h-6 w-auto hidden sm:block" />
        </div>

        <div className="flex items-center space-x-2 text-xs text-neutral-500">
          <Lock className="w-3.5 h-3.5 text-neutral-700" />
          <span>256-Bit Encrypted Secure Checkout • US Domestic Launch</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
        {/* Left Form: Checkout Flow */}
        <div className="lg:col-span-7 space-y-10">
          {/* EXPRESS 1-CLICK CHECKOUT BAR */}
          {(content.applePayEnabled !== false || content.googlePayEnabled !== false || content.paypalEnabled !== false || content.shopPayEnabled !== false) && (
            <div className="bg-[#f9f8f5] border border-neutral-300 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-mono tracking-wider text-neutral-600 font-semibold flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-600" />
                  <span>Express 1-Click Checkout</span>
                </span>
                <span className="text-[10px] text-neutral-400 font-mono">Instant biometric authorization</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {content.applePayEnabled !== false && (
                  <button
                    type="button"
                    onClick={() => handleExpressQuickPay('apple_pay')}
                    className="py-2.5 px-3 bg-black text-white hover:bg-neutral-800 text-xs font-serif font-bold tracking-normal rounded-xs transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                  >
                    <span> Pay</span>
                  </button>
                )}

                {content.googlePayEnabled !== false && (
                  <button
                    type="button"
                    onClick={() => handleExpressQuickPay('google_pay')}
                    className="py-2.5 px-3 bg-[#1f1f1f] text-white hover:bg-black text-xs font-mono font-bold tracking-tight rounded-xs transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                  >
                    <span>G Pay</span>
                  </button>
                )}

                {content.paypalEnabled !== false && (
                  <button
                    type="button"
                    onClick={() => handleExpressQuickPay('paypal')}
                    className="py-2.5 px-3 bg-[#FFC439] text-[#003087] hover:bg-[#F4B400] text-xs font-sans font-bold italic tracking-normal rounded-xs transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                  >
                    <span>PayPal</span>
                  </button>
                )}

                {content.shopPayEnabled !== false && (
                  <button
                    type="button"
                    onClick={() => handleExpressQuickPay('card')}
                    className="py-2.5 px-3 bg-[#5A31F4] text-white hover:bg-[#4924cf] text-xs font-sans font-bold tracking-normal rounded-xs transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                  >
                    <span>Shop Pay</span>
                  </button>
                )}
              </div>

              <div className="relative flex items-center justify-center pt-1">
                <div className="border-t border-neutral-300 w-full" />
                <span className="bg-[#f9f8f5] px-3 text-[10px] uppercase tracking-widest text-neutral-500 font-mono absolute">
                  OR CONTINUE BELOW
                </span>
              </div>
            </div>
          )}

          <form id="checkoutForm" onSubmit={handleSubmit} className="space-y-10">
            {/* 1. Contact Information */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                <h2 className="font-serif text-xl text-neutral-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-black text-white text-[10px] font-mono flex items-center justify-center">1</span>
                  <span>Contact Information</span>
                </h2>
                <span className="text-[11px] text-neutral-400">Order updates will be sent here</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                    Email Address <span className="text-neutral-400">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="maya@example.com"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                    Full Name <span className="text-neutral-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Maya Reynolds"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                    Phone (Optional, for SMS delivery dispatch updates)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(312) 555-0192"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>
              </div>
            </div>

            {/* 2. Shipping Address */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                <h2 className="font-serif text-xl text-neutral-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-black text-white text-[10px] font-mono flex items-center justify-center">2</span>
                  <span>Shipping Address</span>
                </h2>
                <span className="text-[11px] text-neutral-400">US Domestic destinations only</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                    Street Address <span className="text-neutral-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    placeholder="1842 N Damen Ave"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                    Apartment, Suite, Unit (Optional)
                  </label>
                  <input
                    type="text"
                    value={apartment}
                    onChange={(e) => setApartment(e.target.value)}
                    placeholder="Apt 3F"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                    City <span className="text-neutral-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Chicago"
                    className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                      State <span className="text-neutral-400">*</span>
                    </label>
                    <select
                      value={stateCode}
                      onChange={(e) => setStateCode(e.target.value)}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans cursor-pointer"
                    >
                      {US_STATES.map((st) => (
                        <option key={st.code} value={st.code}>
                          {st.name} ({st.code})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                      ZIP Code <span className="text-neutral-400">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={zipCode}
                      onChange={(e) => setZipCode(e.target.value)}
                      placeholder="60647"
                      maxLength={10}
                      className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden focus:border-black"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 3. Shipping Method Selection */}
            <div className="space-y-4">
              <div className="border-b border-neutral-200 pb-2">
                <h2 className="font-serif text-xl text-neutral-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-black text-white text-[10px] font-mono flex items-center justify-center">3</span>
                  <span>Shipping Method</span>
                </h2>
              </div>

              <div className="border border-neutral-300 bg-white p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-neutral-700 shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-neutral-900">
                      USPS Ground Advantage / UPS Ground
                    </p>
                    <p className="text-[11px] text-neutral-500">
                      Standard tracked delivery (3–5 business days after 2–4 days on-demand production)
                    </p>
                  </div>
                </div>
                <span className="font-mono text-xs font-semibold text-neutral-900">
                  {calculatedFreeShipping ? 'FREE' : formatPrice(standardRate)}
                </span>
              </div>
            </div>

            {/* 4. Payment Gateway Engine Integration */}
            <div className="space-y-4">
              <div className="border-b border-neutral-200 pb-2">
                <h2 className="font-serif text-xl text-neutral-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-black text-white text-[10px] font-mono flex items-center justify-center">4</span>
                  <span>Payment Gateway Integration</span>
                </h2>
              </div>

              <PaymentGatewayEngine
                orderTotal={orderTotal}
                selectedMethod={paymentMethod}
                onMethodChange={setPaymentMethod}
                cardNumber={cardNumber}
                onCardNumberChange={setCardNumber}
                cardExp={cardExp}
                onCardExpChange={setCardExp}
                cardCvc={cardCvc}
                onCardCvcChange={setCardCvc}
                cardName={cardName}
                onCardNameChange={setCardName}
                isProcessing={isProcessing}
                onWalletAuthorized={(details) => {
                  setAuthorizedWallet(details);
                }}
              />
            </div>

            {/* Error Display */}
            {errorMessage && (
              <div className="bg-red-50 border border-red-200 text-red-800 text-xs p-3 font-sans leading-relaxed">
                {errorMessage}
              </div>
            )}

            {/* Action Bar */}
            <div className="pt-4 space-y-3">
              <Button
                type="submit"
                variant="primary"
                size="lg"
                fullWidth
                disabled={isProcessing}
                className="py-4 text-sm"
              >
                {isProcessing ? (
                  <span>Authorizing Order & Dispatching...</span>
                ) : (
                  <span>Place Order • {formatPrice(orderTotal)}</span>
                )}
              </Button>

              <div className="flex items-center justify-center space-x-2 text-[11px] text-neutral-500">
                <ShieldCheck className="w-3.5 h-3.5 text-neutral-700" />
                <span>30-Day Quality Guarantee. Replacement or refund for damaged garments.</span>
              </div>
            </div>
          </form>
        </div>

        {/* Right Sidebar: Order Summary */}
        <div className="lg:col-span-5">
          <div className="bg-[#f5f4f0] border border-neutral-200 p-6 sm:p-8 space-y-6 sticky top-28">
            <h3 className="font-serif text-xl text-neutral-900 border-b border-neutral-200 pb-3">
              Order Summary ({items.reduce((acc, i) => acc + i.quantity, 0)} garments)
            </h3>

            {/* Mini Items List */}
            <div className="divide-y divide-neutral-200 max-h-64 overflow-y-auto pr-1">
              {items.map((item) => (
                <div key={item.id} className="py-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.image}
                      alt={item.productName}
                      className="w-12 h-14 object-cover border border-neutral-200 shrink-0 bg-white"
                    />
                    <div>
                      <p className="font-serif text-sm font-medium text-neutral-900 leading-tight">
                        {item.productName}
                      </p>
                      <p className="text-[11px] text-neutral-500">
                        {item.wearType && <span className="font-mono text-neutral-700 font-medium">{item.wearType} • </span>}
                        {item.size} • {item.color} • Qty {item.quantity}
                      </p>
                    </div>
                  </div>
                  <span className="font-mono text-neutral-900 font-medium">
                    {formatPrice(item.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            {/* Calculations Breakdown */}
            <div className="space-y-2.5 text-xs border-t border-neutral-200 pt-4">
              <div className="flex justify-between text-neutral-600">
                <span>Subtotal</span>
                <span className="font-mono text-neutral-900">{formatPrice(subtotal)}</span>
              </div>

              <div className="flex justify-between text-neutral-600">
                <span>US Domestic Shipping</span>
                <span className="font-mono text-neutral-900">
                  {calculatedFreeShipping ? (
                    <span className="text-black font-semibold uppercase text-[10px]">Free</span>
                  ) : (
                    formatPrice(shippingCost)
                  )}
                </span>
              </div>

              <div className="flex justify-between text-neutral-600">
                <span>Estimated Sales Tax ({content.salesTaxRatePercent || 6.5}%)</span>
                <span className="font-mono text-neutral-900">{formatPrice(estimatedTax)}</span>
              </div>

              <div className="flex justify-between text-base font-semibold text-neutral-900 pt-3 border-t border-neutral-200">
                <span>Total Due</span>
                <span className="font-mono">{formatPrice(orderTotal)}</span>
              </div>
            </div>

            {/* Reassurance Notes */}
            <div className="pt-2 border-t border-neutral-200 space-y-2 text-[11px] text-neutral-500 leading-relaxed font-sans">
              <p>• Made on demand via direct-to-film printing with eco-friendly inks.</p>
              <p>• Production window: 2–4 business days before carrier handover.</p>
              <p>• You will receive tracking notifications via USPS Ground Advantage.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
