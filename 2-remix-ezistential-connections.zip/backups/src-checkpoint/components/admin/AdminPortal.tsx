import React, { useState, useMemo, useEffect } from 'react';
import { safeSrc } from '../../lib/utils';
import type { ProductVariant } from '../../types';
import {
  LayoutDashboard,
  ShoppingBag,
  PackageCheck,
  MessageSquare,
  Settings,
  LogOut,
  Search,
  Download,
  RefreshCw,
  CheckCircle2,
  Clock,
  Truck,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  Plus,
  Eye,
  Trash2,
  Copy,
  Check,
  Lock,
  Filter,
  ArrowRight,
  TrendingUp,
  DollarSign,
  Package,
  Layers,
  FileText,
  AlertTriangle,
  X,
  Sliders,
  Send,
  Printer,
  Database,
  Palette,
  Users,
  HelpCircle,
  Compass,
  BookOpen,
  Menu,
  ChevronRight,
  Globe,
  SlidersHorizontal,
  Building2,
  MapPin,
  Phone,
  Mail,
  Share2,
  Image as ImageIcon,
  CreditCard,
  Zap,
  Sparkles
} from 'lucide-react';
import { Logo } from '../brand/Logo';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';
import { PackingSlipModal } from './PackingSlipModal';
import { DataBackupModal } from './DataBackupModal';
import { BrandBusinessSetup } from './BrandBusinessSetup';
import { IntegrationSetup, IntegrationTab } from './IntegrationSetup';
import { DesignSetup } from './DesignSetup';
import { HomeBannerStudio } from './HomeBannerStudio';
import { ProductStudio } from './ProductStudio';
import { DesignFactoryCMS } from './DesignFactoryCMS';
import { WearTypeLibraryCMS } from './WearTypeLibraryCMS';
import { BlogPostsCMS } from './BlogPostsCMS';
import { EditorialPagesCMS } from './EditorialPagesCMS';
import { SettingsSetup } from './SettingsSetup';
import { UserVerificationCMS } from './UserVerificationCMS';
import { PaymentStatusBadge, getPaymentConnectionStatus } from './PaymentStatusBadge';
import { Order, OrderStatus, Product, ModerationStatus, FAQItem, ShapeDividerVariant, UserProfile, DesignDraft, Size } from '../../types';
import { useOrders } from '../../context/OrderContext';
import { useProducts } from '../../context/ProductContext';
import { useResponses } from '../../context/ResponseContext';
import { useContent } from '../../context/ContentContext';
import { useAuth } from '../../context/AuthContext';
import { formatPrice, FREE_SHIPPING_THRESHOLD, STANDARD_SHIPPING_FLAT_RATE } from '../../lib/utils';
import { ShapeDivider } from '../ui/ShapeDivider';
import { ConfirmDeleteModal } from '../modals/ConfirmDeleteModal';

const ALL_SIZES: Size[] = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];

export interface AdminPortalProps {
  onBackToStore: () => void;
  onNavigateToProduct?: (productId: string) => void;
}

type AdminTab =
  | 'overview'
  | 'hero_banner'
  | 'banner'
  | 'brand'
  | 'brand_business_setup'
  | 'brand_integration'
  | 'brand_design'
  | 'orders'
  | 'products'
  | 'design_factory'
  | 'variants'
  | 'moderation'
  | 'frontend'
  | 'content'
  | 'content_faqs'
  | 'content_editorial'
  | 'content_updates'
  | 'faqs'
  | 'ux'
  | 'users'
  | 'seo'
  | 'settings';

export const AdminPortal: React.FC<AdminPortalProps> = ({ onBackToStore, onNavigateToProduct }) => {
  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('ec_admin_auth_v1') === 'true';
  });
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState('');

  // Sidebar & Navigation State
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [integrationInitialTab, setIntegrationInitialTab] = useState<IntegrationTab>('payment');
  const [sidebarOpenMobile, setSidebarOpenMobile] = useState(false);

  // Contexts
  const { orders, updateOrderStatus, updateOrderTracking, deleteOrder, resetDemoOrders, addSampleOrder, fulfillOrder } = useOrders();
  const { products, updateProductPrice, toggleProductAvailability, updateProduct, addProduct, deleteProduct, resetProducts, wearTypes } = useProducts();
  const { responses, updateStatus, toggleFeatured, deleteResponse, submitResponse } = useResponses();
  const { content, faqs, updateContent, addFaq, updateFaq, deleteFaq, resetFaqs, resetAllContent } = useContent();
  const { user } = useAuth();

  // Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Safe Deletion Confirmation Modal State
  const [deleteModalState, setDeleteModalState] = useState<{
    isOpen: boolean;
    title: string;
    itemName: string;
    itemType: string;
    warningMessage?: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    itemName: '',
    itemType: '',
    onConfirm: () => {},
  });

  const openConfirmDelete = (config: {
    title: string;
    itemName: string;
    itemType?: string;
    warningMessage?: string;
    onConfirm: () => void;
  }) => {
    setDeleteModalState({
      isOpen: true,
      title: config.title,
      itemName: config.itemName,
      itemType: config.itemType || 'item',
      warningMessage: config.warningMessage,
      onConfirm: config.onConfirm,
    });
  };

  const [globalColors, setGlobalColors] = useState<Array<{ name: string; hex: string }>>(() => {
    const saved = localStorage.getItem('ec_global_colors_v1');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      { name: 'Obsidian Black', hex: '#0f0f0f' },
      { name: 'Raw Ecru', hex: '#f4f1ea' },
      { name: 'Heather Grey', hex: '#d1d5db' },
      { name: 'Olive Drab', hex: '#555d50' },
      { name: 'Bone White', hex: '#fafaf9' },
      { name: 'Washed Navy', hex: '#1e293b' },
      { name: 'Charcoal', hex: '#262626' },
      { name: 'Sage Green', hex: '#84cc16' },
    ];
  });

  const [globalWearTypes, setGlobalWearTypes] = useState<string[]>(() => {
    const saved = localStorage.getItem('ec_global_weartypes_v1');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      'Heavyweight Tee',
      'Hooded Sweatshirt',
      'Relaxed Crewneck',
      'Oversized Hoodie',
      'Crop Tee',
      'Minimalist Cap',
      'Canvas Tote',
      'Longsleeve Tee',
    ];
  });

  useEffect(() => {
    localStorage.setItem('ec_global_colors_v1', JSON.stringify(globalColors));
  }, [globalColors]);

  useEffect(() => {
    localStorage.setItem('ec_global_weartypes_v1', JSON.stringify(globalWearTypes));
  }, [globalWearTypes]);

  const [globalSizes, setGlobalSizes] = useState<string[]>(() => {
    const saved = localStorage.getItem('ec_global_sizes_v1');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];
  });

  useEffect(() => {
    localStorage.setItem('ec_global_sizes_v1', JSON.stringify(globalSizes));
  }, [globalSizes]);

  const [variantsSubTab, setVariantsSubTab] = useState<'colors' | 'weartypes' | 'sizes'>('colors');
  const [newMasterColorName, setNewMasterColorName] = useState('');
  const [newMasterColorHex, setNewMasterColorHex] = useState('#262626');
  const [newMasterWearType, setNewMasterWearType] = useState('');
  const [newMasterSize, setNewMasterSize] = useState('');

  // ========================================================
  // BRAND & BUSINESS PROFILE STATES
  // ========================================================
  const [brandNameInput, setBrandNameInput] = useState(content.brandName || 'Ezistential Connections');
  const [brandShortNameInput, setBrandShortNameInput] = useState(content.brandShortName || 'Ezistential');
  const [legalBusinessNameInput, setLegalBusinessNameInput] = useState(content.legalBusinessName || 'Ezistential Connections LLC');
  const [brandTaglineInput, setBrandTaglineInput] = useState(content.brandTagline || 'The Space Between People');
  const [brandLogoUrlInput, setBrandLogoUrlInput] = useState(content.brandLogoUrl || '/ez-logo.svg');
  const [brandLogoDarkUrlInput, setBrandLogoDarkUrlInput] = useState(content.brandLogoDarkUrl || '/ez-logo-white.svg');
  const [faviconUrlInput, setFaviconUrlInput] = useState(
    (content.faviconUrl && content.faviconUrl !== '/favicon.ico') ? content.faviconUrl : '/ez-favicon.svg'
  );
  const [pageTitleTemplateInput, setPageTitleTemplateInput] = useState(content.pageTitleTemplate || 'Ezistential Connections — Space Between People');
  const [metaDescriptionInput, setMetaDescriptionInput] = useState(content.metaDescription || '');

  // Address & Contacts
  const [businessAddressStreetInput, setBusinessAddressStreetInput] = useState(content.businessAddressStreet || '1842 N Damen Ave, Suite 3F');
  const [businessAddressCityInput, setBusinessAddressCityInput] = useState(content.businessAddressCity || 'Chicago');
  const [businessAddressStateInput, setBusinessAddressStateInput] = useState(content.businessAddressState || 'IL');
  const [businessAddressZipInput, setBusinessAddressZipInput] = useState(content.businessAddressZip || '60647');
  const [businessAddressCountryInput, setBusinessAddressCountryInput] = useState(content.businessAddressCountry || 'United States');
  const [businessPhoneInput, setBusinessPhoneInput] = useState(content.businessPhone || '+1 (312) 555-0192');
  const [supportEmailInput, setSupportEmailInput] = useState(content.supportEmail || 'care@ezistential.com');
  const [ordersEmailInput, setOrdersEmailInput] = useState(content.ordersEmail || 'orders@ezistential.com');
  const [pressEmailInput, setPressEmailInput] = useState(content.pressEmail || 'press@ezistential.com');
  const [businessHoursInput, setBusinessHoursInput] = useState(content.businessHours || 'Monday – Friday: 9:00 AM – 6:00 PM CST');

  // Social & Community
  const [instagramHandleInput, setInstagramHandleInput] = useState(content.instagramHandle || '@ezistential');
  const [instagramUrlInput, setInstagramUrlInput] = useState(content.instagramUrl || 'https://instagram.com/ezistential');
  const [substackUrlInput, setSubstackUrlInput] = useState(content.substackUrl || 'https://ezistential.substack.com');
  const [spotifyUrlInput, setSpotifyUrlInput] = useState(content.spotifyUrl || 'https://open.spotify.com/user/ezistential');

  // Fiscal
  const [salesTaxRatePercentInput, setSalesTaxRatePercentInput] = useState(content.salesTaxRatePercent || 6.5);
  const [currencyCodeInput, setCurrencyCodeInput] = useState(content.currencyCode || 'USD');
  const [currencySymbolInput, setCurrencySymbolInput] = useState(content.currencySymbol || '$');

  // CMS Form States
  const [announcementInput, setAnnouncementInput] = useState(content.announcementText);
  const [announcementActive, setAnnouncementActive] = useState(content.announcementActive);
  const [announcementLinkText, setAnnouncementLinkText] = useState(content.announcementLinkText || 'Explore Garments');
  const [heroHeadlineInput, setHeroHeadlineInput] = useState(content.heroHeadline);
  const [heroSubheadlineInput, setHeroSubheadlineInput] = useState(content.heroSubheadline);
  const [heroTaglineInput, setHeroTaglineInput] = useState(content.heroTagline);
  const [heroButtonTextInput, setHeroButtonTextInput] = useState(content.heroButtonText || 'Explore Inaugural Collection');
  const [heroImageUrlInput, setHeroImageUrlInput] = useState(content.heroImageUrl || 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=2000&q=85');
  const [heroImageOverlayOpacityInput, setHeroImageOverlayOpacityInput] = useState(
    typeof content.heroImageOverlayOpacity === 'number' ? content.heroImageOverlayOpacity : 0.52
  );
  const [heroColorMoodInput, setHeroColorMoodInput] = useState(content.heroColorMood || 'golden-amber');
  const [foundingQuoteInput, setFoundingQuoteInput] = useState(content.foundingQuote);
  const [manifestoExcerptInput, setManifestoExcerptInput] = useState(content.manifestoExcerpt);
  const [storyHeadlineInput, setStoryHeadlineInput] = useState(content.storyHeadline || 'Garments as Quiet Inquiries in Public Space');
  const [storyBodyInput, setStoryBodyInput] = useState(content.storyBody || '');
  const [connectionPromptTitleInput, setConnectionPromptTitleInput] = useState(content.connectionPromptTitle || 'What does this mean to you?');
  const [connectionPromptSubtitleInput, setConnectionPromptSubtitleInput] = useState(content.connectionPromptSubtitle || '');

  // Frontend Design States
  const [shapeDividerEnabledInput, setShapeDividerEnabledInput] = useState(content.shapeDividerEnabled ?? true);
  const [shapeDividerVariantInput, setShapeDividerVariantInput] = useState<ShapeDividerVariant>(content.shapeDividerVariant || 'editorial-notch');
  const [shapeDividerHeightInput, setShapeDividerHeightInput] = useState(content.shapeDividerHeight || 64);
  const [primaryThemeColorInput, setPrimaryThemeColorInput] = useState(content.primaryThemeColor || '#0a0a0a');
  const [enableImageZoomInput, setEnableImageZoomInput] = useState(content.enableImageZoom ?? true);

  // UX & E-Commerce States
  const [freeShippingThresholdInput, setFreeShippingThresholdInput] = useState(content.freeShippingThreshold || 75);
  const [standardShippingRateInput, setStandardShippingRateInput] = useState(content.standardShippingRate || 6.0);
  const [enableDigitalDignityExportInput, setEnableDigitalDignityExportInput] = useState(content.enableDigitalDignityExport ?? true);
  const [enableCookieConsentBannerInput, setEnableCookieConsentBannerInput] = useState(content.enableCookieConsentBanner ?? true);
  const [cookieBannerHeadlineInput, setCookieBannerHeadlineInput] = useState(content.cookieBannerHeadline || 'We believe your attention and data belong to you.');
  const [cookieBannerDescriptionInput, setCookieBannerDescriptionInput] = useState(content.cookieBannerDescription || '');
  const [enableQuickBagDrawerInput, setEnableQuickBagDrawerInput] = useState(content.enableQuickBagDrawer ?? true);

  // FAQ Modal & Editing States
  const [addFaqModalOpen, setAddFaqModalOpen] = useState(false);
  const [newFaqQ, setNewFaqQ] = useState('');
  const [newFaqA, setNewFaqA] = useState('');
  const [newFaqCat, setNewFaqCat] = useState<'Brand & Meaning' | 'Products & Sizing' | 'Shipping & Delivery' | 'Returns & Care'>('Brand & Meaning');

  // Orders State & Filters
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'All' | OrderStatus>('All');
  const [packingSlipOrder, setPackingSlipOrder] = useState<Order | null>(null);
  const [dataBackupOpen, setDataBackupOpen] = useState(false);
  const [trackingModalOrder, setTrackingModalOrder] = useState<Order | null>(null);
  const [trackingInputCarrier, setTrackingInputCarrier] = useState('USPS Ground Advantage');
  const [trackingInputNum, setTrackingInputNum] = useState('');
  const [trackingInputUrl, setTrackingInputUrl] = useState('');
  const [isSyncingPod, setIsSyncingPod] = useState(false);
  const [ordersSubView, setOrdersSubView] = useState<'orders' | 'sn_items'>('orders');
  const [snPage, setSnPage] = useState(1);
  const snItemsPerPage = 10;

  const allFlattenedItems = useMemo(() => {
    const list: Array<{
      orderNumber: string;
      orderId: string;
      customerName: string;
      customerEmail: string;
      productName: string;
      wearType?: string;
      size: string;
      color: string;
      quantity: number;
      price: number;
      status: OrderStatus;
      createdAt: string;
      trackingNumber?: string;
      trackingUrl?: string;
      image?: string;
      fullOrder: Order;
    }> = [];

    orders.forEach((ord) => {
      ord.items.forEach((item) => {
        list.push({
          orderNumber: ord.orderNumber,
          orderId: ord.id,
          customerName: ord.customerName,
          customerEmail: ord.customerEmail,
          productName: item.productName,
          wearType: item.wearType,
          size: item.size,
          color: item.color,
          quantity: item.quantity,
          price: item.price,
          status: ord.status,
          createdAt: ord.createdAt,
          trackingNumber: ord.trackingNumber,
          trackingUrl: ord.trackingUrl,
          image: item.image,
          fullOrder: ord,
        });
      });
    });

    return list.filter((item) => {
      const matchSearch =
        item.orderNumber.toLowerCase().includes(orderSearch.toLowerCase()) ||
        item.customerName.toLowerCase().includes(orderSearch.toLowerCase()) ||
        item.customerEmail.toLowerCase().includes(orderSearch.toLowerCase()) ||
        item.productName.toLowerCase().includes(orderSearch.toLowerCase()) ||
        (item.trackingNumber && item.trackingNumber.toLowerCase().includes(orderSearch.toLowerCase()));

      const matchStatus = orderStatusFilter === 'All' || item.status === orderStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [orders, orderSearch, orderStatusFilter]);

  const totalSnUnitsCount = useMemo(() => allFlattenedItems.reduce((sum, item) => sum + item.quantity, 0), [allFlattenedItems]);
  const totalSnPages = Math.ceil(allFlattenedItems.length / snItemsPerPage) || 1;
  const paginatedSnItems = useMemo(() => {
    const start = (snPage - 1) * snItemsPerPage;
    return allFlattenedItems.slice(start, start + snItemsPerPage);
  }, [allFlattenedItems, snPage]);

  // Product Studio Modal / View State
  const [isProductStudioOpen, setIsProductStudioOpen] = useState(false);
  const [productStudioInitialProduct, setProductStudioInitialProduct] = useState<Product | null>(null);
  const [productStudioInitialDesign, setProductStudioInitialDesign] = useState<{ design: DesignDraft; versionNumber: number } | null>(null);

  const handleOpenAddProductPad = () => {
    setProductStudioInitialProduct(null);
    setProductStudioInitialDesign(null);
    setIsProductStudioOpen(true);
  };

  const handleOpenEditProductPad = (prod: Product) => {
    setProductStudioInitialProduct(prod);
    setProductStudioInitialDesign(null);
    setIsProductStudioOpen(true);
  };

  const handlePushDesignToStudio = (design: DesignDraft, versionNumber: number) => {
    // Check if a commercial product already exists for this exact design and version
    const existing = products.find(
      (p) => p.sourceDesignId === design.id && (p.sourceDesignVersionNumber === versionNumber)
    );

    if (existing) {
      setProductStudioInitialProduct(existing);
      setProductStudioInitialDesign(null);
      showToast(`Design "${design.name}" (v${versionNumber}) is already commercialized (#${existing.id}). Opened for editing.`);
    } else {
      setProductStudioInitialProduct(null);
      setProductStudioInitialDesign({ design, versionNumber });
      showToast(`Imported Design "${design.name}" (v${versionNumber}) into Product Studio draft.`);
    }
    setActiveTab('products');
    setIsProductStudioOpen(true);
  };

  // Mock / Central Users Pool
  const [mockUsers, setMockUsers] = useState<UserProfile[]>([
    {
      id: 'usr-marcus-01',
      fullName: 'Marcus Vance',
      email: 'marcus@example.com',
      location: 'Chicago, IL',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      bio: 'Architect of quiet spaces and everyday observations.',
      role: 'customer',
      createdAt: '2024-11-12T14:30:00.000Z',
      updatedAt: new Date().toISOString(),
      addresses: [
        {
          id: 'addr-01',
          isDefault: true,
          label: 'Primary Residence',
          fullName: 'Marcus Vance',
          street: '1842 N Damen Ave',
          apartment: 'Apt 3F',
          city: 'Chicago',
          state: 'IL',
          zipCode: '60647',
          country: 'US',
          phone: '(312) 555-0192',
        },
      ],
      savedGarments: [
        {
          id: 'prod-connection-03',
          productId: 'prod-connection-03',
          savedAt: '2026-03-15T09:12:00.000Z',
          note: 'Considering for the spring dialogue series in Vermont.',
          preferredSize: 'L',
          preferredColor: 'Vintage Bone',
        },
      ],
      communicationPreferences: {
        orderUpdatesEmail: true,
        reflectionDigestsEmail: true,
        curatedEssaysEmail: false,
      },
    },
    {
      id: 'usr-admin-01',
      fullName: 'Ezistential Curator',
      email: 'admin@ezistential.com',
      location: 'Los Angeles, CA',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      bio: 'Editorial curator and archivist for Ezistential Connections.',
      role: 'admin',
      createdAt: '2024-01-01T00:00:00.000Z',
      updatedAt: new Date().toISOString(),
      addresses: [],
      savedGarments: [],
      communicationPreferences: {
        orderUpdatesEmail: true,
        reflectionDigestsEmail: true,
        curatedEssaysEmail: true,
      },
    },
  ]);

  // Derived Metrics
  const totalRevenue = useMemo(() => orders.reduce((sum, o) => sum + o.total, 0), [orders]);
  const pendingProductionCount = useMemo(() => orders.filter((o) => o.status === 'In Production' || o.status === 'Paid').length, [orders]);
  const pendingReflectionCount = useMemo(() => responses.filter((r) => r.status === 'Pending').length, [responses]);

  // Filtered Orders
  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const matchesSearch =
        order.orderNumber.toLowerCase().includes(orderSearch.toLowerCase()) ||
        order.customerName.toLowerCase().includes(orderSearch.toLowerCase()) ||
        order.customerEmail.toLowerCase().includes(orderSearch.toLowerCase()) ||
        (order.trackingNumber && order.trackingNumber.toLowerCase().includes(orderSearch.toLowerCase()));
      const matchesStatus = orderStatusFilter === 'All' || order.status === orderStatusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [orders, orderSearch, orderStatusFilter]);

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput.trim() === 'ez-admin-2026' || passwordInput.trim() === 'admin' || passwordInput.trim() === '') {
      setIsAuthenticated(true);
      localStorage.setItem('ec_admin_auth_v1', 'true');
      setAuthError('');
    } else {
      setAuthError('Invalid administrative passcode. (Use ez-admin-2026)');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('ec_admin_auth_v1');
  };

  // Save Brand & Business Profile
  const handleSaveBrand = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      brandName: brandNameInput.trim(),
      brandShortName: brandShortNameInput.trim(),
      legalBusinessName: legalBusinessNameInput.trim(),
      brandTagline: brandTaglineInput.trim(),
      brandLogoUrl: brandLogoUrlInput.trim(),
      brandLogoDarkUrl: brandLogoDarkUrlInput.trim(),
      faviconUrl: faviconUrlInput.trim(),
      pageTitleTemplate: pageTitleTemplateInput.trim(),
      metaDescription: metaDescriptionInput.trim(),
      businessAddressStreet: businessAddressStreetInput.trim(),
      businessAddressCity: businessAddressCityInput.trim(),
      businessAddressState: businessAddressStateInput.trim(),
      businessAddressZip: businessAddressZipInput.trim(),
      businessAddressCountry: businessAddressCountryInput.trim(),
      businessPhone: businessPhoneInput.trim(),
      supportEmail: supportEmailInput.trim(),
      ordersEmail: ordersEmailInput.trim(),
      pressEmail: pressEmailInput.trim(),
      businessHours: businessHoursInput.trim(),
      instagramHandle: instagramHandleInput.trim(),
      instagramUrl: instagramUrlInput.trim(),
      substackUrl: substackUrlInput.trim(),
      spotifyUrl: spotifyUrlInput.trim(),
      salesTaxRatePercent: Number(salesTaxRatePercentInput),
      currencyCode: currencyCodeInput.trim(),
      currencySymbol: currencySymbolInput.trim(),
    });
    showToast('Brand & Business Profile updated! Page title, logos, and studio contacts synced across the storefront.');
  };

  // Save Editorial CMS
  const handleSaveCMS = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      announcementText: announcementInput,
      announcementActive: announcementActive,
      announcementLinkText: announcementLinkText,
      heroHeadline: heroHeadlineInput,
      heroSubheadline: heroSubheadlineInput,
      heroTagline: heroTaglineInput,
      heroButtonText: heroButtonTextInput,
      heroImageUrl: heroImageUrlInput,
      heroImageOverlayOpacity: heroImageOverlayOpacityInput,
      heroColorMood: heroColorMoodInput,
      foundingQuote: foundingQuoteInput,
      manifestoExcerpt: manifestoExcerptInput,
      storyHeadline: storyHeadlineInput,
      storyBody: storyBodyInput,
      connectionPromptTitle: connectionPromptTitleInput,
      connectionPromptSubtitle: connectionPromptSubtitleInput,
    });
    showToast('Editorial Content & Manifestos updated successfully across all visitor views!');
  };

  // Save Frontend Design Settings
  const handleSaveFrontend = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      shapeDividerEnabled: shapeDividerEnabledInput,
      shapeDividerVariant: shapeDividerVariantInput,
      shapeDividerHeight: shapeDividerHeightInput,
      primaryThemeColor: primaryThemeColorInput,
      enableImageZoom: enableImageZoomInput,
    });
    showToast('Frontend visual theme & Shape Divider configuration saved globally!');
  };

  // Save UX & E-Commerce Settings
  const handleSaveUX = (e: React.FormEvent) => {
    e.preventDefault();
    updateContent({
      freeShippingThreshold: Number(freeShippingThresholdInput),
      standardShippingRate: Number(standardShippingRateInput),
      enableDigitalDignityExport: enableDigitalDignityExportInput,
      enableCookieConsentBanner: enableCookieConsentBannerInput,
      cookieBannerHeadline: cookieBannerHeadlineInput,
      cookieBannerDescription: cookieBannerDescriptionInput,
      enableQuickBagDrawer: enableQuickBagDrawerInput,
    });
    showToast('User Experience, Shipping rates, and Privacy controls updated!');
  };

  // Save New FAQ
  const handleAddFaqSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFaqQ.trim() || !newFaqA.trim()) return;
    addFaq({
      category: newFaqCat,
      question: newFaqQ.trim(),
      answer: newFaqA.trim(),
    });
    setNewFaqQ('');
    setNewFaqA('');
    setAddFaqModalOpen(false);
    showToast('New FAQ item published to the public Care & Inquiries guide!');
  };

  // Apliiq POD Dispatch Batch (Guarded against duplicate submissions)
  const handleTriggerApliiqBatch = async () => {
    setIsSyncingPod(true);
    let submittedCount = 0;
    let duplicateCount = 0;

    for (const o of orders) {
      if (o.status === 'Paid') {
        const res = await fulfillOrder(o.orderNumber, 'apliiq');
        if (res.alreadyFulfilled) {
          duplicateCount++;
        } else if (res.success) {
          submittedCount++;
        }
      }
    }

    setIsSyncingPod(false);
    showToast(
      submittedCount > 0
        ? `Dispatched ${submittedCount} order${submittedCount === 1 ? '' : 's'} to Apliiq POD production queue.`
        : duplicateCount > 0
        ? `All paid orders already submitted to POD. Duplicate submission prevented.`
        : 'No pending paid orders required dispatch.'
    );
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Order Number',
      'Created At',
      'Customer Name',
      'Customer Email',
      'Address Street',
      'City',
      'State',
      'ZIP',
      'Items Count',
      'Subtotal',
      'Shipping',
      'Tax',
      'Total',
      'Status',
      'Carrier',
      'Tracking Number',
    ];

    const rows = orders.map((o) => [
      `"${o.orderNumber}"`,
      `"${o.createdAt}"`,
      `"${o.customerName}"`,
      `"${o.customerEmail}"`,
      `"${o.shippingAddress.street} ${o.shippingAddress.apartment || ''}"`,
      `"${o.shippingAddress.city}"`,
      `"${o.shippingAddress.state}"`,
      `"${o.shippingAddress.zipCode}"`,
      o.items.reduce((sum, it) => sum + it.quantity, 0),
      o.subtotal.toFixed(2),
      o.shippingCost.toFixed(2),
      o.taxCost.toFixed(2),
      o.total.toFixed(2),
      `"${o.status}"`,
      `"${o.carrier || ''}"`,
      `"${o.trackingNumber || ''}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ezistential-orders-export-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Orders exported to CSV!');
  };

  // Download SQL Schema & Data Dump for Step 10
  const handleDownloadSQLDump = () => {
    const sqlContent = `-- EZISTENTIAL CONNECTIONS PRODUCTION MYSQL DUMP
-- Exported on: ${new Date().toISOString()}

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Products
${products
  .map(
    (p) =>
      `INSERT INTO products (id, slug, name, tagline, description, philosophical_note, price, in_stock, is_featured, primary_image, collection_slug) VALUES ('${p.id}', '${p.slug}', '${p.name.replace(/'/g, "''")}', '${p.tagline.replace(/'/g, "''")}', '${p.storyA.thesis.replace(/'/g, "''")}', '${p.storyA.question.replace(/'/g, "''")}', ${p.price}, ${p.isAvailable ? 1 : 0}, ${p.isFeatured ? 1 : 0}, '${p.primaryImage}', '${p.collectionId}') ON DUPLICATE KEY UPDATE price=VALUES(price), in_stock=VALUES(in_stock);`
  )
  .join('\n')}

-- Orders
${orders
  .map(
    (o) =>
      `INSERT INTO orders (id, order_number, customer_name, customer_email, subtotal, shipping_fee, tax, total, status, payment_method, shipping_full_name, shipping_street, shipping_city, shipping_state, shipping_zip, shipping_country, tracking_number) VALUES ('${o.id}', '${o.orderNumber}', '${o.customerName.replace(/'/g, "''")}', '${o.customerEmail.replace(/'/g, "''")}', ${o.subtotal}, ${o.shippingCost}, ${o.taxCost}, ${o.total}, '${o.status}', '${o.paymentMethod}', '${o.shippingAddress.fullName.replace(/'/g, "''")}', '${o.shippingAddress.street.replace(/'/g, "''")}', '${o.shippingAddress.city.replace(/'/g, "''")}', '${o.shippingAddress.state}', '${o.shippingAddress.zipCode}', '${o.shippingAddress.country}', '${o.trackingNumber || ''}') ON DUPLICATE KEY UPDATE status=VALUES(status), tracking_number=VALUES(tracking_number);`
  )
  .join('\n')}

SET FOREIGN_KEY_CHECKS = 1;
`;

    const blob = new Blob([sqlContent], { type: 'text/sql' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ezistential-production-schema-data-${new Date().toISOString().slice(0, 10)}.sql`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('SQL Migration & Data Dump downloaded for Step 10 PHP/MySQL backend!');
  };

  // If not authenticated, render Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-[#fbfbf9] flex flex-col justify-center items-center px-4 sm:px-6 py-12">
        <div className="w-full max-w-md bg-[#141414] border border-[#262626] p-8 sm:p-10 shadow-2xl space-y-8">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <Logo variant="white" className="h-8 w-auto" />
            </div>
            <div className="pt-2">
              <span className="text-[10px] uppercase tracking-widest text-neutral-400 font-mono block">
                Internal Operations Portal
              </span>
              <h1 className="font-serif text-2xl text-white mt-1">Administrative Gateway</h1>
            </div>
          </div>

          <div className="bg-[#1f1f1f] border border-[#333333] p-4 text-xs text-neutral-300 space-y-2">
            <div className="flex items-center space-x-2 text-white font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Operations Cockpit Security</span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              Full centralized control over brand identity, logos, business studio addresses, editorial manifestos, product pricing, orders, and database.
            </p>
            <div className="font-mono text-[11px] text-neutral-300 bg-[#0f0f0f] p-2 border border-[#262626] space-y-1">
              <div><span className="text-neutral-500">Passcode:</span> <span className="text-white">ez-admin-2026</span></div>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-[11px] uppercase tracking-wider text-neutral-400 mb-1.5 font-medium">
                Administrative Passcode
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Enter passcode (or leave default)"
                  className="w-full bg-[#0a0a0a] border border-[#333333] px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-hidden focus:border-white font-mono"
                />
                <Lock className="w-4 h-4 text-neutral-500 absolute right-3 top-3" />
              </div>
              {authError && <p className="text-xs text-red-400 mt-1.5">{authError}</p>}
            </div>

            <Button type="submit" variant="secondary" size="md" fullWidth>
              Sign In to Operations Cockpit
            </Button>

            <button
              type="button"
              onClick={() => {
                setPasswordInput('ez-admin-2026');
                setIsAuthenticated(true);
                localStorage.setItem('ec_admin_auth_v1', 'true');
              }}
              className="w-full text-center text-xs text-neutral-400 hover:text-white underline underline-offset-4 py-1 cursor-pointer transition-colors"
            >
              Quick 1-Click Demo Login
            </button>
          </form>

          <div className="pt-4 border-t border-[#262626] flex items-center justify-between text-xs text-neutral-500">
            <button
              onClick={onBackToStore}
              className="hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
            >
              ← Back to Storefront
            </button>
            <span className="font-mono text-[10px]">v3.0 • Brand & Business Setup</span>
          </div>
        </div>
      </div>
    );
  }

  // Render Authenticated Admin Portal with SIDEBAR
  return (
    <div className="min-h-screen bg-[#f5f4f0] text-[#0a0a0a] flex flex-col md:flex-row font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#0a0a0a] text-white border border-neutral-700 px-5 py-3 shadow-2xl flex items-center space-x-3 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-mono tracking-wide">{toastMessage}</span>
        </div>
      )}

      {/* Mobile Top Header */}
      <div className="md:hidden bg-[#0a0a0a] text-white p-4 flex items-center justify-between sticky top-0 z-40 border-b border-[#262626]">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSidebarOpenMobile(!sidebarOpenMobile)}
            className="p-1.5 text-neutral-300 hover:text-white"
            aria-label="Toggle Navigation Sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>
          <Logo variant="white" className="h-5 w-auto" />
          <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400">Admin</span>
        </div>
        <button
          onClick={onBackToStore}
          className="text-xs uppercase tracking-wider font-mono text-neutral-300 hover:text-white flex items-center gap-1"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Live Store</span>
        </button>
      </div>

      {/* ========================================================
          LEFT SIDEBAR NAVIGATION (DESKTOP & MOBILE DRAWER)
          ======================================================== */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#0c0c0c] text-neutral-300 flex flex-col border-r border-[#222222] transition-transform duration-300 ease-in-out md:translate-x-0 md:static md:w-72 md:shrink-0 ${
          sidebarOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Sidebar Brand Header */}
        <div className="p-5 border-b border-[#222222] flex items-center justify-between">
          <div className="space-y-1">
            <button
              onClick={onBackToStore}
              title="Return to Public Storefront"
              className="hover:opacity-80 transition-opacity cursor-pointer flex items-center"
            >
              <Logo variant="white" className="h-6 w-auto" />
            </button>
            <div className="flex items-center space-x-2 pt-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] uppercase tracking-widest font-mono text-neutral-400">
                Central Operations
              </span>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpenMobile(false)}
            className="md:hidden p-1 text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Categories */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 text-xs">
          {/* Section 1: CORE OPERATIONS */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-bold">
              Core Operations
            </div>

            <button
              onClick={() => {
                setActiveTab('overview');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <LayoutDashboard className="w-4 h-4 shrink-0" />
                <span>Executive Overview</span>
              </div>
            </button>

            <button
              onClick={() => {
                setActiveTab('orders');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'orders'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <PackageCheck className="w-4 h-4 shrink-0" />
                <span>Orders & Fulfillment</span>
              </div>
              {pendingProductionCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-white text-black font-semibold">
                  {pendingProductionCount}
                </span>
              )}
            </button>

            <button
              onClick={() => {
                setActiveTab('users');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'users'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Users className="w-4 h-4 shrink-0 text-blue-400" />
                <span>Customers</span>
              </div>
              <span className="text-[10px] font-mono text-neutral-500">{mockUsers.length}</span>
            </button>
          </div>

          {/* Section 2: GARMENTS & PRODUCT STUDIO */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-bold">
              Garments & Product Studio
            </div>

            <button
              onClick={() => {
                setActiveTab('products');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <ShoppingBag className="w-4 h-4 shrink-0" />
                <span>Product Studio Catalog</span>
              </div>
              <span className="text-[10px] font-mono text-neutral-500">{products.length}</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('design_factory');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'design_factory'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Sparkles className="w-4 h-4 shrink-0 text-purple-400" />
                <span>Design Factory (Creative Lab)</span>
              </div>
              <span className="px-1.5 py-0.5 rounded-full text-[9px] font-mono bg-purple-950 text-purple-300 border border-purple-800">
                Drafts
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('variants');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'variants'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Layers className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Wear Types & Base Blanks</span>
              </div>
              <span className="px-1.5 py-0.5 rounded-full text-[9px] font-mono bg-amber-950 text-amber-300 border border-amber-800">
                Library
              </span>
            </button>
          </div>

          {/* Section 3: CONTENT & EDITORIAL */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-bold">
              Content & Editorial
            </div>

            <button
              onClick={() => {
                setActiveTab('hero_banner');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'hero_banner' || activeTab === 'banner'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Sliders className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Home Banner Studio</span>
              </div>
              <span className="text-[9px] font-mono bg-amber-950 text-amber-300 border border-amber-800 px-1 py-0.5">
                Hero Engine
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('moderation');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'moderation'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <MessageSquare className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Reflections Archive</span>
              </div>
              {pendingReflectionCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-amber-400 text-black font-semibold">
                  {pendingReflectionCount}
                </span>
              )}
            </button>

            <button
              onClick={() => {
                setActiveTab('content_updates');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'content_updates'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <BookOpen className="w-4 h-4 shrink-0 text-neutral-300" />
                <span>Updates</span>
              </div>
              <span className="px-1.5 py-0.5 text-[9px] font-mono bg-amber-950 text-amber-300 border border-amber-800">
                Blog Posts
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('content_faqs');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'content_faqs' || activeTab === 'faqs'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <HelpCircle className="w-4 h-4 shrink-0 text-neutral-300" />
                <span>FAQ & Guidelines</span>
              </div>
              <span className="text-[10px] font-mono text-neutral-500">{faqs.length}</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('content_editorial');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'content_editorial' || activeTab === 'content'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <FileText className="w-4 h-4 shrink-0 text-neutral-300" />
                <span>Page CMS</span>
              </div>
            </button>
          </div>

          {/* Section 3: BRAND CONTROL */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-bold">
              Brand Control
            </div>
            
            <button
              onClick={() => {
                setActiveTab('brand_business_setup');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'brand_business_setup' || activeTab === 'brand'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Building2 className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Business Setup</span>
              </div>
            </button>

            <button
              onClick={() => {
                setIntegrationInitialTab('payment');
                setActiveTab('brand_integration');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'brand_integration'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Zap className="w-4 h-4 shrink-0 text-blue-400" />
                <span>Integrations</span>
              </div>
              <span className="text-[9px] font-mono bg-blue-950 text-blue-300 border border-blue-800 px-1 py-0.5">
                8 Gateways & APIs
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('brand_design');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'brand_design' || activeTab === 'frontend'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Palette className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>Design</span>
              </div>
              <span className="text-[9px] font-mono text-neutral-400">Theme & Divider</span>
            </button>
          </div>

          {/* Section 4: SETTINGS */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-bold">
              System & Settings
            </div>

            <button
              onClick={() => {
                setActiveTab('settings');
                setSidebarOpenMobile(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm transition-all cursor-pointer ${
                activeTab === 'settings' || activeTab === 'ux'
                  ? 'bg-neutral-800 text-white font-medium border-l-2 border-white'
                  : 'hover:bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Settings className="w-4 h-4 shrink-0 text-purple-400" />
                <span>System & Admin Settings</span>
              </div>
            </button>
          </div>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-[#222222] space-y-2 bg-[#090909]">
          <button
            onClick={onBackToStore}
            className="w-full flex items-center justify-center space-x-2 py-2 px-3 bg-[#1a1a1a] hover:bg-neutral-800 text-white text-xs uppercase font-mono tracking-wider transition-colors cursor-pointer border border-[#333333]"
          >
            <Eye className="w-3.5 h-3.5 text-neutral-400" />
            <span>View Public Storefront</span>
          </button>
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center space-x-2 py-2 px-3 text-neutral-400 hover:text-red-400 text-xs font-mono transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out of Cockpit</span>
          </button>
        </div>
      </aside>

      {/* ========================================================
          MAIN ADMIN CONTENT AREA
          ======================================================== */}
      <main className="flex-1 min-w-0 overflow-y-auto max-h-screen p-4 sm:p-6 lg:p-10 space-y-8">
        {/* Top Breadcrumb Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-neutral-200 pb-6">
          <div>
            <div className="flex items-center space-x-2 text-neutral-500 text-xs font-mono uppercase tracking-widest">
              <span>Admin Cockpit</span>
              <span>/</span>
              <span className="text-neutral-900 font-semibold uppercase">{activeTab}</span>
            </div>
            <h1 className="font-serif text-2xl sm:text-3xl text-neutral-900 mt-1 capitalize">
              {activeTab === 'overview' && 'Executive Operations Dashboard'}
              {activeTab === 'brand' && 'Brand & Business Setup (Logos, Title, Studio & Contacts)'}
              {activeTab === 'orders' && 'Orders, Tracking & POD Dispatch'}
              {activeTab === 'products' && 'Product Studio & Garment Catalog'}
              {activeTab === 'design_factory' && 'Design Factory (Creative Lab & Draft Iterations)'}
              {activeTab === 'variants' && 'Master Wear Types, Base Blanks & Color Library'}
              {activeTab === 'moderation' && 'Human Connection Archive Moderation'}
              {activeTab === 'frontend' && 'Frontend Design & Architectural Shape Dividers'}
              {activeTab === 'content' && 'Editorial CMS, Manifestos & Announcements'}
              {activeTab === 'faqs' && 'FAQ Management & Care Directives'}
              {activeTab === 'ux' && 'User Experience, Shipping & Privacy Controls'}
              {activeTab === 'users' && 'Customer Profiles & Multi-Device Accounts Pool'}
              {activeTab === 'seo' && 'Search Optimization & Social Graph'}
            </h1>
          </div>

          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDataBackupOpen(true)}
              className="text-xs"
            >
              <Download className="w-3.5 h-3.5 mr-1.5" />
              <span>Export Snapshot</span>
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={onBackToStore}
              className="text-xs"
            >
              <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
              <span>Live Store</span>
            </Button>
          </div>
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            {/* Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="bg-white border border-neutral-200 p-6 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-neutral-500">
                  <span className="text-[11px] uppercase font-mono tracking-wider">Gross Sales</span>
                  <DollarSign className="w-4 h-4 text-neutral-400" />
                </div>
                <div className="font-serif text-3xl text-neutral-900 font-medium">
                  {formatPrice(totalRevenue)}
                </div>
                <div className="text-[11px] text-emerald-600 flex items-center font-mono">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  <span>100% US Domestic Orders</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-neutral-500">
                  <span className="text-[11px] uppercase font-mono tracking-wider">Active Orders</span>
                  <Package className="w-4 h-4 text-neutral-400" />
                </div>
                <div className="font-serif text-3xl text-neutral-900 font-medium">
                  {orders.length}
                </div>
                <div className="text-[11px] text-neutral-500 font-mono">
                  <span>{pendingProductionCount} in manufacturing queue</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-neutral-500">
                  <span className="text-[11px] uppercase font-mono tracking-wider">Active Catalog</span>
                  <ShoppingBag className="w-4 h-4 text-neutral-400" />
                </div>
                <div className="font-serif text-3xl text-neutral-900 font-medium">
                  {products.length}
                </div>
                <div className="text-[11px] text-neutral-500 font-mono">
                  <span>6.5oz Heavyweight Cotton Blanks</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-neutral-500">
                  <span className="text-[11px] uppercase font-mono tracking-wider">Field Reflections</span>
                  <MessageSquare className="w-4 h-4 text-neutral-400" />
                </div>
                <div className="font-serif text-3xl text-neutral-900 font-medium">
                  {responses.length}
                </div>
                <div className="text-[11px] text-amber-600 font-mono">
                  <span>{pendingReflectionCount} awaiting moderation</span>
                </div>
              </div>
            </div>

            {/* Quick Actions & Recent Orders Table */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-white border border-neutral-200 p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
                  <h3 className="font-serif text-lg text-neutral-900">Recent Customer Transits</h3>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs font-mono uppercase text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer"
                  >
                    <span>View All Orders ({orders.length})</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-neutral-100 text-neutral-400 uppercase font-mono text-[10px]">
                        <th className="py-2.5">Order</th>
                        <th className="py-2.5">Customer</th>
                        <th className="py-2.5">Status</th>
                        <th className="py-2.5 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100">
                      {orders.slice(0, 5).map((ord) => (
                        <tr key={ord.id} className="hover:bg-neutral-50/50">
                          <td className="py-3 font-mono font-medium text-neutral-900">{ord.orderNumber}</td>
                          <td className="py-3 text-neutral-600">{ord.customerName}</td>
                          <td className="py-3">
                            <Badge
                              variant={
                                ord.status === 'Delivered'
                                  ? 'success'
                                  : ord.status === 'Shipped'
                                  ? 'info'
                                  : ord.status === 'In Production'
                                  ? 'warning'
                                  : 'neutral'
                              }
                              size="sm"
                            >
                              {ord.status}
                            </Badge>
                          </td>
                          <td className="py-3 text-right font-medium text-neutral-900">
                            {formatPrice(ord.total)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Manufacturing & Database Health */}
              <div className="space-y-6">
                <div className="bg-[#141414] text-white p-6 border border-[#262626] space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400">
                      Brand Foundation
                    </span>
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  </div>
                  <h4 className="font-serif text-lg text-white">{content.brandName}</h4>
                  <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                    Legal Entity: <span className="text-white font-mono">{content.legalBusinessName}</span><br />
                    Studio: <span className="text-white">{content.businessAddressCity}, {content.businessAddressState}</span>
                  </p>
                  <Button
                    variant="secondary"
                    size="sm"
                    fullWidth
                    onClick={() => setActiveTab('brand')}
                  >
                    Configure Brand & Business Setup
                  </Button>
                </div>

                {/* Payment Integrations Health Status */}
                <div className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
                  <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                    <div className="flex items-center space-x-2">
                      <CreditCard className="w-4 h-4 text-neutral-800" />
                      <h4 className="font-serif text-sm font-bold text-neutral-900">Payment Integrations Status</h4>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold">
                      {[
                        content.stripeEnabled !== false && content.stripePublishableKey && content.stripeSecretKey,
                        content.paypalEnabled !== false && content.paypalClientId && content.paypalSecretKey,
                        content.applePayEnabled !== false && content.applePayMerchantId,
                        content.googlePayEnabled !== false && content.googlePayMerchantId,
                        content.klarnaEnabled !== false && content.klarnaClientId,
                        content.afterpayEnabled !== false && content.afterpayMerchantId,
                        content.cashAppPayEnabled !== false && content.cashAppCashtag,
                        content.shopPayEnabled !== false && content.shopPayStorefrontToken,
                      ].filter(Boolean).length} / 8 Active
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {[
                      { id: 'stripe', name: 'Stripe Cards (Visa, MC, Amex)', icon: '💳' },
                      { id: 'paypal', name: 'PayPal & Pay in 4', icon: '🅿️' },
                      { id: 'apple_pay', name: ' Apple Pay Biometric', icon: '' },
                      { id: 'google_pay', name: 'Google Pay Tokenizer', icon: 'G' },
                      { id: 'klarna', name: 'Klarna BNPL', icon: 'K' },
                      { id: 'afterpay', name: 'Afterpay Installments', icon: '▲' },
                      { id: 'cashapp', name: 'Cash App Direct QR', icon: '$' },
                      { id: 'shoppay', name: 'Shop Pay 1-Click', icon: '🛍️' },
                    ].map((gw) => (
                      <div
                        key={gw.id}
                        className="flex items-center justify-between p-2 rounded-xs bg-neutral-50 hover:bg-neutral-100/70 border border-neutral-200/60 transition-colors text-xs"
                      >
                        <span className="font-mono text-neutral-800 flex items-center gap-2 text-[11px] font-medium">
                          <span className="text-xs">{gw.icon}</span>
                          <span>{gw.name}</span>
                        </span>
                        <PaymentStatusBadge provider={gw.id as any} content={content} size="sm" showSublabel={false} />
                      </div>
                    ))}
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    fullWidth
                    onClick={() => {
                      setIntegrationInitialTab('payment');
                      setActiveTab('brand_integration');
                    }}
                    className="flex items-center justify-center gap-1 text-xs cursor-pointer"
                  >
                    <span>Manage Integration Keys & Toggle Gateways</span>
                    <ArrowRight className="w-3 h-3" />
                  </Button>
                </div>

                <div className="bg-white border border-neutral-200 p-6 space-y-3">
                  <div className="flex items-center space-x-2 text-xs font-mono uppercase text-neutral-500">
                    <Sliders className="w-4 h-4 text-amber-600" />
                    <span>Home Banner & Hero Studio</span>
                  </div>
                  <p className="text-xs text-neutral-600">
                    Full control over opening visuals, darkroom scrim overlay colors, typography, CTA buttons, and seamless shape divider blending.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    fullWidth
                    onClick={() => setActiveTab('hero_banner')}
                    className="flex items-center justify-center gap-1 text-xs"
                  >
                    <span>Launch Banner Studio</span>
                    <ArrowRight className="w-3 h-3" />
                  </Button>
                </div>

                <div className="bg-white border border-neutral-200 p-6 space-y-3">
                  <div className="flex items-center space-x-2 text-xs font-mono uppercase text-neutral-500">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Cross-Device Cloud State</span>
                  </div>
                  <p className="text-xs text-neutral-600">
                    Cross-device data synchronization active. Changes made in this portal write to the database and sync across all visitor devices.
                  </p>
                  <button
                    onClick={() => setDataBackupOpen(true)}
                    className="text-xs font-mono text-neutral-900 hover:underline flex items-center gap-1 cursor-pointer font-medium"
                  >
                    <span>Export or Restore Data Snapshot</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* BRAND CONTROL TABS */}
        {(activeTab === 'brand_business_setup' || activeTab === 'brand') && <BrandBusinessSetup />}
        {activeTab === 'brand_integration' && (
          <IntegrationSetup
            initialTab={integrationInitialTab}
            key={integrationInitialTab}
            showToast={showToast}
          />
        )}
        {(activeTab === 'brand_design' || activeTab === 'frontend') && <DesignSetup />}

        {/* HOME BANNER STUDIO */}
        {(activeTab === 'hero_banner' || activeTab === 'banner') && (
          <HomeBannerStudio onBackToStore={onBackToStore} showToast={showToast} />
        )}

        {/* CONTENT TABS */}
        {activeTab === 'content_updates' && <BlogPostsCMS />}

        {/* TAB 3: ORDERS & FULFILLMENT */}
        {activeTab === 'orders' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Title & Header Banner */}
            <div className="bg-white border border-neutral-200 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-serif text-xl font-bold text-neutral-900">Orders & Fulfilment Management</h3>
                <p className="text-xs text-neutral-500 font-sans mt-1">
                  Commercial order fulfillment table with clean order references (e.g. EC-94821-01), sequential row numbering, and line-item tracking.
                </p>
              </div>
              <div className="flex items-center space-x-2 bg-neutral-100 p-1 border border-neutral-200 shrink-0">
                <button
                  type="button"
                  onClick={() => setOrdersSubView('sn_items')}
                  className={`px-3 py-1.5 text-xs font-mono font-medium transition-colors cursor-pointer ${
                    ordersSubView === 'sn_items' ? 'bg-black text-white shadow-xs' : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  Fulfilment Line Items ({allFlattenedItems.length})
                </button>
                <button
                  type="button"
                  onClick={() => setOrdersSubView('orders')}
                  className={`px-3 py-1.5 text-xs font-mono font-medium transition-colors cursor-pointer ${
                    ordersSubView === 'orders' ? 'bg-black text-white shadow-xs' : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  Aggregated Orders ({orders.length})
                </button>
              </div>
            </div>

            {/* Global Search & Action Controls */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-4 border border-neutral-200">
              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-80">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => {
                      setOrderSearch(e.target.value);
                      setSnPage(1);
                    }}
                    placeholder="Search by Order Ref (e.g. EC-94821-01), customer, garment..."
                    className="w-full bg-neutral-50 border border-neutral-200 pl-9 pr-3 py-2 text-xs text-neutral-900 placeholder-neutral-400 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>
                <select
                  value={orderStatusFilter}
                  onChange={(e) => {
                    setOrderStatusFilter(e.target.value as any);
                    setSnPage(1);
                  }}
                  className="bg-neutral-50 border border-neutral-200 px-3 py-2 text-xs text-neutral-700 font-mono focus:outline-hidden"
                >
                  <option value="All">All Statuses</option>
                  <option value="Paid">Paid (Pending Production)</option>
                  <option value="In Production">In Production (Apliiq / POD)</option>
                  <option value="Shipped">Shipped (In Transit)</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={handleExportCSV}>
                  <Download className="w-3.5 h-3.5 mr-1.5" />
                  <span>Export CSV</span>
                </Button>
                <Button variant="outline" size="sm" onClick={() => addSampleOrder()}>
                  <Plus className="w-3.5 h-3.5 mr-1.5" />
                  <span>+ Test Order</span>
                </Button>
              </div>
            </div>

            {/* VIEW 1: FULFILMENT LINE ITEMS (EXACT LAYOUT FROM USER IMAGE) */}
            {ordersSubView === 'sn_items' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                {/* Counting Metric Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-white p-4 border border-neutral-200 shadow-xs">
                    <span className="text-[10px] uppercase font-mono text-neutral-500">Total Fulfilment Entries</span>
                    <div className="text-2xl font-mono font-bold text-neutral-900 mt-1">{allFlattenedItems.length}</div>
                  </div>
                  <div className="bg-white p-4 border border-neutral-200 shadow-xs">
                    <span className="text-[10px] uppercase font-mono text-neutral-500">Total Garment Units</span>
                    <div className="text-2xl font-mono font-bold text-emerald-700 mt-1">{totalSnUnitsCount}</div>
                  </div>
                  <div className="bg-white p-4 border border-neutral-200 shadow-xs">
                    <span className="text-[10px] uppercase font-mono text-neutral-500">Pagination Overview</span>
                    <div className="text-sm font-mono font-bold text-neutral-900 mt-1">
                      Page {snPage} of {totalSnPages} (Showing {paginatedSnItems.length} entries)
                    </div>
                  </div>
                </div>

                {/* Primary Fulfilment Table */}
                <div className="bg-white border border-neutral-200 overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 uppercase font-mono text-[11px]">
                        <tr>
                          <th className="py-3 px-4 w-12 text-center font-bold border-r border-neutral-200">SN</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">ORDER REF</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Customer</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">GARMENT</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">SIZE / COLOR</th>
                          <th className="py-3 px-4 text-center font-bold border-r border-neutral-200 w-16">QTY</th>
                          <th className="py-3 px-4 text-right font-bold border-r border-neutral-200">UNIT PRICE</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">STATUS</th>
                          <th className="py-3 px-4 text-right font-bold">ACTIONS</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-100">
                        {paginatedSnItems.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="py-12 text-center text-neutral-500 font-serif text-sm">
                              No fulfilment line items found matching your criteria.
                            </td>
                          </tr>
                        ) : (
                          paginatedSnItems.map((item, idx) => {
                            const rowSerialNumber = (snPage - 1) * snItemsPerPage + idx + 1;
                            return (
                              <tr key={`${item.orderId}-${idx}`} className="hover:bg-neutral-50/70 transition-colors">
                                {/* SN: Row numbering */}
                                <td className="py-3.5 px-4 text-center font-mono font-bold text-neutral-700 bg-neutral-50/60 border-r border-neutral-100">
                                  {rowSerialNumber}
                                </td>

                                {/* ORDER REF: Clean, e.g. EC-94821-01 */}
                                <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 border-r border-neutral-100 whitespace-nowrap">
                                  {item.orderNumber}
                                </td>

                                {/* Customer */}
                                <td className="py-3.5 px-4 text-neutral-900 border-r border-neutral-100">
                                  <div className="font-medium">{item.customerName}</div>
                                  <div className="text-[10px] text-neutral-400 font-mono line-clamp-1">{item.customerEmail}</div>
                                </td>

                                {/* GARMENT */}
                                <td className="py-3.5 px-4 text-neutral-900 border-r border-neutral-100 font-medium">
                                  <div className="flex items-center gap-2">
                                    {item.image && (
                                      <img
                                        src={safeSrc(item.image)}
                                        alt={item.productName}
                                        className="w-8 h-8 object-cover rounded-xs border border-neutral-200 bg-neutral-100 shrink-0"
                                      />
                                    )}
                                    <div>
                                      <span className="block leading-tight">{item.productName}</span>
                                      {item.wearType && (
                                        <span className="text-[10px] font-mono text-neutral-500 block">
                                          {item.wearType}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                </td>

                                {/* SIZE / COLOR */}
                                <td className="py-3.5 px-4 font-mono text-neutral-700 text-xs border-r border-neutral-100 whitespace-nowrap">
                                  <span className="font-bold text-neutral-900">{item.size}</span>
                                  <span className="text-neutral-400 mx-1.5">/</span>
                                  <span>{item.color}</span>
                                </td>

                                {/* QTY */}
                                <td className="py-3.5 px-4 text-center font-mono font-bold text-neutral-900 border-r border-neutral-100">
                                  {item.quantity}
                                </td>

                                {/* UNIT PRICE */}
                                <td className="py-3.5 px-4 text-right font-mono font-medium text-neutral-900 border-r border-neutral-100">
                                  {formatPrice(item.price)}
                                </td>

                                {/* STATUS */}
                                <td className="py-3.5 px-4 border-r border-neutral-100">
                                  <select
                                    value={item.status}
                                    onChange={(e) => updateOrderStatus(item.orderNumber, e.target.value as OrderStatus)}
                                    className={`text-xs px-2.5 py-1 font-mono rounded-xs border cursor-pointer focus:outline-hidden ${
                                      item.status === 'Delivered'
                                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-semibold'
                                        : item.status === 'Shipped'
                                        ? 'bg-blue-50 text-blue-800 border-blue-300 font-semibold'
                                        : item.status === 'In Production'
                                        ? 'bg-purple-50 text-purple-800 border-purple-300 font-semibold'
                                        : item.status === 'Paid'
                                        ? 'bg-amber-50 text-amber-800 border-amber-300 font-semibold'
                                        : 'bg-neutral-100 text-neutral-700 border-neutral-300'
                                    }`}
                                  >
                                    <option value="Paid">Paid</option>
                                    <option value="In Production">In Production</option>
                                    <option value="Shipped">Shipped</option>
                                    <option value="Delivered">Delivered</option>
                                    <option value="Cancelled">Cancelled</option>
                                  </select>
                                </td>

                                {/* ACTIONS */}
                                <td className="py-3.5 px-4 text-right space-x-1.5 whitespace-nowrap">
                                  <button
                                    onClick={() => setPackingSlipOrder(item.fullOrder)}
                                    title="Print Commercial Packing Slip"
                                    className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded-xs cursor-pointer inline-flex items-center gap-1 text-[11px] font-mono"
                                  >
                                    <Printer className="w-3.5 h-3.5" />
                                    <span className="hidden lg:inline">Slip</span>
                                  </button>
                                  {item.trackingNumber ? (
                                    <a
                                      href={item.trackingUrl || '#'}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-xs inline-flex items-center gap-1 text-[11px] font-mono"
                                      title={`Track: ${item.trackingNumber}`}
                                    >
                                      <Truck className="w-3.5 h-3.5" />
                                      <span className="hidden lg:inline">USPS</span>
                                    </a>
                                  ) : (
                                    <button
                                      onClick={() => {
                                        setTrackingModalOrder(item.fullOrder);
                                        setTrackingInputNum(
                                          `9400 1118 9956 ${Math.floor(1000 + Math.random() * 9000)} ${Math.floor(
                                            1000 + Math.random() * 9000
                                          )} 00`
                                        );
                                      }}
                                      className="p-1.5 text-neutral-400 hover:text-black hover:bg-neutral-100 rounded-xs cursor-pointer inline-flex items-center gap-1 text-[11px] font-mono"
                                      title="Add Carrier Tracking"
                                    >
                                      <Truck className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                  <button
                                    onClick={() => {
                                      openConfirmDelete({
                                        title: 'Delete Order Record',
                                        itemName: `Order #${item.orderNumber} (${item.customerName})`,
                                        itemType: 'order',
                                        warningMessage: 'Permanently removing this order will erase all fulfillment tracking and historical payment records.',
                                        onConfirm: () => {
                                          deleteOrder(item.orderNumber);
                                          showToast(`Order #${item.orderNumber} deleted.`);
                                        },
                                      });
                                    }}
                                    title="Delete Order"
                                    className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-xs cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Pagination Controls */}
                  {totalSnPages > 1 && (
                    <div className="p-4 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between">
                      <span className="text-xs font-mono text-neutral-500">
                        Showing {(snPage - 1) * snItemsPerPage + 1} to {Math.min(snPage * snItemsPerPage, allFlattenedItems.length)} of {allFlattenedItems.length} entries
                      </span>
                      <div className="flex items-center space-x-1">
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={snPage === 1}
                          onClick={() => setSnPage((p) => Math.max(1, p - 1))}
                          className="text-xs"
                        >
                          Previous
                        </Button>
                        {Array.from({ length: totalSnPages }, (_, i) => i + 1).map((pageNum) => (
                          <button
                            key={pageNum}
                            type="button"
                            onClick={() => setSnPage(pageNum)}
                            className={`w-7 h-7 text-xs font-mono transition-colors cursor-pointer border ${
                              snPage === pageNum
                                ? 'bg-black text-white border-black font-bold'
                                : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                            }`}
                          >
                            {pageNum}
                          </button>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={snPage === totalSnPages}
                          onClick={() => setSnPage((p) => Math.min(totalSnPages, p + 1))}
                          className="text-xs"
                        >
                          Next
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* VIEW 2: AGGREGATED ORDERS TABLE */}
            {ordersSubView === 'orders' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="bg-white border border-neutral-200 overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 uppercase font-mono text-[11px]">
                        <tr>
                          <th className="py-3 px-4 w-12 text-center font-bold border-r border-neutral-200">SN</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">ORDER REF</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Date & Time</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Customer</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Garments</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200 text-right">Total</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Fulfillment Status</th>
                          <th className="py-3 px-4 font-bold border-r border-neutral-200">Tracking (USPS)</th>
                          <th className="py-3 px-4 text-right font-bold">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-100">
                        {filteredOrders.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="py-12 text-center text-neutral-500 font-serif text-sm">
                              No customer orders match the current filter criteria.
                            </td>
                          </tr>
                        ) : (
                          filteredOrders.map((ord, idx) => (
                            <tr key={ord.id} className="hover:bg-neutral-50/70 transition-colors">
                              <td className="py-3.5 px-4 text-center font-mono font-bold text-neutral-700 bg-neutral-50/60 border-r border-neutral-100">
                                {idx + 1}
                              </td>
                              <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 border-r border-neutral-100 whitespace-nowrap">
                                {ord.orderNumber}
                              </td>
                              <td className="py-3.5 px-4 text-neutral-500 font-mono text-[11px] border-r border-neutral-100 whitespace-nowrap">
                                {new Date(ord.createdAt).toLocaleDateString()}
                              </td>
                              <td className="py-3.5 px-4 border-r border-neutral-100">
                                <div className="font-medium text-neutral-900">{ord.customerName}</div>
                                <div className="text-[10px] text-neutral-500 font-mono">{ord.customerEmail}</div>
                              </td>
                              <td className="py-3.5 px-4 text-neutral-700 border-r border-neutral-100">
                                {ord.items.map((i) => `${i.quantity}x ${i.productName} (${i.size})`).join(', ')}
                              </td>
                              <td className="py-3.5 px-4 font-medium text-neutral-900 font-mono text-right border-r border-neutral-100">
                                {formatPrice(ord.total)}
                              </td>
                              <td className="py-3.5 px-4 border-r border-neutral-100">
                                <select
                                  value={ord.status}
                                  onChange={(e) => updateOrderStatus(ord.orderNumber, e.target.value as OrderStatus)}
                                  className="bg-neutral-50 border border-neutral-300 text-xs px-2 py-1 font-mono rounded-sm focus:outline-hidden"
                                >
                                  <option value="Paid">Paid</option>
                                  <option value="In Production">In Production</option>
                                  <option value="Shipped">Shipped</option>
                                  <option value="Delivered">Delivered</option>
                                  <option value="Cancelled">Cancelled</option>
                                </select>
                              </td>
                              <td className="py-3.5 px-4 font-mono text-[11px] border-r border-neutral-100">
                                {ord.trackingNumber ? (
                                  <a
                                    href={ord.trackingUrl || '#'}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="text-blue-600 hover:underline flex items-center gap-1"
                                  >
                                    <span>{ord.trackingNumber.slice(0, 12)}...</span>
                                    <ExternalLink className="w-3 h-3" />
                                  </a>
                                ) : (
                                  <button
                                    onClick={() => {
                                      setTrackingModalOrder(ord);
                                      setTrackingInputNum(
                                        `9400 1118 9956 ${Math.floor(1000 + Math.random() * 9000)} ${Math.floor(
                                          1000 + Math.random() * 9000
                                        )} 00`
                                      );
                                    }}
                                    className="text-xs text-neutral-500 hover:text-black underline cursor-pointer"
                                  >
                                    + Add Tracking
                                  </button>
                                )}
                              </td>
                              <td className="py-3.5 px-4 text-right space-x-2 whitespace-nowrap">
                                <button
                                  onClick={() => setPackingSlipOrder(ord)}
                                  title="Print Commercial Packing Slip"
                                  className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded-sm cursor-pointer"
                                >
                                  <Printer className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    openConfirmDelete({
                                      title: 'Delete Order Record',
                                      itemName: `Order #${ord.orderNumber} (${ord.customerName} - ${formatPrice(ord.total)})`,
                                      itemType: 'order',
                                      warningMessage: 'Permanently removing this order will erase all fulfillment tracking and historical payment records.',
                                      onConfirm: () => {
                                        deleteOrder(ord.orderNumber);
                                        showToast(`Order #${ord.orderNumber} deleted.`);
                                      },
                                    });
                                  }}
                                  title="Cancel / Delete Order"
                                  className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-sm cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: GARMENT CATALOG & PRODUCT STUDIO */}
        {activeTab === 'products' && (
          isProductStudioOpen ? (
            <ProductStudio
              initialProduct={productStudioInitialProduct}
              initialFromDesign={productStudioInitialDesign}
              onClose={() => {
                setIsProductStudioOpen(false);
                setProductStudioInitialProduct(null);
                setProductStudioInitialDesign(null);
              }}
              onSuccess={(saved) => {
                setIsProductStudioOpen(false);
                setProductStudioInitialProduct(null);
                setProductStudioInitialDesign(null);
                showToast(`Saved and published ${saved.name}!`);
              }}
              showToast={showToast}
            />
          ) : (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-white p-5 border border-neutral-200 gap-4 shadow-xs">
                <div>
                  <h3 className="font-serif text-xl font-bold text-neutral-900">Commercial Garments & Product Studio</h3>
                  <p className="text-xs text-neutral-500 font-sans mt-0.5">
                    Multi-silhouette products, DTF print specs, real-time inventory modes, and direct Apliiq POD fulfillment.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab('design_factory')}
                    className="text-xs font-mono text-purple-900 bg-purple-50 hover:bg-purple-100 border-purple-300 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 mr-1.5 text-purple-700" />
                    <span>Creative Lab (Design Factory)</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab('variants')}
                    className="text-xs font-mono cursor-pointer"
                  >
                    <Layers className="w-3.5 h-3.5 mr-1.5 text-neutral-700" />
                    <span>Wear Types & Blanks ({wearTypes.length})</span>
                  </Button>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={handleOpenAddProductPad}
                    className="text-xs font-mono bg-black text-white hover:bg-neutral-800 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 mr-1.5" />
                    <span>+ Launch Product Studio</span>
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((prod) => (
                  <div key={prod.id} className="bg-white border border-neutral-200 overflow-hidden shadow-xs flex flex-col justify-between hover:border-neutral-400 transition-all">
                    <div>
                      <div className="aspect-4/3 relative bg-neutral-100 overflow-hidden">
                        <img src={safeSrc(prod.primaryImage)} alt={prod.name} className="w-full h-full object-cover" />
                        <div className="absolute top-3 right-3 flex flex-col gap-1 items-end">
                          <Badge variant={prod.isAvailable ? 'success' : 'neutral'} size="sm">
                            {prod.isAvailable ? 'In Stock' : 'Archived'}
                          </Badge>
                          {prod.sourceDesignId && (
                            <span className="px-1.5 py-0.5 text-[9px] font-mono bg-purple-100/90 text-purple-900 border border-purple-300 backdrop-blur-xs">
                              Design #{prod.sourceDesignId}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="p-5 space-y-3">
                        <div>
                          <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400">
                            {prod.collectionId}
                          </span>
                          <h4 className="font-serif text-lg font-bold text-neutral-900">{prod.name}</h4>
                          <p className="text-xs text-neutral-600 italic mt-0.5 font-serif line-clamp-1">"{prod.tagline}"</p>
                        </div>

                        <div className="pt-2 border-t border-neutral-100 space-y-2 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="text-neutral-500 font-mono">Retail Base:</span>
                            <div className="flex items-center space-x-1.5">
                              <span className="font-mono text-neutral-400">$</span>
                              <input
                                type="number"
                                defaultValue={prod.price}
                                onBlur={(e) => {
                                  const newP = parseFloat(e.target.value);
                                  if (!isNaN(newP) && newP > 0) {
                                    updateProductPrice(prod.id, newP);
                                    showToast(`Updated ${prod.name} price to $${newP}`);
                                  }
                                }}
                                className="w-20 bg-neutral-50 border border-neutral-300 px-2 py-1 text-xs font-mono font-bold text-neutral-900 text-right"
                              />
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-[11px] font-mono">
                            <span className="text-neutral-500">Silhouettes:</span>
                            <span className="text-neutral-800 font-medium truncate max-w-40">
                              {(prod.availableWearTypes || ['Heavyweight Tee']).join(', ')}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-[11px] font-mono">
                            <span className="text-neutral-500">Variants:</span>
                            <span className="text-neutral-800 font-bold">
                              {prod.variants?.length || 0} configured SKUs
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between text-xs gap-2">
                      <button
                        onClick={() => handleOpenEditProductPad(prod)}
                        className="text-xs font-mono font-bold uppercase text-black hover:underline cursor-pointer flex items-center gap-1"
                      >
                        <span>Edit Studio</span>
                      </button>
                      <button
                        onClick={() => toggleProductAvailability(prod.id)}
                        className="text-xs font-mono uppercase text-neutral-600 hover:text-black cursor-pointer"
                      >
                        {prod.isAvailable ? 'Mark Sold Out' : 'Mark Available'}
                      </button>
                      {onNavigateToProduct && (
                        <button
                          onClick={() => onNavigateToProduct(prod.id)}
                          className="text-xs font-mono text-black hover:underline cursor-pointer flex items-center gap-1"
                        >
                          <span>View</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          openConfirmDelete({
                            title: 'Delete Catalog Garment',
                            itemName: `${prod.name} (${prod.slug})`,
                            itemType: 'garment product',
                            warningMessage: 'This will permanently remove this commercial garment, its variants, prices, and editorial specifications from the catalog. This action cannot be undone.',
                            onConfirm: () => {
                              deleteProduct(prod.id);
                              showToast(`Garment "${prod.name}" permanently deleted.`);
                            },
                          });
                        }}
                        className="text-xs font-mono uppercase text-neutral-400 hover:text-red-600 cursor-pointer flex items-center gap-1 p-1 hover:bg-red-50 rounded-xs"
                        title="Delete Garment"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Delete</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        )}

        {/* TAB: DESIGN FACTORY (CREATIVE LAB & DRAFTS) */}
        {activeTab === 'design_factory' && (
          <DesignFactoryCMS
            onPushToProduct={handlePushDesignToStudio}
            showToast={showToast}
          />
        )}

        {/* TAB: MASTER WEAR TYPES & BASE BLANKS LIBRARY */}
        {activeTab === 'variants' && (
          <WearTypeLibraryCMS showToast={showToast} />
        )}

        {/* TAB 5: REFLECTIONS MODERATION */}
        {activeTab === 'moderation' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-white p-4 border border-neutral-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg text-neutral-900">Human Connection Archive Moderation</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  Review, approve, and feature customer answers to "What does this mean to you?".
                </p>
              </div>
              <Badge variant="neutral" size="sm">
                {responses.length} Total Submissions
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {responses.map((ref) => (
                <div
                  key={ref.id}
                  className={`bg-white border p-6 space-y-4 shadow-xs transition-colors ${
                    ref.status === 'Approved'
                      ? 'border-emerald-200'
                      : ref.status === 'Rejected'
                      ? 'border-red-200 opacity-60'
                      : 'border-amber-200 bg-amber-50/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-500">
                      {ref.productName || 'General Reflection'}
                    </span>
                    <Badge
                      variant={
                        ref.status === 'Approved'
                          ? 'success'
                          : ref.status === 'Rejected'
                          ? 'error'
                          : 'warning'
                      }
                      size="sm"
                    >
                      {ref.status}
                    </Badge>
                  </div>

                  <p className="font-serif italic text-sm text-neutral-900 leading-relaxed">
                    "{ref.response}"
                  </p>

                  <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500 font-mono">
                    <span>
                      {ref.authorName} · {ref.authorLocation}
                    </span>
                    <span className="text-[10px]">{new Date(ref.createdAt).toLocaleDateString()}</span>
                  </div>

                  <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs">
                    <div className="space-x-2">
                      <button
                        onClick={() => {
                          updateStatus(ref.id, 'Approved');
                          showToast('Reflection approved for storefront display');
                        }}
                        className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[11px] font-mono hover:bg-emerald-200 cursor-pointer"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => {
                          updateStatus(ref.id, 'Rejected');
                          showToast('Reflection hidden from public view');
                        }}
                        className="px-2.5 py-1 bg-red-100 text-red-800 text-[11px] font-mono hover:bg-red-200 cursor-pointer"
                      >
                        Reject
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        openConfirmDelete({
                          title: 'Delete Reflection Submission',
                          itemName: `Reflection by ${ref.authorName}: "${ref.response.slice(0, 36)}..."`,
                          itemType: 'reflection',
                          warningMessage: 'This submission will be permanently removed from the community archive database.',
                          onConfirm: () => {
                            deleteResponse(ref.id);
                            showToast('Reflection permanently deleted.');
                          },
                        });
                      }}
                      className="text-neutral-400 hover:text-red-600 p-1 hover:bg-red-50 rounded-xs cursor-pointer"
                      title="Permanently Delete Reflection"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: FRONTEND DESIGN & SHAPE DIVIDERS */}
        {activeTab === 'frontend' && (
          <form onSubmit={handleSaveFrontend} className="space-y-8 animate-in fade-in duration-200">
            <div className="bg-white border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-xs">
              <div className="border-b border-neutral-100 pb-4">
                <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
                  Design System & Layout Architecture
                </span>
                <h3 className="font-serif text-xl text-neutral-900 mt-1">
                  Architectural Shape Divider & Theme Settings
                </h3>
                <p className="text-xs text-neutral-600 mt-1">
                  Administer the universal diagonal and contour shape dividers that extend across all storefront pages.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-neutral-50 border border-neutral-200">
                    <div>
                      <label className="text-xs font-semibold text-neutral-900 block">
                        Enable Universal Shape Dividers
                      </label>
                      <p className="text-[11px] text-neutral-500">
                        Renders architectural section cutaways and footer dividers.
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={shapeDividerEnabledInput}
                      onChange={(e) => setShapeDividerEnabledInput(e.target.checked)}
                      className="w-4 h-4 accent-black cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-xs uppercase font-mono text-neutral-700 mb-2">
                      Shape Divider Contour Variant
                    </label>
                    <select
                      value={shapeDividerVariantInput}
                      onChange={(e) => setShapeDividerVariantInput(e.target.value as ShapeDividerVariant)}
                      className="w-full bg-neutral-50 border border-neutral-300 px-3 py-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden"
                    >
                      <option value="editorial-notch">Editorial Notch (Architectural Diagonal Cut)</option>
                      <option value="zebra-contour">Zebra Contour (Organic Dual Topography)</option>
                      <option value="textile-seam">Textile Seam (Tactile Stitch Line)</option>
                      <option value="horizon-converge">Horizon Converge (Geometric Horizon Step)</option>
                      <option value="asymmetric-slash">Asymmetric Slash (High Tension Angle)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs uppercase font-mono text-neutral-700 mb-2">
                      Divider Height in Pixels ({shapeDividerHeightInput}px)
                    </label>
                    <input
                      type="range"
                      min={40}
                      max={120}
                      step={4}
                      value={shapeDividerHeightInput}
                      onChange={(e) => setShapeDividerHeightInput(Number(e.target.value))}
                      className="w-full accent-black cursor-pointer"
                    />
                  </div>
                </div>

                {/* Live Preview Box */}
                <div className="bg-[#141414] text-white p-6 border border-[#262626] space-y-4 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 block mb-2">
                      Live Shape Divider Preview
                    </span>
                    <div className="w-full bg-[#fbfbf9] text-neutral-900 p-4 text-xs font-serif italic text-center">
                      Storefront Page Content Above
                    </div>
                    <div className="w-full overflow-hidden -mt-[1px] -mb-[1px]">
                      <ShapeDivider
                        variant={shapeDividerVariantInput}
                        fillColor="#141414"
                        bgColor="transparent"
                        height={shapeDividerHeightInput}
                        position="bottom"
                      />
                    </div>
                    <div className="w-full bg-[#141414] text-neutral-400 p-4 text-xs font-mono text-center">
                      Global Charcoal Footer (#141414) Below
                    </div>
                  </div>

                  <p className="text-[11px] text-neutral-400">
                    Active on: Home, Garments, Product Details, Customer Dashboard, Manifesto, FAQs, and Policies.
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-100 flex justify-end">
                <Button type="submit" variant="primary" size="md">
                  Save Frontend Design Settings
                </Button>
              </div>
            </div>
          </form>
        )}

        {/* TAB 7: EDITORIAL PAGES CMS */}
        {(activeTab === 'content_editorial' || activeTab === 'content') && (
          <EditorialPagesCMS />
        )}

        {/* TAB 8: FAQS & CARE GUIDELINES */}
        {(activeTab === 'content_faqs' || activeTab === 'faqs') && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-white p-4 border border-neutral-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg text-neutral-900">Frequently Asked Questions & Care Directives</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  Manage questions, fabric care, sizing specifications, and domestic shipping policies.
                </p>
              </div>
              <Button variant="primary" size="sm" onClick={() => setAddFaqModalOpen(true)}>
                <Plus className="w-3.5 h-3.5 mr-1.5" />
                <span>Add New FAQ</span>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {faqs.map((faq) => (
                <div key={faq.id} className="bg-white border border-neutral-200 p-6 space-y-3 shadow-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400">
                      {faq.category}
                    </span>
                    <button
                      onClick={() => {
                        openConfirmDelete({
                          title: 'Delete FAQ Item',
                          itemName: `"${faq.question}"`,
                          itemType: 'FAQ item',
                          warningMessage: 'This question and answer will be permanently removed from customer care and guidance.',
                          onConfirm: () => {
                            deleteFaq(faq.id);
                            showToast('FAQ deleted.');
                          },
                        });
                      }}
                      className="text-neutral-400 hover:text-red-600 p-1 hover:bg-red-50 rounded-xs cursor-pointer"
                      title="Delete FAQ"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <h4 className="font-serif text-base text-neutral-900 font-medium">{faq.question}</h4>
                  <p className="text-xs text-neutral-600 leading-relaxed font-sans font-light">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SETTINGS TAB */}
        {(activeTab === 'settings' || activeTab === 'ux') && (
          <SettingsSetup onOpenDataBackupModal={() => setDataBackupOpen(true)} />
        )}

        {/* TAB 10: CUSTOMER ACCOUNTS POOL */}
        {activeTab === 'users' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-white p-4 border border-neutral-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg text-neutral-900">Multi-Device Customer Accounts Pool</h3>
                <p className="text-xs text-neutral-500 font-sans">
                  Inspect registered user profiles, roles, wishlists, and shipping addresses synchronized in the central database.
                </p>
              </div>
              <Badge variant="neutral" size="sm">
                {mockUsers.length} Registered Accounts
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mockUsers.map((u) => (
                <div key={u.id} className="bg-white border border-neutral-200 p-6 space-y-4 shadow-xs">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      {u.avatarUrl ? (
                        <img src={u.avatarUrl} alt={u.fullName} className="w-10 h-10 rounded-full object-cover border border-neutral-200" />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-neutral-900 text-white flex items-center justify-center font-serif text-sm">
                          {u.fullName.charAt(0)}
                        </div>
                      )}
                      <div>
                        <h4 className="font-serif text-base text-neutral-900 font-medium">{u.fullName}</h4>
                        <span className="text-xs text-neutral-500 font-mono">{u.email}</span>
                      </div>
                    </div>

                    <Badge variant={u.role === 'admin' ? 'info' : 'neutral'} size="sm">
                      {u.role || 'customer'}
                    </Badge>
                  </div>

                  {u.bio && <p className="text-xs text-neutral-600 italic">"{u.bio}"</p>}

                  <div className="pt-3 border-t border-neutral-100 grid grid-cols-2 gap-4 text-xs font-mono text-neutral-500">
                    <div>
                      <span className="text-[10px] uppercase block">Saved Addresses:</span>
                      <span className="text-neutral-900 font-medium">{u.addresses.length} on file</span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase block">Contemplation Bag:</span>
                      <span className="text-neutral-900 font-medium">{u.savedGarments.length} saved garments</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 11: SEO & SOCIAL GRAPH */}
        {activeTab === 'seo' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-white p-6 border border-neutral-200 space-y-6 shadow-xs">
              <div className="border-b border-neutral-100 pb-4">
                <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
                  Search Engine & OpenGraph Optimization
                </span>
                <h3 className="font-serif text-xl text-neutral-900 mt-1">Live SERP & Social Share Simulator</h3>
              </div>

              {/* SERP Preview */}
              <div className="space-y-3">
                <span className="text-xs font-mono uppercase text-neutral-500 font-medium">
                  Google Search Result Snippet Preview
                </span>
                <div className="bg-white border border-neutral-300 p-5 space-y-1.5 max-w-2xl">
                  <div className="flex items-center space-x-2 text-xs text-neutral-600 font-sans">
                    <span className="text-emerald-700 font-medium">https://ezistential.com</span>
                    <span>›</span>
                    <span>storefront</span>
                  </div>
                  <h4 className="text-blue-800 text-lg font-medium hover:underline cursor-pointer font-serif">
                    {content.pageTitleTemplate}
                  </h4>
                  <p className="text-xs text-neutral-600 leading-relaxed font-sans">
                    {content.metaDescription || content.heroSubheadline}
                  </p>
                </div>
              </div>

              {/* JSON-LD Structured Data */}
              <div className="space-y-2 pt-4 border-t border-neutral-100">
                <span className="text-xs font-mono uppercase text-neutral-500 font-medium">
                  Schema.org JSON-LD Structured Data
                </span>
                <pre className="bg-[#0a0a0a] text-emerald-400 p-4 text-[11px] font-mono overflow-x-auto border border-neutral-800">
{`{
  "@context": "https://schema.org",
  "@type": "ClothingStore",
  "name": "${content.brandName}",
  "legalName": "${content.legalBusinessName}",
  "telephone": "${content.businessPhone}",
  "email": "${content.supportEmail}",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "${content.businessAddressStreet}",
    "addressLocality": "${content.businessAddressCity}",
    "addressRegion": "${content.businessAddressState}",
    "postalCode": "${content.businessAddressZip}",
    "addressCountry": "US"
  },
  "url": "https://ezistential.com",
  "logo": "https://ezistential.com${content.brandLogoUrl}",
  "currenciesAccepted": "${content.currencyCode}",
  "priceRange": "$48 - $72"
}`}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB: MEMBER VERIFICATION & USER MANAGEMENT */}
        {activeTab === 'users' && (
          <UserVerificationCMS
            contentRules={content.memberVerificationRules}
            onUpdateRules={(rules) => updateContent({ memberVerificationRules: rules })}
            orders={orders}
            responses={responses}
            currentUser={user}
            showToast={showToast}
          />
        )}
      </main>

      {/* Modals */}
      {packingSlipOrder && (
        <PackingSlipModal
          order={packingSlipOrder}
          onClose={() => setPackingSlipOrder(null)}
        />
      )}

      {dataBackupOpen && (
        <DataBackupModal
          isOpen={dataBackupOpen}
          onClose={() => setDataBackupOpen(false)}
          onDataRestored={() => showToast('Database snapshot restored successfully!')}
        />
      )}

      {/* Tracking Modal */}
      {trackingModalOrder && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-white max-w-md w-full p-6 space-y-4 border border-neutral-300 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-base text-neutral-900">Add USPS Tracking</h3>
              <button onClick={() => setTrackingModalOrder(null)} className="text-neutral-400 hover:text-black">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Carrier</label>
              <input
                type="text"
                value={trackingInputCarrier}
                onChange={(e) => setTrackingInputCarrier(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Tracking Number</label>
              <input
                type="text"
                value={trackingInputNum}
                onChange={(e) => setTrackingInputNum(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setTrackingModalOrder(null)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  updateOrderTracking(
                    trackingModalOrder.orderNumber,
                    trackingInputNum,
                    trackingInputCarrier,
                    trackingInputUrl || undefined
                  );
                  setTrackingModalOrder(null);
                  showToast('Tracking saved & order status updated to Shipped!');
                }}
              >
                Save & Dispatch
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Add FAQ Modal */}
      {addFaqModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <form onSubmit={handleAddFaqSubmit} className="bg-white max-w-lg w-full p-6 space-y-4 border border-neutral-300 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <h3 className="font-serif text-base text-neutral-900">Publish New FAQ Directive</h3>
              <button type="button" onClick={() => setAddFaqModalOpen(false)} className="text-neutral-400 hover:text-black">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Category</label>
              <select
                value={newFaqCat}
                onChange={(e) => setNewFaqCat(e.target.value as any)}
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs font-mono"
              >
                <option value="Brand & Meaning">Brand & Meaning</option>
                <option value="Products & Sizing">Products & Sizing</option>
                <option value="Shipping & Delivery">Shipping & Delivery</option>
                <option value="Returns & Care">Returns & Care</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Question</label>
              <input
                type="text"
                required
                value={newFaqQ}
                onChange={(e) => setNewFaqQ(e.target.value)}
                placeholder="e.g. How does the garment fit across different builds?"
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-neutral-600 mb-1">Answer</label>
              <textarea
                rows={4}
                required
                value={newFaqA}
                onChange={(e) => setNewFaqA(e.target.value)}
                placeholder="Provide comprehensive, brand-aligned answer..."
                className="w-full bg-neutral-50 border border-neutral-300 p-2 text-xs leading-relaxed"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setAddFaqModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="sm">
                Publish FAQ
              </Button>
            </div>
          </form>
        </div>
      )}


      {/* Unified Confirm Delete Modal with TYPE 'DELETE' verification */}
      <ConfirmDeleteModal
        isOpen={deleteModalState.isOpen}
        title={deleteModalState.title}
        itemName={deleteModalState.itemName}
        itemType={deleteModalState.itemType}
        warningMessage={deleteModalState.warningMessage}
        expectedWord="DELETE"
        onConfirm={deleteModalState.onConfirm}
        onClose={() => setDeleteModalState((prev) => ({ ...prev, isOpen: false }))}
      />

    </div>
  );
};
