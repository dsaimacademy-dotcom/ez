import React, { useState } from 'react';
import { CartProvider, useCart } from './context/CartContext';
import { ResponseProvider } from './context/ResponseContext';
import { OrderProvider } from './context/OrderContext';
import { ProductProvider, useProducts } from './context/ProductContext';
import { ContentProvider, useContent } from './context/ContentContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { PostProvider } from './context/PostContext';
import { Order } from './types';
import { AnnouncementBar } from './components/layout/AnnouncementBar';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { CartDrawer } from './components/cart/CartDrawer';
import { CartPage } from './components/cart/CartPage';
import { CheckoutPage } from './components/checkout/CheckoutPage';
import { OrderConfirmationPage } from './components/checkout/OrderConfirmationPage';
import { TrackOrderView } from './components/tracking/TrackOrderView';
import { AdminPortal } from './components/admin/AdminPortal';
import { UserDashboard } from './components/account/UserDashboard';
import { AuthModal } from './components/auth/AuthModal';
import { ShippingReturnsPage } from './components/pages/ShippingReturnsPage';
import { PrivacyPolicyPage } from './components/pages/PrivacyPolicyPage';
import { TermsOfServicePage } from './components/pages/TermsOfServicePage';
import { ConnectionArchivePage } from './components/pages/ConnectionArchivePage';
import { ContactPage } from './components/pages/ContactPage';
import { JournalUpdatesPage } from './components/pages/JournalUpdatesPage';
import { EcosystemPage } from './components/pages/EcosystemPage';
import { CommunityPhotoGallery } from './components/ugc/CommunityPhotoGallery';
import { SizeGuideModal } from './components/modals/SizeGuideModal';
import { ManifestoModal } from './components/modals/ManifestoModal';
import { FitCalculatorModal } from './components/modals/FitCalculatorModal';
import { InternationalWaitlistModal } from './components/modals/InternationalWaitlistModal';
import { PRODUCTS, COLLECTIONS } from './data/products';
import { MANIFESTO_BRIEF, WHY_WE_EXIST_CONTENT, OUR_STORY_CONTENT } from './data/content';
import { FAQ_DATA } from './data/faqs';
import { Button } from './components/ui/Button';
import { cn, safeSrc, formatPrice } from './lib/utils';
import { Badge } from './components/ui/Badge';
import { Tabs } from './components/ui/Tabs';
import { Accordion } from './components/ui/Accordion';
import { SEOHead } from './components/seo/SEOHead';
import { SocialShareModal } from './components/seo/SocialShareModal';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { PWABottomBanner } from './components/pwa/PWABottomBanner';
import { CookieConsentBanner } from './components/layout/CookieConsentBanner';
import { ExperienceGuideModal } from './components/testing/ExperienceGuideModal';
import { ShapeDivider } from './components/ui/ShapeDivider';
import { EditorialHero } from './components/home/EditorialHero';
import { MemberTestimonials } from './components/home/MemberTestimonials';
import { isVariantPurchasable } from './lib/productNormalization';
import { ArrowRight, ShieldCheck, Truck, RefreshCw, MessageSquare, Check, Search, Plus, Minus, ArrowLeft, Share2, Heart, User as UserIcon } from 'lucide-react';
import { useResponses } from './context/ResponseContext';

function MainApp() {
  const { products } = useProducts();
  const { content, faqs } = useContent();
  const { isGarmentSaved, toggleSavedGarment, isAuthenticated } = useAuth();
  const [currentView, setCurrentView] = useState<'home' | 'shop' | 'collections' | 'product' | 'cart' | 'checkout' | 'order-confirmation' | 'why-we-exist' | 'our-story' | 'manifesto' | 'connection' | 'faq' | 'contact' | 'track-order' | 'shipping-returns' | 'privacy' | 'terms' | 'admin' | 'account' | 'updates' | 'ecosystem'>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>(PRODUCTS[0].id);
  const [selectedWearType, setSelectedWearType] = useState<string>(
    PRODUCTS[0].availableWearTypes?.[0] || 'Heavyweight Tee'
  );
  const [selectedSize, setSelectedSize] = useState<string>('L');
  const [selectedColor, setSelectedColor] = useState<string>(PRODUCTS[0].availableColors[0].name);
  const [activeStoryTab, setActiveStoryTab] = useState<'storyA' | 'storyB'>('storyA');
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);
  const [fitCalculatorOpen, setFitCalculatorOpen] = useState(false);
  const [intWaitlistOpen, setIntWaitlistOpen] = useState(false);
  const [manifestoModalOpen, setManifestoModalOpen] = useState(false);
  const [experienceGuideOpen, setExperienceGuideOpen] = useState(false);
  const [socialShareOpen, setSocialShareOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [shareData, setShareData] = useState<{ title: string; statement: string; url?: string; image?: string }>({
    title: 'Ezistential Connections',
    statement: 'The distance between us is man-made.',
  });

  const handleOpenShare = (title: string, statement: string, image?: string) => {
    setShareData({
      title,
      statement,
      url: window.location.href,
      image,
    });
    setSocialShareOpen(true);
  };

  const [faqCategory, setFaqCategory] = useState<string>('All');
  const [faqSearch, setFaqSearch] = useState<string>('');

  // Shop Advanced Filter & Sort State
  const [shopCollectionFilter, setShopCollectionFilter] = useState<string>('all');
  const [shopColorFilter, setShopColorFilter] = useState<string>('all');
  const [shopSortOption, setShopSortOption] = useState<'newest' | 'price-asc' | 'price-desc' | 'name'>('newest');
  const [shopSearchKeyword, setShopSearchKeyword] = useState<string>('');

  // Order & Checkout State
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [trackOrderPrefill, setTrackOrderPrefill] = useState<{ orderNumber: string; email: string }>({
    orderNumber: '',
    email: '',
  });

  // Product Detail Page State
  const [productQuantity, setProductQuantity] = useState<number>(1);
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);
  const [productReflectOpen, setProductReflectOpen] = useState(false);
  const [productReflectText, setProductReflectText] = useState('');
  const [productReflectAuthor, setProductReflectAuthor] = useState('');
  const [productReflectSubmitted, setProductReflectSubmitted] = useState(false);
  
  // Connection Form State
  const [connectionText, setConnectionText] = useState('');
  const [connectionAuthor, setConnectionAuthor] = useState('');
  const [connectionLocation, setConnectionLocation] = useState('');
  const [connectionEmail, setConnectionEmail] = useState('');
  const [connectionPermission, setConnectionPermission] = useState(true);
  const [connectionSubmitted, setConnectionSubmitted] = useState(false);

  // Spotlight Image Carousel State
  const [spotlightImageIndex, setSpotlightImageIndex] = useState<number>(0);
  const spotlightImages = content.spotlightSlides && content.spotlightSlides.length > 0 ? content.spotlightSlides : [
    {
      id: 'slide-1',
      url: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Diverse Age Showcase · Park Series',
      caption: 'The Distance Between Us Is Man-Made',
    },
    {
      id: 'slide-2',
      url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Editorial Campaign · 02',
      caption: 'Interrupted Typography in Public Space',
    },
    {
      id: 'slide-3',
      url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Community & Connection',
      caption: 'Inaugural Statement — Est. Nov 2008',
    },
  ];

  // Contact Form State (In-UI, zero alert)
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('Order & Shipping Assistance');
  const [contactMessage, setContactMessage] = useState('');

  // Tracking Form State
  const [trackingOrderNum, setTrackingOrderNum] = useState('');
  const [trackingEmail, setTrackingEmail] = useState('');
  const [trackingResult, setTrackingResult] = useState<any>(null);

  const { addItem, openCart } = useCart();
  const { responses, approvedResponses, submitResponse } = useResponses();

  const currentProduct = products.find((p) => p.id === selectedProductId) || products[0] || PRODUCTS[0];

  const selectedVariant = currentProduct.variants.find(
    (v) => (selectedWearType ? (v.wearTypeName === selectedWearType || v.wearTypeId === selectedWearType) : true) &&
           v.size === selectedSize && (v.colorName === selectedColor || v.colorId === selectedColor)
  ) || currentProduct.variants.find(
    (v) => v.size === selectedSize && (v.colorName === selectedColor || v.colorId === selectedColor)
  ) || currentProduct.variants[0];

  const currentEffectivePrice = selectedVariant?.priceOverride !== undefined ? selectedVariant.priceOverride : currentProduct.price;

  const isPurchasable = Boolean(
    currentProduct.isAvailable !== false &&
    currentProduct.readinessStatus !== 'draft' &&
    selectedVariant &&
    isVariantPurchasable(selectedVariant)
  );

  const [accountSubView, setAccountSubView] = useState<'overview' | 'verification' | 'orders' | 'wishlist' | 'reflections' | 'addresses' | 'settings'>('overview');

  const handleNavigate = (view: string, param?: string) => {
    if (param && view === 'product') {
      setSelectedProductId(param);
      const prod = products.find((p) => p.id === param) || PRODUCTS.find((p) => p.id === param);
      if (prod) {
        setSelectedColor(prod.availableColors[0]?.name || 'Obsidian Black');
        if (prod.availableWearTypes && prod.availableWearTypes.length > 0) {
          setSelectedWearType(prod.availableWearTypes[0]);
        }
      }
      setProductQuantity(1);
      setActiveImageIndex(0);
      setProductReflectSubmitted(false);
      setProductReflectOpen(false);
    }

    if (view === 'account') {
      if (param && ['overview', 'verification', 'orders', 'wishlist', 'reflections', 'addresses', 'settings'].includes(param)) {
        setAccountSubView(param as any);
      } else {
        setAccountSubView('overview');
      }
      setCurrentView('account');
    } else if (view === 'account-verification') {
      setCurrentView('account');
      setAccountSubView('verification');
    } else if (view === 'account-orders') {
      setCurrentView('account');
      setAccountSubView('orders');
    } else if (view === 'wishlist' || view === 'account-wishlist' || view === 'account-saved') {
      setCurrentView('account');
      setAccountSubView('wishlist');
    } else if (view === 'account-reflections') {
      setCurrentView('account');
      setAccountSubView('reflections');
    } else if (view === 'account-addresses') {
      setCurrentView('account');
      setAccountSubView('addresses');
    } else if (view === 'account-settings') {
      setCurrentView('account');
      setAccountSubView('settings');
    } else {
      setCurrentView(view as any);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = () => {
    if (!isPurchasable || !selectedVariant) return;

    addItem({
      productId: currentProduct.id,
      productSlug: currentProduct.slug,
      productName: currentProduct.name,
      wearTypeId: selectedVariant.wearTypeId,
      wearType: selectedVariant.wearTypeName || selectedWearType,
      price: currentEffectivePrice,
      image: currentProduct.primaryImage,
      variantId: selectedVariant.id,
      size: selectedSize as any,
      colorId: selectedVariant.colorId,
      color: selectedColor,
      colorHex: selectedVariant.colorHex,
      sku: selectedVariant.sku,
      podVariantId: selectedVariant.podVariantId,
      quantity: productQuantity,
    });
  };

  const handleProductReflectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productReflectText.trim()) return;

    submitResponse({
      productId: currentProduct.id,
      productName: currentProduct.name,
      authorName: productReflectAuthor.trim() || 'Anonymous',
      response: productReflectText.trim(),
      permissionGranted: true,
    });

    setProductReflectSubmitted(true);
    setProductReflectText('');
  };

  const handleConnectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!connectionText.trim()) return;

    submitResponse({
      productId: currentProduct.id,
      productName: currentProduct.name,
      authorName: connectionAuthor,
      authorLocation: connectionLocation,
      email: connectionEmail,
      response: connectionText,
      permissionGranted: connectionPermission,
    });

    setConnectionSubmitted(true);
    setConnectionText('');
  };

  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackingOrderNum.trim()) return;

    // Standard demo tracking lookup simulation
    setTrackingResult({
      orderNumber: trackingOrderNum.toUpperCase(),
      status: 'In Production',
      carrier: 'USPS Ground Advantage',
      trackingNumber: '9400 1118 9956 2000 0000 00',
      estimatedDelivery: '3–5 business days',
      history: [
        { date: 'Oct 02, 2026', step: 'Order Paid & Confirmed' },
        { date: 'Oct 03, 2026', step: 'Submitted to On-Demand Production (Apliiq)' },
        { date: 'Current', step: 'Direct-to-Film Print & Quality Curing' },
      ],
    });
  };

  // Filtered FAQs
  const filteredFaqs = faqs.filter((item) => {
    const matchesCategory = faqCategory === 'All' || item.category === faqCategory;
    const matchesSearch =
      faqSearch === '' ||
      item.question.toLowerCase().includes(faqSearch.toLowerCase()) ||
      item.answer.toLowerCase().includes(faqSearch.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  if (currentView === 'admin') {
    return (
      <AdminPortal
        onBackToStore={() => handleNavigate('home')}
        onNavigateToProduct={(id) => handleNavigate('product', id)}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#fbfbf9] text-[#0a0a0a]">
      {/* Dynamic SEO, OpenGraph & Schema.org JSON-LD (Stage 7) */}
      <SEOHead
        currentView={currentView}
        product={currentView === 'product' ? currentProduct : undefined}
        faqs={faqs}
        siteHeadline={content.heroHeadline}
        siteSubheadline={content.heroSubheadline}
      />

      {/* Offline Connectivity Toast (Stage 8) */}
      <OfflineIndicator />

      {/* PWA Floating Bottom Install Banner for PC & Phone (Always re-appears on reload until installed) */}
      <PWABottomBanner />

      {/* Global Privacy & Cookie Consent Covenant */}
      <CookieConsentBanner onNavigateToPrivacy={() => handleNavigate('privacy')} />

      {/* 1. Global Announcement */}
      <AnnouncementBar onOpenGuide={() => setExperienceGuideOpen(true)} />

      {/* 2. Global Navigation Header */}
      <Header
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      {/* 3. Main Views */}
      <main className="flex-1">
        {/* VIEW: HOMEPAGE */}
        {currentView === 'home' && (
          <div>
            {/* Opening Editorial Hero with Atmospheric Background Image & Embedded Seamless Shape Divider */}
            <EditorialHero onNavigate={handleNavigate} />

            {/* Core Philosophy Statement Ribbon */}
            <section className="bg-[#f5f4f0] py-14 px-4 sm:px-6 text-center">
              <div className="max-w-4xl mx-auto space-y-3">
                <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium">
                  Guiding Conviction
                </span>
                <p className="font-serif text-2xl sm:text-3xl tracking-tight text-neutral-900 italic md:whitespace-nowrap text-balance">
                  "{content.foundingQuote}"
                </p>
                <p className="text-xs uppercase tracking-widest text-neutral-500 font-sans md:whitespace-nowrap text-balance">
                  Difference is the threshold where authentic connection begins.
                </p>
              </div>
            </section>

            {/* Shape Divider 2: Running Textile Seam transition into Garment Showcase */}
            <ShapeDivider
              variant="textile-seam"
              fillColor="#fbfbf9"
              bgColor="#f5f4f0"
              height={42}
              position="bottom"
            />

            {/* Featured Garment Showcase */}
            <section className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
              <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-4 border-b border-neutral-200">
                <div>
                  <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium block mb-1">
                    Inaugural Garments
                  </span>
                  <h2 className="font-serif text-3xl sm:text-4xl text-neutral-900 tracking-tight">
                    Ideas Moving Through Public Space
                  </h2>
                </div>
                <button
                  onClick={() => handleNavigate('shop')}
                  className="mt-4 md:mt-0 text-xs uppercase tracking-wider font-medium text-neutral-900 hover:text-neutral-600 flex items-center group cursor-pointer"
                >
                  <span>View All Releases</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1.5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {products.filter((p) => p.isAvailable).map((prod) => (
                  <div
                    key={prod.id}
                    onClick={() => handleNavigate('product', prod.id)}
                    className="group cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      <div className="aspect-3/4 overflow-hidden bg-neutral-100 border border-neutral-200 mb-4 relative">
                        <img
                          src={prod.primaryImage}
                          alt={prod.name}
                          className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                        />
                        {prod.isFeatured && (
                          <div className="absolute top-3 left-3">
                            <Badge variant="dark">Core Concept</Badge>
                          </div>
                        )}
                      </div>

                      <span className="text-[10px] uppercase tracking-widest text-neutral-500 block mb-1">
                        Heavyweight 6.5oz Cotton
                      </span>
                      <h3 className="font-serif text-lg text-neutral-900 group-hover:underline underline-offset-4 decoration-neutral-300">
                        {prod.name}
                      </h3>
                      <p className="text-xs text-neutral-500 mt-1 line-clamp-1 italic font-serif">
                        "{prod.tagline}"
                      </p>
                    </div>

                    <div className="mt-3 flex items-center justify-between pt-2 border-t border-neutral-100">
                      <span className="font-mono text-xs font-medium text-neutral-900">
                        {formatPrice(prod.price)}
                      </span>
                      <span className="text-[11px] uppercase tracking-wider text-neutral-500 group-hover:text-black">
                        Inspect →
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Shape Divider 3: Architectural Faultline Cut leading into Dark Room */}
            <ShapeDivider
              variant="editorial-notch"
              fillColor="#141414"
              bgColor="#fbfbf9"
              height={56}
              position="bottom"
            />

            {/* Featured Product Story (Story A / Story B Spotlight) */}
            <section className="bg-[#141414] text-[#fbfbf9] py-20 sm:py-28 px-4 sm:px-6 lg:px-8">
              <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                <div className="lg:col-span-6 space-y-6">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="inline-block border border-neutral-700 px-3 py-1 text-[10px] uppercase tracking-widest text-neutral-300 font-mono">
                      Story Spotlight
                    </span>
                    <span className="inline-flex items-center gap-1.5 border border-neutral-800 bg-neutral-900/80 px-3 py-1 text-[10px] uppercase font-mono tracking-[0.22em] text-neutral-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-neutral-400" />
                      Est. Nov 2008 • Core Thesis
                    </span>
                  </div>
                  <h2 className="font-serif text-3xl sm:text-5xl text-white tracking-tight leading-tight">
                    "THE DISTANCE BETWEEN US IS MAN-MADE."
                  </h2>
                  <p className="text-neutral-400 text-sm leading-relaxed font-sans font-light">
                    Conceived during reflections on election night in November 2008, this was our first design. It asserts that human distance is not a law of physics; it is an artifact of assumptions and unexamined separation.
                  </p>
                  <blockquote className="border-l border-neutral-600 pl-4 text-xs italic text-neutral-300 font-serif">
                    "A shirt moves through neutral ground. It asks a question without raising its voice."
                  </blockquote>

                  <div className="pt-4 flex items-center gap-4">
                    <Button
                      onClick={() => handleNavigate('product', 'prod-distance-02')}
                      variant="secondary"
                      size="md"
                    >
                      Examine This Garment
                    </Button>
                    <Button
                      onClick={() => handleNavigate('our-story')}
                      variant="ghost"
                      size="md"
                      className="text-neutral-300 hover:text-white hover:bg-neutral-800"
                    >
                      Read Our Story
                    </Button>
                  </div>
                </div>

                <div className="lg:col-span-6">
                  <div
                    onClick={() => handleNavigate('product', 'prod-distance-02')}
                    className="aspect-4/3 bg-neutral-900 border border-neutral-800 overflow-hidden relative shadow-2xl group cursor-pointer"
                    title="Examine Distance Tee — The Distance Between Us Is Man-Made"
                  >
                    <img
                      src={spotlightImages[spotlightImageIndex].url}
                      alt={spotlightImages[spotlightImageIndex].caption}
                      className="w-full h-full object-cover opacity-90 group-hover:opacity-100 group-hover:scale-102 transition-all duration-700"
                    />
                    <div className="absolute bottom-4 left-4 bg-black/80 backdrop-blur-xs px-3 py-2 border border-neutral-700 z-10 pointer-events-none">
                      <p className="text-[10px] uppercase tracking-widest text-neutral-400">{spotlightImages[spotlightImageIndex].subtitle}</p>
                      <p className="text-xs font-serif text-white">{spotlightImages[spotlightImageIndex].caption}</p>
                    </div>

                    {/* Carousel Navigation Buttons */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSpotlightImageIndex((prev) => (prev === 0 ? spotlightImages.length - 1 : prev - 1));
                      }}
                      className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-black/60 hover:bg-black text-white border border-neutral-700 flex items-center justify-center transition-colors cursor-pointer opacity-80 group-hover:opacity-100 z-20"
                      aria-label="Previous image"
                    >
                      ←
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSpotlightImageIndex((prev) => (prev === spotlightImages.length - 1 ? 0 : prev + 1));
                      }}
                      className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-black/60 hover:bg-black text-white border border-neutral-700 flex items-center justify-center transition-colors cursor-pointer opacity-80 group-hover:opacity-100 z-20"
                      aria-label="Next image"
                    >
                      →
                    </button>

                    {/* Carousel Dots */}
                    <div
                      className="absolute bottom-4 right-4 flex items-center space-x-1.5 z-20 bg-black/60 px-2.5 py-1.5 border border-neutral-700"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {spotlightImages.map((_, idx) => (
                        <button
                          key={idx}
                          onClick={() => setSpotlightImageIndex(idx)}
                          className={cn(
                            'w-2 h-2 rounded-full transition-all cursor-pointer',
                            spotlightImageIndex === idx ? 'bg-white w-4' : 'bg-neutral-500 hover:bg-neutral-300'
                          )}
                          aria-label={`Go to slide ${idx + 1}`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Shape Divider 4: Organic Zebra Rhythm return into Manifesto */}
            <ShapeDivider
              variant="zebra-contour"
              fillColor="#fbfbf9"
              bgColor="#141414"
              flipX={true}
              height={54}
              position="bottom"
            />

            {/* Dual-Level Manifesto Teaser */}
            <section className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto text-center space-y-6">
              <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium">
                The Manifesto
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl md:text-[2.75rem] lg:text-[3.25rem] text-neutral-900 tracking-tight md:whitespace-nowrap text-balance leading-tight">
                {MANIFESTO_BRIEF.title}
              </h2>
              <p className="text-sm sm:text-base text-neutral-600 leading-relaxed font-sans max-w-2xl mx-auto text-balance">
                {MANIFESTO_BRIEF.excerpt}
              </p>
              <div className="pt-2">
                <Button
                  onClick={() => setManifestoModalOpen(true)}
                  variant="outline"
                  size="md"
                >
                  Read the Manifesto
                </Button>
              </div>
            </section>

            {/* Member Testimonials: Voices from the Threshold */}
            <MemberTestimonials onNavigate={handleNavigate} />

            {/* Shape Divider 5: Convergence Plane into Community Exchange */}
            <ShapeDivider
              variant="horizon-converge"
              fillColor="#f5f4f0"
              bgColor="#fbfbf9"
              height={46}
              position="bottom"
            />

            {/* "What Does This Mean To You?" Interactive Connection Section */}
            <section className="bg-[#f5f4f0] py-20 sm:py-28 px-4 sm:px-6 lg:px-8">
              <div className="max-w-3xl mx-auto text-center space-y-6">
                <div className="inline-flex items-center space-x-2 text-neutral-600 text-xs">
                  <MessageSquare className="w-4 h-4 stroke-[1.5]" />
                  <span className="uppercase tracking-widest text-[10px]">Community Exchange</span>
                </div>

                <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-neutral-900 tracking-tight md:whitespace-nowrap text-balance">
                  What does this mean to you?
                </h2>
                <p className="text-xs text-neutral-600 max-w-lg mx-auto leading-relaxed">
                  We don't publish unmoderated comments or algorithmic feeds. We invite thoughtful human reflections on difference and connection. With your permission, select responses become part of our permanent archive.
                </p>

                {connectionSubmitted ? (
                  <div className="bg-white border border-neutral-300 p-8 shadow-xs text-center space-y-3 animate-in fade-in duration-300">
                    <div className="w-10 h-10 rounded-full bg-neutral-900 text-white flex items-center justify-center mx-auto">
                      <Check className="w-5 h-5" />
                    </div>
                    <h3 className="font-serif text-xl text-neutral-900">Your Reflection Was Received</h3>
                    <p className="text-xs text-neutral-600 max-w-md mx-auto">
                      Thank you for participating in the space between us. Every submission is read and reviewed thoughtfully.
                    </p>
                    <Button
                      onClick={() => setConnectionSubmitted(false)}
                      variant="outline"
                      size="sm"
                    >
                      Submit Another Reflection
                    </Button>
                  </div>
                ) : (
                  <form
                    onSubmit={handleConnectionSubmit}
                    className="bg-white border border-neutral-300 p-6 sm:p-8 text-left space-y-4 shadow-xs"
                  >
                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-600 font-medium mb-1.5">
                        Your Reflection <span className="text-neutral-400">*</span>
                      </label>
                      <textarea
                        rows={4}
                        required
                        value={connectionText}
                        onChange={(e) => setConnectionText(e.target.value)}
                        placeholder="Reflect on an encounter, an unspoken distance, or what wearing this garment might mean to you..."
                        className="w-full border border-neutral-300 p-3 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans leading-relaxed"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[11px] uppercase tracking-wider text-neutral-600 font-medium mb-1.5">
                          Name / Initials (Optional)
                        </label>
                        <input
                          type="text"
                          value={connectionAuthor}
                          onChange={(e) => setConnectionAuthor(e.target.value)}
                          placeholder="e.g. Maya R."
                          className="w-full border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] uppercase tracking-wider text-neutral-600 font-medium mb-1.5">
                          Location (Optional)
                        </label>
                        <input
                          type="text"
                          value={connectionLocation}
                          onChange={(e) => setConnectionLocation(e.target.value)}
                          placeholder="e.g. Seattle, WA"
                          className="w-full border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-600 font-medium mb-1.5">
                        Email Address (Private, for verification)
                      </label>
                      <input
                        type="email"
                        value={connectionEmail}
                        onChange={(e) => setConnectionEmail(e.target.value)}
                        placeholder="your@email.com"
                        className="w-full border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                      />
                    </div>

                    <div className="flex items-start space-x-2 pt-1">
                      <input
                        type="checkbox"
                        id="permissionCheck"
                        checked={connectionPermission}
                        onChange={(e) => setConnectionPermission(e.target.checked)}
                        className="mt-1"
                      />
                      <label htmlFor="permissionCheck" className="text-xs text-neutral-600">
                        I grant permission for Ezistential Connections to respectfully feature this reflection in curated brand editorial.
                      </label>
                    </div>

                    <Button type="submit" variant="primary" size="md" fullWidth>
                      Submit Response for Moderation
                    </Button>
                  </form>
                )}

                {/* Approved Curated Stories Display */}
                {approvedResponses.length > 0 && (
                  <div className="pt-10 text-left">
                    <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-medium block mb-4">
                      Curated Reflections from the Field
                    </span>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {approvedResponses.slice(0, 3).map((res) => (
                        <div
                          key={res.id}
                          className="bg-white border border-neutral-200 overflow-hidden shadow-xs flex flex-col justify-between group hover:border-black transition-all"
                        >
                          {res.photoUrl && (
                            <div className="aspect-16/10 bg-neutral-100 overflow-hidden relative border-b border-neutral-200">
                              <img
                                src={safeSrc(res.photoUrl)}
                                alt={`${res.authorName} wearing ${res.productName}`}
                                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500 filter contrast-105"
                              />
                              <div className="absolute top-2 left-2 bg-black/75 backdrop-blur-xs text-white px-2 py-0.5 text-[9px] font-mono uppercase tracking-widest">
                                Worn in Public
                              </div>
                            </div>
                          )}
                          <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                            <p className="font-serif italic text-xs text-neutral-800 leading-relaxed">
                              "{res.response}"
                            </p>
                            <div className="flex justify-between items-center text-[10px] uppercase tracking-wider text-neutral-500 pt-3 border-t border-neutral-100">
                              <span className="font-semibold text-neutral-900">{res.authorName} · {res.authorLocation}</span>
                              <span className="font-mono text-neutral-400">{res.productName}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </section>
          </div>
        )}

        {/* VIEW: SHOP / ALL GARMENTS */}
        {currentView === 'shop' && (() => {
          const filteredShopProducts = products.filter((p) => {
            if (!p.isAvailable) return false;
            if (shopCollectionFilter !== 'all' && p.collectionId !== shopCollectionFilter) return false;
            if (shopColorFilter !== 'all' && !p.availableColors.some(c => c.name.toLowerCase() === shopColorFilter.toLowerCase())) return false;
            if (shopSearchKeyword.trim()) {
              const q = shopSearchKeyword.toLowerCase();
              const matchName = p.name.toLowerCase().includes(q);
              const matchTagline = p.tagline.toLowerCase().includes(q);
              const matchStory = p.storyA.thesis.toLowerCase().includes(q);
              if (!matchName && !matchTagline && !matchStory) return false;
            }
            return true;
          }).sort((a, b) => {
            if (shopSortOption === 'price-asc') return a.price - b.price;
            if (shopSortOption === 'price-desc') return b.price - a.price;
            if (shopSortOption === 'name') return a.name.localeCompare(b.name);
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
          });

          return (
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-10">
              <div className="border-b border-neutral-200 pb-8">
                <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium block mb-1">
                  The Collection Archive
                </span>
                <h1 className="font-serif text-4xl sm:text-5xl text-neutral-900 tracking-tight">
                  All Garments
                </h1>
                <p className="text-xs text-neutral-600 mt-2 max-w-xl">
                  Every garment is crafted in heavyweight combed cotton and finished on demand in the United States. Each piece is designed around two stories: the idea and the practical garment.
                </p>
              </div>

              {/* Professional E-Commerce Filter & Sort Control Bar */}
              <div className="bg-white border border-neutral-300 p-4 sm:p-6 shadow-xs space-y-4">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Collection Tabs */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[11px] uppercase tracking-wider font-mono text-neutral-500 mr-2">Series:</span>
                    {[
                      { id: 'all', label: 'All Series' },
                      { id: 'core-concepts', label: 'Core Concepts' },
                      { id: 'dialogue-series', label: 'Dialogue Series' },
                    ].map((col) => (
                      <button
                        key={col.id}
                        onClick={() => setShopCollectionFilter(col.id)}
                        className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer border ${
                          shopCollectionFilter === col.id
                            ? 'bg-black text-white border-black font-semibold'
                            : 'bg-white text-neutral-700 border-neutral-300 hover:border-black'
                        }`}
                      >
                        {col.label}
                      </button>
                    ))}
                  </div>

                  {/* Search Input */}
                  <div className="relative min-w-[240px]">
                    <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={shopSearchKeyword}
                      onChange={(e) => setShopSearchKeyword(e.target.value)}
                      placeholder="Search garments, statements..."
                      className="w-full bg-[#fbfbf9] border border-neutral-300 pl-9 pr-3 py-2 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
                  {/* Color Filter & Count */}
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="text-[11px] uppercase tracking-wider font-mono text-neutral-500">Color:</span>
                    {[
                      { id: 'all', label: 'All Colors' },
                      { id: 'raw black', label: 'Raw Black' },
                      { id: 'bone off-white', label: 'Bone Off-White' },
                      { id: 'washed charcoal', label: 'Washed Charcoal' },
                    ].map((color) => (
                      <button
                        key={color.id}
                        onClick={() => setShopColorFilter(color.id)}
                        className={`px-2.5 py-1 uppercase font-mono tracking-wider transition-colors cursor-pointer border ${
                          shopColorFilter === color.id
                            ? 'bg-neutral-900 text-white border-neutral-900 font-medium'
                            : 'bg-neutral-100 text-neutral-600 border-neutral-200 hover:border-neutral-400'
                        }`}
                      >
                        {color.label}
                      </button>
                    ))}

                    <span className="text-neutral-400 ml-2">
                      Showing {filteredShopProducts.length} of {products.filter(p => p.isAvailable).length} garments
                    </span>
                  </div>

                  {/* Sort By Dropdown */}
                  <div className="flex items-center space-x-2">
                    <span className="text-[11px] uppercase tracking-wider font-mono text-neutral-500">Sort:</span>
                    <select
                      value={shopSortOption}
                      onChange={(e) => setShopSortOption(e.target.value as any)}
                      className="bg-[#fbfbf9] border border-neutral-300 px-3 py-1.5 text-xs text-neutral-900 font-mono uppercase tracking-wider cursor-pointer focus:outline-hidden focus:border-black"
                    >
                      <option value="newest">Newest Arrivals</option>
                      <option value="price-asc">Price: Low to High</option>
                      <option value="price-desc">Price: High to Low</option>
                      <option value="name">Name: A–Z</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Product Grid */}
              {filteredShopProducts.length === 0 ? (
                <div className="bg-white border border-neutral-200 p-16 text-center space-y-4">
                  <p className="font-serif text-2xl text-neutral-900">No garments match your active filters</p>
                  <p className="text-xs text-neutral-500 max-w-md mx-auto">
                    Try clearing your search keyword or resetting color and collection filters.
                  </p>
                  <Button
                    onClick={() => {
                      setShopCollectionFilter('all');
                      setShopColorFilter('all');
                      setShopSearchKeyword('');
                      setShopSortOption('newest');
                    }}
                    variant="outline"
                    size="sm"
                  >
                    Reset All Filters
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
                  {filteredShopProducts.map((prod) => (
                    <div
                      key={prod.id}
                      onClick={() => handleNavigate('product', prod.id)}
                      className="group cursor-pointer flex flex-col justify-between"
                    >
                      <div>
                        <div className="aspect-3/4 overflow-hidden bg-neutral-100 border border-neutral-200 mb-4 relative">
                          <img
                            src={prod.primaryImage}
                            alt={prod.name}
                            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                          />
                          <div className="absolute top-3 left-3 flex flex-col gap-1">
                            <Badge variant="dark">{prod.collectionId.replace('-', ' ')}</Badge>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (!isAuthenticated) {
                                setAuthModalOpen(true);
                              } else {
                                toggleSavedGarment(prod.id);
                              }
                            }}
                            className={`absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center transition-transform hover:scale-110 shadow-xs z-10 ${
                              isGarmentSaved(prod.id) ? 'text-red-600' : 'text-neutral-400 hover:text-black'
                            }`}
                            title={isGarmentSaved(prod.id) ? 'Remove from Saved' : 'Save to Wishlist'}
                          >
                            <Heart className={`w-4 h-4 ${isGarmentSaved(prod.id) ? 'fill-red-600' : ''}`} />
                          </button>
                        </div>

                        <div className="flex items-center space-x-1.5 mb-2">
                          {prod.availableColors.map((c) => (
                            <span
                              key={c.name}
                              className="w-3.5 h-3.5 rounded-full border border-neutral-300"
                              style={{ backgroundColor: c.hex }}
                              title={c.name}
                            />
                          ))}
                        </div>

                        <h3 className="font-serif text-xl text-neutral-900 group-hover:underline underline-offset-4 decoration-neutral-300">
                          {prod.name}
                        </h3>
                        <p className="text-xs text-neutral-500 mt-1 italic font-serif">
                          "{prod.tagline}"
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-neutral-200 flex items-center justify-between">
                        <span className="font-mono text-sm font-medium text-neutral-900">
                          {formatPrice(prod.price)}
                        </span>
                        <span className="text-xs uppercase tracking-wider text-neutral-700 font-medium group-hover:text-black">
                          Examine Garment →
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })()}

        {/* VIEW: COLLECTIONS */}
        {currentView === 'collections' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
            <div className="border-b border-neutral-200 pb-8">
              <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium block mb-1">
                Curated Series
              </span>
              <h1 className="font-serif text-4xl sm:text-5xl text-neutral-900 tracking-tight">
                Collections
              </h1>
              <p className="text-xs text-neutral-600 mt-2 max-w-xl">
                Each collection investigates a specific dimension of the distance between people, starting from our foundational questions in 2008 through our ongoing public dialogue interventions.
              </p>
            </div>

            <div className="space-y-20">
              {COLLECTIONS.map((col) => {
                const colProducts = products.filter((p) => p.collectionId === col.id && p.isAvailable);
                return (
                  <div key={col.id} className="space-y-8">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end border-b border-neutral-200 pb-6">
                      <div className="lg:col-span-8 space-y-2">
                        <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-mono">
                          Series 0{col.displayOrder}
                        </span>
                        <h2 className="font-serif text-3xl text-neutral-900">{col.name}</h2>
                        <p className="font-serif italic text-neutral-600 text-sm">{col.subtitle}</p>
                        <p className="text-xs text-neutral-600 max-w-2xl leading-relaxed font-sans">{col.description}</p>
                      </div>
                      <div className="lg:col-span-4 lg:text-right">
                        <span className="text-xs uppercase tracking-wider text-neutral-500 font-medium font-mono">
                          {colProducts.length} {colProducts.length === 1 ? 'Garment' : 'Garments'}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                      {colProducts.map((prod) => (
                        <div
                          key={prod.id}
                          onClick={() => handleNavigate('product', prod.id)}
                          className="group cursor-pointer flex flex-col justify-between"
                        >
                          <div>
                            <div className="aspect-3/4 overflow-hidden bg-neutral-100 border border-neutral-200 mb-4 relative">
                              <img
                                src={prod.primaryImage}
                                alt={prod.name}
                                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                              />
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (!isAuthenticated) {
                                    setAuthModalOpen(true);
                                  } else {
                                    toggleSavedGarment(prod.id);
                                  }
                                }}
                                className={`absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center transition-transform hover:scale-110 shadow-xs z-10 ${
                                  isGarmentSaved(prod.id) ? 'text-red-600' : 'text-neutral-400 hover:text-black'
                                }`}
                                title={isGarmentSaved(prod.id) ? 'Remove from Saved' : 'Save to Wishlist'}
                              >
                                <Heart className={`w-4 h-4 ${isGarmentSaved(prod.id) ? 'fill-red-600' : ''}`} />
                              </button>
                            </div>
                            <h3 className="font-serif text-lg text-neutral-900 group-hover:underline underline-offset-4">
                              {prod.name}
                            </h3>
                            <p className="text-xs text-neutral-500 mt-1 italic font-serif">
                              "{prod.tagline}"
                            </p>
                          </div>
                          <div className="mt-3 pt-2 border-t border-neutral-100 flex items-center justify-between">
                            <span className="font-mono text-xs font-medium text-neutral-900">
                              {formatPrice(prod.price)}
                            </span>
                            <span className="text-xs uppercase tracking-wider text-neutral-500 group-hover:text-black">
                              Examine →
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* VIEW: PRODUCT DETAIL (TWO STORIES ARCHITECTURE) */}
        {currentView === 'product' && (() => {
          const allProductImages = [
            currentProduct.primaryImage,
            ...currentProduct.galleryImages.map((g) => g.url),
          ];
          const activeImage = allProductImages[activeImageIndex] || currentProduct.primaryImage;
          const otherProducts = products.filter((p) => p.id !== currentProduct.id && p.isAvailable);

          return (
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
                {/* Left Column: Interactive Product Gallery */}
                <div className="lg:col-span-7 space-y-4">
                  <div className="aspect-3/4 overflow-hidden bg-neutral-100 border border-neutral-200 relative group">
                    <img
                      src={activeImage}
                      alt={currentProduct.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge variant="dark">{currentProduct.collectionId.replace('-', ' ')}</Badge>
                    </div>
                  </div>

                  {/* Thumbnail Switcher */}
                  <div className="grid grid-cols-4 gap-3">
                    {allProductImages.map((imgUrl, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveImageIndex(idx)}
                        className={`aspect-square bg-neutral-100 border transition-all overflow-hidden cursor-pointer ${
                          activeImageIndex === idx
                            ? 'border-black ring-1 ring-black'
                            : 'border-neutral-200 hover:border-neutral-400 opacity-80 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={imgUrl}
                          alt={`${currentProduct.name} view ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Right Column: Commercial & Dual-Story Engine */}
                <div className="lg:col-span-5 space-y-6">
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-neutral-500 block mb-1">
                      Ezistential Connections • {currentProduct.collectionId.replace('-', ' ')}
                    </span>
                    <h1 className="font-serif text-3xl sm:text-4xl text-neutral-900 tracking-tight">
                      {currentProduct.name}
                    </h1>
                    <p className="font-serif italic text-neutral-600 text-sm mt-1">
                      "{currentProduct.tagline}"
                    </p>
                    <div className="flex items-center gap-3 mt-3">
                      <p className="font-mono text-xl font-medium text-neutral-900">
                        {formatPrice(currentEffectivePrice)}
                      </p>
                      {selectedVariant?.inventoryMode === 'pod' ? (
                        <span className="px-2 py-0.5 text-[10px] font-mono bg-purple-50 text-purple-800 border border-purple-200">
                          POD • Crafted to Order
                        </span>
                      ) : selectedVariant?.inventoryMode === 'made_to_order' ? (
                        <span className="px-2 py-0.5 text-[10px] font-mono bg-blue-50 text-blue-800 border border-blue-200">
                          Made to Order
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-50 text-emerald-800 border border-emerald-200">
                          In Stock ({selectedVariant?.quantity ?? 24} units)
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Silhouette / Garment Cut Selection */}
                  {currentProduct.availableWearTypes && currentProduct.availableWearTypes.length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-neutral-200">
                      <div className="flex justify-between text-xs">
                        <span className="uppercase tracking-wider text-neutral-500 font-medium">Silhouette / Cut</span>
                        <span className="font-medium text-neutral-900 font-mono text-[11px]">{selectedWearType}</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {currentProduct.availableWearTypes.map((wt) => (
                          <button
                            key={wt}
                            onClick={() => setSelectedWearType(wt)}
                            className={`px-3 py-1.5 text-xs font-mono border uppercase transition-colors cursor-pointer ${
                              selectedWearType === wt
                                ? 'bg-black text-white border-black font-semibold'
                                : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-600'
                            }`}
                          >
                            {wt}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Color Selection */}
                  <div className="space-y-2 pt-2 border-t border-neutral-200">
                    <div className="flex justify-between text-xs">
                      <span className="uppercase tracking-wider text-neutral-500 font-medium">Color</span>
                      <span className="font-medium text-neutral-900">{selectedColor}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      {currentProduct.availableColors.map((color) => (
                        <button
                          key={color.name}
                          onClick={() => setSelectedColor(color.name)}
                          className={`w-7 h-7 rounded-full border-2 transition-all p-0.5 cursor-pointer ${
                            selectedColor === color.name ? 'border-black scale-110' : 'border-transparent hover:scale-105'
                          }`}
                          title={color.name}
                        >
                          <span
                            className="w-full h-full rounded-full block border border-neutral-300"
                            style={{ backgroundColor: color.hex }}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Size Selection */}
                  <div className="space-y-2 pt-2 border-t border-neutral-200">
                    <div className="flex justify-between items-center text-xs">
                      <span className="uppercase tracking-wider text-neutral-500 font-medium">Size</span>
                      <div className="flex items-center space-x-3">
                        <button
                          type="button"
                          onClick={() => setFitCalculatorOpen(true)}
                          className="text-emerald-800 hover:text-emerald-950 font-bold underline underline-offset-4 cursor-pointer flex items-center gap-1 font-mono text-[11px]"
                        >
                          <span>✦ Find My Fit</span>
                        </button>
                        <span className="text-neutral-300">|</span>
                        <button
                          type="button"
                          onClick={() => setSizeGuideOpen(true)}
                          className="text-neutral-700 hover:text-black underline underline-offset-4 cursor-pointer"
                        >
                          Size Guide
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-2">
                      {currentProduct.availableSizes.map((size) => (
                        <button
                          key={size}
                          onClick={() => setSelectedSize(size)}
                          className={`py-2 text-xs font-mono font-medium border uppercase transition-colors cursor-pointer ${
                            selectedSize === size
                              ? 'bg-black text-white border-black'
                              : 'bg-white text-neutral-800 border-neutral-300 hover:border-neutral-700'
                          }`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Quantity & Add to Bag CTA */}
                  <div className="pt-4 space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center border border-neutral-300 bg-white shrink-0">
                        <button
                          onClick={() => setProductQuantity(Math.max(1, productQuantity - 1))}
                          className="p-3.5 hover:bg-neutral-100 text-neutral-600 transition-colors cursor-pointer"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-3.5 text-xs font-mono font-medium">{productQuantity}</span>
                        <button
                          onClick={() => setProductQuantity(productQuantity + 1)}
                          className="p-3.5 hover:bg-neutral-100 text-neutral-600 transition-colors cursor-pointer"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <Button
                        onClick={handleAddToCart}
                        variant={isPurchasable ? "primary" : "secondary"}
                        size="lg"
                        fullWidth
                        disabled={!isPurchasable}
                        className={`py-4 ${!isPurchasable ? 'opacity-60 cursor-not-allowed bg-neutral-200 text-neutral-600 border-neutral-300' : ''}`}
                      >
                        {currentProduct.readinessStatus === 'draft'
                          ? 'Draft Catalog Concept (Not for Sale)'
                          : !selectedVariant || selectedVariant.status === 'unsupported'
                          ? 'Silhouette / Colorway Unsupported'
                          : selectedVariant.status === 'inactive' || !isPurchasable
                          ? 'Currently Unavailable'
                          : `Add to Bag • ${formatPrice(currentEffectivePrice * productQuantity)}`}
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] text-neutral-500 pt-1">
                      <div className="flex items-center space-x-1.5">
                        <Truck className="w-3.5 h-3.5 text-neutral-700 shrink-0" />
                        <span>Free US shipping over $75</span>
                      </div>
                      <div className="flex items-center space-x-1.5">
                        <RefreshCw className="w-3.5 h-3.5 text-neutral-700 shrink-0" />
                        <span>30-day quality guarantee</span>
                      </div>
                    </div>

                    {/* Verified Member Perks Callout Banner */}
                    <div className="bg-[#fcfcfb] border border-neutral-200 p-3 space-y-1 text-xs font-sans">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono uppercase tracking-widest text-amber-900 bg-amber-100 px-2 py-0.5 border border-amber-200 font-bold">
                          Verified Member Privilege
                        </span>
                        <span className="text-[10px] font-mono text-neutral-400">Order + Reflection</span>
                      </div>
                      <p className="text-neutral-700 leading-snug">
                        Verified Wearers unlock early dispatch drops, custom interior label embroidery, and featured placement in the public Connection Archive.
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (!isAuthenticated) {
                            setAuthModalOpen(true);
                          } else {
                            toggleSavedGarment(currentProduct.id);
                          }
                        }}
                        className={`flex-1 text-xs uppercase tracking-wider font-medium border py-2.5 transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                          isGarmentSaved(currentProduct.id)
                            ? 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100'
                            : 'bg-white text-neutral-600 border-neutral-300 hover:border-black hover:text-black'
                        }`}
                      >
                        <Heart className={`w-3.5 h-3.5 ${isGarmentSaved(currentProduct.id) ? 'fill-red-600' : ''}`} />
                        <span>{isGarmentSaved(currentProduct.id) ? 'Saved in Dashboard' : 'Save for Contemplation'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleOpenShare(currentProduct.name, currentProduct.tagline, currentProduct.primaryImage)}
                        className="flex-1 text-xs uppercase tracking-wider text-neutral-600 hover:text-black font-medium border border-neutral-300 hover:border-black py-2.5 transition-colors flex items-center justify-center gap-2 cursor-pointer bg-white"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Share Inquiry</span>
                      </button>
                    </div>
                  </div>

                  {/* THE TWO STORIES ARCHITECTURE (Section 8 of Master Spec) */}
                  <div className="pt-6 border-t border-neutral-200">
                    <Tabs
                      tabs={[
                        { id: 'storyA', label: 'Story A: The Idea' },
                        { id: 'storyB', label: 'Story B: Practical Specs' },
                      ]}
                      activeTab={activeStoryTab}
                      onChange={(id) => setActiveStoryTab(id as any)}
                    />

                    <div className="pt-5 text-xs text-neutral-700 leading-relaxed font-sans">
                      {activeStoryTab === 'storyA' ? (
                        <div className="space-y-4">
                          <div className="bg-[#f5f4f0] p-4 border border-neutral-200">
                            <span className="text-[10px] uppercase tracking-widest text-neutral-500 block mb-1">
                              The Underlying Question
                            </span>
                            <p className="font-serif italic text-base text-neutral-900">
                              "{currentProduct.storyA.question}"
                            </p>
                          </div>
                          <p className="font-sans leading-relaxed">
                            {currentProduct.storyA.thesis}
                          </p>
                          <div className="pt-2 border-t border-neutral-100">
                            <span className="text-[10px] uppercase tracking-widest text-neutral-500 block">
                              Wearer Participation
                            </span>
                            <p className="text-xs text-neutral-600 mt-1 font-serif italic">
                              {currentProduct.storyA.wearerRole}
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3 font-sans">
                          <div className="grid grid-cols-2 gap-3 py-2 border-b border-neutral-100">
                            <div>
                              <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">Fabric</span>
                              <span className="text-neutral-900 font-medium">{currentProduct.storyB.fabric}</span>
                            </div>
                            <div>
                              <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">Weight</span>
                              <span className="text-neutral-900 font-medium">{currentProduct.storyB.weight}</span>
                            </div>
                          </div>

                          <div className="py-2 border-b border-neutral-100">
                            <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">Fit Description</span>
                            <span className="text-neutral-900">{currentProduct.storyB.fit}</span>
                          </div>

                          <div className="py-2 border-b border-neutral-100">
                            <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">Print Method</span>
                            <span className="text-neutral-900">{currentProduct.storyB.printTechnique}</span>
                          </div>

                          <div className="py-2 border-b border-neutral-100">
                            <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">Production & Fulfillment</span>
                            <span className="text-neutral-900">{currentProduct.storyB.productionNotes}</span>
                          </div>

                          <div className="pt-2">
                            <span className="text-[10px] uppercase tracking-wider text-neutral-400 block mb-1">Care Guidelines</span>
                            <ul className="list-disc pl-4 space-y-1 text-neutral-600 text-[11px]">
                              {currentProduct.storyB.careInstructions.map((c, i) => (
                                <li key={i}>{c}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Prompt: What does this mean to you? with inline expandable form */}
                  <div className="bg-[#f5f4f0] p-4 border border-neutral-200 mt-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] uppercase tracking-widest font-semibold text-neutral-900">
                        What does this mean to you?
                      </span>
                      <button
                        onClick={() => setProductReflectOpen(!productReflectOpen)}
                        className="text-xs underline text-neutral-700 hover:text-black cursor-pointer"
                      >
                        {productReflectOpen ? 'Close Reflection' : 'Reflect on This Garment →'}
                      </button>
                    </div>
                    <p className="text-[11px] text-neutral-600 leading-relaxed">
                      How does the statement <em>"{currentProduct.tagline}"</em> resonate with your experience?
                    </p>

                    {productReflectOpen && (
                      <div className="pt-2 border-t border-neutral-200 animate-in fade-in duration-200">
                        {productReflectSubmitted ? (
                          <div className="bg-white p-3 border border-neutral-200 text-xs text-neutral-700 flex items-center space-x-2">
                            <Check className="w-4 h-4 text-black shrink-0" />
                            <span>Your reflection on {currentProduct.name} was received for moderation.</span>
                          </div>
                        ) : (
                          <form onSubmit={handleProductReflectionSubmit} className="space-y-2">
                            <textarea
                              rows={3}
                              required
                              value={productReflectText}
                              onChange={(e) => setProductReflectText(e.target.value)}
                              placeholder={`What does "${currentProduct.tagline}" bring to mind?`}
                              className="w-full bg-white border border-neutral-300 p-2 text-xs focus:outline-hidden focus:border-black font-sans"
                            />
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={productReflectAuthor}
                                onChange={(e) => setProductReflectAuthor(e.target.value)}
                                placeholder="Your name / initials (Optional)"
                                className="flex-1 bg-white border border-neutral-300 p-2 text-xs focus:outline-hidden focus:border-black font-sans"
                              />
                              <Button type="submit" variant="primary" size="sm">
                                Submit
                              </Button>
                            </div>
                          </form>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Community On-Body Photo Gallery (Phase 2 & Ecosystem) */}
              <div className="mt-16 pt-12 border-t border-neutral-200">
                <CommunityPhotoGallery
                  responses={responses}
                  productId={currentProduct.id}
                  productName={currentProduct.name}
                  onNavigateToProduct={(id) => handleNavigate('product', id)}
                  onOpenSubmissionModal={() => setProductReflectOpen(true)}
                />
              </div>

              {/* Related Garments Section */}
              <div className="mt-20 pt-12 border-t border-neutral-200">
                <div className="flex justify-between items-end mb-8">
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-medium block mb-1">
                      Continue Exploring
                    </span>
                    <h3 className="font-serif text-2xl text-neutral-900">
                      Other Garments in this Exploration
                    </h3>
                  </div>
                  <button
                    onClick={() => handleNavigate('shop')}
                    className="text-xs uppercase tracking-wider text-neutral-500 hover:text-black cursor-pointer font-medium"
                  >
                    All Garments →
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
                  {otherProducts.slice(0, 3).map((prod) => (
                    <div
                      key={prod.id}
                      onClick={() => handleNavigate('product', prod.id)}
                      className="group cursor-pointer flex flex-col justify-between"
                    >
                      <div>
                        <div className="aspect-3/4 overflow-hidden bg-neutral-100 border border-neutral-200 mb-3">
                          <img
                            src={prod.primaryImage}
                            alt={prod.name}
                            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                          />
                        </div>
                        <h4 className="font-serif text-base text-neutral-900 group-hover:underline underline-offset-4">
                          {prod.name}
                        </h4>
                        <p className="text-xs text-neutral-500 font-serif italic truncate">
                          "{prod.tagline}"
                        </p>
                      </div>
                      <span className="font-mono text-xs font-medium text-neutral-900 mt-2 block">
                        {formatPrice(prod.price)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })()}

        {/* VIEW: CART PAGE */}
        {currentView === 'cart' && (
          <CartPage
            onNavigateToShop={() => handleNavigate('shop')}
            onNavigateToCheckout={() => handleNavigate('checkout')}
          />
        )}

        {/* VIEW: CHECKOUT */}
        {currentView === 'checkout' && (
          <CheckoutPage
            onBackToCart={() => handleNavigate('cart')}
            onOrderComplete={(order) => {
              setCompletedOrder(order);
              setCurrentView('order-confirmation');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* VIEW: ORDER CONFIRMATION */}
        {currentView === 'order-confirmation' && completedOrder && (
          <OrderConfirmationPage
            order={completedOrder}
            onTrackOrder={(num, em) => {
              setTrackOrderPrefill({ orderNumber: num, email: em });
              setCurrentView('track-order');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onContinueShopping={() => handleNavigate('shop')}
          />
        )}

        {/* VIEW: WHY WE EXIST (Section 4 of Master Spec) */}
        {currentView === 'why-we-exist' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 space-y-12">
            <div className="text-center space-y-4 border-b border-neutral-200 pb-10">
              <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium">
                The Core Problem
              </span>
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-neutral-900 tracking-tight md:whitespace-nowrap text-balance">
                {WHY_WE_EXIST_CONTENT.title}
              </h1>
              <p className="font-serif italic text-lg sm:text-xl text-neutral-600 max-w-3xl mx-auto md:whitespace-nowrap text-balance">
                "{WHY_WE_EXIST_CONTENT.subheading}"
              </p>
            </div>

            <ShapeDivider
              variant="textile-seam"
              fillColor="#fbfbf9"
              bgColor="#f5f4f0"
              height={36}
            />

            <div className="space-y-12 text-sm sm:text-base text-neutral-800 leading-relaxed font-sans font-light">
              {WHY_WE_EXIST_CONTENT.sections.map((sec, i) => (
                <div key={i} className="space-y-4">
                  <h3 className="font-serif text-2xl text-neutral-900 tracking-tight font-normal">
                    {sec.lead}
                  </h3>
                  {sec.paragraphs.map((p, idx) => (
                    <p key={idx}>{p}</p>
                  ))}
                </div>
              ))}
            </div>

            <ShapeDivider
              variant="horizon-converge"
              fillColor="#f5f4f0"
              bgColor="#fbfbf9"
              height={40}
            />

            <div className="bg-[#f5f4f0] p-8 border border-neutral-200 text-center space-y-4">
              <p className="font-serif italic text-lg text-neutral-900 md:whitespace-nowrap text-balance">
                "Somewhere between you and me, there is an us worth discovering."
              </p>
              <div className="pt-2">
                <Button onClick={() => handleNavigate('shop')} variant="primary" size="md">
                  Explore the Garments
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* VIEW: OUR STORY (Section 3 of Master Spec) */}
        {currentView === 'our-story' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 space-y-12">
            <div className="text-center space-y-4 border-b border-neutral-200 pb-10">
              <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium">
                Origin & Medium
              </span>
              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-neutral-900 tracking-tight md:whitespace-nowrap text-balance">
                {OUR_STORY_CONTENT.title}
              </h1>
              <p className="font-serif italic text-lg sm:text-xl text-neutral-600 max-w-3xl mx-auto md:whitespace-nowrap text-balance">
                "{OUR_STORY_CONTENT.subheading}"
              </p>
            </div>

            <div className="relative border-l border-neutral-300 ml-4 sm:ml-8 pl-6 sm:pl-10 space-y-12">
              {OUR_STORY_CONTENT.timeline.map((item, idx) => (
                <div key={idx} className="relative space-y-2">
                  <span className="absolute -left-[31px] sm:-left-[47px] top-1.5 w-3 h-3 rounded-full bg-black border-4 border-[#fbfbf9]" />
                  <span className="text-[11px] uppercase tracking-widest text-neutral-400 font-mono block">
                    {item.year}
                  </span>
                  <h3 className="font-serif text-2xl text-neutral-900 tracking-tight font-normal">
                    {item.title}
                  </h3>
                  <p className="text-sm text-neutral-700 leading-relaxed font-sans font-light">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>

            <div className="pt-8 text-center border-t border-neutral-200">
              <Button onClick={() => handleNavigate('manifesto')} variant="outline" size="md">
                Read the Complete Manifesto
              </Button>
            </div>
          </div>
        )}

        {/* VIEW: MANIFESTO */}
        {currentView === 'manifesto' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 space-y-12">
            <div className="text-center space-y-4 border-b border-neutral-200 pb-10 max-w-5xl mx-auto">
              <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium">
                Foundational Thesis
              </span>
              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] xl:text-[3.6rem] text-neutral-900 tracking-tight md:whitespace-nowrap text-balance leading-tight">
                We Believe in the Space Between Us
              </h1>
              <p className="font-serif italic text-lg sm:text-xl text-neutral-600 md:whitespace-nowrap text-balance">
                "We are not the same. That’s the point."
              </p>
            </div>

            <div className="space-y-8 text-sm sm:text-base text-neutral-800 leading-relaxed font-sans">
              <p className="text-lg font-serif italic border-l-2 border-black pl-4">
                We share the same world, yet we experience each other at a distance. Ezistential Connections exists in that threshold.
              </p>

              <div className="space-y-6 pt-4">
                <h3 className="font-serif text-2xl text-neutral-900 tracking-tight">
                  1. The Illusion of Uniformity
                </h3>
                <p>
                  Too often, unity is mistakenly treated as sameness: that in order to stand beside one another, we must flatten our histories, smooth out our convictions, or parrot identical words. We reject this demand. Difference is not an obstacle to be overcome; it is the very medium in which consciousness, discovery, and respect take shape.
                </p>

                <h3 className="font-serif text-2xl text-neutral-900 tracking-tight">
                  2. Clothing as a Public Intervention
                </h3>
                <p>
                  Why choose garments rather than essays or billboards? Because a garment moves with a human pulse. When you wear a shirt bearing a question, you bring that question into subways, grocery stores, sidewalks, and family tables. It catches the eye of a stranger. It interrupts the automated assumptions we make about one another.
                </p>

                <h3 className="font-serif text-2xl text-neutral-900 tracking-tight">
                  3. The Distance Is Man-Made
                </h3>
                <p>
                  If the distance between two human beings is erected by assumptions, cynicism, and silence, then that distance can also be bridged by deliberate attention. The garments we make will not fix the world. But an idea can change a conversation, and a conversation can change a mind.
                </p>
              </div>
            </div>

            <div className="pt-8 border-t border-neutral-200 text-center">
              <Button onClick={() => handleNavigate('shop')} variant="primary" size="md">
                Explore the Garment Collection
              </Button>
            </div>
          </div>
        )}

        {/* VIEW: JOURNAL UPDATES (BLOG SYSTEM) */}
        {currentView === 'updates' && (
          <JournalUpdatesPage
            onNavigateToShop={() => handleNavigate('shop')}
            onNavigateToHome={() => handleNavigate('home')}
          />
        )}

        {/* VIEW: EC ECOSYSTEM (FILMS, AUDIO, EXHIBITIONS - Phase 2 & Ecosystem) */}
        {currentView === 'ecosystem' && (
          <EcosystemPage
            onNavigateToProduct={(id) => handleNavigate('product', id)}
            onNavigateToShop={() => handleNavigate('shop')}
          />
        )}

        {/* VIEW: CONNECTION ARCHIVE (Stage 6) */}
        {currentView === 'connection' && (
          <ConnectionArchivePage
            onNavigateToProduct={(id) => handleNavigate('product', id)}
            onNavigateToShop={() => handleNavigate('shop')}
          />
        )}

        {/* VIEW: FAQ */}
        {currentView === 'faq' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 space-y-8">
            <div className="text-center space-y-3 border-b border-neutral-200 pb-8">
              <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium">
                Clarity & Transparency
              </span>
              <h1 className="font-serif text-4xl sm:text-5xl text-neutral-900 tracking-tight">
                Frequently Asked Questions
              </h1>
              <p className="text-xs text-neutral-600 max-w-lg mx-auto">
                Honest and direct answers regarding our philosophy, production partners, shipping, sizing, and policies.
              </p>
            </div>

            {/* Search and Category Filter */}
            <div className="space-y-4">
              <div className="relative">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={faqSearch}
                  onChange={(e) => setFaqSearch(e.target.value)}
                  placeholder="Search questions (e.g. sizing, shipping, political, apliiq)..."
                  className="w-full bg-white border border-neutral-300 pl-10 pr-4 py-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans"
                />
              </div>

              <div className="flex flex-wrap gap-2">
                {['All', 'Brand & Meaning', 'Products & Sizing', 'Shipping & Delivery', 'Returns & Care'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setFaqCategory(cat)}
                    className={`px-3 py-1.5 text-[11px] uppercase tracking-wider font-medium border cursor-pointer transition-colors ${
                      faqCategory === cat
                        ? 'bg-black text-white border-black'
                        : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-400'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Accordion FAQ Display */}
            <Accordion
              items={filteredFaqs.map((item) => ({
                id: item.id,
                title: item.question,
                content: <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed">{item.answer}</p>,
              }))}
            />
          </div>
        )}

        {/* VIEW: ORDER TRACKING */}
        {currentView === 'track-order' && (
          <TrackOrderView
            initialOrderNumber={trackOrderPrefill.orderNumber}
            initialEmail={trackOrderPrefill.email}
            onExploreGarments={() => handleNavigate('shop')}
          />
        )}

        {/* VIEW: SHIPPING & RETURNS (Stage 6 Dedicated Page) */}
        {currentView === 'shipping-returns' && (
          <ShippingReturnsPage
            onNavigateToTrack={() => handleNavigate('track-order')}
            onNavigateToContact={() => handleNavigate('contact')}
            onNavigateToShop={() => handleNavigate('shop')}
          />
        )}

        {/* VIEW: CONTACT */}
        {currentView === 'contact' && (
          <ContactPage
            onBackToStore={() => handleNavigate('home')}
            onNavigateToFaq={() => handleNavigate('faq')}
          />
        )}

        {/* VIEW: PRIVACY POLICY (Stage 6 Dedicated Page) */}
        {currentView === 'privacy' && (
          <PrivacyPolicyPage
            onBackToStore={() => handleNavigate('home')}
            onNavigateToContact={() => handleNavigate('contact')}
          />
        )}

        {/* VIEW: USER DASHBOARD & ACCOUNT (Customer Portal) */}
        {currentView === 'account' && (
          <UserDashboard
            currentTab={accountSubView}
            onTabChange={(tab) => setAccountSubView(tab as any)}
            onNavigate={handleNavigate}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {/* VIEW: TERMS OF SERVICE (Stage 6 Dedicated Page) */}
        {currentView === 'terms' && (
          <TermsOfServicePage
            onBackToStore={() => handleNavigate('home')}
            onNavigateToContact={() => handleNavigate('contact')}
          />
        )}
      </main>

      {/* 4. Global Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenGuide={() => setExperienceGuideOpen(true)}
        onOpenIntWaitlist={() => setIntWaitlistOpen(true)}
      />

      {/* 5. Slide-Over Cart Drawer */}
      <CartDrawer
        onNavigateToCheckout={() => handleNavigate('checkout')}
        onNavigateToShop={() => handleNavigate('shop')}
        onNavigateToCart={() => handleNavigate('cart')}
      />

      {/* 6. Modals & Guided Experiential Pathways */}
      <SizeGuideModal isOpen={sizeGuideOpen} onClose={() => setSizeGuideOpen(false)} />
      <FitCalculatorModal
        isOpen={fitCalculatorOpen}
        onClose={() => setFitCalculatorOpen(false)}
        onSelectSize={(s) => setSelectedSize(s)}
        productName={currentProduct?.name || 'Garment'}
      />
      <InternationalWaitlistModal
        isOpen={intWaitlistOpen}
        onClose={() => setIntWaitlistOpen(false)}
      />
      <ManifestoModal isOpen={manifestoModalOpen} onClose={() => setManifestoModalOpen(false)} />
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={() => handleNavigate('account')}
      />
      <ExperienceGuideModal
        isOpen={experienceGuideOpen}
        onClose={() => setExperienceGuideOpen(false)}
        onNavigate={handleNavigate}
        onOpenManifesto={() => setManifestoModalOpen(true)}
        onOpenSizeGuide={() => setSizeGuideOpen(true)}
      />
      <SocialShareModal
        isOpen={socialShareOpen}
        onClose={() => setSocialShareOpen(false)}
        title={shareData.title}
        statement={shareData.statement}
        url={shareData.url}
        image={shareData.image}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ResponseProvider>
        <ContentProvider>
          <PostProvider>
            <ProductProvider>
              <OrderProvider>
                <CartProvider>
                  <MainApp />
                </CartProvider>
              </OrderProvider>
            </ProductProvider>
          </PostProvider>
        </ContentProvider>
      </ResponseProvider>
    </AuthProvider>
  );
}
