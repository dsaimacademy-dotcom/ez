import React, { createContext, useContext, useState, useEffect } from 'react';
import { CustomerResponse, ModerationStatus } from '../types';
import { INITIAL_CUSTOMER_RESPONSES } from '../data/content';
import { api } from '../lib/api';

interface ResponseContextType {
  responses: CustomerResponse[];
  approvedResponses: CustomerResponse[];
  featuredResponses: CustomerResponse[];
  submitResponse: (data: {
    productId?: string;
    productName?: string;
    authorName?: string;
    authorLocation?: string;
    email?: string;
    response: string;
    photoUrl?: string;
    photoCaption?: string;
    garmentOnBodySize?: CustomerResponse['garmentOnBodySize'];
    permissionGranted: boolean;
  }) => void;
  updateStatus: (id: string, status: ModerationStatus) => void;
  toggleFeatured: (id: string) => void;
  deleteResponse: (id: string) => void;
}

const ResponseContext = createContext<ResponseContextType | undefined>(undefined);

const STORAGE_KEY = 'ec_customer_responses_v1';

export const ResponseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [responses, setResponses] = useState<CustomerResponse[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed: CustomerResponse[] = JSON.parse(saved);
        const initialMap = new Map(INITIAL_CUSTOMER_RESPONSES.map((r) => [r.id, r]));
        // Enrich any items missing photos
        const enriched = parsed.map((item) => {
          const init = initialMap.get(item.id);
          if (init && !item.photoUrl) {
            return {
              ...item,
              photoUrl: init.photoUrl,
              garmentOnBodySize: item.garmentOnBodySize || init.garmentOnBodySize,
            };
          }
          return item;
        });

        const existingIds = new Set(enriched.map((p) => p.id));
        const missing = INITIAL_CUSTOMER_RESPONSES.filter((r) => !existingIds.has(r.id));
        const result = [...enriched, ...missing];
        return result.length >= 3 ? result : INITIAL_CUSTOMER_RESPONSES;
      }
      return INITIAL_CUSTOMER_RESPONSES;
    } catch {
      return INITIAL_CUSTOMER_RESPONSES;
    }
  });

  // Cross-device sync: fetch community reflections from central database
  useEffect(() => {
    const syncReflections = async () => {
      try {
        const serverRefs = await api.getReflections('all');
        if (serverRefs && serverRefs.length > 0) {
          const initialMap = new Map(INITIAL_CUSTOMER_RESPONSES.map((r) => [r.id, r]));
          const mapped: CustomerResponse[] = serverRefs.map((r: any, idx: number) => {
            const fallbackInit = initialMap.get(r.id) || INITIAL_CUSTOMER_RESPONSES[idx % INITIAL_CUSTOMER_RESPONSES.length];
            return {
              id: r.id,
              productId: r.productId || fallbackInit?.productId || 'prod-distance-01',
              productName: r.productName || fallbackInit?.productName || 'The Distance Tee',
              authorName: r.authorName,
              authorLocation: r.authorLocation,
              email: r.email,
              response: r.response,
              photoUrl: r.photoUrl || fallbackInit?.photoUrl,
              photoCaption: r.photoCaption || fallbackInit?.photoCaption,
              garmentOnBodySize: r.garmentOnBodySize || fallbackInit?.garmentOnBodySize || 'M',
              permissionGranted: r.permissionGranted ?? true,
              status: (r.status === 'Approved' ? 'Approved' : r.status === 'Rejected' ? 'Rejected' : 'Pending') as ModerationStatus,
              featuredQuote: r.featuredQuote ?? (fallbackInit?.featuredQuote || false),
              createdAt: r.createdAt || new Date().toISOString(),
            };
          });

          // Ensure curated items are retained
          const serverIds = new Set(mapped.map((m) => m.id));
          const missingCurated = INITIAL_CUSTOMER_RESPONSES.filter((c) => !serverIds.has(c.id));
          setResponses([...mapped, ...missingCurated]);
        }
      } catch (err) {
        console.warn('Central DB reflections sync notice:', err);
      }
    };
    syncReflections();
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(responses));
    } catch {
      // ignore storage error
    }
  }, [responses]);

  const submitResponse = (data: {
    productId?: string;
    productName?: string;
    authorName?: string;
    authorLocation?: string;
    email?: string;
    response: string;
    photoUrl?: string;
    photoCaption?: string;
    garmentOnBodySize?: CustomerResponse['garmentOnBodySize'];
    permissionGranted: boolean;
  }) => {
    const newEntry: CustomerResponse = {
      id: `resp-${Date.now().toString(36)}`,
      productId: data.productId,
      productName: data.productName,
      authorName: data.authorName?.trim() || 'Anonymous',
      authorLocation: data.authorLocation?.trim() || 'United States',
      email: data.email?.trim(),
      response: data.response.trim(),
      photoUrl: data.photoUrl?.trim(),
      photoCaption: data.photoCaption?.trim(),
      garmentOnBodySize: data.garmentOnBodySize,
      createdAt: new Date().toISOString(),
      status: 'Approved',
      featuredQuote: false,
      permissionGranted: data.permissionGranted,
    };

    setResponses((prev) => [newEntry, ...prev]);

    // Persist to central database
    api.createReflection({
      productName: newEntry.productName || 'The Distance Tee',
      authorName: newEntry.authorName || 'Anonymous',
      authorLocation: newEntry.authorLocation || 'United States',
      email: newEntry.email,
      response: newEntry.response,
      permissionGranted: newEntry.permissionGranted,
    }).catch(console.warn);
  };

  const updateStatus = (id: string, status: ModerationStatus) => {
    setResponses((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status } : item))
    );
    api.updateReflectionStatus(id, status).catch(console.warn);
  };

  const toggleFeatured = (id: string) => {
    setResponses((prev) =>
      prev.map((item) => (item.id === id ? { ...item, featuredQuote: !item.featuredQuote } : item))
    );
  };

  const deleteResponse = (id: string) => {
    setResponses((prev) => prev.filter((item) => item.id !== id));
  };

  const approvedResponses = responses.filter((r) => r.status === 'Approved');
  const featuredResponses = responses.filter((r) => r.status === 'Approved' && r.featuredQuote);

  return (
    <ResponseContext.Provider
      value={{
        responses,
        approvedResponses,
        featuredResponses,
        submitResponse,
        updateStatus,
        toggleFeatured,
        deleteResponse,
      }}
    >
      {children}
    </ResponseContext.Provider>
  );
};

export const useResponses = (): ResponseContextType => {
  const context = useContext(ResponseContext);
  if (!context) {
    throw new Error('useResponses must be used within a ResponseProvider');
  }
  return context;
};
