-- Ezistential Connections — Complete MySQL Production Database Schema
-- Target: MySQL 5.7+ / 8.0+ / MariaDB 10.3+ (cPanel Compatible)
-- Engine: InnoDB with UTF8MB4 Full Unicode Support

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------
-- 1. Master Wear Types (Silhouettes & Blanks)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wear_types` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `wholesale_cost` DECIMAL(10,2) NOT NULL DEFAULT 18.50,
  `default_retail_price` DECIMAL(10,2) NOT NULL DEFAULT 48.00,
  `fabric_weight` VARCHAR(100) NOT NULL DEFAULT '6.5oz / 220 GSM Combed Cotton',
  `fit_profile` VARCHAR(100) NOT NULL DEFAULT 'Architectural Relaxed Boxy Fit',
  `primary_provider` ENUM('apliiq', 'printful', 'custom') NOT NULL DEFAULT 'apliiq',
  `base_garment_code` VARCHAR(100) NOT NULL DEFAULT 'APL-TEE-6500',
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 2. Master Color Library
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `colors` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `hex` VARCHAR(10) NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 3. Master Size Scale
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sizes` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(20) NOT NULL,
  `chest_inches` DECIMAL(5,1) NULL,
  `length_inches` DECIMAL(5,1) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 4. Creative Lab Design Drafts
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `designs` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `thesis` TEXT NULL,
  `status` ENUM('draft', 'in_review', 'approved', 'archived') NOT NULL DEFAULT 'draft',
  `approved_version_id` VARCHAR(64) NULL,
  `suggested_wear_types` JSON NULL,
  `suggested_colors` JSON NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 5. Design Version Iterations & Artwork Files
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `design_versions` (
  `id` VARCHAR(64) NOT NULL,
  `design_id` VARCHAR(64) NOT NULL,
  `version_number` INT NOT NULL DEFAULT 1,
  `artwork_front_url` TEXT NULL,
  `artwork_back_url` TEXT NULL,
  `artwork_sleeve_url` TEXT NULL,
  `artwork_preview_url` TEXT NULL,
  `notes` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_design_id` (`design_id`),
  CONSTRAINT `fk_versions_design` FOREIGN KEY (`design_id`) REFERENCES `designs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 6. Commercial Catalog Products
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `category` VARCHAR(100) NOT NULL DEFAULT 'Tees',
  `collection_name` VARCHAR(100) NOT NULL DEFAULT 'Inaugural Concept',
  `base_price` DECIMAL(10,2) NOT NULL DEFAULT 48.00,
  `wholesale_cost` DECIMAL(10,2) NOT NULL DEFAULT 18.50,
  `status` ENUM('draft', 'published', 'archived') NOT NULL DEFAULT 'published',
  `is_ready_for_pod` TINYINT(1) NOT NULL DEFAULT 1,
  `story_a_thesis` TEXT NULL,
  `story_a_meaning` TEXT NULL,
  `story_a_wearer_role` TEXT NULL,
  `story_a_contemplation` TEXT NULL,
  `story_b_fabric_spec` TEXT NULL,
  `story_b_weight_gsm` VARCHAR(100) NULL,
  `story_b_fit_notes` TEXT NULL,
  `story_b_print_method` VARCHAR(150) NULL,
  `primary_image_url` TEXT NOT NULL,
  `gallery_urls` JSON NULL,
  `source_design_id` VARCHAR(64) NULL,
  `source_design_version_id` VARCHAR(64) NULL,
  `source_design_version_number` INT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_product_slug` (`slug`),
  INDEX `idx_source_design` (`source_design_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 7. Product Variants (Specific SKU combinations)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `product_variants` (
  `id` VARCHAR(64) NOT NULL,
  `product_id` VARCHAR(64) NOT NULL,
  `sku` VARCHAR(100) NOT NULL UNIQUE,
  `wear_type_id` VARCHAR(64) NOT NULL,
  `wear_type_name` VARCHAR(255) NOT NULL,
  `size` VARCHAR(20) NOT NULL,
  `color_id` VARCHAR(64) NOT NULL,
  `color_name` VARCHAR(100) NOT NULL,
  `color_hex` VARCHAR(10) NOT NULL,
  `price_override` DECIMAL(10,2) NULL,
  `in_stock` TINYINT(1) NOT NULL DEFAULT 1,
  `is_available` TINYINT(1) NOT NULL DEFAULT 1,
  `status` ENUM('active', 'inactive', 'discontinued') NOT NULL DEFAULT 'active',
  `inventory_mode` ENUM('pod', 'on_hand', 'preorder') NOT NULL DEFAULT 'pod',
  `pod_provider` ENUM('apliiq', 'printful', 'custom') NOT NULL DEFAULT 'apliiq',
  `pod_product_id` VARCHAR(100) NULL,
  `pod_variant_id` VARCHAR(100) NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_variant_product` (`product_id`),
  CONSTRAINT `fk_variants_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 8. Customer Orders & Fulfillment Records
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `orders` (
  `id` VARCHAR(64) NOT NULL,
  `order_number` VARCHAR(50) NOT NULL UNIQUE,
  `customer_name` VARCHAR(255) NOT NULL,
  `customer_email` VARCHAR(255) NOT NULL,
  `shipping_address` JSON NOT NULL,
  `subtotal` DECIMAL(10,2) NOT NULL,
  `tax_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `shipping_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'USD',
  `payment_method` VARCHAR(50) NOT NULL DEFAULT 'card',
  `payment_status` ENUM('Pending', 'Paid', 'Failed', 'Refunded') NOT NULL DEFAULT 'Paid',
  `status` ENUM('Paid', 'Submitted to POD', 'In Production', 'Shipped', 'Delivered', 'Cancelled') NOT NULL DEFAULT 'Paid',
  `pod_provider` ENUM('apliiq', 'printful', 'manual') NOT NULL DEFAULT 'apliiq',
  `pod_order_id` VARCHAR(100) NULL,
  `idempotency_key` VARCHAR(100) NULL,
  `tracking_number` VARCHAR(100) NULL,
  `tracking_carrier` VARCHAR(100) NULL DEFAULT 'USPS',
  `tracking_url` TEXT NULL,
  `submitted_to_pod_at` DATETIME NULL,
  `shipped_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_order_number` (`order_number`),
  INDEX `idx_customer_email` (`customer_email`),
  INDEX `idx_idempotency` (`idempotency_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 9. Immutable Order Items (Point-in-Time Snapshot)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` VARCHAR(64) NOT NULL,
  `order_id` VARCHAR(64) NOT NULL,
  `product_id` VARCHAR(64) NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `sku` VARCHAR(100) NOT NULL,
  `wear_type_name` VARCHAR(255) NOT NULL,
  `color_name` VARCHAR(100) NOT NULL,
  `color_hex` VARCHAR(10) NOT NULL,
  `size` VARCHAR(20) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(10,2) NOT NULL,
  `pod_variant_id` VARCHAR(100) NULL,
  `artwork_url` TEXT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_items_order` (`order_id`),
  CONSTRAINT `fk_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 10. Community Reflection Archive (Voices of Encounters)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reflections` (
  `id` VARCHAR(64) NOT NULL,
  `product_id` VARCHAR(64) NULL,
  `product_name` VARCHAR(255) NOT NULL DEFAULT 'The Distance Tee',
  `author_name` VARCHAR(255) NOT NULL DEFAULT 'Anonymous',
  `author_location` VARCHAR(255) NOT NULL DEFAULT 'Public Space',
  `email` VARCHAR(255) NULL,
  `response` TEXT NOT NULL,
  `photo_url` TEXT NULL,
  `photo_caption` TEXT NULL,
  `garment_on_body_size` VARCHAR(20) NULL DEFAULT 'L',
  `permission_granted` TINYINT(1) NOT NULL DEFAULT 1,
  `status` ENUM('Approved', 'Pending Review', 'Rejected') NOT NULL DEFAULT 'Pending Review',
  `featured_quote` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 11. Customer Accounts & Multi-Device Profiles
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(64) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NULL,
  `name` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(50) NULL,
  `saved_items` JSON NULL,
  `shipping_address` JSON NULL,
  `role` ENUM('customer', 'admin', 'moderator') NOT NULL DEFAULT 'customer',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_user_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 12. Global Site Content, Branding & Integration Settings
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_content` (
  `config_key` VARCHAR(100) NOT NULL,
  `config_value` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 13. FAQs
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `faqs` (
  `id` VARCHAR(64) NOT NULL,
  `category` VARCHAR(100) NOT NULL DEFAULT 'General',
  `question` VARCHAR(255) NOT NULL,
  `answer` TEXT NOT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 14. Journal & Brand Updates
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `blog_posts` (
  `id` VARCHAR(64) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `excerpt` TEXT NOT NULL,
  `content` LONGTEXT NOT NULL,
  `author` VARCHAR(100) NOT NULL DEFAULT 'Ezistential Studio',
  `published_at` VARCHAR(50) NOT NULL,
  `read_time` VARCHAR(50) NOT NULL DEFAULT '3 min read',
  `tags` JSON NULL,
  `status` ENUM('published', 'draft') NOT NULL DEFAULT 'published',
  `cover_image` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
