import { UserProfile, Order, CustomerResponse, FAQItem, ModerationStatus } from '../types';

/**
 * Ezistential Connections — Centralized Database Client Engine
 * Provides cross-device cloud persistence for accounts, orders, reflections, and CMS.
 */

const API_BASE = '/api';

export const api = {
  // ========================================================
  // USER AUTHENTICATION & PROFILE (CROSS-DEVICE CLOUD SYNC)
  // ========================================================

  async register(data: { email: string; password?: string; fullName: string; location?: string }): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    try {
      const res = await fetch(`${API_BASE}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      return await res.json();
    } catch (err: any) {
      console.warn('Network issue during register, operating in resilient mode:', err);
      return { success: false, error: err.message };
    }
  },

  async login(email: string, password?: string): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      return await res.json();
    } catch (err: any) {
      console.warn('Network issue during login, operating in resilient mode:', err);
      return { success: false, error: err.message };
    }
  },

  async getUser(idOrEmail: string): Promise<UserProfile | null> {
    try {
      const res = await fetch(`${API_BASE}/users/${encodeURIComponent(idOrEmail)}`);
      if (!res.ok) return null;
      const data = await res.json();
      return data.user || null;
    } catch {
      return null;
    }
  },

  async updateUser(id: string, updates: Partial<UserProfile>): Promise<UserProfile | null> {
    try {
      const res = await fetch(`${API_BASE}/users/${encodeURIComponent(id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.user || null;
    } catch {
      return null;
    }
  },

  async deleteUser(id: string): Promise<boolean> {
    try {
      const res = await fetch(`${API_BASE}/users/${encodeURIComponent(id)}`, {
        method: 'DELETE',
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  // ========================================================
  // ORDERS & SHIPMENTS (CENTRALIZED TRACKING)
  // ========================================================

  async getOrders(email?: string): Promise<Order[]> {
    try {
      const url = email ? `${API_BASE}/orders?email=${encodeURIComponent(email)}` : `${API_BASE}/orders`;
      const res = await fetch(url);
      if (!res.ok) return [];
      const data = await res.json();
      return data.orders || [];
    } catch {
      return [];
    }
  },

  async getOrder(orderNumber: string): Promise<Order | null> {
    try {
      const res = await fetch(`${API_BASE}/orders?orderNumber=${encodeURIComponent(orderNumber)}`);
      if (!res.ok) return null;
      const data = await res.json();
      return data.order || null;
    } catch {
      return null;
    }
  },

  async createOrder(order: Order): Promise<Order | null> {
    try {
      const res = await fetch(`${API_BASE}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(order),
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.order || order;
    } catch {
      return order;
    }
  },

  async updateOrder(id: string, updates: Partial<Order>): Promise<Order | null> {
    try {
      const res = await fetch(`${API_BASE}/orders/${encodeURIComponent(id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.order || null;
    } catch {
      return null;
    }
  },

  // ========================================================
  // REFLECTIONS ARCHIVE (CENTRALIZED MODERATION)
  // ========================================================

  async getReflections(status: string = 'all'): Promise<any[]> {
    try {
      const res = await fetch(`${API_BASE}/reflections?status=${encodeURIComponent(status)}`);
      if (!res.ok) return [];
      const data = await res.json();
      return data.reflections || [];
    } catch {
      return [];
    }
  },

  async createReflection(reflection: {
    productName?: string;
    authorName: string;
    authorLocation: string;
    email?: string;
    response: string;
    permissionGranted: boolean;
  }): Promise<any | null> {
    try {
      const res = await fetch(`${API_BASE}/reflections`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reflection),
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.reflection || null;
    } catch {
      return null;
    }
  },

  async updateReflectionStatus(id: string, status: ModerationStatus): Promise<boolean> {
    try {
      const res = await fetch(`${API_BASE}/reflections/${encodeURIComponent(id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  // ========================================================
  // CMS CONTENT & FAQS (SERVED GLOBALLY ACROSS ALL USERS)
  // ========================================================

  async getContent(): Promise<{ content?: any; faqs?: FAQItem[] } | null> {
    try {
      const res = await fetch(`${API_BASE}/content`);
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  async updateContent(content?: any, faqs?: FAQItem[]): Promise<boolean> {
    try {
      const res = await fetch(`${API_BASE}/content`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, faqs }),
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  // ========================================================
  // TRANSACTIONAL EMAIL API CLIENT
  // ========================================================

  async sendEmail(payload: {
    to: string;
    subject: string;
    html?: string;
    text?: string;
    templateKey?: string;
    data?: any;
    provider?: string;
    apiKey?: string;
    fromEmail?: string;
    fromName?: string;
  }): Promise<{ success: boolean; messageId?: string; error?: string; latencyMs?: number; provider?: string }> {
    try {
      const res = await fetch(`${API_BASE}/email/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return await res.json();
    } catch (err: any) {
      console.warn('Transactional email dispatch error:', err);
      return { success: false, error: err.message };
    }
  },

  async testEmail(payload: {
    provider?: string;
    apiKey?: string;
    fromEmail?: string;
    fromName?: string;
    recipientEmail?: string;
  }): Promise<{ success: boolean; messageId?: string; error?: string; latencyMs?: number; provider?: string }> {
    try {
      const res = await fetch(`${API_BASE}/email/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },
};
