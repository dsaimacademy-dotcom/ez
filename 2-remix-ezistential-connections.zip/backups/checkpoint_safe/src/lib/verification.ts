import { UserProfile, MemberVerificationRules, Order, CustomerResponse } from '../types';

export const DEFAULT_VERIFICATION_RULES: MemberVerificationRules = {
  requirePurchase: true,
  minPurchasesCount: 1,
  requireReflection: true,
  requirePhoto: false,
  requireProfileLocation: true,
  allowManualOverride: true,
};

export interface VerificationEvaluation {
  isVerified: boolean;
  score: number;
  maxScore: number;
  percentage: number;
  statusLabel: 'Verified Wearer & Member' | 'Verification In Progress' | 'Member Threshold';
  reasons: {
    hasPurchase: boolean;
    purchaseCount: number;
    purchaseMet: boolean;
    hasReflection: boolean;
    reflectionCount: number;
    reflectionMet: boolean;
    hasPhoto: boolean;
    photoMet: boolean;
    hasLocation: boolean;
    locationMet: boolean;
    isManualOverride: boolean;
  };
}

export function evaluateMemberVerification(
  user: UserProfile | null,
  userOrders: Order[] = [],
  userReflections: CustomerResponse[] = [],
  rules: MemberVerificationRules = DEFAULT_VERIFICATION_RULES
): VerificationEvaluation {
  if (!user) {
    return {
      isVerified: false,
      score: 0,
      maxScore: 4,
      percentage: 0,
      statusLabel: 'Member Threshold',
      reasons: {
        hasPurchase: false,
        purchaseCount: 0,
        purchaseMet: false,
        hasReflection: false,
        reflectionCount: 0,
        reflectionMet: false,
        hasPhoto: false,
        photoMet: false,
        hasLocation: false,
        locationMet: false,
        isManualOverride: false,
      },
    };
  }

  // Check manual override
  if (rules.allowManualOverride && user.isVerifiedManualOverride) {
    return {
      isVerified: true,
      score: 4,
      maxScore: 4,
      percentage: 100,
      statusLabel: 'Verified Wearer & Member',
      reasons: {
        hasPurchase: userOrders.length > 0,
        purchaseCount: userOrders.length,
        purchaseMet: true,
        hasReflection: userReflections.length > 0,
        reflectionCount: userReflections.length,
        reflectionMet: true,
        hasPhoto: false,
        photoMet: true,
        hasLocation: Boolean(user.location),
        locationMet: true,
        isManualOverride: true,
      },
    };
  }

  const purchaseCount = userOrders.length;
  const reflectionCount = userReflections.length;
  const hasPhoto = userReflections.some((r) => Boolean(r.photoUrl));
  const hasLocation = Boolean(user.location && user.location.trim().length > 0);

  const purchaseMet = !rules.requirePurchase || purchaseCount >= rules.minPurchasesCount;
  const reflectionMet = !rules.requireReflection || reflectionCount >= 1;
  const photoMet = !rules.requirePhoto || hasPhoto;
  const locationMet = !rules.requireProfileLocation || hasLocation;

  let activeCriteriaCount = 0;
  let metCriteriaCount = 0;

  if (rules.requirePurchase) {
    activeCriteriaCount++;
    if (purchaseMet) metCriteriaCount++;
  }

  if (rules.requireReflection) {
    activeCriteriaCount++;
    if (reflectionMet) metCriteriaCount++;
  }

  if (rules.requirePhoto) {
    activeCriteriaCount++;
    if (photoMet) metCriteriaCount++;
  }

  if (rules.requireProfileLocation) {
    activeCriteriaCount++;
    if (locationMet) metCriteriaCount++;
  }

  if (activeCriteriaCount === 0) {
    activeCriteriaCount = 1;
    metCriteriaCount = 1;
  }

  const isVerified = purchaseMet && reflectionMet && photoMet && locationMet;
  const percentage = Math.round((metCriteriaCount / activeCriteriaCount) * 100);

  return {
    isVerified,
    score: metCriteriaCount,
    maxScore: activeCriteriaCount,
    percentage,
    statusLabel: isVerified ? 'Verified Wearer & Member' : 'Verification In Progress',
    reasons: {
      hasPurchase: purchaseCount > 0,
      purchaseCount,
      purchaseMet,
      hasReflection: reflectionCount > 0,
      reflectionCount,
      reflectionMet,
      hasPhoto,
      photoMet,
      hasLocation,
      locationMet,
      isManualOverride: false,
    },
  };
}
