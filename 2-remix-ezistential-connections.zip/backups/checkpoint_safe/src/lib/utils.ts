import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(centsOrDollars: number, isCents = false): string {
  const amount = isCents ? centsOrDollars / 100 : centsOrDollars;
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function generateOrderNumber(): string {
  const num = Math.floor(10000 + Math.random() * 90000);
  const suffix = (Math.floor(1 + Math.random() * 99)).toString().padStart(2, '0');
  return `EC-${num}-${suffix}`;
}

export const FREE_SHIPPING_THRESHOLD = 75; // $75 USD free US shipping rule
export const STANDARD_SHIPPING_FLAT_RATE = 7.50; // Under $75 USD flat rate

export function safeSrc(url?: string, fallback = 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85'): string {
  if (!url || typeof url !== 'string' || !url.trim()) {
    return fallback;
  }
  return url.trim();
}
