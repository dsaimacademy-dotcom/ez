import { Product, ProductVariant, WearType, ColorItem, MasterSizeItem, Size, Order } from '../types';
import { DEFAULT_WEAR_TYPES, MASTER_COLOR_LIBRARY, DEFAULT_MASTER_SIZES } from '../data/wearTypes';

/**
 * Maps a wear type name or ID to its authoritative WearType ID.
 */
export function resolveWearTypeId(identifier: string, wearTypesList: WearType[] = DEFAULT_WEAR_TYPES): string {
  if (!identifier) return wearTypesList[0]?.id || 'wt-heavyweight-tee';
  const match = wearTypesList.find(
    (wt) => wt.id.toLowerCase() === identifier.toLowerCase() || wt.name.toLowerCase() === identifier.toLowerCase()
  );
  if (match) return match.id;

  // Keyword-based fallback
  const lower = identifier.toLowerCase();
  if (lower.includes('hoodie')) return 'wt-boxy-hoodie';
  if (lower.includes('crewneck') || lower.includes('crew')) return 'wt-drop-crewneck';
  if (lower.includes('longsleeve') || lower.includes('long sleeve')) return 'wt-ribbed-longsleeve';
  if (lower.includes('tote')) return 'wt-canvas-tote';
  return wearTypesList[0]?.id || 'wt-heavyweight-tee';
}

/**
 * Maps a wear type ID or name to its display name snapshot.
 */
export function resolveWearTypeName(identifier: string, wearTypesList: WearType[] = DEFAULT_WEAR_TYPES): string {
  const match = wearTypesList.find(
    (wt) => wt.id.toLowerCase() === identifier.toLowerCase() || wt.name.toLowerCase() === identifier.toLowerCase()
  );
  return match?.name || identifier || '6.5oz Heavyweight Boxy Tee';
}

/**
 * Maps a color name or ID to its authoritative ColorItem ID.
 */
export function resolveColorId(identifier: string, colorsList: ColorItem[] = MASTER_COLOR_LIBRARY): string {
  if (!identifier) return colorsList[0]?.id || 'col-obsidian-black';
  const match = colorsList.find(
    (c) => c.id.toLowerCase() === identifier.toLowerCase() || c.name.toLowerCase() === identifier.toLowerCase()
  );
  if (match) return match.id;
  return `col-${identifier.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
}

/**
 * Determines whether a variant is currently purchasable on the storefront.
 * Strictly checks active status, availability, in-stock state, and numeric stock levels.
 */
export function isVariantPurchasable(variant: ProductVariant | undefined | null): boolean {
  if (!variant) return false;
  if (variant.status === 'unsupported' || variant.status === 'inactive') return false;
  if (variant.isAvailable === false || variant.inStock === false) return false;
  if (variant.inventoryMode === 'stocked' && typeof variant.quantity === 'number' && variant.quantity <= 0) {
    return false;
  }
  return true;
}

/**
 * Guard to prevent deleting master records (Wear Types, Colors, Sizes)
 * that are referenced by active products or existing orders.
 */
export function canDeleteMasterRecord(
  recordType: 'wearType' | 'color' | 'size',
  recordIdOrName: string,
  products: Product[] = [],
  orders: Order[] = []
): { canDelete: boolean; referencedInProducts: string[]; referencedInOrders: string[]; reason?: string } {
  const cleanId = recordIdOrName.trim().toLowerCase();
  const referencedInProducts: string[] = [];
  const referencedInOrders: string[] = [];

  // Check products
  products.forEach((prod) => {
    let isReferenced = false;
    if (recordType === 'wearType') {
      const matchWearId = prod.availableWearTypeIds?.some((w) => w.toLowerCase() === cleanId);
      const matchWearName = prod.availableWearTypes?.some((w) => w.toLowerCase() === cleanId);
      const matchVariant = prod.variants?.some(
        (v) => v.wearTypeId.toLowerCase() === cleanId || v.wearTypeName.toLowerCase() === cleanId
      );
      if (matchWearId || matchWearName || matchVariant) isReferenced = true;
    } else if (recordType === 'color') {
      const matchColorId = prod.availableColorIds?.some((c) => c.toLowerCase() === cleanId);
      const matchColorObj = prod.availableColors?.some(
        (c) => c.id?.toLowerCase() === cleanId || c.name.toLowerCase() === cleanId
      );
      const matchVariant = prod.variants?.some(
        (v) => v.colorId.toLowerCase() === cleanId || v.colorName.toLowerCase() === cleanId
      );
      if (matchColorId || matchColorObj || matchVariant) isReferenced = true;
    } else if (recordType === 'size') {
      const matchSize = prod.availableSizes?.some((s) => s.toLowerCase() === cleanId);
      const matchVariant = prod.variants?.some((v) => v.size.toLowerCase() === cleanId || v.sizeId?.toLowerCase() === cleanId);
      if (matchSize || matchVariant) isReferenced = true;
    }

    if (isReferenced) {
      referencedInProducts.push(prod.name);
    }
  });

  // Check orders
  orders.forEach((ord) => {
    let orderReferenced = false;
    ord.items?.forEach((item) => {
      if (recordType === 'wearType') {
        if (
          item.wearTypeId?.toLowerCase() === cleanId ||
          item.wearTypeName?.toLowerCase() === cleanId ||
          item.wearType?.toLowerCase() === cleanId
        ) {
          orderReferenced = true;
        }
      } else if (recordType === 'color') {
        if (item.colorId?.toLowerCase() === cleanId || item.color?.toLowerCase() === cleanId) {
          orderReferenced = true;
        }
      } else if (recordType === 'size') {
        if (item.size?.toLowerCase() === cleanId || item.sizeId?.toLowerCase() === cleanId) {
          orderReferenced = true;
        }
      }
    });

    if (orderReferenced) {
      referencedInOrders.push(ord.orderNumber);
    }
  });

  const canDelete = referencedInProducts.length === 0 && referencedInOrders.length === 0;
  let reason: string | undefined;
  if (!canDelete) {
    const parts: string[] = [];
    if (referencedInProducts.length > 0) {
      parts.push(`referenced by ${referencedInProducts.length} product(s): ${referencedInProducts.slice(0, 3).join(', ')}${referencedInProducts.length > 3 ? '...' : ''}`);
    }
    if (referencedInOrders.length > 0) {
      parts.push(`referenced in ${referencedInOrders.length} historical order(s): ${referencedInOrders.slice(0, 3).join(', ')}${referencedInOrders.length > 3 ? '...' : ''}`);
    }
    reason = `Cannot delete master ${recordType} because it is ${parts.join(' and ')}. Deactivate or archive this record instead to protect product integrity and order history.`;
  }

  return {
    canDelete,
    referencedInProducts,
    referencedInOrders,
    reason,
  };
}

/**
 * Normalizes a product record so that both new and existing records follow strict rules:
 * - Stable IDs for wear types and colors
 * - Preserved snapshots for display & backward compatibility
 * - Clean inventory mode without artificial 999 quantities
 * - Variant status: active, inactive, or unsupported
 */
export function normalizeProduct(
  raw: any,
  wearTypesList: WearType[] = DEFAULT_WEAR_TYPES,
  colorsList: ColorItem[] = MASTER_COLOR_LIBRARY
): Product {
  // 1. Resolve Wear Type IDs & Names
  const rawWearTypes: string[] = Array.isArray(raw.availableWearTypes) ? raw.availableWearTypes : [];
  const rawWearTypeIds: string[] = Array.isArray(raw.availableWearTypeIds) ? raw.availableWearTypeIds : [];

  let wearTypeIds = rawWearTypeIds.length > 0
    ? rawWearTypeIds.map((id: string) => resolveWearTypeId(id, wearTypesList))
    : rawWearTypes.map((name: string) => resolveWearTypeId(name, wearTypesList));

  if (wearTypeIds.length === 0) {
    wearTypeIds = [wearTypesList[0]?.id || 'wt-heavyweight-tee'];
  }
  // Deduplicate
  wearTypeIds = Array.from(new Set(wearTypeIds));

  const wearTypeNames = wearTypeIds.map((id) => resolveWearTypeName(id, wearTypesList));

  // 2. Resolve Colors
  const rawColors: any[] = Array.isArray(raw.availableColors) ? raw.availableColors : [];
  const rawColorIds: string[] = Array.isArray(raw.availableColorIds) ? raw.availableColorIds : [];

  let normalizedColors: Array<{ id: string; name: string; hex: string }> = [];

  if (rawColors.length > 0) {
    normalizedColors = rawColors.map((c) => {
      const colorId = c.id || resolveColorId(c.name, colorsList);
      const master = colorsList.find((m) => m.id === colorId || m.name.toLowerCase() === (c.name || '').toLowerCase());
      return {
        id: colorId,
        name: c.name || master?.name || 'Obsidian Black',
        hex: c.hex || master?.hex || '#0f0f0f',
      };
    });
  } else if (rawColorIds.length > 0) {
    normalizedColors = rawColorIds.map((id) => {
      const master = colorsList.find((m) => m.id === id);
      return {
        id,
        name: master?.name || id,
        hex: master?.hex || '#0f0f0f',
      };
    });
  } else {
    normalizedColors = [
      { id: 'col-obsidian-black', name: 'Obsidian Black', hex: '#0f0f0f' },
      { id: 'col-raw-ecru', name: 'Raw Ecru', hex: '#f4f1ea' },
    ];
  }

  const colorIds = normalizedColors.map((c) => c.id);

  // 3. Resolve Sizes
  const availableSizes: Size[] = Array.isArray(raw.availableSizes) && raw.availableSizes.length > 0
    ? raw.availableSizes
    : ['S', 'M', 'L', 'XL'];

  // 4. Normalize Variants
  const rawVariants: any[] = Array.isArray(raw.variants) ? raw.variants : [];
  const normalizedVariants: ProductVariant[] = rawVariants.map((v, idx) => {
    const wtId = resolveWearTypeId(v.wearTypeId || v.wearTypeName || wearTypeIds[0], wearTypesList);
    const wtName = v.wearTypeName || resolveWearTypeName(wtId, wearTypesList);
    const colId = v.colorId || resolveColorId(v.colorName || '', colorsList);
    const colName = v.colorName || colorsList.find((c) => c.id === colId)?.name || 'Obsidian Black';
    const colHex = v.colorHex || colorsList.find((c) => c.id === colId)?.hex || '#0f0f0f';

    const invMode: 'pod' | 'made_to_order' | 'stocked' = v.inventoryMode || 'pod';
    // Purge fake 999 quantity if POD or made_to_order
    const cleanQty = invMode === 'stocked'
      ? (typeof v.quantity === 'number' && v.quantity !== 999 ? v.quantity : 0)
      : undefined;

    const status: 'active' | 'inactive' | 'unsupported' = v.status || (v.inStock === false ? 'inactive' : 'active');
    const isAvailable = v.isAvailable !== undefined ? v.isAvailable : (status === 'active' && v.inStock !== false);

    // Clean stable SKU & ID
    const cleanSlug = (raw.slug || 'PROD').replace(/[^a-zA-Z0-9]/g, '').toUpperCase().substring(0, 8);
    const wtSlug = wtId.replace('wt-', '').toUpperCase();
    const colCode = colName.toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 4);
    const stableSku = v.sku || `EC-${cleanSlug}-${wtSlug}-${v.size}-${colCode}`;
    const stableId = v.id || `var-${cleanSlug.toLowerCase()}-${wtId}-${(v.size || 'm').toLowerCase()}-${colId}`;

    return {
      id: stableId,
      sku: stableSku,
      wearTypeId: wtId,
      wearTypeName: wtName,
      size: v.size || 'M',
      sizeId: v.sizeId,
      colorId: colId,
      colorName: colName,
      colorHex: colHex,
      inStock: v.inStock !== false,
      isAvailable,
      status,
      inventoryMode: invMode,
      quantity: cleanQty,
      priceOverride: v.priceOverride,
      podProvider: v.podProvider || 'apliiq',
      podProductId: v.podProductId,
      podVariantId: v.podVariantId,
      supplierSku: v.supplierSku,
    };
  });

  return {
    ...raw,
    id: raw.id,
    slug: raw.slug,
    name: raw.name,
    tagline: raw.tagline || '',
    price: raw.price || 48,
    collectionId: raw.collectionId || 'core-concepts',
    isFeatured: Boolean(raw.isFeatured),
    isAvailable: raw.isAvailable !== undefined ? Boolean(raw.isAvailable) : true,
    readinessStatus: raw.readinessStatus || (raw.isAvailable ? 'published' : 'draft'),
    sourceDesignId: raw.sourceDesignId,
    sourceDesignVersionId: raw.sourceDesignVersionId,
    sourceDesignVersionNumber: raw.sourceDesignVersionNumber,
    availableWearTypeIds: wearTypeIds,
    availableWearTypes: wearTypeNames,
    availableColorIds: colorIds,
    availableColors: normalizedColors,
    availableSizes,
    primaryImage: raw.primaryImage || '',
    galleryImages: Array.isArray(raw.galleryImages) ? raw.galleryImages : [],
    storyA: raw.storyA || {
      headline: raw.name || '',
      question: 'What happens in the space between people?',
      thesis: raw.tagline || '',
      wearerRole: 'Carrying reflection into public space.',
    },
    storyB: raw.storyB || {
      fabric: '100% Organic Combed Ringspun Cotton',
      weight: '6.5 oz / 220 GSM Heavyweight Jersey',
      fit: 'Relaxed drop-shoulder boxy architectural drape',
      origin: 'Ethically crafted in Los Angeles, CA',
      printTechnique: 'Direct-to-Film (DTF) Soft-Hand Archival Pigment',
      careInstructions: [
        'Machine wash cold inside out with like colors',
        'Hang dry recommended to preserve structural drape',
        'Tumble dry low if necessary',
      ],
      productionNotes: 'Printed on demand with eco-friendly water-based discharge inks.',
      estimatedDeliveryDays: 'Production: 2–4 business days. Standard US delivery: 3–5 business days.',
    },
    variants: normalizedVariants,
    createdAt: raw.createdAt || new Date().toISOString(),
    updatedAt: raw.updatedAt || new Date().toISOString(),
  };
}

/**
 * Checks a product for commercial publication readiness.
 * Returns readiness validation state and detailed diagnostic feedback.
 */
export function validateProductReadiness(product: Partial<Product>): {
  isReady: boolean;
  errors: string[];
  warnings: string[];
} {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!product.name?.trim()) errors.push('Product name is required.');
  if (!product.slug?.trim()) errors.push('Product slug identifier is required.');
  if (typeof product.price !== 'number' || product.price <= 0) errors.push('Retail base price must be greater than $0.');
  if (!product.primaryImage?.trim()) errors.push('Primary storefront image is required.');

  const variants = product.variants || [];
  if (variants.length === 0) {
    errors.push('At least one configured product variant is required.');
  } else {
    const activeVariants = variants.filter((v) => isVariantPurchasable(v));
    if (activeVariants.length === 0) {
      errors.push('At least one variant must be in active, purchasable status with positive stock or POD availability.');
    }

    // Check automated POD fulfillment requirements
    const podVariants = variants.filter((v) => v.inventoryMode === 'pod' && v.status === 'active');
    const missingPodMapping = podVariants.filter((v) => !v.podVariantId && !v.podProductId);
    if (missingPodMapping.length > 0) {
      warnings.push(`${missingPodMapping.length} active POD variant(s) do not have a supplier variant ID (Apliiq/Printful) mapped.`);
    }
  }

  if (!product.storyA?.thesis?.trim()) warnings.push('Philosophical thesis (Story A) is empty.');
  if (!product.storyB?.fabric?.trim()) warnings.push('Textile & fabric description (Story B) is empty.');
  if (!product.availableWearTypeIds || product.availableWearTypeIds.length === 0) {
    warnings.push('No master wear type silhouettes attached.');
  }

  return {
    isReady: errors.length === 0,
    errors,
    warnings,
  };
}

/**
 * Builds or updates the variant matrix while preserving existing variant IDs,
 * custom price overrides, and supplier mappings.
 * Validates garment-specific size & color compatibility.
 */
export function generateValidVariantsMatrix(
  productSlug: string,
  selectedWearTypeIds: string[],
  selectedColors: Array<{ id: string; name: string; hex: string }>,
  selectedSizes: Size[],
  existingVariants: ProductVariant[] = [],
  wearTypesList: WearType[] = DEFAULT_WEAR_TYPES,
  baseRetailPrice: number = 48
): ProductVariant[] {
  const result: ProductVariant[] = [];
  const cleanSlug = (productSlug || 'prod').replace(/[^a-zA-Z0-9]/g, '').toLowerCase().substring(0, 8);

  selectedWearTypeIds.forEach((wtId) => {
    const wearType = wearTypesList.find((w) => w.id === wtId);
    const wtName = wearType?.name || resolveWearTypeName(wtId, wearTypesList);
    const wtCode = wtId.replace('wt-', '').toUpperCase();

    // Default price override based on silhouette wholesale costs if higher than base
    const defaultSilhouettePrice = wearType?.defaultRetailPrice || baseRetailPrice;
    const priceOverride = defaultSilhouettePrice !== baseRetailPrice ? defaultSilhouettePrice : undefined;

    selectedColors.forEach((color) => {
      const colorCode = color.name.toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 4);

      // Check garment color constraint if wear type has restricted palette
      const isColorSupported = !wearType?.supportedColorIds || wearType.supportedColorIds.length === 0
        ? true
        : wearType.supportedColorIds.includes(color.id);

      selectedSizes.forEach((size) => {
        // Check garment size constraint if wear type has restricted sizes
        const isSizeSupported = !wearType?.supportedSizes || wearType.supportedSizes.length === 0
          ? true
          : wearType.supportedSizes.includes(size);

        const isCombinationSupported = isColorSupported && isSizeSupported;

        // Look for existing variant to preserve custom configuration & ID stability!
        const existing = existingVariants.find(
          (v) => (v.wearTypeId === wtId || v.wearTypeName === wtName) &&
                 (v.colorId === color.id || v.colorName.toLowerCase() === color.name.toLowerCase()) &&
                 v.size === size
        );

        if (existing) {
          result.push({
            ...existing,
            wearTypeId: wtId,
            wearTypeName: wtName,
            colorId: color.id,
            colorName: color.name,
            colorHex: color.hex,
            size,
            status: !isCombinationSupported ? 'unsupported' : existing.status || 'active',
            isAvailable: !isCombinationSupported ? false : existing.isAvailable !== false,
            // Clean up 999 if present
            quantity: existing.inventoryMode === 'stocked' && existing.quantity !== 999 ? existing.quantity : undefined,
          });
        } else {
          // Generate new variant with stable deterministic ID and SKU
          const sku = `EC-${cleanSlug.toUpperCase()}-${wtCode}-${size}-${colorCode}`;
          const stableId = `var-${cleanSlug}-${wtId.replace('wt-', '')}-${size.toLowerCase()}-${color.id.replace('col-', '')}`;

          result.push({
            id: stableId,
            sku,
            wearTypeId: wtId,
            wearTypeName: wtName,
            size,
            colorId: color.id,
            colorName: color.name,
            colorHex: color.hex,
            inStock: isCombinationSupported,
            isAvailable: isCombinationSupported,
            status: isCombinationSupported ? 'active' : 'unsupported',
            inventoryMode: 'pod',
            quantity: undefined,
            priceOverride,
            podProvider: 'apliiq',
            podProductId: wearType?.supplierSku || `APL-${wtCode}`,
            podVariantId: `APL-${cleanSlug.toUpperCase().substring(0, 4)}-${wtCode.substring(0, 4)}-${size}-${colorCode}`,
            supplierSku: wearType?.supplierSku,
          });
        }
      });
    });
  });

  return result;
}

