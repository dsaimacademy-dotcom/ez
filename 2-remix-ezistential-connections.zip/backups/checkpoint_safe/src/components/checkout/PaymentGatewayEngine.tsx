import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  ShieldCheck,
  Lock,
  CheckCircle2,
  AlertCircle,
  QrCode,
  Smartphone,
  ExternalLink,
  RefreshCw,
  Layers,
  ArrowRight,
  Zap,
  Info,
  Check,
  AlertTriangle
} from 'lucide-react';
import { Button } from '../ui/Button';
import { formatPrice } from '../../lib/utils';
import { useContent } from '../../context/ContentContext';

export type SelectedPaymentMethod =
  | 'card'
  | 'apple_pay'
  | 'google_pay'
  | 'paypal'
  | 'klarna'
  | 'afterpay'
  | 'cashapp'
  | 'shoppay';

export interface PaymentGatewayEngineProps {
  orderTotal: number;
  selectedMethod: SelectedPaymentMethod;
  onMethodChange: (method: SelectedPaymentMethod) => void;
  // Card details
  cardNumber: string;
  onCardNumberChange: (val: string) => void;
  cardExp: string;
  onCardExpChange: (val: string) => void;
  cardCvc: string;
  onCardCvcChange: (val: string) => void;
  cardName: string;
  onCardNameChange: (val: string) => void;
  // Execution status & callback
  isProcessing: boolean;
  onWalletAuthorized?: (details: {
    method: SelectedPaymentMethod;
    transactionId: string;
    last4?: string;
    brand?: string;
  }) => void;
}

export function detectCardBrand(num: string): 'visa' | 'mastercard' | 'amex' | 'discover' | 'jcb' | 'generic' {
  const clean = num.replace(/\s/g, '');
  if (/^4/.test(clean)) return 'visa';
  if (/^(5[1-5]|2[2-7])/.test(clean)) return 'mastercard';
  if (/^3[47]/.test(clean)) return 'amex';
  if (/^(6011|65|64[4-9])/.test(clean)) return 'discover';
  if (/^(?:2131|1800|35\d{3})/.test(clean)) return 'jcb';
  return 'generic';
}

export const PaymentGatewayEngine: React.FC<PaymentGatewayEngineProps> = ({
  orderTotal,
  selectedMethod,
  onMethodChange,
  cardNumber,
  onCardNumberChange,
  cardExp,
  onCardExpChange,
  cardCvc,
  onCardCvcChange,
  cardName,
  onCardNameChange,
  isProcessing,
  onWalletAuthorized,
}) => {
  const { content } = useContent();
  const cardBrand = detectCardBrand(cardNumber);

  // Installment calculation for Klarna/Afterpay (4 payments)
  const installmentAmount = (orderTotal / 4).toFixed(2);

  // Modal simulation for Express Wallets
  const [activeWalletModal, setActiveWalletModal] = useState<SelectedPaymentMethod | null>(null);
  const [walletAuthorized, setWalletAuthorized] = useState(false);

  // Automatically fall back to an active gateway if current selectedMethod is disabled
  useEffect(() => {
    const isMethodActive = (m: SelectedPaymentMethod) => {
      if (m === 'card') return content.stripeEnabled !== false;
      if (m === 'apple_pay') return content.applePayEnabled !== false;
      if (m === 'google_pay') return content.googlePayEnabled !== false;
      if (m === 'paypal') return content.paypalEnabled !== false;
      if (m === 'klarna') return content.klarnaEnabled !== false;
      if (m === 'afterpay') return content.afterpayEnabled !== false;
      if (m === 'cashapp') return content.cashAppPayEnabled !== false;
      if (m === 'shoppay') return content.shopPayEnabled !== false;
      return false;
    };

    if (!isMethodActive(selectedMethod)) {
      if (content.stripeEnabled !== false) onMethodChange('card');
      else if (content.applePayEnabled !== false) onMethodChange('apple_pay');
      else if (content.googlePayEnabled !== false) onMethodChange('google_pay');
      else if (content.paypalEnabled !== false) onMethodChange('paypal');
      else if (content.klarnaEnabled !== false) onMethodChange('klarna');
      else if (content.afterpayEnabled !== false) onMethodChange('afterpay');
      else if (content.cashAppPayEnabled !== false) onMethodChange('cashapp');
      else if (content.shopPayEnabled !== false) onMethodChange('shoppay');
    }
  }, [content, selectedMethod, onMethodChange]);

  const anyGatewayActive =
    content.stripeEnabled !== false ||
    content.applePayEnabled !== false ||
    content.googlePayEnabled !== false ||
    content.paypalEnabled !== false ||
    content.klarnaEnabled !== false ||
    content.afterpayEnabled !== false ||
    content.cashAppPayEnabled !== false ||
    content.shopPayEnabled !== false;

  const handleCardNumberInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '').slice(0, 16);
    const formatted = raw.match(/.{1,4}/g)?.join(' ') || raw;
    onCardNumberChange(formatted);
  };

  const handleExpInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (raw.length >= 3) {
      onCardExpChange(`${raw.slice(0, 2)}/${raw.slice(2)}`);
    } else {
      onCardExpChange(raw);
    }
  };

  const triggerWalletModal = (type: SelectedPaymentMethod) => {
    setActiveWalletModal(type);
  };

  const confirmWalletAuthorization = (type: SelectedPaymentMethod) => {
    setWalletAuthorized(true);
    setActiveWalletModal(null);
    const mockTxnId = `txn_${type}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;
    if (onWalletAuthorized) {
      onWalletAuthorized({
        method: type,
        transactionId: mockTxnId,
        last4: type === 'card' ? cardNumber.slice(-4) : '8821',
        brand: type === 'apple_pay' ? 'Apple Wallet' : type === 'google_pay' ? 'Google Pay' : type === 'paypal' ? 'PayPal' : 'Express Checkout',
      });
    }
  };

  // Test card autofill helpers
  const fillTestCard = (type: 'visa' | 'mastercard' | 'amex' | 'discover') => {
    if (type === 'visa') {
      onCardNumberChange('4242 4242 4242 4242');
      onCardExpChange('12/28');
      onCardCvcChange('424');
      onCardNameChange('Marcus Vance');
    } else if (type === 'mastercard') {
      onCardNumberChange('5555 5555 5555 4444');
      onCardExpChange('08/29');
      onCardCvcChange('555');
      onCardNameChange('Elena Rostova');
    } else if (type === 'amex') {
      onCardNumberChange('3782 822463 10005');
      onCardExpChange('11/27');
      onCardCvcChange('3782');
      onCardNameChange('Julian Mercer');
    } else if (type === 'discover') {
      onCardNumberChange('6011 0009 9013 9424');
      onCardExpChange('04/30');
      onCardCvcChange('601');
      onCardNameChange('Sora Takahashi');
    }
  };

  if (!anyGatewayActive) {
    return (
      <div className="bg-amber-50 border border-amber-200 p-6 text-center space-y-2 text-amber-900">
        <AlertTriangle className="w-6 h-6 mx-auto text-amber-600" />
        <h3 className="font-serif text-base font-semibold">Payment Gateways Temporarily Offline</h3>
        <p className="text-xs text-amber-800">
          The administrator has not turned on any active payment gateways. Please contact{' '}
          <a href={`mailto:${content.supportEmail}`} className="underline font-bold">
            {content.supportEmail}
          </a>{' '}
          for direct invoice dispatch.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Provider Selector Tabs */}
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-2">
        {content.stripeEnabled !== false && (
          <button
            type="button"
            onClick={() => {
              onMethodChange('card');
              setWalletAuthorized(false);
            }}
            className={`p-3 text-xs font-medium uppercase tracking-wider border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              selectedMethod === 'card'
                ? 'bg-black text-white border-black shadow-xs font-semibold'
                : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-500'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span className="text-[10px]">Credit Card</span>
          </button>
        )}

        {content.applePayEnabled !== false && (
          <button
            type="button"
            onClick={() => {
              onMethodChange('apple_pay');
              setWalletAuthorized(false);
            }}
            className={`p-3 text-xs font-medium uppercase tracking-wider border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              selectedMethod === 'apple_pay'
                ? 'bg-black text-white border-black shadow-xs font-semibold'
                : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-500'
            }`}
          >
            <span className="font-serif font-bold text-sm tracking-normal"> Pay</span>
            <span className="text-[10px]">Apple Pay</span>
          </button>
        )}

        {content.googlePayEnabled !== false && (
          <button
            type="button"
            onClick={() => {
              onMethodChange('google_pay');
              setWalletAuthorized(false);
            }}
            className={`p-3 text-xs font-medium uppercase tracking-wider border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              selectedMethod === 'google_pay'
                ? 'bg-black text-white border-black shadow-xs font-semibold'
                : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-500'
            }`}
          >
            <span className="font-mono font-bold text-xs tracking-tight">G Pay</span>
            <span className="text-[10px]">Google Pay</span>
          </button>
        )}

        {content.paypalEnabled !== false && (
          <button
            type="button"
            onClick={() => {
              onMethodChange('paypal');
              setWalletAuthorized(false);
            }}
            className={`p-3 text-xs font-medium uppercase tracking-wider border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              selectedMethod === 'paypal'
                ? 'bg-[#003087] text-white border-[#003087] shadow-xs font-semibold'
                : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-500'
            }`}
          >
            <span className="font-sans font-bold text-xs italic tracking-normal text-amber-300">PayPal</span>
            <span className="text-[10px]">PayPal / 4x</span>
          </button>
        )}

        {content.klarnaEnabled !== false && (
          <button
            type="button"
            onClick={() => {
              onMethodChange('klarna');
              setWalletAuthorized(false);
            }}
            className={`p-3 text-xs font-medium uppercase tracking-wider border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              selectedMethod === 'klarna'
                ? 'bg-[#ffb3c7] text-black border-[#ffb3c7] shadow-xs font-semibold'
                : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-500'
            }`}
          >
            <span className="font-sans font-bold text-xs">Klarna.</span>
            <span className="text-[10px]">4 Payments</span>
          </button>
        )}

        {content.afterpayEnabled !== false && (
          <button
            type="button"
            onClick={() => {
              onMethodChange('afterpay');
              setWalletAuthorized(false);
            }}
            className={`p-3 text-xs font-medium uppercase tracking-wider border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              selectedMethod === 'afterpay'
                ? 'bg-[#b2fce4] text-black border-[#b2fce4] shadow-xs font-semibold'
                : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-500'
            }`}
          >
            <span className="font-mono font-bold text-xs">afterpay</span>
            <span className="text-[10px]">Afterpay</span>
          </button>
        )}

        {content.cashAppPayEnabled !== false && (
          <button
            type="button"
            onClick={() => {
              onMethodChange('cashapp');
              setWalletAuthorized(false);
            }}
            className={`p-3 text-xs font-medium uppercase tracking-wider border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              selectedMethod === 'cashapp'
                ? 'bg-[#00D632] text-black border-[#00D632] shadow-xs font-semibold'
                : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-500'
            }`}
          >
            <span className="font-mono font-bold text-xs">$ Cash App</span>
            <span className="text-[10px]">Cash App</span>
          </button>
        )}
      </div>

      {/* 1. CREDIT / DEBIT CARD DETAILS */}
      {selectedMethod === 'card' && content.stripeEnabled !== false && (
        <div className="bg-white border border-neutral-300 p-6 space-y-4 shadow-xs animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-100 pb-3 gap-2">
            <div className="flex items-center space-x-2">
              <Lock className="w-3.5 h-3.5 text-neutral-700" />
              <span className="text-xs uppercase font-mono tracking-wider text-neutral-800 font-semibold">
                PCI-DSS Encrypted Stripe Processing • {content.stripeStatementDescriptor || 'EZISTENTIAL STORE'}
              </span>
            </div>
            {/* Card Brand Badges */}
            <div className="flex items-center space-x-1.5 text-[10px] font-mono">
              <span className={`px-1.5 py-0.5 border ${cardBrand === 'visa' ? 'bg-blue-600 border-blue-600 text-white font-bold' : 'border-neutral-200 text-neutral-500'}`}>VISA</span>
              <span className={`px-1.5 py-0.5 border ${cardBrand === 'mastercard' ? 'bg-red-600 border-red-600 text-white font-bold' : 'border-neutral-200 text-neutral-500'}`}>MC</span>
              <span className={`px-1.5 py-0.5 border ${cardBrand === 'amex' ? 'bg-indigo-600 border-indigo-600 text-white font-bold' : 'border-neutral-200 text-neutral-500'}`}>AMEX</span>
              <span className={`px-1.5 py-0.5 border ${cardBrand === 'discover' ? 'bg-orange-600 border-orange-600 text-white font-bold' : 'border-neutral-200 text-neutral-500'}`}>DISC</span>
              <span className={`px-1.5 py-0.5 border ${cardBrand === 'jcb' ? 'bg-emerald-600 border-emerald-600 text-white font-bold' : 'border-neutral-200 text-neutral-500'}`}>JCB</span>
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
              Card Number *
            </label>
            <input
              type="text"
              required
              value={cardNumber}
              onChange={handleCardNumberInput}
              placeholder="4000 1234 5678 9010"
              maxLength={19}
              className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden focus:border-black"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                Expiration (MM/YY) *
              </label>
              <input
                type="text"
                required
                value={cardExp}
                onChange={handleExpInput}
                placeholder="12/28"
                maxLength={5}
                className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden focus:border-black"
              />
            </div>

            <div>
              <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
                Security Code (CVC) *
              </label>
              <input
                type="password"
                required
                value={cardCvc}
                onChange={(e) => onCardCvcChange(e.target.value.slice(0, 4))}
                placeholder="123"
                maxLength={4}
                className="w-full bg-white border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden focus:border-black"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase font-mono text-neutral-700 font-medium mb-1">
              Name on Card *
            </label>
            <input
              type="text"
              required
              value={cardName}
              onChange={(e) => onCardNameChange(e.target.value)}
              placeholder="Maya Reynolds"
              className="w-full bg-white border border-neutral-300 p-2.5 text-xs focus:outline-hidden focus:border-black font-sans"
            />
          </div>

          {/* Sandbox Test Card Quick-Filler Helper */}
          {!content.stripeLiveMode && (
            <div className="pt-2 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-2 text-[11px] text-neutral-500">
              <span className="font-mono text-[10px] text-neutral-400">Sandbox Test Cards:</span>
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => fillTestCard('visa')}
                  className="px-2 py-0.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-mono text-[10px] rounded-xs cursor-pointer border border-neutral-200"
                >
                  + Test Visa
                </button>
                <button
                  type="button"
                  onClick={() => fillTestCard('mastercard')}
                  className="px-2 py-0.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-mono text-[10px] rounded-xs cursor-pointer border border-neutral-200"
                >
                  + Test MC
                </button>
                <button
                  type="button"
                  onClick={() => fillTestCard('amex')}
                  className="px-2 py-0.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-mono text-[10px] rounded-xs cursor-pointer border border-neutral-200"
                >
                  + Test Amex
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. APPLE PAY INTEGRATION */}
      {selectedMethod === 'apple_pay' && content.applePayEnabled !== false && (
        <div className="bg-black text-white p-6 sm:p-8 space-y-4 border border-neutral-800 text-center animate-in fade-in duration-200 shadow-lg">
          <div className="flex items-center justify-center space-x-2">
            <span className="font-serif text-3xl font-bold"> Pay</span>
          </div>
          <p className="text-xs text-neutral-300 max-w-sm mx-auto leading-relaxed">
            Fast, secure biometric checkout with Face ID or Touch ID registered to <strong>{content.applePayMerchantId || content.legalBusinessName}</strong>.
          </p>

          <div className="pt-2">
            <button
              type="button"
              onClick={() => triggerWalletModal('apple_pay')}
              className="px-6 py-3.5 bg-white text-black hover:bg-neutral-100 text-xs uppercase font-mono font-bold tracking-wider inline-flex items-center gap-2 cursor-pointer transition-colors shadow-md rounded-xs"
            >
              <span>Authorize with  Pay • {formatPrice(orderTotal)}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {walletAuthorized && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-xs font-mono flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Apple Pay biometric pre-authorization ready. Click 'Place Order' below to dispatch.</span>
            </div>
          )}
        </div>
      )}

      {/* 3. GOOGLE PAY INTEGRATION */}
      {selectedMethod === 'google_pay' && content.googlePayEnabled !== false && (
        <div className="bg-white border border-neutral-300 p-6 sm:p-8 space-y-4 text-center animate-in fade-in duration-200 shadow-xs">
          <div className="flex items-center justify-center space-x-1.5">
            <span className="font-mono text-2xl font-bold text-neutral-900 tracking-tight">G Pay</span>
          </div>
          <p className="text-xs text-neutral-600 max-w-sm mx-auto leading-relaxed">
            Complete your order instantly using payment and address credentials stored securely in your Google Account ({content.googlePayEnvironment || 'TEST'} profile).
          </p>

          <div className="pt-2">
            <button
              type="button"
              onClick={() => triggerWalletModal('google_pay')}
              className="px-6 py-3.5 bg-[#1f1f1f] text-white hover:bg-black text-xs uppercase font-mono font-bold tracking-wider inline-flex items-center gap-2 cursor-pointer transition-colors shadow-md rounded-xs"
            >
              <span>Pay with G Pay • {formatPrice(orderTotal)}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {walletAuthorized && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-mono flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Google Pay authorization token verified. Click 'Place Order' below to complete.</span>
            </div>
          )}
        </div>
      )}

      {/* 4. PAYPAL & PAY IN 4 */}
      {selectedMethod === 'paypal' && content.paypalEnabled !== false && (
        <div className="bg-[#fcfbf7] border border-[#003087]/30 p-6 sm:p-8 space-y-4 text-center animate-in fade-in duration-200">
          <div className="flex items-center justify-center space-x-1.5">
            <span className="font-sans font-bold text-2xl italic text-[#003087]">Pay</span>
            <span className="font-sans font-bold text-2xl italic text-[#0079C1]">Pal</span>
          </div>
          <p className="text-xs text-neutral-700 max-w-md mx-auto leading-relaxed">
            Pay safely with your PayPal balance, connected bank accounts, or select <strong>PayPal Pay in 4</strong> to split your purchase into 4 interest-free bi-weekly payments of <strong>${installmentAmount}</strong>.
          </p>

          <div className="pt-2">
            <button
              type="button"
              onClick={() => triggerWalletModal('paypal')}
              className="px-8 py-3.5 bg-[#FFC439] hover:bg-[#F4B400] text-[#003087] font-bold text-xs uppercase tracking-wider inline-flex items-center gap-2 cursor-pointer transition-colors shadow-sm rounded-sm"
            >
              <span>Continue with PayPal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          {walletAuthorized && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-mono flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>PayPal Account Pre-Approved. Click 'Place Order' below to confirm dispatch.</span>
            </div>
          )}
        </div>
      )}

      {/* 5. KLARNA */}
      {selectedMethod === 'klarna' && content.klarnaEnabled !== false && (
        <div className="bg-[#ffb3c7]/20 border border-[#ffb3c7] p-6 space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-[#ffb3c7]/50 pb-3">
            <span className="font-serif text-lg font-bold text-neutral-900">Klarna. Pay in 4</span>
            <span className="text-xs font-mono text-neutral-700">0% APR Interest-Free ({content.klarnaRegion || 'US'})</span>
          </div>

          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <div className="bg-white p-3 border border-neutral-200 rounded-xs">
              <span className="text-[10px] text-neutral-500 uppercase block font-mono">Today</span>
              <span className="font-bold text-neutral-900 font-mono">${installmentAmount}</span>
            </div>
            <div className="bg-white p-3 border border-neutral-200 rounded-xs">
              <span className="text-[10px] text-neutral-500 uppercase block font-mono">2 Weeks</span>
              <span className="font-bold text-neutral-900 font-mono">${installmentAmount}</span>
            </div>
            <div className="bg-white p-3 border border-neutral-200 rounded-xs">
              <span className="text-[10px] text-neutral-500 uppercase block font-mono">4 Weeks</span>
              <span className="font-bold text-neutral-900 font-mono">${installmentAmount}</span>
            </div>
            <div className="bg-white p-3 border border-neutral-200 rounded-xs">
              <span className="text-[10px] text-neutral-500 uppercase block font-mono">6 Weeks</span>
              <span className="font-bold text-neutral-900 font-mono">${installmentAmount}</span>
            </div>
          </div>

          <p className="text-[11px] text-neutral-600 leading-relaxed text-center">
            No credit impact to check eligibility. Automatic payments billed every 14 days to your debit or credit card.
          </p>
        </div>
      )}

      {/* 6. AFTERPAY */}
      {selectedMethod === 'afterpay' && content.afterpayEnabled !== false && (
        <div className="bg-[#b2fce4]/20 border border-[#b2fce4] p-6 space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-[#b2fce4]/50 pb-3">
            <span className="font-mono text-base font-bold text-neutral-900">afterpay ▾ Pay in 4</span>
            <span className="text-xs font-mono text-neutral-700">4 Payments • 0% Interest</span>
          </div>

          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <div className="bg-white p-3 border border-neutral-200 rounded-xs">
              <span className="text-[10px] text-neutral-500 uppercase block font-mono">Today</span>
              <span className="font-bold text-neutral-900 font-mono">${installmentAmount}</span>
            </div>
            <div className="bg-white p-3 border border-neutral-200 rounded-xs">
              <span className="text-[10px] text-neutral-500 uppercase block font-mono">2 Weeks</span>
              <span className="font-bold text-neutral-900 font-mono">${installmentAmount}</span>
            </div>
            <div className="bg-white p-3 border border-neutral-200 rounded-xs">
              <span className="text-[10px] text-neutral-500 uppercase block font-mono">4 Weeks</span>
              <span className="font-bold text-neutral-900 font-mono">${installmentAmount}</span>
            </div>
            <div className="bg-white p-3 border border-neutral-200 rounded-xs">
              <span className="text-[10px] text-neutral-500 uppercase block font-mono">6 Weeks</span>
              <span className="font-bold text-neutral-900 font-mono">${installmentAmount}</span>
            </div>
          </div>

          <p className="text-[11px] text-neutral-600 leading-relaxed text-center">
            Always zero interest when you pay on time. Pay in 4 equal installments every 2 weeks.
          </p>
        </div>
      )}

      {/* 7. CASH APP PAY */}
      {selectedMethod === 'cashapp' && content.cashAppPayEnabled !== false && (
        <div className="bg-[#00D632]/10 border border-[#00D632] p-6 space-y-4 text-center animate-in fade-in duration-200">
          <div className="flex items-center justify-center space-x-2">
            <span className="font-mono font-bold text-xl text-[#00A827]">$ Cash App Pay</span>
          </div>
          <p className="text-xs text-neutral-700 max-w-sm mx-auto leading-relaxed">
            Send payment directly to <strong>{content.cashAppCashtag || '$EzistentialStudio'}</strong> or scan the dynamic QR code below.
          </p>

          <div className="w-32 h-32 bg-white border border-neutral-300 mx-auto flex items-center justify-center shadow-xs">
            <QrCode className="w-24 h-24 text-neutral-900" />
          </div>

          <p className="text-[10px] text-neutral-500 font-mono">
            Scan with your iPhone / Android camera or Cash App scanner
          </p>
        </div>
      )}

      {/* Interactive Wallet Simulation Modal */}
      {activeWalletModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-white max-w-md w-full p-6 space-y-5 border border-neutral-300 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <span className="font-serif text-base text-neutral-900 font-semibold">
                {activeWalletModal === 'apple_pay' && ' Apple Pay Biometric Sheet'}
                {activeWalletModal === 'google_pay' && 'G Pay Google Wallet Authorization'}
                {activeWalletModal === 'paypal' && 'PayPal Secure Checkout Window'}
                {activeWalletModal === 'shoppay' && 'Shop Pay 1-Click Fast Verification'}
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>

            <div className="p-4 bg-neutral-50 border border-neutral-200 text-xs space-y-2 font-mono">
              <div className="flex justify-between">
                <span className="text-neutral-500">Merchant:</span>
                <span className="text-neutral-900 font-bold">{content.legalBusinessName || 'Ezistential Connections LLC'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Total Authorization:</span>
                <span className="text-neutral-900 font-bold">{formatPrice(orderTotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Card / Funding:</span>
                <span className="text-neutral-900 font-semibold">Default Verified Account (•••• 8821)</span>
              </div>
            </div>

            <p className="text-xs text-neutral-600 leading-relaxed">
              Biometric authorization token generated securely. Confirming will approve the payment token for immediate order creation.
            </p>

            <div className="flex justify-end space-x-2 pt-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setActiveWalletModal(null)}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="primary"
                size="sm"
                onClick={() => confirmWalletAuthorization(activeWalletModal)}
              >
                <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" />
                <span>Confirm & Authorize</span>
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
