import React, { useState, useEffect, useRef } from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { Button } from '../ui/Button';

export interface ConfirmDeleteModalProps {
  isOpen: boolean;
  title: string;
  itemName: string;
  itemType?: string;
  warningMessage?: string;
  expectedWord?: string; // Default: 'DELETE'
  onConfirm: () => void;
  onClose: () => void;
}

export const ConfirmDeleteModal: React.FC<ConfirmDeleteModalProps> = ({
  isOpen,
  title,
  itemName,
  itemType = 'item',
  warningMessage = 'This action is irreversible. All associated data will be permanently removed.',
  expectedWord = 'DELETE',
  onConfirm,
  onClose,
}) => {
  const [typedInput, setTypedInput] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTypedInput('');
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isMatched = typedInput.trim().toUpperCase() === expectedWord.trim().toUpperCase();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isMatched) {
      onConfirm();
      onClose();
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div className="relative w-full max-w-md bg-white border border-red-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
        {/* Accent Warning Header Bar */}
        <div className="bg-red-600 text-white px-5 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-white" />
            <h3 className="font-mono text-xs font-bold uppercase tracking-wider">
              {title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white transition-colors cursor-pointer p-0.5"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <p className="text-xs text-neutral-600 font-sans leading-relaxed">
              You are about to permanently delete this {itemType}:
            </p>
            <div className="mt-2 p-3 bg-red-50/70 border border-red-200 rounded-xs">
              <span className="font-mono text-xs font-bold text-red-950 block truncate">
                {itemName}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-neutral-500 font-sans leading-relaxed">
            {warningMessage}
          </p>

          <div className="space-y-1.5 pt-2 border-t border-neutral-100">
            <label className="block text-xs font-mono text-neutral-800">
              To verify, type <span className="font-bold text-red-600 bg-red-50 px-1.5 py-0.5 border border-red-200">{expectedWord}</span> below:
            </label>
            <input
              ref={inputRef}
              type="text"
              value={typedInput}
              onChange={(e) => setTypedInput(e.target.value)}
              placeholder={`Type "${expectedWord}" to confirm`}
              className="w-full bg-neutral-50 border border-neutral-300 focus:border-red-600 focus:ring-1 focus:ring-red-600 p-2.5 text-xs font-mono uppercase tracking-wider transition-all"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-neutral-100">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={onClose}
              className="text-xs font-mono border-neutral-300 hover:border-black cursor-pointer"
            >
              Cancel
            </Button>

            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={!isMatched}
              className={`text-xs font-mono flex items-center gap-1.5 cursor-pointer transition-all ${
                isMatched
                  ? 'bg-red-600 hover:bg-red-700 text-white border-red-700 shadow-xs'
                  : 'bg-neutral-200 text-neutral-400 border-neutral-300 cursor-not-allowed'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Permanently</span>
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
