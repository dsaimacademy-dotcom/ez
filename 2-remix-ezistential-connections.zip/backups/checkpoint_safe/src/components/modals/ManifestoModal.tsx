import React from 'react';
import { Modal } from '../ui/Modal';
import { MANIFESTO_FULL } from '../../data/content';

export interface ManifestoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ManifestoModal: React.FC<ManifestoModalProps> = ({ isOpen, onClose }) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={MANIFESTO_FULL.title}
      subtitle="Ezistential Connections Founding Text"
      maxWidth="xl"
    >
      <div className="space-y-8 py-2 max-h-[70vh] overflow-y-auto pr-2">
        <blockquote className="border-l-2 border-black pl-4 italic font-serif text-lg text-neutral-800 my-4">
          "Somewhere between you and me, there is an us worth discovering."
        </blockquote>

        {MANIFESTO_FULL.sections.map((section, idx) => (
          <div key={idx} className="space-y-2">
            <h4 className="font-serif text-lg font-medium text-neutral-900 tracking-tight">
              {section.heading}
            </h4>
            <p className="text-sm text-neutral-700 leading-relaxed font-sans">
              {section.body}
            </p>
          </div>
        ))}

        <div className="pt-6 border-t border-neutral-200 text-center">
          <p className="text-xs uppercase tracking-widest text-neutral-400">
            Ezistential Connections • Est. 2008
          </p>
        </div>
      </div>
    </Modal>
  );
};
