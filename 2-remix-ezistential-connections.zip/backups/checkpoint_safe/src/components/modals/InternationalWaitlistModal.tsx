import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Globe, Check, Send } from 'lucide-react';

export interface InternationalWaitlistModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const COUNTRIES = [
  'Canada',
  'United Kingdom',
  'Germany',
  'France',
  'Japan',
  'Australia',
  'Nigeria',
  'United Arab Emirates',
  'Brazil',
  'South Korea',
  'Netherlands',
  'Italy',
  'Spain',
  'Mexico',
  'Other Region',
];

export const InternationalWaitlistModal: React.FC<InternationalWaitlistModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedCountry, setSelectedCountry] = useState(COUNTRIES[0]);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;

    // Save to local storage waitlist log
    const existing = JSON.parse(localStorage.getItem('ec_int_waitlist') || '[]');
    existing.push({ country: selectedCountry, email, timestamp: new Date().toISOString() });
    localStorage.setItem('ec_int_waitlist', JSON.stringify(existing));

    setIsSubmitted(true);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="International Dispatch Waitlist" maxWidth="md">
      <div className="space-y-6">
        <div className="flex items-center space-x-3 bg-neutral-900 text-white p-4 border border-neutral-800">
          <Globe className="w-5 h-5 text-amber-300 shrink-0" />
          <div className="space-y-0.5">
            <h4 className="font-serif text-sm font-bold text-white">US Launch Phase</h4>
            <p className="text-xs text-neutral-400">
              We currently fulfill within the United States. Join the waitlist for priority dispatch when international shipping unlocks.
            </p>
          </div>
        </div>

        {isSubmitted ? (
          <div className="bg-emerald-50 border border-emerald-200 p-6 text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
              <Check className="w-5 h-5" />
            </div>
            <h4 className="font-serif text-lg font-bold text-emerald-950">You Are On The Waitlist</h4>
            <p className="text-xs text-emerald-900 leading-relaxed max-w-sm mx-auto">
              We have recorded your email for <strong className="font-bold">{selectedCountry}</strong>. You will receive direct notification before global dispatch goes live.
            </p>
            <Button variant="outline" size="sm" onClick={onClose} className="border-emerald-800 text-emerald-950 mt-2">
              Close Window
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 font-sans text-xs">
            <div>
              <label className="block uppercase font-mono tracking-wider text-neutral-600 mb-1.5 font-bold text-[10px]">
                Your Country / Region
              </label>
              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs font-mono text-neutral-900 focus:outline-hidden focus:border-black"
              >
                {COUNTRIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block uppercase font-mono tracking-wider text-neutral-600 mb-1.5 font-bold text-[10px]">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="care@example.com"
                className="w-full bg-[#fbfbf9] border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black"
              />
            </div>

            <Button type="submit" variant="primary" size="md" fullWidth className="py-3">
              <Send className="w-3.5 h-3.5 mr-1.5" />
              <span>Join Global Dispatch Waitlist</span>
            </Button>
          </form>
        )}
      </div>
    </Modal>
  );
};
