import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { SIZE_GUIDE_DATA, SIZE_MEASURING_TIPS } from '../../data/sizeGuide';
import { cn } from '../../lib/utils';

export interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  const [unit, setUnit] = useState<'inches' | 'cm'>('inches');

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Garment Sizing & Fit"
      subtitle="Standard Unisex Measurements"
      maxWidth="lg"
    >
      <div className="space-y-6">
        {/* Unit Toggle */}
        <div className="flex items-center justify-between">
          <p className="text-xs text-neutral-600">
            All garments cut in a relaxed drop-shoulder silhouette.
          </p>
          <div className="flex items-center border border-neutral-300 rounded-xs overflow-hidden">
            <button
              onClick={() => setUnit('inches')}
              className={cn(
                'px-3 py-1 text-xs uppercase tracking-wider font-medium transition-colors',
                unit === 'inches' ? 'bg-black text-white' : 'bg-transparent text-neutral-600 hover:text-black'
              )}
            >
              Inches
            </button>
            <button
              onClick={() => setUnit('cm')}
              className={cn(
                'px-3 py-1 text-xs uppercase tracking-wider font-medium transition-colors',
                unit === 'cm' ? 'bg-black text-white' : 'bg-transparent text-neutral-600 hover:text-black'
              )}
            >
              Centimeters
            </button>
          </div>
        </div>

        {/* Measurement Table */}
        <div className="overflow-x-auto border border-neutral-200">
          <table className="w-full text-left text-xs font-sans">
            <thead className="bg-[#f5f4f0] text-neutral-700 uppercase tracking-wider text-[10px] border-b border-neutral-200">
              <tr>
                <th className="py-2.5 px-4 font-semibold">Size</th>
                <th className="py-2.5 px-4 font-semibold">Chest Width</th>
                <th className="py-2.5 px-4 font-semibold">Body Length</th>
                <th className="py-2.5 px-4 font-semibold">Sleeve Length</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 font-mono">
              {SIZE_GUIDE_DATA.map((row) => (
                <tr key={row.size} className="hover:bg-neutral-50 transition-colors">
                  <td className="py-2.5 px-4 font-sans font-semibold text-neutral-900">{row.size}</td>
                  <td className="py-2.5 px-4 text-neutral-700">
                    {unit === 'inches' ? row.chestInches : row.chestCm}
                  </td>
                  <td className="py-2.5 px-4 text-neutral-700">
                    {unit === 'inches' ? row.lengthInches : row.lengthCm}
                  </td>
                  <td className="py-2.5 px-4 text-neutral-700">
                    {unit === 'inches' ? row.sleeveInches : row.sleeveCm}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Measuring Advice */}
        <div className="bg-[#f5f4f0] p-4 space-y-3 border border-neutral-200">
          <h4 className="text-xs uppercase tracking-widest font-semibold text-neutral-900">
            How to Measure
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-neutral-600">
            {SIZE_MEASURING_TIPS.map((tip, idx) => (
              <div key={idx} className="space-y-1">
                <span className="font-medium text-neutral-900 block">{tip.title}</span>
                <p className="text-[11px] leading-relaxed text-neutral-500">{tip.instruction}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
};
