import React from 'react';
import { useContent } from '../../context/ContentContext';
import { safeSrc } from '../../lib/utils';

export interface LogoProps {
  variant?: 'black' | 'white' | 'currentColor';
  className?: string;
  customSrc?: string;
}

export const Logo: React.FC<LogoProps> = ({
  variant = 'black',
  className = 'h-7 sm:h-8 w-auto',
  customSrc,
}) => {
  const { content } = useContent();
  const isWhite = variant === 'white';

  const defaultSrc = isWhite ? '/ez-logo-white.svg' : '/ez-logo.svg';
  const logoSrc = safeSrc(customSrc || (isWhite ? content?.brandLogoDarkUrl : content?.brandLogoUrl), defaultSrc);

  return (
    <div className="inline-flex items-center justify-center">
      <img
        src={logoSrc}
        alt={content?.brandName || 'Ezistential Logo'}
        className={`${className} object-contain transition-opacity`}
        style={{ aspectRatio: '1440 / 280' }}
        loading="eager"
        onError={(e) => {
          // Fallback to default SVG if custom URL fails to load
          const target = e.currentTarget as HTMLImageElement;
          if (target.src !== defaultSrc) {
            target.src = defaultSrc;
          }
        }}
      />
    </div>
  );
};
