import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  maxWidth = 'lg',
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#0a0a0a]/75 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Dialog Window */}
      <div
        className={cn(
          'relative w-full bg-[#fbfbf9] text-[#0a0a0a] shadow-2xl border border-[#e5e5e5] p-6 sm:p-8 z-10 my-8 transition-transform duration-300',
          maxWidth === 'sm' && 'max-w-md',
          maxWidth === 'md' && 'max-w-lg',
          maxWidth === 'lg' && 'max-w-2xl',
          maxWidth === 'xl' && 'max-w-3xl',
          maxWidth === '2xl' && 'max-w-4xl'
        )}
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-neutral-500 hover:text-black transition-colors focus:outline-hidden"
          aria-label="Close modal"
        >
          <X className="w-5 h-5 stroke-[1.5]" />
        </button>

        {(title || subtitle) && (
          <div className="mb-6 pr-8 border-b border-neutral-200 pb-4">
            {title && <h3 className="font-serif text-2xl tracking-tight text-neutral-900 text-balance">{title}</h3>}
            {subtitle && <p className="text-xs uppercase tracking-wider text-neutral-500 mt-1">{subtitle}</p>}
          </div>
        )}

        <div>{children}</div>
      </div>
    </div>
  );
};
