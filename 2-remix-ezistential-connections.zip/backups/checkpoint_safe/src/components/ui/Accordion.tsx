import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface AccordionItemProps {
  id: string;
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

export const AccordionItem: React.FC<
  AccordionItemProps & {
    isOpen?: boolean;
    onToggle?: () => void;
    className?: string;
  }
> = ({ title, children, isOpen, onToggle, className }) => {
  return (
    <div className={cn('border-b border-neutral-200 py-4 transition-colors', className)}>
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between text-left focus:outline-hidden py-1 group"
        aria-expanded={isOpen}
      >
        <span className="font-serif text-lg tracking-tight text-neutral-900 group-hover:text-black transition-colors">
          {title}
        </span>
        <ChevronDown
          className={cn(
            'w-4 h-4 text-neutral-500 transition-transform duration-200 shrink-0 ml-4',
            isOpen && 'rotate-180 text-black'
          )}
        />
      </button>
      {isOpen && (
        <div className="pt-3 pb-2 text-sm text-neutral-600 leading-relaxed font-sans animate-in fade-in-50 duration-200">
          {children}
        </div>
      )}
    </div>
  );
};

export interface AccordionProps {
  items: {
    id: string;
    title: string;
    content: React.ReactNode;
  }[];
  allowMultiple?: boolean;
  className?: string;
}

export const Accordion: React.FC<AccordionProps> = ({
  items,
  allowMultiple = false,
  className,
}) => {
  const [openIds, setOpenIds] = useState<string[]>([]);

  const handleToggle = (id: string) => {
    if (allowMultiple) {
      setOpenIds((prev) =>
        prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
      );
    } else {
      setOpenIds((prev) => (prev.includes(id) ? [] : [id]));
    }
  };

  return (
    <div className={cn('divide-y divide-neutral-200 border-t border-neutral-200', className)}>
      {items.map((item) => (
        <AccordionItem
          key={item.id}
          id={item.id}
          title={item.title}
          isOpen={openIds.includes(item.id)}
          onToggle={() => handleToggle(item.id)}
        >
          {item.content}
        </AccordionItem>
      ))}
    </div>
  );
};
