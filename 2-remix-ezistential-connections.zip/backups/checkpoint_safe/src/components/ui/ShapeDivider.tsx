import React from 'react';

export type ShapeDividerVariant =
  | 'zebra-contour'
  | 'editorial-notch'
  | 'textile-seam'
  | 'horizon-converge'
  | 'asymmetric-slash';

export interface ShapeDividerProps {
  variant: ShapeDividerVariant;
  /** Fill color of the shape (matches the section it points into or emerges from) */
  fillColor?: string;
  /** Background color of the parent container or underlying canvas (transparent by default to prevent color mismatches) */
  bgColor?: string;
  /** Top or bottom edge of the section */
  position?: 'top' | 'bottom';
  /** Flip horizontally for visual rhythm alternation */
  flipX?: boolean;
  /** Height in pixels or custom Tailwind height */
  height?: number;
  className?: string;
}

export const ShapeDivider: React.FC<ShapeDividerProps> = ({
  variant,
  fillColor = '#0a0a0a',
  bgColor = 'transparent',
  position = 'bottom',
  flipX = false,
  height = 56,
  className = '',
}) => {
  const isTop = position === 'top';

  // Transform for orientation & flip
  const transform = [
    isTop ? 'rotate(180deg)' : '',
    flipX ? 'scaleX(-1)' : '',
  ]
    .filter(Boolean)
    .join(' ');

  const isDarkFill = fillColor === '#0a0a0a' || fillColor === '#141414' || fillColor === '#121212' || fillColor === '#1a1a1a';
  const strokeColor = isDarkFill ? 'rgba(255, 255, 255, 0.12)' : 'rgba(0, 0, 0, 0.08)';

  const renderShape = () => {
    switch (variant) {
      case 'editorial-notch':
        // Architectural cut with a subtle tension step and seamless flush bottom
        return (
          <svg
            viewBox="0 0 1440 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            {/* Seamless angled facet extending slightly past bottom boundary to prevent subpixel hairline gaps */}
            <path
              d="M0,28 L660,54 L720,40 L1440,24 L1440,84 L0,84 Z"
              fill={fillColor}
            />
            {/* Accent hairline on the fault contour only (does not intersect or create bottom straight lines) */}
            <path
              d="M0,28 L660,54 L720,40 L1440,24"
              stroke={strokeColor}
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        );

      case 'zebra-contour':
        // Dual-tiered organic contour inspired by topographical distance and zebra striping
        return (
          <svg
            viewBox="0 0 1440 90"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            {/* Subtle secondary ghost contour line */}
            <path
              d="M0,45 C280,75 520,20 840,55 C1120,85 1320,35 1440,50 L1440,94 L0,94 Z"
              fill={fillColor}
              opacity="0.35"
            />
            {/* Primary organic wave contour */}
            <path
              d="M0,30 C240,65 480,10 760,45 C1040,80 1260,25 1440,38 L1440,94 L0,94 Z"
              fill={fillColor}
            />
            <path
              d="M0,30 C240,65 480,10 760,45 C1040,80 1260,25 1440,38"
              stroke={strokeColor}
              strokeWidth="1"
            />
          </svg>
        );

      case 'textile-seam':
        // Soft sculpted cloth crest with a tactile stitch thread line
        return (
          <svg
            viewBox="0 0 1440 70"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            {/* Soft cloth crest fill */}
            <path
              d="M0,35 Q360,68 720,35 T1440,35 L1440,74 L0,74 Z"
              fill={fillColor}
            />
            {/* Tactile running stitch thread */}
            <path
              d="M0,31 Q360,64 720,31 T1440,31"
              stroke={strokeColor}
              strokeWidth="1.5"
              strokeDasharray="6 8"
              opacity="0.6"
            />
          </svg>
        );

      case 'horizon-converge':
        // Perspective convergence plane tapering toward center vanishing point
        return (
          <svg
            viewBox="0 0 1440 60"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <path
              d="M0,12 L720,48 L1440,12 L1440,64 L0,64 Z"
              fill={fillColor}
            />
            <path
              d="M0,12 L720,48 L1440,12"
              stroke={strokeColor}
              strokeWidth="1.2"
            />
            {/* Central focal needle */}
            <line
              x1="720"
              y1="48"
              x2="720"
              y2="64"
              stroke={strokeColor}
              strokeWidth="1"
            />
          </svg>
        );

      case 'asymmetric-slash':
      default:
        // Asymmetric brutalist diagonal slash
        return (
          <svg
            viewBox="0 0 1440 60"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full block overflow-visible"
            preserveAspectRatio="none"
          >
            <polygon points="0,64 1440,14 1440,64" fill={fillColor} />
            <line x1="0" y1="64" x2="1440" y2="14" stroke={strokeColor} strokeWidth="1.2" />
          </svg>
        );
    }
  };

  return (
    <div
      className={`relative w-full overflow-hidden select-none pointer-events-none z-10 block leading-none ${className}`}
      style={{
        backgroundColor: bgColor === 'transparent' ? undefined : bgColor,
        height: `${height}px`,
        transform: transform || undefined,
        transformOrigin: 'center center',
      }}
      aria-hidden="true"
    >
      {renderShape()}
    </div>
  );
};
