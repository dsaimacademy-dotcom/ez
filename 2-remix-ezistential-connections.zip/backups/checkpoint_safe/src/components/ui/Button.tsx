import React from 'react';
import { cn } from '../../lib/utils';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'link';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', fullWidth = false, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          'inline-flex items-center justify-center font-medium transition-all duration-200 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed select-none text-xs uppercase tracking-wider',
          // Variants
          variant === 'primary' &&
            'bg-[#0a0a0a] text-[#fbfbf9] hover:bg-[#262626] active:bg-[#000000] border border-transparent shadow-xs',
          variant === 'secondary' &&
            'bg-[#f5f4f0] text-[#0a0a0a] hover:bg-[#eae8e2] border border-[#e5e5e5]',
          variant === 'outline' &&
            'bg-transparent text-[#0a0a0a] border border-[#0a0a0a] hover:bg-[#0a0a0a] hover:text-[#fbfbf9]',
          variant === 'ghost' &&
            'bg-transparent text-[#0a0a0a] hover:bg-[#f5f4f0]',
          variant === 'link' &&
            'bg-transparent text-[#0a0a0a] underline-offset-4 hover:underline p-0 lowercase font-normal tracking-normal text-sm',
          // Sizes
          size === 'sm' && variant !== 'link' && 'px-3 py-1.5 text-[11px]',
          size === 'md' && variant !== 'link' && 'px-5 py-3 text-xs',
          size === 'lg' && variant !== 'link' && 'px-7 py-4 text-xs font-semibold',
          fullWidth && 'w-full',
          className
        )}
        {...props}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
