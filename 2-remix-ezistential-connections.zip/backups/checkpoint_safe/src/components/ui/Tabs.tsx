import React from 'react';
import { cn } from '../../lib/utils';

export interface TabItem {
  id: string;
  label: string;
  count?: number;
}

export interface TabsProps {
  tabs: TabItem[];
  activeTab: string;
  onChange: (id: string) => void;
  className?: string;
  variant?: 'underline' | 'pills' | 'editorial';
}

export const Tabs: React.FC<TabsProps> = ({
  tabs,
  activeTab,
  onChange,
  className,
  variant = 'editorial',
}) => {
  return (
    <div className={cn('flex items-center space-x-1 sm:space-x-3 border-b border-neutral-200 overflow-x-auto pb-px', className)}>
      {tabs.map((tab) => {
        const isActive = tab.id === activeTab;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={cn(
              'px-4 py-3 text-xs uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer relative',
              isActive
                ? 'text-black font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[2px] after:bg-black'
                : 'text-neutral-500 hover:text-neutral-800 font-medium'
            )}
          >
            <span>{tab.label}</span>
            {typeof tab.count === 'number' && (
              <span className={cn('ml-2 text-[10px] px-1.5 py-0.5 rounded-full', isActive ? 'bg-neutral-900 text-white' : 'bg-neutral-100 text-neutral-600')}>
                {tab.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};
