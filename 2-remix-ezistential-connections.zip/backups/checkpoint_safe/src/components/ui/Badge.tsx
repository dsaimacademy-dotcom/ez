import React from 'react';
import { cn } from '../../lib/utils';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'default' | 'outline' | 'dark' | 'muted' | 'success' | 'warning' | 'info' | 'error' | 'neutral';
  size?: 'sm' | 'md' | 'lg';
}

export const Badge: React.FC<BadgeProps> = ({
  className,
  variant = 'default',
  size = 'md',
  children,
  ...props
}) => {
  return (
    <span
      className={cn(
        'inline-flex items-center uppercase tracking-widest font-mono font-medium transition-colors',
        size === 'sm' && 'text-[9px] px-2 py-0.5',
        size === 'md' && 'text-[10px] px-2.5 py-1',
        size === 'lg' && 'text-xs px-3 py-1.5',
        (variant === 'default' || variant === 'neutral') && 'bg-[#f5f4f0] text-[#141414] border border-[#d4d2cc]',
        variant === 'outline' && 'bg-transparent text-[#141414] border border-[#d4d4d4]',
        variant === 'dark' && 'bg-[#141414] text-[#fbfbf9] border border-[#262626]',
        variant === 'muted' && 'bg-[#f0f0ee] text-[#737373]',
        variant === 'success' && 'bg-emerald-50 text-emerald-800 border border-emerald-300',
        variant === 'warning' && 'bg-amber-50 text-amber-900 border border-amber-300',
        variant === 'info' && 'bg-blue-50 text-blue-800 border border-blue-300',
        variant === 'error' && 'bg-red-50 text-red-800 border border-red-300',
        className
      )}
      {...props}
    >
      {children}
    </span>
  );
};
