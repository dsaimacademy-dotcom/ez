import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, CheckCircle2, Zap, X, RefreshCw, Eye } from 'lucide-react';
import { compressImage, CompressionResult } from '../../lib/imageCompressor';
import { Button } from './Button';

export interface ImageUploadCompressorProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  helperText?: string;
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  previewBg?: 'light' | 'dark';
  placeholder?: string;
}

export const ImageUploadCompressor: React.FC<ImageUploadCompressorProps> = ({
  label,
  value,
  onChange,
  helperText,
  maxWidth = 1200,
  maxHeight = 1200,
  quality = 0.82,
  previewBg = 'light',
  placeholder = 'Paste image URL or click below to upload & compress...',
}) => {
  const [isCompressing, setIsCompressing] = useState(false);
  const [compressionStats, setCompressionStats] = useState<CompressionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file (PNG, JPG, SVG, WebP).');
      return;
    }

    setError(null);
    setIsCompressing(true);

    try {
      // SVGs don't need raster canvas compression, read directly as data URL
      if (file.type === 'image/svg+xml') {
        const reader = new FileReader();
        reader.onload = (event) => {
          const result = event.target?.result as string;
          onChange(result);
          setCompressionStats({
            dataUrl: result,
            originalSizeKb: Math.round(file.size / 1024),
            compressedSizeKb: Math.round(file.size / 1024),
            reductionPercentage: 0,
            format: 'image/webp',
            width: 0,
            height: 0,
          });
          setIsCompressing(false);
        };
        reader.readAsDataURL(file);
        return;
      }

      const compressed = await compressImage(file, {
        maxWidth,
        maxHeight,
        quality,
        outputFormat: 'image/webp',
      });

      onChange(compressed.dataUrl);
      setCompressionStats(compressed);
    } catch (err: any) {
      setError(err.message || 'Failed to compress image.');
    } finally {
      setIsCompressing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between">
        <label className="block text-xs uppercase font-mono text-neutral-800 font-semibold tracking-wider">
          {label}
        </label>
        {compressionStats && (
          <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 border border-emerald-200 flex items-center gap-1">
            <Zap className="w-3 h-3 text-emerald-600" />
            <span>
              {compressionStats.originalSizeKb}KB → {compressionStats.compressedSizeKb}KB (-{compressionStats.reductionPercentage}%)
            </span>
          </span>
        )}
      </div>

      {helperText && <p className="text-[11px] text-neutral-500">{helperText}</p>}

      {/* URL or Direct text input */}
      <div className="flex items-center space-x-2">
        <input
          type="text"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setCompressionStats(null);
          }}
          placeholder={placeholder}
          className="flex-1 bg-white border border-neutral-300 px-3 py-2 text-xs font-mono text-neutral-900 focus:outline-hidden focus:border-black"
        />

        {/* Upload Trigger Button */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileSelect}
        />

        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          disabled={isCompressing}
          className="shrink-0 text-xs flex items-center space-x-1.5"
        >
          {isCompressing ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Optimizing...</span>
            </>
          ) : (
            <>
              <Upload className="w-3.5 h-3.5" />
              <span>Upload & Compress</span>
            </>
          )}
        </Button>
      </div>

      {error && <p className="text-xs text-red-500">{error}</p>}

      {/* Live Preview Box */}
      {value && (
        <div
          className={`relative p-4 border flex items-center justify-center min-h-[90px] max-h-[140px] overflow-hidden rounded-xs ${
            previewBg === 'dark' ? 'bg-[#0c0c0c] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <img
            src={value}
            alt="Asset Preview"
            className="max-h-24 max-w-full object-contain"
            loading="lazy"
            decoding="async"
            onError={(e) => {
              (e.currentTarget as HTMLElement).style.display = 'none';
            }}
          />

          <button
            type="button"
            onClick={() => {
              onChange('');
              setCompressionStats(null);
            }}
            title="Clear image"
            className="absolute top-2 right-2 p-1 bg-black/60 hover:bg-black text-white rounded-full cursor-pointer transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
