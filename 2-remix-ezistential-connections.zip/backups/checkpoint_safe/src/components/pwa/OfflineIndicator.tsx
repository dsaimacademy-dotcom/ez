import React, { useState, useEffect } from 'react';
import { WifiOff, Wifi, RefreshCw } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [showReconnected, setShowReconnected] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowReconnected(true);
      const timer = setTimeout(() => setShowReconnected(false), 4000);
      return () => clearTimeout(timer);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowReconnected(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline && !showReconnected) return null;

  if (showReconnected) {
    return (
      <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 bg-emerald-900 text-emerald-100 border border-emerald-700 px-3.5 py-2 text-xs font-mono uppercase tracking-wider shadow-lg animate-in fade-in slide-in-from-bottom-2 duration-300">
        <Wifi className="w-3.5 h-3.5 text-emerald-400" />
        <span>Connection Restored · Live Sync Active</span>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 bg-[#0a0a0a] text-white border border-[#262626] px-3.5 py-2 text-xs font-mono uppercase tracking-wider shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-300">
      <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
      <WifiOff className="w-3.5 h-3.5 text-neutral-400" />
      <span>Offline Mode · Cached garments & manifesto available</span>
    </div>
  );
};
