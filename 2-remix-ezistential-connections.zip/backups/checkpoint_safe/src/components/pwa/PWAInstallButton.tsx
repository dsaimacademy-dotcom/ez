import React, { useState } from 'react';
import { Download, Smartphone, X, Check, ArrowRight } from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

export interface PWAInstallButtonProps {
  variant?: 'header' | 'footer' | 'pill';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'pill',
  className = '',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    if (variant === 'header') {
      return (
        <button
          onClick={install}
          title="Install Ezistential App"
          className={`flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono uppercase tracking-wider text-neutral-800 hover:text-black border border-neutral-300 hover:border-black transition-colors cursor-pointer bg-white ${className}`}
        >
          <Download className="w-3 h-3 text-neutral-600" />
          <span className="hidden sm:inline">Install App</span>
        </button>
      );
    }

    return (
      <button
        onClick={install}
        className={`inline-flex items-center gap-2 px-3 py-1.5 text-xs font-mono uppercase tracking-wider text-neutral-900 bg-white border border-neutral-300 hover:border-black transition-colors cursor-pointer shadow-xs ${className}`}
      >
        <Download className="w-3.5 h-3.5 text-neutral-700" />
        <span>Install Web App</span>
      </button>
    );
  }

  // iOS Safari flow (beforeinstallprompt is not supported by WebKit)
  if (isIOS) {
    return (
      <>
        {variant === 'header' ? (
          <button
            onClick={() => setShowIOSGuide(true)}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono uppercase tracking-wider text-neutral-800 hover:text-black border border-neutral-300 hover:border-black transition-colors cursor-pointer bg-white ${className}`}
          >
            <Smartphone className="w-3 h-3 text-neutral-600" />
            <span className="hidden sm:inline">Add to Home</span>
          </button>
        ) : (
          <button
            onClick={() => setShowIOSGuide(true)}
            className={`inline-flex items-center gap-2 px-3 py-1.5 text-xs font-mono uppercase tracking-wider text-neutral-800 bg-white border border-neutral-300 hover:border-black transition-colors cursor-pointer shadow-xs ${className}`}
          >
            <Smartphone className="w-3.5 h-3.5 text-neutral-700" />
            <span>Install on iOS</span>
          </button>
        )}

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
            <div className="relative w-full max-w-sm bg-white border border-neutral-300 p-6 space-y-5 shadow-2xl z-10">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
                    Apple iOS Safari
                  </span>
                  <h3 className="font-serif text-xl text-neutral-900">
                    Add to Home Screen
                  </h3>
                </div>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 text-neutral-400 hover:text-black cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-neutral-700 font-sans leading-relaxed">
                <div className="flex items-start gap-3 p-3 bg-[#f5f4f0] border border-neutral-200">
                  <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center font-mono text-xs shrink-0 mt-0.5">
                    1
                  </div>
                  <div>
                    Tap the <strong>Share</strong> button (box with an arrow pointing up) in the Safari bottom bar.
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-[#f5f4f0] border border-neutral-200">
                  <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center font-mono text-xs shrink-0 mt-0.5">
                    2
                  </div>
                  <div>
                    Scroll down and select <strong>Add to Home Screen</strong>.
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-[#f5f4f0] border border-neutral-200">
                  <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center font-mono text-xs shrink-0 mt-0.5">
                    3
                  </div>
                  <div>
                    Tap <strong>Add</strong> in the top-right corner to install the standalone app icon.
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full bg-black text-white text-xs font-mono uppercase tracking-wider py-2.5 hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                Got It
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Fallback for desktop browsers without prompt triggered yet (or already installed)
  return null;
};
