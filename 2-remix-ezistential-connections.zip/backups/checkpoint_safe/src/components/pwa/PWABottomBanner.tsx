import React, { useState } from 'react';
import { Download, Smartphone, X, Monitor, Check } from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';
import { useContent } from '../../context/ContentContext';

export const PWABottomBanner: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { content } = useContent();
  const faviconSrc = (content?.faviconUrl && content.faviconUrl !== '/favicon.ico') ? content.faviconUrl : '/ez-favicon.svg';

  // We keep dismissed state in memory only so it re-appears on every screen reload until installed
  const [isDismissed, setIsDismissed] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [showDesktopGuide, setShowDesktopGuide] = useState(false);

  // If already installed or currently dismissed for this screen view, hide
  if (isInstalled || isDismissed) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const outcome = await install();
      if (outcome) {
        setIsDismissed(true);
      }
    } else if (isIOS) {
      setShowIOSGuide(true);
    } else {
      setShowDesktopGuide(true);
    }
  };

  return (
    <>
      {/* Floating Bottom Prompt Banner for both PC and Phone */}
      <aside
        aria-label="Install Application"
        className="fixed bottom-3 inset-x-3 sm:bottom-5 sm:right-5 sm:left-auto sm:max-w-md z-40 bg-[#0d0d0d]/95 backdrop-blur-md text-white border border-neutral-700/90 shadow-2xl p-3.5 sm:p-4 animate-in fade-in slide-in-from-bottom-3 duration-300"
      >
        <div className="flex items-center justify-between gap-3">
          {/* Brand Icon (dynamic favicon from business setup) & Information */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 bg-white p-1 rounded-xs shrink-0 border border-neutral-400 flex items-center justify-center overflow-hidden shadow-xs">
              <img
                src={faviconSrc}
                alt={content?.brandName || 'Ezistential App Favicon'}
                className="w-full h-full object-contain"
                onError={(e) => {
                  const target = e.currentTarget as HTMLImageElement;
                  if (target.src !== '/ez-favicon.svg') {
                    target.src = '/ez-favicon.svg';
                  }
                }}
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-white truncate">
                  {content?.brandName || 'Ezistential Connections'}
                </h4>
                <span className="hidden xs:inline-block px-1.5 py-0.2 bg-neutral-800 text-neutral-300 text-[9px] font-mono uppercase tracking-widest border border-neutral-700">
                  App
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 font-sans truncate">
                Install app for instant loading &amp; offline access
              </p>
            </div>
          </div>

          {/* Action Buttons: Install App + Cancel (X) */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleInstallClick}
              className="flex items-center gap-1.5 bg-white text-black hover:bg-neutral-200 px-3 py-1.5 text-xs font-mono font-semibold uppercase tracking-wider transition-colors cursor-pointer shadow-sm active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install App</span>
            </button>

            <button
              type="button"
              onClick={() => setIsDismissed(true)}
              title="Cancel (Dismiss for now)"
              aria-label="Cancel and dismiss install prompt"
              className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer border border-transparent hover:border-neutral-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* iOS Safari Installation Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm bg-white border border-neutral-300 p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white p-1 rounded-xs border border-neutral-300 flex items-center justify-center shrink-0 overflow-hidden">
                  <img src={faviconSrc} alt="Favicon" className="w-full h-full object-contain" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
                    Apple iOS Safari
                  </span>
                  <h3 className="font-serif text-xl text-neutral-900">
                    Install on iPhone / iPad
                  </h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="p-1 text-neutral-400 hover:text-black cursor-pointer"
                aria-label="Close guide"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-neutral-700 font-sans leading-relaxed">
              <div className="flex items-start gap-3 p-3 bg-[#f5f4f0] border border-neutral-200">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center font-mono text-xs shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  Tap the <strong>Share</strong> button (the square with an arrow pointing upward) in the Safari bottom menu.
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-[#f5f4f0] border border-neutral-200">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center font-mono text-xs shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  Scroll down the share options and tap <strong>Add to Home Screen</strong>.
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-[#f5f4f0] border border-neutral-200">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center font-mono text-xs shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  Tap <strong>Add</strong> in the top-right corner to place the app on your home screen.
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="w-full bg-black text-white text-xs font-mono uppercase tracking-wider py-2.5 hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Desktop Browser Installation Guide Modal (for browsers without direct prompt event) */}
      {showDesktopGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm bg-white border border-neutral-300 p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white p-1 rounded-xs border border-neutral-300 flex items-center justify-center shrink-0 overflow-hidden">
                  <img src={faviconSrc} alt="Favicon" className="w-full h-full object-contain" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
                    Desktop Browser
                  </span>
                  <h3 className="font-serif text-xl text-neutral-900">
                    Install on PC / Mac
                  </h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowDesktopGuide(false)}
                className="p-1 text-neutral-400 hover:text-black cursor-pointer"
                aria-label="Close guide"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-neutral-700 font-sans leading-relaxed">
              <div className="flex items-start gap-3 p-3 bg-[#f5f4f0] border border-neutral-200">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center font-mono text-xs shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  Look at the right side of your browser address bar for the <strong>Install</strong> or <strong>Computer/Download icon (⊕ or ⭳)</strong>.
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-[#f5f4f0] border border-neutral-200">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center font-mono text-xs shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  Or click your browser menu (<strong>⋮</strong> or <strong>⋯</strong> in Chrome/Edge), choose <strong>Save and share</strong> or <strong>Apps</strong> &rarr; <strong>Install Ezistential Connections</strong>.
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowDesktopGuide(false)}
              className="w-full bg-black text-white text-xs font-mono uppercase tracking-wider py-2.5 hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              Understood
            </button>
          </div>
        </div>
      )}
    </>
  );
};
