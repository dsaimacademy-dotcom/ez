import React, { useState } from 'react';
import { CustomerResponse } from '../../types';
import { Camera, Heart, ShoppingBag, X, Check, MapPin, Maximize2, Sparkles } from 'lucide-react';
import { Button } from '../ui/Button';

interface CommunityPhotoGalleryProps {
  responses: CustomerResponse[];
  productId?: string;
  productName?: string;
  onNavigateToProduct?: (productId: string) => void;
  onOpenSubmissionModal?: () => void;
}

export const CommunityPhotoGallery: React.FC<CommunityPhotoGalleryProps> = ({
  responses,
  productId,
  productName,
  onNavigateToProduct,
  onOpenSubmissionModal,
}) => {
  const [selectedPhoto, setSelectedPhoto] = useState<CustomerResponse | null>(null);

  // Filter responses that have photos
  const photoResponses = responses.filter(
    (r) => r.photoUrl && (r.status === 'Approved' || r.permissionGranted)
  );

  if (photoResponses.length === 0) {
    return (
      <div className="bg-neutral-50 border border-neutral-200 p-8 text-center space-y-4">
        <div className="w-12 h-12 mx-auto rounded-full bg-white border border-neutral-200 flex items-center justify-center text-neutral-600">
          <Camera className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h4 className="font-serif text-lg font-bold text-neutral-900">
            Be the First to Share Your On-Body Perspective
          </h4>
          <p className="text-xs text-neutral-600 max-w-md mx-auto font-sans">
            How do you carry this garment into public space? Share an on-body photo and reflection to join our curated Community Archive.
          </p>
        </div>
        {onOpenSubmissionModal && (
          <Button
            onClick={onOpenSubmissionModal}
            variant="outline"
            className="border-black text-black hover:bg-black hover:text-white text-xs font-mono py-2 px-5"
          >
            Submit Your On-Body Photo & Perspective
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono uppercase tracking-widest text-neutral-500">
            <Camera className="w-3.5 h-3.5 text-neutral-800" />
            <span>Curated Community Gallery • Phase 2 UGC</span>
          </div>
          <h3 className="font-serif text-2xl font-bold text-neutral-900">
            {productName ? `On-Body Perspectives for ${productName}` : 'Community On-Body Perspectives'}
          </h3>
        </div>

        {onOpenSubmissionModal && (
          <Button
            onClick={onOpenSubmissionModal}
            variant="outline"
            className="border-black text-black hover:bg-black hover:text-white text-xs font-mono py-2 px-4 shrink-0"
          >
            <Camera className="w-3.5 h-3.5 mr-2" />
            <span>Share Your Photo</span>
          </Button>
        )}
      </div>

      {/* Grid of Community Photos */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {photoResponses.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedPhoto(item)}
            className="group relative aspect-4/5 bg-neutral-900 border border-neutral-200 overflow-hidden cursor-pointer shadow-xs hover:border-black transition-all"
          >
            <img
              src={item.photoUrl}
              alt={item.photoCaption || item.response}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
            />

            {/* Size Badge Overlay */}
            {item.garmentOnBodySize && (
              <span className="absolute top-2.5 left-2.5 bg-black/80 text-white text-[9px] font-mono px-2 py-0.5 border border-neutral-700">
                Size {item.garmentOnBodySize}
              </span>
            )}

            {/* Hover Quote Preview */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-end text-white">
              <p className="text-xs font-serif italic line-clamp-2">"{item.response}"</p>
              <div className="text-[10px] font-mono text-neutral-300 mt-1 flex items-center justify-between">
                <span>— {item.authorName || 'Anonymous'}</span>
                <Maximize2 className="w-3 h-3 text-neutral-300" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* LIGHTBOX MODAL */}
      {selectedPhoto && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white text-neutral-900 border border-neutral-300 w-full max-w-4xl max-h-[90vh] flex flex-col md:flex-row shadow-2xl relative overflow-hidden">
            {/* Close Button */}
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-3 right-3 z-20 bg-black text-white p-1.5 hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Left: High-Res Image */}
            <div className="md:w-1/2 bg-black flex items-center justify-center p-2 relative min-h-[300px]">
              <img
                src={selectedPhoto.photoUrl}
                alt={selectedPhoto.response}
                className="max-h-[75vh] w-full object-contain"
              />
              {selectedPhoto.garmentOnBodySize && (
                <span className="absolute bottom-4 left-4 bg-black/90 text-white text-[10px] font-mono px-2.5 py-1 border border-neutral-700">
                  Worn in Size {selectedPhoto.garmentOnBodySize}
                </span>
              )}
            </div>

            {/* Right: Author Perspective Details */}
            <div className="md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto space-y-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-xs font-mono uppercase tracking-widest text-neutral-500">
                  <Heart className="w-3.5 h-3.5 text-neutral-800" />
                  <span>Human Connection Archive</span>
                </div>

                <div className="space-y-1">
                  <h4 className="font-serif text-xl sm:text-2xl font-bold text-neutral-900 leading-snug italic">
                    "{selectedPhoto.response}"
                  </h4>
                  {selectedPhoto.photoCaption && (
                    <p className="text-xs font-sans text-neutral-600 leading-relaxed border-l-2 border-neutral-300 pl-3">
                      {selectedPhoto.photoCaption}
                    </p>
                  )}
                </div>

                <div className="space-y-1 pt-2 border-t border-neutral-200">
                  <p className="text-xs font-mono font-bold text-neutral-900">
                    {selectedPhoto.authorName || 'Anonymous Contributor'}
                  </p>
                  {selectedPhoto.authorLocation && (
                    <p className="text-[11px] font-mono text-neutral-500 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-neutral-400" />
                      <span>{selectedPhoto.authorLocation}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Garment Buy Link */}
              <div className="pt-4 border-t border-neutral-200 space-y-3">
                {selectedPhoto.productName && (
                  <div className="text-xs font-mono text-neutral-600">
                    Garment: <span className="font-bold text-neutral-900">{selectedPhoto.productName}</span>
                  </div>
                )}

                {selectedPhoto.productId && onNavigateToProduct && (
                  <Button
                    onClick={() => {
                      const pid = selectedPhoto.productId!;
                      setSelectedPhoto(null);
                      onNavigateToProduct(pid);
                    }}
                    variant="primary"
                    className="w-full bg-black text-white hover:bg-neutral-800 text-xs font-mono py-2.5"
                  >
                    <ShoppingBag className="w-3.5 h-3.5 mr-2" />
                    <span>View Garment Details & Order</span>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
