import React from 'react';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, ShieldCheck, Truck, ArrowLeft } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { Button } from '../ui/Button';
import { formatPrice } from '../../lib/utils';

export interface CartPageProps {
  onNavigateToShop: () => void;
  onNavigateToCheckout: () => void;
}

export const CartPage: React.FC<CartPageProps> = ({
  onNavigateToShop,
  onNavigateToCheckout,
}) => {
  const {
    items,
    totalCount,
    subtotal,
    isFreeShipping,
    remainingForFreeShipping,
    freeShippingThreshold,
    shippingEstimate,
    total,
    updateQuantity,
    removeItem,
    clearCart,
  } = useCart();

  const progressPercent = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mx-auto text-neutral-400">
          <ShoppingBag className="w-8 h-8 stroke-[1.2]" />
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl text-neutral-900 tracking-tight">
          Your Bag Is Empty
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 max-w-md mx-auto leading-relaxed">
          You haven’t selected any garments yet. Explore our initial statements exploring difference, distance, and connection.
        </p>
        <div className="pt-2">
          <Button onClick={onNavigateToShop} variant="primary" size="md">
            <span>Explore All Garments</span>
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Page Title & Back */}
      <div className="border-b border-neutral-200 pb-8 mb-10 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <button
            onClick={onNavigateToShop}
            className="text-xs uppercase tracking-wider text-neutral-500 hover:text-black flex items-center gap-1.5 mb-2 cursor-pointer transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Continue Shopping</span>
          </button>
          <h1 className="font-serif text-3xl sm:text-4xl text-neutral-900 tracking-tight">
            Your Bag ({totalCount} {totalCount === 1 ? 'Garment' : 'Garments'})
          </h1>
        </div>

        <button
          onClick={clearCart}
          className="text-xs text-neutral-400 hover:text-red-700 underline underline-offset-4 cursor-pointer self-start sm:self-auto"
        >
          Clear Bag
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
        {/* Left: Items List */}
        <div className="lg:col-span-7 space-y-6">
          {/* Free Shipping Meter */}
          <div className="bg-[#f5f4f0] p-4 border border-neutral-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-neutral-800">
                {isFreeShipping ? (
                  <span className="text-black font-semibold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
                    Complimentary US Standard Shipping Unlocked
                  </span>
                ) : (
                  <span>
                    Add <strong className="text-black">{formatPrice(remainingForFreeShipping)}</strong> more to earn Free US Shipping
                  </span>
                )}
              </span>
              <span className="font-mono text-neutral-500 text-[11px]">{progressPercent}%</span>
            </div>
            <div className="w-full bg-neutral-300 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-black h-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Items Table */}
          <div className="divide-y divide-neutral-200 border-t border-b border-neutral-200">
            {items.map((item) => (
              <div key={item.id} className="py-6 flex gap-6">
                <img
                  src={item.image}
                  alt={item.productName}
                  className="w-24 h-32 object-cover bg-neutral-100 border border-neutral-200 shrink-0"
                />

                <div className="flex-1 flex flex-col justify-between">
                  <div className="space-y-1">
                    <div className="flex justify-between items-start">
                      <h3 className="font-serif text-lg font-medium text-neutral-900">
                        {item.productName}
                      </h3>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-neutral-400 hover:text-black p-1 transition-colors cursor-pointer"
                        title="Remove item"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-4 h-4 stroke-[1.5]" />
                      </button>
                    </div>

                    <div className="text-xs text-neutral-500 space-x-2 flex flex-wrap items-center">
                      {item.wearType && (
                        <>
                          <span className="font-mono text-neutral-700 bg-neutral-100 px-1.5 py-0.5 text-[10px]">{item.wearType}</span>
                          <span>•</span>
                        </>
                      )}
                      <span>Size: <strong className="text-neutral-900">{item.size}</strong></span>
                      <span>•</span>
                      <span>Color: <strong className="text-neutral-900">{item.color}</strong></span>
                    </div>

                    <p className="text-[11px] text-neutral-400 font-mono pt-1">
                      Made on demand with DTF soft pigment
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-4">
                    {/* Quantity Selector */}
                    <div className="flex items-center border border-neutral-300 bg-white">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1.5 hover:bg-neutral-100 text-neutral-600 transition-colors cursor-pointer"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-4 text-xs font-mono font-medium">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1.5 hover:bg-neutral-100 text-neutral-600 transition-colors cursor-pointer"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-right">
                      <span className="font-mono text-sm font-semibold text-neutral-900">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                      {item.quantity > 1 && (
                        <span className="block text-[10px] text-neutral-400 font-mono">
                          {formatPrice(item.price)} each
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-xs text-neutral-500 space-y-2">
            <p>• Orders are produced individually to eliminate waste.</p>
            <p>• Standard production takes 2–4 business days prior to shipping dispatch.</p>
          </div>
        </div>

        {/* Right: Order Summary Card */}
        <div className="lg:col-span-5">
          <div className="bg-[#f5f4f0] border border-neutral-200 p-6 sm:p-8 space-y-6 sticky top-28">
            <h2 className="font-serif text-xl text-neutral-900 border-b border-neutral-200 pb-4">
              Order Summary
            </h2>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between text-neutral-600">
                <span>Garments Subtotal</span>
                <span className="font-mono font-medium text-neutral-900">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Estimated US Shipping</span>
                <span className="font-mono font-medium">
                  {isFreeShipping ? (
                    <span className="text-neutral-900 font-semibold uppercase text-[10px] tracking-wider">Free</span>
                  ) : (
                    formatPrice(shippingEstimate)
                  )}
                </span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Estimated Sales Tax</span>
                <span className="text-[11px] text-neutral-400">Calculated at Checkout</span>
              </div>
              <div className="flex justify-between text-base font-semibold text-neutral-900 pt-3 border-t border-neutral-200">
                <span>Estimated Total</span>
                <span className="font-mono">{formatPrice(total)}</span>
              </div>
            </div>

            <Button
              onClick={onNavigateToCheckout}
              variant="primary"
              size="lg"
              fullWidth
              className="py-4 flex items-center justify-center space-x-2"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>

            <div className="pt-2 space-y-3 text-[11px] text-neutral-500 border-t border-neutral-200">
              <div className="flex items-center space-x-2">
                <Truck className="w-4 h-4 text-neutral-700 shrink-0" />
                <span>US Domestic shipping via USPS Ground Advantage or UPS.</span>
              </div>
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-neutral-700 shrink-0" />
                <span>Encrypted checkout. Cards, Apple Pay, & Google Pay ready.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
