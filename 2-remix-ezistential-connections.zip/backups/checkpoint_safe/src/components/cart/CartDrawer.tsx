import React from 'react';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, ShieldCheck, Truck } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { Drawer } from '../ui/Drawer';
import { Button } from '../ui/Button';
import { formatPrice } from '../../lib/utils';

export interface CartDrawerProps {
  onNavigateToCheckout: () => void;
  onNavigateToShop: () => void;
  onNavigateToCart?: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  onNavigateToCheckout,
  onNavigateToShop,
  onNavigateToCart,
}) => {
  const {
    items,
    isCartOpen,
    closeCart,
    totalCount,
    subtotal,
    isFreeShipping,
    remainingForFreeShipping,
    freeShippingThreshold,
    shippingEstimate,
    total,
    updateQuantity,
    removeItem,
  } = useCart();

  const handleCheckoutClick = () => {
    closeCart();
    onNavigateToCheckout();
  };

  const handleShopClick = () => {
    closeCart();
    onNavigateToShop();
  };

  const handleViewCartClick = () => {
    closeCart();
    if (onNavigateToCart) {
      onNavigateToCart();
    }
  };

  // Calculate percentage of free shipping progress
  const progressPercent = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));

  return (
    <Drawer
      isOpen={isCartOpen}
      onClose={closeCart}
      title="Your Bag"
      subtitle={`${totalCount} ${totalCount === 1 ? 'Garment' : 'Garments'}`}
      widthClass="max-w-md"
    >
      <div className="flex flex-col h-full -mx-6 -my-5">
        {/* Free Shipping Progress Indicator */}
        <div className="bg-[#f5f4f0] px-6 py-3.5 border-b border-neutral-200">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-medium text-neutral-800">
              {isFreeShipping ? (
                <span className="text-black font-semibold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
                  Unlocked Complimentary US Shipping
                </span>
              ) : (
                <span>
                  Add <strong className="text-black">{formatPrice(remainingForFreeShipping)}</strong> for Free US Shipping
                </span>
              )}
            </span>
            <span className="font-mono text-[11px] text-neutral-500">{progressPercent}%</span>
          </div>
          <div className="w-full bg-neutral-300 h-1 rounded-full overflow-hidden">
            <div
              className="bg-black h-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Item List */}
        <div className="flex-1 overflow-y-auto px-6 py-4 divide-y divide-neutral-200">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-16 px-4">
              <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mb-4 text-neutral-400">
                <ShoppingBag className="w-8 h-8 stroke-[1.2]" />
              </div>
              <h3 className="font-serif text-xl tracking-tight text-neutral-900 mb-1">
                Your Bag Is Empty
              </h3>
              <p className="text-xs text-neutral-500 max-w-xs mb-6">
                Explore our garments carrying ideas and questions into public space.
              </p>
              <Button onClick={handleShopClick} variant="outline" size="sm">
                Explore Garments
              </Button>
            </div>
          ) : (
            items.map((item) => (
              <div key={item.id} className="py-4 flex gap-4">
                <img
                  src={item.image}
                  alt={item.productName}
                  className="w-20 h-24 object-cover bg-neutral-100 border border-neutral-200 shrink-0"
                />

                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <h4 className="font-serif text-base font-medium text-neutral-900 leading-tight">
                        {item.productName}
                      </h4>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-neutral-400 hover:text-black p-1 transition-colors"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-4 h-4 stroke-[1.5]" />
                      </button>
                    </div>

                    <div className="text-xs text-neutral-500 mt-1 space-x-1.5 flex flex-wrap items-center">
                      {item.wearType && (
                        <>
                          <span className="font-mono text-neutral-700 bg-neutral-100 px-1 py-0.5 text-[10px]">{item.wearType}</span>
                          <span>•</span>
                        </>
                      )}
                      <span>Size: <strong className="text-neutral-800">{item.size}</strong></span>
                      <span>•</span>
                      <span>Color: <strong className="text-neutral-800">{item.color}</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-3 pt-2">
                    {/* Quantity Selector */}
                    <div className="flex items-center border border-neutral-300">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1 hover:bg-neutral-100 text-neutral-600 transition-colors"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 text-xs font-mono font-medium">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1 hover:bg-neutral-100 text-neutral-600 transition-colors"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <span className="font-mono text-sm font-medium text-neutral-900">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {items.length > 0 && (
          <div className="bg-[#fbfbf9] border-t border-neutral-200 px-6 py-5 space-y-4">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-neutral-600">
                <span>Subtotal</span>
                <span className="font-mono font-medium text-neutral-900">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Estimated US Shipping</span>
                <span className="font-mono font-medium">
                  {isFreeShipping ? (
                    <span className="text-neutral-900 font-semibold uppercase text-[10px] tracking-wider">Free</span>
                  ) : (
                    formatPrice(shippingEstimate)
                  )}
                </span>
              </div>
              <div className="flex justify-between text-sm font-semibold text-neutral-900 pt-2 border-t border-neutral-200">
                <span>Estimated Total</span>
                <span className="font-mono">{formatPrice(total)}</span>
              </div>
            </div>

            {/* Estimated Delivery Date Bar */}
            <div className="bg-[#f7f6f2] border border-neutral-200 p-2.5 rounded-xs flex items-center justify-between text-xs font-mono">
              <span className="text-neutral-600 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-neutral-800" />
                <span>Est. US Delivery:</span>
              </span>
              <span className="text-neutral-900 font-bold">Oct 4 – Oct 7 (USPS)</span>
            </div>

            <Button
              onClick={handleCheckoutClick}
              variant="primary"
              size="lg"
              fullWidth
              className="flex items-center justify-center space-x-2"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>

            {onNavigateToCart && (
              <Button
                onClick={handleViewCartClick}
                variant="outline"
                size="md"
                fullWidth
              >
                View Full Bag Details
              </Button>
            )}

            <div className="flex items-center justify-center space-x-1.5 text-[11px] text-neutral-500 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-neutral-700" />
              <span>Secure checkout. Crafted and finished on demand.</span>
            </div>
          </div>
        )}
      </div>
    </Drawer>
  );
};
