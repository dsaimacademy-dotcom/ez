import React, { useState } from 'react';
import { X, Copy, Check, Share2, ExternalLink } from 'lucide-react';
import { Button } from '../ui/Button';
import { safeSrc } from '../../lib/utils';

export interface SocialShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  statement: string;
  url?: string;
  image?: string;
}

export const SocialShareModal: React.FC<SocialShareModalProps> = ({
  isOpen,
  onClose,
  title,
  statement,
  url,
  image,
}) => {
  const [copied, setCopied] = useState(false);
  const shareUrl = url || (typeof window !== 'undefined' ? window.location.href : 'https://ezistential.com');
  const shareImage = safeSrc(image, 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85');

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard?.writeText(`${statement} · ${shareUrl}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Social Intent URLs
  const twitterIntent = `https://twitter.com/intent/tweet?text=${encodeURIComponent(`"${statement}" / @ezistential`)}&url=${encodeURIComponent(shareUrl)}`;
  const threadsIntent = `https://www.threads.net/intent/post?text=${encodeURIComponent(`"${statement}" ${shareUrl}`)}`;
  const linkedInIntent = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
  const facebookIntent = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-lg bg-white border border-neutral-300 p-6 sm:p-8 space-y-6 shadow-2xl z-10 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
          <div className="flex items-center space-x-2">
            <Share2 className="w-4 h-4 text-neutral-800" />
            <h3 className="font-serif text-xl sm:text-2xl text-neutral-900 tracking-tight">
              Share Inquiry
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-black cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Social Card Preview */}
        <div className="space-y-2">
          <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
            Social Card Preview (OpenGraph / X Card)
          </span>
          <div className="border border-neutral-200 rounded-xs overflow-hidden bg-neutral-50 shadow-xs">
            <div className="aspect-16/9 bg-neutral-200 overflow-hidden relative">
              <img
                src={shareImage}
                alt={title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2 bg-black/80 text-white text-[9px] font-mono uppercase px-2 py-0.5 tracking-wider">
                Ezistential Connections
              </div>
            </div>
            <div className="p-3.5 space-y-1 bg-white border-t border-neutral-200">
              <div className="text-[10px] uppercase font-mono text-neutral-400 tracking-wider">
                ezistential.com
              </div>
              <div className="font-serif text-sm font-medium text-neutral-900 leading-snug">
                {title}
              </div>
              <p className="text-xs text-neutral-600 font-sans line-clamp-2 leading-relaxed">
                "{statement}"
              </p>
            </div>
          </div>
        </div>

        {/* Action Sharing Buttons */}
        <div className="space-y-3">
          <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
            Share Directly to Channels
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <a
              href={twitterIntent}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 border border-neutral-300 py-2.5 px-3 bg-white hover:bg-neutral-50 hover:border-black transition-colors font-medium text-neutral-900"
            >
              <span>X / Twitter</span>
              <ExternalLink className="w-3 h-3 text-neutral-400" />
            </a>

            <a
              href={threadsIntent}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 border border-neutral-300 py-2.5 px-3 bg-white hover:bg-neutral-50 hover:border-black transition-colors font-medium text-neutral-900"
            >
              <span>Threads</span>
              <ExternalLink className="w-3 h-3 text-neutral-400" />
            </a>

            <a
              href={linkedInIntent}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 border border-neutral-300 py-2.5 px-3 bg-white hover:bg-neutral-50 hover:border-black transition-colors font-medium text-neutral-900"
            >
              <span>LinkedIn</span>
              <ExternalLink className="w-3 h-3 text-neutral-400" />
            </a>

            <a
              href={facebookIntent}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 border border-neutral-300 py-2.5 px-3 bg-white hover:bg-neutral-50 hover:border-black transition-colors font-medium text-neutral-900"
            >
              <span>Facebook</span>
              <ExternalLink className="w-3 h-3 text-neutral-400" />
            </a>
          </div>
        </div>

        {/* Copy Link Section */}
        <div className="pt-2 border-t border-neutral-200">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="w-full bg-[#fbfbf9] border border-neutral-300 px-3 py-2 text-xs text-neutral-700 font-mono focus:outline-hidden"
            />
            <Button onClick={handleCopy} variant="primary" size="sm">
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 mr-1 text-emerald-300" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 mr-1" />
                  <span>Copy Link</span>
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
