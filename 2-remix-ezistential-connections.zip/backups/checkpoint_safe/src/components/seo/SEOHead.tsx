import React, { useEffect } from 'react';
import { Product, FAQItem } from '../../types';

export interface SEOHeadProps {
  currentView: string;
  product?: Product;
  faqs?: FAQItem[];
  siteHeadline?: string;
  siteSubheadline?: string;
}

export const SEOHead: React.FC<SEOHeadProps> = ({
  currentView,
  product,
  faqs,
  siteHeadline,
  siteSubheadline,
}) => {
  useEffect(() => {
    // 1. Determine title, description, image, and canonical based on view
    let title = 'Ezistential Connections | The Space Between Us';
    let description =
      siteSubheadline ||
      'Brand-led apparel exploring the space between people, human connection, identity, and difference. 6.5oz heavyweight cotton finished on demand in the USA.';
    let image = 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1200&q=85';
    let ogType = 'website';
    const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ezistential.com';
    let canonicalUrl = `${baseUrl}/${currentView === 'home' ? '' : currentView}`;

    if (currentView === 'product' && product) {
      title = `${product.name} | Ezistential Connections`;
      description = `"${product.tagline}". Heavyweight 6.5oz combed cotton with direct-to-film discharge print. Ethical on-demand production.`;
      image = product.primaryImage;
      canonicalUrl = `${baseUrl}/product/${product.slug}`;
      ogType = 'product';
    } else if (currentView === 'shop') {
      title = 'Garment Catalog | Ezistential Connections';
      description = 'Explore on-demand heavyweight combed cotton apparel carrying quiet questions into public space.';
      canonicalUrl = `${baseUrl}/shop`;
    } else if (currentView === 'collections') {
      title = 'Series Collections | Ezistential Connections';
      description = 'Core Concepts and Dialogue Series garments exploring human proximity and authentic dialogue.';
      canonicalUrl = `${baseUrl}/collections`;
    } else if (currentView === 'why-we-exist') {
      title = 'Why We Exist | Ezistential Connections';
      description = 'Distance can become disconnection. Difference can become separation. We exist in the space between people.';
      canonicalUrl = `${baseUrl}/why-we-exist`;
    } else if (currentView === 'our-story') {
      title = 'Our Story | Ezistential Connections';
      description = 'From reflections on election night in November 2008 to ideas walking through the world on clothing.';
      canonicalUrl = `${baseUrl}/our-story`;
    } else if (currentView === 'manifesto') {
      title = 'The Brand Manifesto | Ezistential Connections';
      description = 'We believe in the space between us. Difference is not a defect; it is where consciousness awakens.';
      canonicalUrl = `${baseUrl}/manifesto`;
    } else if (currentView === 'connection') {
      title = 'What Does This Mean to You? | Human Reflection Archive';
      description = 'Curated public reflections and observations on distance, connection, and human encounters.';
      canonicalUrl = `${baseUrl}/connection`;
    } else if (currentView === 'faq') {
      title = 'Frequently Asked Questions | Ezistential Connections';
      description = 'Honest answers regarding heavyweight 6.5oz ring-spun cotton, Apliiq DTF production, sizing, and shipping.';
      canonicalUrl = `${baseUrl}/faq`;
    } else if (currentView === 'shipping-returns') {
      title = 'Shipping, Production & Returns Policy | Ezistential Connections';
      description = 'Transparent on-demand production (2-4 days), USPS Ground domestic transit (3-5 days), and our 30-day quality guarantee.';
      canonicalUrl = `${baseUrl}/shipping-returns`;
    } else if (currentView === 'privacy') {
      title = 'Privacy Policy & Digital Dignity | Ezistential Connections';
      description = 'We reject surveillance ad networks. Zero data selling, minimal operational sharing, and private reflections.';
      canonicalUrl = `${baseUrl}/privacy`;
    } else if (currentView === 'terms') {
      title = 'Terms of Service & Covenant | Ezistential Connections';
      description = 'Made-to-order manufacturing terms, trademark intellectual property protections, and community guidelines.';
      canonicalUrl = `${baseUrl}/terms`;
    } else if (currentView === 'track-order') {
      title = 'Track Your Order | Ezistential Connections';
      description = 'Look up live on-demand production and USPS domestic tracking status for your order.';
      canonicalUrl = `${baseUrl}/track-order`;
    } else if (currentView === 'account') {
      title = 'Member Dashboard | Ezistential Connections';
      description = 'View order history, live Apliiq manufacturing tracking, saved garments, and submitted reflections.';
      canonicalUrl = `${baseUrl}/account`;
    } else if (currentView === 'admin') {
      title = 'Operations Engine | Ezistential Connections';
      description = 'Internal operational management cockpit.';
    }

    // 2. Update Document Title
    document.title = title;

    // 3. Helper to update or create meta tag
    const setMeta = (nameAttr: string, key: string, contentVal: string) => {
      let meta = document.querySelector(`meta[${nameAttr}="${key}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(nameAttr, key);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', contentVal);
    };

    setMeta('name', 'description', description);
    setMeta('property', 'og:title', title);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:image', image);
    setMeta('property', 'og:url', canonicalUrl);
    setMeta('property', 'og:type', ogType);
    setMeta('property', 'og:site_name', 'Ezistential Connections');
    setMeta('name', 'twitter:card', 'summary_large_image');
    setMeta('name', 'twitter:title', title);
    setMeta('name', 'twitter:description', description);
    setMeta('name', 'twitter:image', image);

    // 4. Update or create canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', canonicalUrl);

    // 5. Build Schema.org Structured Data (JSON-LD)
    let jsonLdData: any = null;

    if (currentView === 'product' && product) {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'Product',
        name: product.name,
        image: [product.primaryImage, ...product.galleryImages.map((g) => g.url)],
        description: product.storyA.thesis,
        sku: product.id,
        brand: {
          '@type': 'Brand',
          name: 'Ezistential Connections',
          logo: `${baseUrl}/ez-logo.svg`,
        },
        offers: {
          '@type': 'Offer',
          url: canonicalUrl,
          priceCurrency: 'USD',
          price: product.price,
          itemCondition: 'https://schema.org/NewCondition',
          availability: product.isAvailable
            ? 'https://schema.org/InStock'
            : 'https://schema.org/OutOfStock',
          seller: {
            '@type': 'Organization',
            name: 'Ezistential Connections',
          },
        },
      };
    } else if (currentView === 'faq' && faqs && faqs.length > 0) {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqs.map((f) => ({
          '@type': 'Question',
          name: f.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: f.answer,
          },
        })),
      };
    } else {
      jsonLdData = {
        '@context': 'https://schema.org',
        '@type': 'ClothingStore',
        name: 'Ezistential Connections',
        description:
          'Brand-led apparel exploring the space between people, human connection, identity, and difference.',
        url: baseUrl,
        logo: `${baseUrl}/ez-logo.svg`,
        slogan: 'We are not the same. That’s the point.',
        foundingDate: '2008-11-04',
        currenciesAccepted: 'USD',
        paymentAccepted: 'Credit Card, Apple Pay, Google Pay',
        priceRange: '$$',
        address: {
          '@type': 'PostalAddress',
          addressCountry: 'US',
        },
      };
    }

    let scriptTag = document.getElementById('schema-org-jsonld') as HTMLScriptElement | null;
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = 'schema-org-jsonld';
      scriptTag.type = 'application/ld+json';
      document.head.appendChild(scriptTag);
    }
    scriptTag.textContent = JSON.stringify(jsonLdData, null, 2);
  }, [currentView, product, faqs, siteHeadline, siteSubheadline]);

  return null;
};
