import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
  Sparkles,
  Sliders,
  Check
} from 'lucide-react';
import { useContent } from '../../context/ContentContext';
import { Button } from '../ui/Button';
import { safeSrc } from '../../lib/utils';
import { ShapeDivider } from '../ui/ShapeDivider';
import { DEFAULT_HERO_SLIDES } from '../../data/heroSlides';
import { HeroSlide } from '../../types';

export interface EditorialHeroProps {
  onNavigate: (view: string, param?: string) => void;
}

export { DEFAULT_HERO_SLIDES as HERO_SLIDES };

const AUTOPLAY_INTERVAL_MS = 7500;

export const EditorialHero: React.FC<EditorialHeroProps> = ({ onNavigate }) => {
  const { content } = useContent();
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [progress, setProgress] = useState(0);

  const rawSlides = content.heroSlides && content.heroSlides.length > 0 ? content.heroSlides : DEFAULT_HERO_SLIDES;
  const availableSlides = rawSlides.filter((s) => s.active !== false);
  const slides = availableSlides.length > 0 ? availableSlides : DEFAULT_HERO_SLIDES;

  const isStaticMode = content.heroMode === 'static';
  const activeIndex = Math.min(currentSlideIndex, slides.length - 1);
  const activeSlide = slides[activeIndex] || DEFAULT_HERO_SLIDES[0];

  const currentHeadline = activeSlide.headline;
  const currentSubheadline = activeSlide.subheadline;
  const currentTagline = activeSlide.tagline;
  const currentChapterNum = activeSlide.chapterNumber;
  const currentChapterLabel = activeSlide.chapterLabel;
  const currentButtonText = activeSlide.primaryCtaText;
  const currentButtonTarget = activeSlide.primaryCtaTarget;
  const currentSecondaryText = activeSlide.secondaryCtaText || 'Why We Exist';
  const currentSecondaryTarget = activeSlide.secondaryCtaTarget || 'why-we-exist';
  const showSecondary = activeSlide.showSecondaryCta !== false && content.heroShowSecondaryButton !== false;

  const overlayBaseColor = activeSlide.overlayColor || content.heroOverlayColor || '#0a0a0a';
  const overlayOpacity = typeof activeSlide.overlayOpacity === 'number'
    ? activeSlide.overlayOpacity
    : (typeof content.heroImageOverlayOpacity === 'number' ? content.heroImageOverlayOpacity : 0.55);

  const activeMood = activeSlide.colorMood || content.heroColorMood || 'golden-amber';
  const autoplaySpeed = content.heroAutoplayIntervalMs || AUTOPLAY_INTERVAL_MS;

  // Next / Prev slide handlers
  const goToNextSlide = useCallback(() => {
    if (isStaticMode || slides.length <= 1) return;
    setCurrentSlideIndex((prev) => (prev + 1) % slides.length);
    setProgress(0);
  }, [isStaticMode, slides.length]);

  const goToPrevSlide = useCallback(() => {
    if (isStaticMode || slides.length <= 1) return;
    setCurrentSlideIndex((prev) => (prev - 1 + slides.length) % slides.length);
    setProgress(0);
  }, [isStaticMode, slides.length]);

  const goToSlide = (index: number) => {
    if (isStaticMode) return;
    setCurrentSlideIndex(index % slides.length);
    setProgress(0);
  };

  // Autoplay timer with progress bar
  useEffect(() => {
    if (isPaused || isStaticMode) return;

    const intervalTime = 50; // update progress every 50ms
    const stepIncrement = (intervalTime / autoplaySpeed) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          goToNextSlide();
          return 0;
        }
        return prev + stepIncrement;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isPaused, isStaticMode, autoplaySpeed, goToNextSlide]);

  // Touch gesture swipe handling
  const handleTouchStart = (e: React.TouchEvent) => {
    if (isStaticMode) return;
    setTouchStartX(e.touches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (isStaticMode || touchStartX === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX - touchEndX;

    if (diff > 50) {
      goToNextSlide();
    } else if (diff < -50) {
      goToPrevSlide();
    }
    setTouchStartX(null);
  };

  // Mood color schemes for dynamic glowing light blooms
  const getMoodBlooms = (mood: HeroSlide['colorMood'] | string) => {
    switch (mood) {
      case 'noir-black':
        return {
          bloomLeft: 'rgba(255, 255, 255, 0.05)',
          bloomCenter: 'rgba(212, 212, 212, 0.08)',
          bloomRight: 'rgba(255, 255, 255, 0.04)',
          dotColor: 'bg-neutral-300',
          badgeBorder: 'border-white/20 bg-black/60 text-neutral-200',
        };
      case 'emerald-moss':
        return {
          bloomLeft: 'rgba(16, 185, 129, 0.28)',
          bloomCenter: 'rgba(5, 150, 105, 0.22)',
          bloomRight: 'rgba(52, 211, 153, 0.18)',
          dotColor: 'bg-emerald-400',
          badgeBorder: 'border-emerald-500/40 bg-emerald-950/40 text-emerald-200',
        };
      case 'terracotta-sunset':
        return {
          bloomLeft: 'rgba(234, 88, 12, 0.30)',   // Terracotta
          bloomCenter: 'rgba(225, 29, 72, 0.22)', // Sunset rose
          bloomRight: 'rgba(168, 85, 247, 0.22)', // Twilight violet
          dotColor: 'bg-orange-400',
          badgeBorder: 'border-orange-500/40 bg-orange-950/40 text-orange-200',
        };
      case 'twilight-indigo':
        return {
          bloomLeft: 'rgba(59, 130, 246, 0.28)',  // Deep indigo
          bloomCenter: 'rgba(99, 102, 241, 0.24)', // Cobalt
          bloomRight: 'rgba(168, 85, 247, 0.22)', // Violet amethyst
          dotColor: 'bg-indigo-400',
          badgeBorder: 'border-indigo-500/40 bg-indigo-950/40 text-indigo-200',
        };
      case 'golden-amber':
      default:
        return {
          bloomLeft: 'rgba(245, 158, 11, 0.32)',  // Golden amber
          bloomCenter: 'rgba(234, 88, 12, 0.24)', // Warm terracotta
          bloomRight: 'rgba(79, 70, 229, 0.18)',  // Dusky cobalt accent
          dotColor: 'bg-amber-400',
          badgeBorder: 'border-amber-500/40 bg-amber-950/40 text-amber-200',
        };
    }
  };

  const moodStyles = getMoodBlooms(activeMood);

  // Gradient style rendering
  const renderGradientOverlay = () => {
    switch (content.heroGradientStyle) {
      case 'cinematic':
        return <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/95 via-black/40 to-transparent pointer-events-none" />;
      case 'minimal':
        return <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/50 via-transparent to-transparent pointer-events-none" />;
      case 'none':
        return null;
      case 'soft':
      default:
        return <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/80 via-black/15 to-transparent pointer-events-none" />;
    }
  };

  return (
    <section
      aria-label="Opening Editorial Hero Carousel"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="relative bg-[#0a0a0a] text-[#fbfbf9] pt-20 pb-28 sm:pt-36 sm:pb-36 px-4 sm:px-6 lg:px-8 overflow-hidden min-h-[580px] sm:min-h-[720px] flex items-center justify-center select-none"
    >
      {/* 1. Cinematic Background Layer with Smooth Crossfade */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {slides.map((slide, index) => {
          const isCurrent = index === activeIndex;
          const slideOverlayColor = slide.overlayColor || overlayBaseColor;
          const slideOverlayOpacity = typeof slide.overlayOpacity === 'number' ? slide.overlayOpacity : overlayOpacity;

          return (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                isCurrent ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
              }`}
            >
              <img
                src={safeSrc(slide.imageUrl, DEFAULT_HERO_SLIDES[0].imageUrl)}
                alt={slide.chapterLabel}
                className={`w-full h-full object-cover object-center transform transition-transform duration-10000 ease-linear ${
                  isCurrent ? 'scale-105' : 'scale-100'
                }`}
              />

              {/* Scrim Overlay */}
              <div
                className="absolute inset-0 transition-colors duration-500"
                style={{
                  backgroundColor: slideOverlayColor,
                  opacity: slideOverlayOpacity,
                }}
              />
            </div>
          );
        })}

        {/* 2. Layered Ambient Color Blooms (Radiates Warmth & Color Behind Active Slide) */}
        {content.heroEnableColorBlooms !== false && (
          <>
            <div
              className="absolute -top-24 -left-24 w-[480px] sm:w-[700px] h-[480px] sm:h-[700px] rounded-full blur-3xl pointer-events-none transition-all duration-1000"
              style={{ backgroundColor: moodStyles.bloomLeft }}
            />
            <div
              className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[400px] sm:w-[620px] h-[350px] sm:h-[460px] rounded-full blur-3xl pointer-events-none transition-all duration-1000"
              style={{ backgroundColor: moodStyles.bloomCenter }}
            />
            <div
              className="absolute -bottom-20 -right-20 w-[420px] sm:w-[650px] h-[420px] sm:h-[650px] rounded-full blur-3xl pointer-events-none transition-all duration-1000"
              style={{ backgroundColor: moodStyles.bloomRight }}
            />
          </>
        )}

        {/* Top gradient for navbar legibility without forcing a black bar at the bottom */}
        {renderGradientOverlay()}

        {/* Film grain vignette */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-transparent to-black/60 pointer-events-none" />
      </div>

      {/* Top Slide Timing Progress Bar (Only in Carousel Mode) */}
      {!isStaticMode && (
        <div className="absolute top-0 inset-x-0 h-1 bg-white/10 z-30 overflow-hidden">
          <div
            className="h-full bg-white transition-all duration-75 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* 3. Main Editorial Content Container */}
      <div className="max-w-5xl mx-auto text-center space-y-4 sm:space-y-7 relative z-20 py-2 sm:py-6 px-1 sm:px-4">
        {/* Floating Chapter Tagline Pill with Glassmorphism - Responsive single line */}
        <div className="inline-flex items-center space-x-2 px-3 py-1 sm:px-4 sm:py-1.5 backdrop-blur-md border border-white/20 bg-black/40 rounded-full text-[10px] sm:text-xs font-mono uppercase tracking-wider shadow-xl transition-all duration-300 max-w-[94vw] overflow-hidden whitespace-nowrap">
          <span className={`w-1.5 h-1.5 sm:w-2 sm:h-2 shrink-0 rounded-full ${moodStyles.dotColor} animate-pulse`} />
          <span className="text-white font-bold shrink-0">
            {currentChapterNum}
          </span>
          <span className="text-white/40 shrink-0">/</span>
          <span className="text-neutral-200 font-medium truncate">
            {currentChapterLabel}
          </span>
          <span className="text-white/30 hidden md:inline shrink-0">·</span>
          <span className="text-neutral-300 font-normal hidden md:inline truncate max-w-sm">
            {currentTagline}
          </span>
        </div>

        {/* Main Hero Headline with Smooth Key Transition */}
        <h1
          key={`headline-${currentSlideIndex}`}
          className="font-serif text-2xl sm:text-4xl md:text-5xl lg:text-[68px] font-normal tracking-tight text-white max-w-4xl mx-auto leading-[1.14] sm:leading-[1.08] drop-shadow-md text-balance animate-in fade-in slide-in-from-bottom-2 duration-500"
        >
          {currentHeadline}
        </h1>

        {/* Subheadline Description */}
        <p
          key={`subheadline-${currentSlideIndex}`}
          className="text-xs sm:text-base md:text-lg text-neutral-200/90 max-w-2xl mx-auto font-sans leading-relaxed font-light drop-shadow-sm text-balance animate-in fade-in slide-in-from-bottom-2 duration-500 line-clamp-3 sm:line-clamp-none px-2 sm:px-0"
        >
          {currentSubheadline}
        </p>

        {/* Dual Call-to-Action Buttons */}
        <div className="pt-1 sm:pt-4 flex flex-col sm:flex-row items-center justify-center gap-2.5 sm:gap-4 w-full max-w-xs sm:max-w-none mx-auto">
          <Button
            onClick={() => onNavigate(currentButtonTarget)}
            variant="secondary"
            size="md"
            className="w-full sm:w-auto bg-white text-black hover:bg-neutral-200 border-transparent shadow-xl font-mono text-[11px] sm:text-xs uppercase tracking-wider group cursor-pointer py-2.5 sm:py-3 px-5 sm:px-6"
          >
            <span>{currentButtonText}</span>
            <ArrowRight className="w-3.5 h-3.5 ml-1.5 group-hover:translate-x-1 transition-transform" />
          </Button>

          {showSecondary && (
            <Button
              onClick={() => onNavigate(currentSecondaryTarget)}
              variant="outline"
              size="md"
              className="w-full sm:w-auto border-white/30 text-white hover:bg-white/10 hover:border-white backdrop-blur-xs font-mono text-[11px] sm:text-xs uppercase tracking-wider cursor-pointer py-2.5 sm:py-3 px-5 sm:px-6"
            >
              {currentSecondaryText}
            </Button>
          )}
        </div>
      </div>

      {/* 4. Left & Right Navigation Arrows (Only in Carousel Mode) */}
      {!isStaticMode && (
        <>
          <button
            type="button"
            onClick={goToPrevSlide}
            aria-label="Previous editorial slide"
            className="hidden md:flex absolute left-4 lg:left-8 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/40 hover:bg-black/80 backdrop-blur-md border border-white/20 hover:border-white/50 text-white items-center justify-center transition-all duration-200 z-30 cursor-pointer shadow-lg hover:scale-105"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={goToNextSlide}
            aria-label="Next editorial slide"
            className="hidden md:flex absolute right-4 lg:right-8 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/40 hover:bg-black/80 backdrop-blur-md border border-white/20 hover:border-white/50 text-white items-center justify-center transition-all duration-200 z-30 cursor-pointer shadow-lg hover:scale-105"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {/* 5. Bottom Navigation & Chapter Markers Bar (Floating above the shape divider, Carousel Mode Only) */}
      {!isStaticMode && (
        <div className="absolute bottom-14 sm:bottom-20 inset-x-0 z-30 px-3 sm:px-8 flex items-center justify-between pointer-events-none">
        {/* Left: Play / Pause & Slide Count */}
        <div className="flex items-center space-x-2 sm:space-x-3 pointer-events-auto">
          <button
            type="button"
            onClick={() => setIsPaused(!isPaused)}
            aria-label={isPaused ? 'Resume hero carousel autoplay' : 'Pause hero carousel autoplay'}
            className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-black/60 backdrop-blur-md border border-white/20 hover:border-white text-neutral-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            title={isPaused ? 'Play Autoplay' : 'Pause Autoplay'}
          >
            {isPaused ? <Play className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-white" /> : <Pause className="w-2.5 h-2.5 sm:w-3 sm:h-3" />}
          </button>

          <span className="text-[10px] sm:text-[11px] font-mono text-neutral-400 tracking-wider">
            <span className="text-white font-bold">{activeSlide.chapterNumber}</span> /{' '}
            {slides.length.toString().padStart(2, '0')}
          </span>
        </div>

        {/* Center: Slide Chapter Pills (Interactive) */}
        <div className="flex items-center space-x-1 sm:space-x-2 pointer-events-auto bg-black/60 backdrop-blur-md border border-white/10 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full">
          {slides.map((slide, idx) => {
            const isActive = idx === activeIndex;
            return (
              <button
                key={slide.id}
                type="button"
                onClick={() => goToSlide(idx)}
                aria-label={`Go to slide ${slide.chapterNumber}: ${slide.chapterLabel}`}
                className={`group flex items-center space-x-1.5 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-full transition-all cursor-pointer ${
                  isActive
                    ? 'bg-white/20 text-white font-semibold'
                    : 'text-neutral-400 hover:text-white hover:bg-white/10'
                }`}
              >
                <span
                  className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full inline-block transition-transform group-hover:scale-125"
                  style={{
                    backgroundColor: isActive ? (slide.accentHex || '#ffffff') : '#737373',
                  }}
                />
                <span className="text-[10px] font-mono hidden md:inline uppercase tracking-wider">
                  {slide.chapterLabel}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right: Quick Mobile Arrows */}
        <div className="flex md:hidden items-center space-x-1.5 pointer-events-auto">
          <button
            type="button"
            onClick={goToPrevSlide}
            aria-label="Previous slide"
            className="w-6 h-6 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white flex items-center justify-center cursor-pointer active:scale-95"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={goToNextSlide}
            aria-label="Next slide"
            className="w-6 h-6 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white flex items-center justify-center cursor-pointer active:scale-95"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
      )}

      {/* 6. Seamless Bottom Shape Divider: Directly overlays the background image into #f5f4f0 with zero black gap */}
      {content.shapeDividerEnabled !== false && (
        <div className="absolute bottom-0 inset-x-0 z-20 overflow-hidden leading-none pointer-events-none -mb-px">
          <ShapeDivider
            variant={content.shapeDividerVariant || 'zebra-contour'}
            fillColor="#f5f4f0"
            bgColor="transparent"
            height={content.shapeDividerHeight || 56}
            position="bottom"
            className="w-full block"
          />
        </div>
      )}
    </section>
  );
};
