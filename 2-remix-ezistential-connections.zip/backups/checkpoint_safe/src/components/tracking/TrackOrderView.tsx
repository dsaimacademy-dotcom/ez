import React, { useState, useEffect } from 'react';
import { Search, Package, Truck, CheckCircle2, Clock, AlertCircle, ExternalLink, ArrowRight } from 'lucide-react';
import { useOrders } from '../../context/OrderContext';
import { Order } from '../../types';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { formatPrice } from '../../lib/utils';

export interface TrackOrderViewProps {
  initialOrderNumber?: string;
  initialEmail?: string;
  onExploreGarments: () => void;
}

export const TrackOrderView: React.FC<TrackOrderViewProps> = ({
  initialOrderNumber = '',
  initialEmail = '',
  onExploreGarments,
}) => {
  const { lookupOrder } = useOrders();

  const [orderNumber, setOrderNumber] = useState(initialOrderNumber);
  const [email, setEmail] = useState(initialEmail);
  const [foundOrder, setFoundOrder] = useState<Order | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Auto-search if initial props provided
  useEffect(() => {
    if (initialOrderNumber && initialEmail) {
      const match = lookupOrder(initialOrderNumber, initialEmail);
      if (match) {
        setFoundOrder(match);
        setHasSearched(true);
      }
    }
  }, [initialOrderNumber, initialEmail]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError(null);
    setHasSearched(true);

    if (!orderNumber.trim()) {
      setSearchError('Please provide an order number.');
      return;
    }

    const res = lookupOrder(orderNumber, email);
    if (res) {
      setFoundOrder(res);
      setSearchError(null);
    } else {
      setFoundOrder(null);
      setSearchError(
        `No order matched "${orderNumber.trim().toUpperCase()}" with email "${email.trim()}". Please verify your order number and email address.`
      );
    }
  };

  // Timeline steps
  const getTimelineSteps = (status: string) => {
    const isPaid = ['Paid', 'Processing', 'Submitted to POD', 'In Production', 'Shipped', 'Delivered'].includes(status);
    const isProduction = ['Submitted to POD', 'In Production', 'Shipped', 'Delivered'].includes(status);
    const isShipped = ['Shipped', 'Delivered'].includes(status);
    const isDelivered = status === 'Delivered';

    return [
      { label: 'Order Confirmed', completed: isPaid, date: 'Day 1' },
      { label: 'On-Demand Production (Apliiq)', completed: isProduction, date: 'Days 2–4' },
      { label: 'Carrier Handover (USPS)', completed: isShipped, date: 'Days 4–5' },
      { label: 'Delivered to Door', completed: isDelivered, date: 'Days 5–8' },
    ];
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 space-y-12">
      {/* Title */}
      <div className="text-center space-y-3 border-b border-neutral-200 pb-8">
        <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-medium">
          Customer Self-Service
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl text-neutral-900 tracking-tight">
          Track Your Garment Dispatch
        </h1>
        <p className="text-xs sm:text-sm text-neutral-600 max-w-lg mx-auto leading-relaxed">
          Monitor your order from individual on-demand printing to carrier delivery via USPS Ground Advantage.
        </p>
      </div>

      {/* Lookup Form */}
      <div className="bg-white border border-neutral-200 p-6 sm:p-8 shadow-xs">
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                Order Number <span className="text-neutral-400">*</span>
              </label>
              <input
                type="text"
                required
                value={orderNumber}
                onChange={(e) => setOrderNumber(e.target.value)}
                placeholder="e.g. EC-7K9A-3M2"
                className="w-full border border-neutral-300 p-2.5 text-xs font-mono uppercase focus:outline-hidden focus:border-black font-medium"
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-700 font-medium mb-1">
                Email Address <span className="text-neutral-400">*</span>
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. marcus@example.com"
                className="w-full border border-neutral-300 p-2.5 text-xs focus:outline-hidden focus:border-black font-sans"
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <Button type="submit" variant="primary" size="md" className="w-full sm:w-auto">
              <span>Track Order Status</span>
              <Search className="w-3.5 h-3.5 ml-2" />
            </Button>
          </div>
        </form>

        {searchError && (
          <div className="mt-4 p-4 bg-neutral-50 border border-neutral-200 text-xs text-neutral-700 flex items-start space-x-2.5 leading-relaxed">
            <AlertCircle className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
            <span>{searchError}</span>
          </div>
        )}
      </div>

      {/* Found Order Card */}
      {foundOrder && (
        <div className="bg-white border border-neutral-300 p-6 sm:p-10 shadow-xs space-y-8 animate-in fade-in duration-300">
          {/* Header Row */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-6">
            <div>
              <span className="text-[10px] uppercase tracking-widest text-neutral-400 font-mono">
                Order Tracking Record
              </span>
              <h2 className="font-mono text-2xl font-bold text-neutral-900 mt-0.5">
                {foundOrder.orderNumber}
              </h2>
              <p className="text-xs text-neutral-500 mt-1">
                Placed on {new Date(foundOrder.createdAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <Badge variant="dark" className="text-xs py-1.5 px-3">
                {foundOrder.status}
              </Badge>
            </div>
          </div>

          {/* Stepper Timeline */}
          <div className="space-y-3">
            <h3 className="text-xs uppercase tracking-widest text-neutral-500 font-medium">
              Fulfillment Journey
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-2">
              {getTimelineSteps(foundOrder.status).map((step, idx) => (
                <div
                  key={idx}
                  className={`p-4 border transition-all ${
                    step.completed
                      ? 'border-black bg-[#f5f4f0]'
                      : 'border-neutral-200 bg-white opacity-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] uppercase tracking-widest text-neutral-400 font-mono">
                      Step 0{idx + 1}
                    </span>
                    {step.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-black" />
                    ) : (
                      <Clock className="w-4 h-4 text-neutral-400" />
                    )}
                  </div>
                  <p className="text-xs font-semibold text-neutral-900 leading-snug">
                    {step.label}
                  </p>
                  <span className="text-[11px] text-neutral-500 block mt-1 font-mono">
                    {step.date}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Carrier & Tracking Info */}
          <div className="bg-[#f5f4f0] border border-neutral-200 p-5 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <span className="text-neutral-500 uppercase tracking-wider text-[10px] block">Carrier</span>
              <span className="text-neutral-900 font-medium">{foundOrder.carrier || 'USPS Ground Advantage'}</span>
            </div>
            <div>
              <span className="text-neutral-500 uppercase tracking-wider text-[10px] block">Tracking Number</span>
              <span className="text-neutral-900 font-mono font-medium">{foundOrder.trackingNumber || 'Pending Label Creation'}</span>
            </div>
            <div>
              <span className="text-neutral-500 uppercase tracking-wider text-[10px] block">Estimated Delivery</span>
              <span className="text-neutral-900 font-medium">{foundOrder.estimatedDeliveryDate || '3–5 business days'}</span>
            </div>
          </div>

          {/* Items & Shipping Destination */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-neutral-200">
            {/* Garments list */}
            <div className="space-y-3">
              <h4 className="font-serif text-lg text-neutral-900">
                Garments in this Order ({foundOrder.items.reduce((acc, i) => acc + i.quantity, 0)})
              </h4>
              <div className="divide-y divide-neutral-200">
                {foundOrder.items.map((it) => (
                  <div key={it.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <img
                        src={it.image}
                        alt={it.productName}
                        className="w-10 h-12 object-cover border border-neutral-200 bg-neutral-100"
                      />
                      <div>
                        <p className="font-medium text-neutral-900">{it.productName}</p>
                        <p className="text-neutral-500 text-[11px]">
                          {it.size} • {it.color} • Qty {it.quantity}
                        </p>
                      </div>
                    </div>
                    <span className="font-mono text-neutral-900">
                      {formatPrice(it.price * it.quantity)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Destination */}
            <div className="space-y-3">
              <h4 className="font-serif text-lg text-neutral-900">
                Delivery Destination
              </h4>
              <div className="text-xs text-neutral-700 space-y-1 font-sans bg-[#f5f4f0] p-4 border border-neutral-200">
                <p className="font-semibold text-neutral-900">{foundOrder.shippingAddress.fullName}</p>
                <p>{foundOrder.shippingAddress.street}</p>
                {foundOrder.shippingAddress.apartment && <p>{foundOrder.shippingAddress.apartment}</p>}
                <p>
                  {foundOrder.shippingAddress.city}, {foundOrder.shippingAddress.state} {foundOrder.shippingAddress.zipCode}
                </p>
                <p className="text-[10px] text-neutral-500 uppercase tracking-widest pt-1">
                  United States
                </p>
              </div>

              <div className="text-right pt-2">
                <Button onClick={onExploreGarments} variant="outline" size="sm">
                  <span>Explore More Garments</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
