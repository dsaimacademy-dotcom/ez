import React, { useState } from 'react';
import { Check, X, Star, Trash2, Search, MessageSquare, ShieldCheck, Filter, Plus, ArrowRight, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';
import { useResponses } from '../../context/ResponseContext';
import { ModerationStatus } from '../../types';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface ModerationPortalProps {
  onBackToSite: () => void;
}

export const ModerationPortal: React.FC<ModerationPortalProps> = ({ onBackToSite }) => {
  const { responses, updateStatus, toggleFeatured, deleteResponse, submitResponse } = useResponses();

  const [activeTab, setActiveTab] = useState<'All' | ModerationStatus | 'Featured'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProductFilter, setSelectedProductFilter] = useState('All');

  // Counts
  const pendingCount = responses.filter((r) => r.status === 'Pending').length;
  const approvedCount = responses.filter((r) => r.status === 'Approved').length;
  const rejectedCount = responses.filter((r) => r.status === 'Rejected').length;
  const featuredCount = responses.filter((r) => r.status === 'Approved' && r.featuredQuote).length;

  // Filtered List
  const filteredResponses = responses.filter((r) => {
    // Tab filter
    if (activeTab === 'Featured') {
      if (!r.featuredQuote || r.status !== 'Approved') return false;
    } else if (activeTab !== 'All') {
      if (r.status !== activeTab) return false;
    }

    // Product filter
    if (selectedProductFilter !== 'All') {
      if (r.productName !== selectedProductFilter) return false;
    }

    // Text search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchText = r.response.toLowerCase().includes(q);
      const matchAuthor = (r.authorName || '').toLowerCase().includes(q);
      const matchLocation = (r.authorLocation || '').toLowerCase().includes(q);
      const matchProduct = (r.productName || '').toLowerCase().includes(q);
      if (!matchText && !matchAuthor && !matchLocation && !matchProduct) return false;
    }

    return true;
  });

  const handleSimulateSubmission = () => {
    const sampleThoughts = [
      {
        product: 'The Distance Tee',
        author: 'Siddharth M.',
        location: 'Denver, CO',
        text: 'A colleague at work noticed the shirt and asked why distance is man-made. What followed was a 45-minute discussion about how remote work made us more isolated, and how small conscious interactions can reverse it.',
      },
      {
        product: 'The Difference Tee',
        author: 'Amara K.',
        location: 'Atlanta, GA',
        text: 'People often think community requires total consensus. This garment reminds me that real community is forged when we respect the frictions and distinct voices in the room.',
      },
      {
        product: 'The Connection Tee',
        author: 'Julian B.',
        location: 'Portland, OR',
        text: 'The heavy cotton drape feels intentional and grounded. Wearing it in a busy coffee shop, two different people commented on the phrasing before lunchtime.',
      },
    ];

    const pick = sampleThoughts[Math.floor(Math.random() * sampleThoughts.length)];
    submitResponse({
      productName: pick.product,
      authorName: pick.author,
      authorLocation: pick.location,
      email: `${pick.author.toLowerCase().replace(/\s+/g, '.')}@example.com`,
      response: pick.text,
      permissionGranted: true,
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 space-y-10">
      {/* Top Breadcrumb & Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-6">
        <div>
          <button
            onClick={onBackToSite}
            className="text-xs uppercase tracking-wider text-neutral-500 hover:text-black flex items-center gap-1.5 cursor-pointer font-medium mb-1"
          >
            ← Return to Storefront
          </button>
          <h1 className="font-serif text-3xl sm:text-4xl text-neutral-900 tracking-tight">
            Connection Reflection Moderation
          </h1>
          <p className="text-xs text-neutral-500 mt-1">
            Curate human reflections on "What does this mean to you?". Approved submissions publish immediately to public editorial.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={handleSimulateSubmission}
            variant="secondary"
            size="sm"
            className="flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Simulate Incoming Reflection</span>
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-neutral-200 p-5 space-y-1">
          <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-medium">
            Pending Queue
          </span>
          <div className="flex items-center justify-between">
            <span className="font-mono text-2xl font-bold text-neutral-900">{pendingCount}</span>
            {pendingCount > 0 ? (
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" title="Awaiting Review" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            )}
          </div>
          <p className="text-[11px] text-neutral-400">Requires editorial triage</p>
        </div>

        <div className="bg-white border border-neutral-200 p-5 space-y-1">
          <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-medium">
            Approved & Live
          </span>
          <div className="flex items-center justify-between">
            <span className="font-mono text-2xl font-bold text-neutral-900">{approvedCount}</span>
            <CheckCircle2 className="w-4 h-4 text-neutral-400" />
          </div>
          <p className="text-[11px] text-neutral-400">Publicly visible on site</p>
        </div>

        <div className="bg-white border border-neutral-200 p-5 space-y-1">
          <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-medium">
            Featured Quotes
          </span>
          <div className="flex items-center justify-between">
            <span className="font-mono text-2xl font-bold text-neutral-900">{featuredCount}</span>
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
          <p className="text-[11px] text-neutral-400">Hero & Spotlight displays</p>
        </div>

        <div className="bg-white border border-neutral-200 p-5 space-y-1">
          <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-medium">
            Archived / Rejected
          </span>
          <div className="flex items-center justify-between">
            <span className="font-mono text-2xl font-bold text-neutral-900">{rejectedCount}</span>
            <X className="w-4 h-4 text-neutral-400" />
          </div>
          <p className="text-[11px] text-neutral-400">Filtered from public view</p>
        </div>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="space-y-4">
        {/* Tabs */}
        <div className="flex items-center gap-2 border-b border-neutral-200 overflow-x-auto pb-px">
          {[
            { id: 'All', label: 'All Submissions', count: responses.length },
            { id: 'Pending', label: 'Pending Review', count: pendingCount },
            { id: 'Approved', label: 'Approved & Live', count: approvedCount },
            { id: 'Featured', label: 'Featured Quotes', count: featuredCount },
            { id: 'Rejected', label: 'Rejected', count: rejectedCount },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 text-xs uppercase tracking-wider font-medium whitespace-nowrap cursor-pointer transition-all border-b-2 -mb-px ${
                activeTab === tab.id
                  ? 'border-black text-black font-semibold'
                  : 'border-transparent text-neutral-500 hover:text-black'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`ml-2 font-mono text-[10px] px-1.5 py-0.5 rounded-full ${
                activeTab === tab.id ? 'bg-black text-white' : 'bg-neutral-100 text-neutral-600'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Search & Garment Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search reflection text, author name, or location..."
              className="w-full bg-white border border-neutral-300 pl-10 pr-4 py-2 text-xs focus:outline-hidden focus:border-black font-sans"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={selectedProductFilter}
              onChange={(e) => setSelectedProductFilter(e.target.value)}
              className="w-full bg-white border border-neutral-300 py-2 px-3 text-xs focus:outline-hidden focus:border-black font-sans cursor-pointer"
            >
              <option value="All">All Associated Garments</option>
              <option value="The Distance Tee">The Distance Tee</option>
              <option value="The Difference Tee">The Difference Tee</option>
              <option value="The Connection Tee">The Connection Tee</option>
              <option value="The Signature EC Tee">The Signature EC Tee</option>
            </select>
          </div>
        </div>
      </div>

      {/* Submissions List */}
      <div className="space-y-4">
        {filteredResponses.length === 0 ? (
          <div className="bg-white border border-neutral-200 p-12 text-center space-y-3">
            <MessageSquare className="w-10 h-10 text-neutral-300 mx-auto stroke-[1.2]" />
            <h3 className="font-serif text-xl text-neutral-900">No Reflections Found</h3>
            <p className="text-xs text-neutral-500 max-w-sm mx-auto">
              There are no customer reflections matching your current filter criteria.
            </p>
            <Button onClick={handleSimulateSubmission} variant="outline" size="sm">
              Add Sample Reflection
            </Button>
          </div>
        ) : (
          filteredResponses.map((item) => (
            <div
              key={item.id}
              className={`bg-white border transition-all p-6 sm:p-7 space-y-4 ${
                item.status === 'Pending'
                  ? 'border-amber-300 shadow-xs'
                  : item.status === 'Approved'
                  ? 'border-neutral-200'
                  : 'border-neutral-200 opacity-60 bg-neutral-50'
              }`}
            >
              {/* Top metadata row */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-100 pb-3">
                <div className="flex items-center gap-3">
                  {item.status === 'Pending' && (
                    <Badge variant="outline" className="border-amber-500 text-amber-800 bg-amber-50">
                      Pending Review
                    </Badge>
                  )}
                  {item.status === 'Approved' && (
                    <Badge variant="dark">Approved & Live</Badge>
                  )}
                  {item.status === 'Rejected' && (
                    <Badge variant="muted">Archived / Rejected</Badge>
                  )}
                  {item.featuredQuote && item.status === 'Approved' && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 uppercase tracking-wider">
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                      Featured Quote
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-4 text-[11px] text-neutral-500 font-mono">
                  <span>ID: {item.id}</span>
                  <span>•</span>
                  <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                  <span>•</span>
                  <span className={item.permissionGranted ? 'text-emerald-700' : 'text-neutral-400'}>
                    {item.permissionGranted ? 'Permission Granted' : 'Private Only'}
                  </span>
                </div>
              </div>

              {/* Reflection Body */}
              <div className="space-y-2">
                <blockquote className="font-serif italic text-base sm:text-lg text-neutral-900 leading-relaxed pl-4 border-l-2 border-black">
                  "{item.response}"
                </blockquote>
              </div>

              {/* Author & Associated Garment */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2 text-xs text-neutral-600">
                <div className="space-y-0.5">
                  <p className="font-medium text-neutral-900">
                    {item.authorName} · <span className="text-neutral-500">{item.authorLocation}</span>
                  </p>
                  {item.email && (
                    <p className="text-[11px] text-neutral-400 font-mono">
                      Verified Contact: {item.email}
                    </p>
                  )}
                  {item.productName && (
                    <p className="text-[11px] text-neutral-500">
                      Prompted by: <strong className="text-neutral-800">{item.productName}</strong>
                    </p>
                  )}
                </div>

                {/* Editorial Action Buttons */}
                <div className="flex flex-wrap items-center gap-2">
                  {item.status !== 'Approved' && (
                    <Button
                      onClick={() => updateStatus(item.id, 'Approved')}
                      variant="primary"
                      size="sm"
                      className="bg-black hover:bg-neutral-800 text-white flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve for Editorial</span>
                    </Button>
                  )}

                  {item.status === 'Approved' && (
                    <button
                      onClick={() => toggleFeatured(item.id)}
                      className={`px-3 py-1.5 text-[11px] uppercase tracking-wider font-medium border flex items-center gap-1.5 cursor-pointer transition-colors ${
                        item.featuredQuote
                          ? 'bg-amber-100 border-amber-300 text-amber-900 hover:bg-amber-200'
                          : 'bg-white border-neutral-300 text-neutral-700 hover:border-black'
                      }`}
                    >
                      <Star className={`w-3.5 h-3.5 ${item.featuredQuote ? 'fill-amber-600 text-amber-600' : 'text-neutral-500'}`} />
                      <span>{item.featuredQuote ? 'Featured' : 'Feature Quote'}</span>
                    </button>
                  )}

                  {item.status !== 'Rejected' && (
                    <button
                      onClick={() => updateStatus(item.id, 'Rejected')}
                      className="px-3 py-1.5 text-[11px] uppercase tracking-wider font-medium border border-neutral-200 bg-white text-neutral-600 hover:border-neutral-400 hover:text-black cursor-pointer transition-colors"
                    >
                      Archive / Reject
                    </button>
                  )}

                  <button
                    onClick={() => deleteResponse(item.id)}
                    className="p-1.5 text-neutral-400 hover:text-red-700 cursor-pointer transition-colors"
                    title="Delete record"
                    aria-label="Delete response"
                  >
                    <Trash2 className="w-4 h-4 stroke-[1.5]" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
