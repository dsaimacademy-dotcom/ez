import React, { useState, useEffect } from 'react';
import { safeSrc } from '../../lib/utils';
import {
  Package,
  Heart,
  MessageSquare,
  MapPin,
  Settings,
  LogOut,
  Plus,
  ExternalLink,
  Truck,
  CheckCircle2,
  Clock,
  Download,
  ShoppingBag,
  Trash2,
  Edit2,
  ShieldCheck,
  ArrowRight,
  Info,
  Check,
  ChevronRight,
  User as UserIcon,
  LayoutDashboard,
  ArrowLeft,
  FileText,
  Copy,
  Eye,
  Camera,
  Upload,
  Image as ImageIcon,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useOrders } from '../../context/OrderContext';
import { useProducts } from '../../context/ProductContext';
import { useResponses } from '../../context/ResponseContext';
import { useCart } from '../../context/CartContext';
import { useContent } from '../../context/ContentContext';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { ConfirmDeleteModal } from '../modals/ConfirmDeleteModal';
import { ImageUploadCompressor } from '../ui/ImageUploadCompressor';
import { UserAddress, Size } from '../../types';
import { evaluateMemberVerification } from '../../lib/verification';
import { WishlistView } from './WishlistView';

const CURATED_AVATARS = [
  { label: 'Portrait 1', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80' },
  { label: 'Portrait 2', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80' },
  { label: 'Portrait 3', url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80' },
  { label: 'Portrait 4', url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80' },
  { label: 'Portrait 5', url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=300&q=80' },
  { label: 'Portrait 6', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80' },
];

export type AccountTab = 'overview' | 'verification' | 'orders' | 'wishlist' | 'reflections' | 'addresses' | 'settings';

export interface UserDashboardProps {
  currentTab?: AccountTab;
  onTabChange?: (tab: AccountTab) => void;
  onNavigate: (view: string, param?: string) => void;
  onOpenAuth: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  currentTab = 'overview',
  onTabChange,
  onNavigate,
  onOpenAuth,
}) => {
  const {
    user,
    isAuthenticated,
    logout,
    updateProfile,
    addAddress,
    updateAddress,
    deleteAddress,
    setDefaultAddress,
    toggleSavedGarment,
    updateSavedGarment,
    exportUserData,
    deleteAccount,
  } = useAuth();

  const { orders } = useOrders();
  const { products } = useProducts();
  const { responses, submitResponse } = useResponses();
  const { addItem } = useCart();
  const { content } = useContent();

  const [activeTab, setActiveTab] = useState<AccountTab>(currentTab);

  // Sync internal state with prop changes from header dropdown or navigation
  useEffect(() => {
    if (currentTab) {
      setActiveTab(currentTab);
    }
  }, [currentTab]);

  const switchTab = (tab: AccountTab) => {
    setActiveTab(tab);
    onTabChange?.(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Address Modal State
  const [addressModalOpen, setAddressModalOpen] = useState(false);
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);

  // Order Item Reflection Modal State
  const [orderReflectionModalItem, setOrderReflectionModalItem] = useState<{
    orderNumber: string;
    item: any;
  } | null>(null);
  const [orderReflectionText, setOrderReflectionText] = useState('');
  const [orderReflectionLocation, setOrderReflectionLocation] = useState('');
  const [orderReflectionPhotoUrl, setOrderReflectionPhotoUrl] = useState('');
  const [orderReflectionPermission, setOrderReflectionPermission] = useState(true);
  const [orderReflectionSubmittedKeys, setOrderReflectionSubmittedKeys] = useState<string[]>([]);

  const handleOpenOrderReflection = (orderNumber: string, item: any) => {
    setOrderReflectionModalItem({ orderNumber, item });
    setOrderReflectionText('');
    setOrderReflectionLocation(user?.location || 'United States');
    setOrderReflectionPhotoUrl('');
    setOrderReflectionPermission(true);
  };

  const handleSaveOrderReflection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderReflectionModalItem || !orderReflectionText.trim()) return;

    const { item, orderNumber } = orderReflectionModalItem;

    submitResponse({
      productId: item.productId,
      productName: item.productName,
      authorName: user?.fullName || 'Verified Member',
      authorLocation: orderReflectionLocation.trim() || user?.location || 'United States',
      email: user?.email,
      response: orderReflectionText.trim(),
      photoUrl: orderReflectionPhotoUrl.trim() || undefined,
      garmentOnBodySize: item.size,
      permissionGranted: orderReflectionPermission,
    });

    const key = `${orderNumber}-${item.productName}-${item.size}`;
    setOrderReflectionSubmittedKeys((prev) => [...prev, key]);
    setOrderReflectionModalItem(null);
    switchTab('reflections');
  };
  const [addressToDelete, setAddressToDelete] = useState<UserAddress | null>(null);
  const [addressForm, setAddressForm] = useState<Omit<UserAddress, 'id'>>({
    label: 'Home',
    fullName: '',
    street: '',
    apartment: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'US',
    phone: '',
    isDefault: false,
  });

  // Profile Edit State
  const [profileName, setProfileName] = useState(user?.fullName || '');
  const [profileLocation, setProfileLocation] = useState(user?.location || '');
  const [profileBio, setProfileBio] = useState(user?.bio || '');
  const [profileAvatarUrl, setProfileAvatarUrl] = useState(user?.avatarUrl || '');
  const [profileSavedFeedback, setProfileSavedFeedback] = useState(false);

  // Keep state synced if user changes
  useEffect(() => {
    if (user) {
      setProfileName(user.fullName || '');
      setProfileLocation(user.location || '');
      setProfileBio(user.bio || '');
      setProfileAvatarUrl(user.avatarUrl || '');
    }
  }, [user]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setProfileAvatarUrl(result);
        updateProfile({ avatarUrl: result });
      }
    };
    reader.readAsDataURL(file);
  };

  // New Reflection Modal State
  const [newReflectionModalOpen, setNewReflectionModalOpen] = useState(false);
  const [reflectionText, setReflectionText] = useState('');
  const [reflectionProduct, setReflectionProduct] = useState(products[0]?.name || 'The Distance Tee');
  const [reflectionCity, setReflectionCity] = useState(user?.location || 'United States');

  // Delete Account Confirmation
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  // Copy Feedback
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);

  if (!isAuthenticated || !user) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-24 text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mx-auto border border-neutral-300">
          <UserIcon className="w-8 h-8 text-neutral-600 stroke-[1.5]" />
        </div>
        <div className="space-y-2">
          <span className="text-[11px] uppercase tracking-widest font-mono text-neutral-500">
            Ezistential Connections • Customer Threshold
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl text-neutral-900 tracking-tight">
            Sign In to Access Your Dashboard
          </h1>
          <p className="text-sm text-neutral-600 max-w-md mx-auto leading-relaxed">
            Track your made-to-order garments, manage saved items, review submitted reflections, and control your digital dignity settings.
          </p>
        </div>
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Button onClick={onOpenAuth} variant="primary" size="md">
            Sign In / Register
          </Button>
          <Button onClick={() => onNavigate('shop')} variant="outline" size="md">
            Explore Garments
          </Button>
        </div>
      </div>
    );
  }

  // Filter user specific orders and reflections
  const userOrders = orders.filter(
    (o) =>
      o.customerEmail.toLowerCase() === user.email.toLowerCase() ||
      (o.shippingAddress?.email && o.shippingAddress.email.toLowerCase() === user.email.toLowerCase())
  );

  const userReflections = responses.filter(
    (r) =>
      (r.email && r.email.toLowerCase() === user.email.toLowerCase()) ||
      r.authorName?.toLowerCase() === user.fullName.toLowerCase()
  );

  const savedProducts = products.filter((p) =>
    user.savedGarments.some((sg) => sg.productId === p.id || sg.productId === p.slug)
  );

  const verificationEval = evaluateMemberVerification(
    user,
    userOrders,
    userReflections,
    content.memberVerificationRules
  );

  // Helper to open address modal
  const handleOpenNewAddress = () => {
    setEditingAddressId(null);
    setAddressForm({
      label: 'Home',
      fullName: user.fullName || '',
      street: '',
      apartment: '',
      city: user.location?.split(',')[0]?.trim() || '',
      state: user.location?.split(',')[1]?.trim() || '',
      zipCode: '',
      country: 'US',
      phone: '',
      isDefault: user.addresses.length === 0,
    });
    setAddressModalOpen(true);
  };

  const handleEditAddress = (addr: UserAddress) => {
    setEditingAddressId(addr.id);
    setAddressForm({
      label: addr.label,
      fullName: addr.fullName,
      street: addr.street,
      apartment: addr.apartment || '',
      city: addr.city,
      state: addr.state,
      zipCode: addr.zipCode,
      country: addr.country,
      phone: addr.phone || '',
      isDefault: addr.isDefault,
    });
    setAddressModalOpen(true);
  };

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addressForm.fullName || !addressForm.street || !addressForm.city || !addressForm.state || !addressForm.zipCode) {
      return;
    }

    if (editingAddressId) {
      updateAddress(editingAddressId, addressForm);
    } else {
      addAddress(addressForm);
    }
    setAddressModalOpen(false);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      fullName: profileName,
      location: profileLocation,
      bio: profileBio,
      avatarUrl: profileAvatarUrl || undefined,
    });
    setProfileSavedFeedback(true);
    setTimeout(() => setProfileSavedFeedback(false), 2500);
  };

  const handleCreateReflection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reflectionText.trim()) return;

    submitResponse({
      productName: reflectionProduct,
      authorName: user.fullName,
      authorLocation: reflectionCity,
      email: user.email,
      response: reflectionText.trim(),
      permissionGranted: true,
    });

    setReflectionText('');
    setNewReflectionModalOpen(false);
    switchTab('reflections');
  };

  const getInitials = (name: string) => {
    if (!name) return 'EC';
    const parts = name.split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return name.slice(0, 2).toUpperCase();
  };

  const copyToClipboard = (text: string, orderId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedOrderId(orderId);
    setTimeout(() => setCopiedOrderId(null), 2000);
  };

  const navTabs: { id: AccountTab; label: string; icon: any; count?: number }[] = [
    { id: 'overview', label: 'Dashboard Hub', icon: LayoutDashboard },
    { id: 'verification', label: 'Member Verification Engine', icon: ShieldCheck },
    { id: 'orders', label: 'Orders & Tracking', icon: Package, count: userOrders.length },
    { id: 'wishlist', label: 'Wishlist & Saved', icon: Heart, count: user.savedGarments.length },
    { id: 'reflections', label: 'My Reflections', icon: MessageSquare, count: userReflections.length },
    { id: 'addresses', label: 'Shipping Addresses', icon: MapPin, count: user.addresses.length },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-8">
      {/* 1. Member Profile Hero Banner */}
      <div className="bg-[#0f0f0f] text-white p-6 sm:p-8 border border-neutral-800 relative overflow-hidden shadow-md rounded-xs">
        {/* Subtle Background Architectural Line Accent */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-neutral-800/20 via-transparent to-transparent pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center space-x-4 sm:space-x-6">
            <div className="relative group shrink-0">
              <div className="p-0.5 rounded-full bg-neutral-800 border border-neutral-700">
                {user.avatarUrl ? (
                  <img
                    src={user.avatarUrl}
                    alt={user.fullName}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover shadow-inner"
                  />
                ) : (
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-neutral-900 text-[#fbfbf9] font-serif text-2xl flex items-center justify-center shrink-0 shadow-inner">
                    {getInitials(user.fullName)}
                  </div>
                )}
              </div>
              <button
                onClick={() => switchTab('settings')}
                className="absolute bottom-0 right-0 p-1.5 rounded-full bg-neutral-900 border border-neutral-700 text-neutral-300 hover:text-white transition-all hover:scale-110 cursor-pointer shadow-md"
                title="Update Profile Photo"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                {verificationEval.isVerified ? (
                  <span className="text-[10px] font-mono uppercase tracking-widest text-amber-300 bg-neutral-900 px-2.5 py-0.5 border border-neutral-800 flex items-center gap-1.5 shadow-xs">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Verified Wearer & Member</span>
                  </span>
                ) : (
                  <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-300 bg-neutral-900 px-2.5 py-0.5 border border-neutral-800 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                    <span>Verification Progress ({verificationEval.percentage}%)</span>
                  </span>
                )}
                {user.location && (
                  <span className="text-xs text-neutral-400 flex items-center gap-1 font-mono">
                    <MapPin className="w-3 h-3 text-neutral-500" />
                    {user.location}
                  </span>
                )}
              </div>

              <h1 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
                {user.fullName}
              </h1>

              <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-400 font-mono">
                <span>{user.email}</span>
                <span className="text-neutral-700">•</span>
                <span>{userOrders.length} Orders</span>
                <span className="text-neutral-700">•</span>
                <span>{userReflections.length} Reflections</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2 md:pt-0 border-t md:border-t-0 border-neutral-800">
            <Button
              onClick={() => switchTab('settings')}
              variant="outline"
              size="sm"
              className="bg-neutral-900/80 text-neutral-200 border-neutral-700 hover:bg-neutral-800 hover:text-white cursor-pointer text-xs font-mono py-2 px-4"
            >
              <Settings className="w-3.5 h-3.5 mr-2 text-neutral-400" />
              Settings
            </Button>
            <Button
              onClick={logout}
              variant="outline"
              size="sm"
              className="bg-neutral-900/80 text-neutral-300 border-neutral-700 hover:bg-neutral-800 hover:text-white cursor-pointer text-xs font-mono py-2 px-4"
            >
              <LogOut className="w-3.5 h-3.5 mr-2 text-neutral-400" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>

      {/* 2. Main Account Workspace: Vertical Sidebar Menu + Content View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Vertical Sidebar Navigation */}
        <div className="lg:col-span-3 bg-white border border-neutral-200 p-4 space-y-4 shadow-xs sticky top-24 rounded-xs">
          <div className="px-3 pt-2 pb-2.5 border-b border-neutral-200 flex items-center justify-between">
            <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 font-bold flex items-center gap-1.5">
              <LayoutDashboard className="w-3 h-3 text-neutral-800" />
              <span>Personal Threshold</span>
            </span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" title="Active Connection Session" />
          </div>

          <nav className="space-y-1.5">
            {navTabs.map((t) => {
              const Icon = t.icon;
              const isActive = activeTab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => switchTab(t.id)}
                  className={`w-full flex items-center justify-between p-3.5 text-xs uppercase tracking-wider font-medium transition-all text-left cursor-pointer border relative ${
                    isActive
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-sm font-bold before:absolute before:left-0 before:top-0 before:bottom-0 before:w-1 before:bg-amber-400'
                      : 'bg-[#fbfbf9] text-neutral-700 hover:text-black hover:bg-neutral-100 border-neutral-200/90'
                  }`}
                >
                  <div className="flex items-center space-x-3 truncate">
                    <Icon className={`w-4 h-4 stroke-[1.5] shrink-0 ${isActive ? 'text-amber-300' : 'text-neutral-500'}`} />
                    <span className="truncate">{t.label}</span>
                  </div>
                  {t.count !== undefined && (
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 shrink-0 ${
                        isActive
                          ? 'bg-neutral-800 text-amber-300 border border-neutral-700'
                          : 'bg-neutral-200 text-neutral-800'
                      }`}
                    >
                      {t.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Quick Curator Admin shortcut if admin */}
          {user.role === 'admin' && (
            <div className="pt-3 border-t border-neutral-200">
              <button
                onClick={() => onNavigate('admin')}
                className="w-full p-3 bg-amber-50 hover:bg-amber-100 text-amber-950 text-[11px] font-mono uppercase tracking-wider flex items-center justify-between transition-colors border border-amber-200 cursor-pointer shadow-2xs"
              >
                <span className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-700" />
                  <span>Curator Admin Portal</span>
                </span>
                <ChevronRight className="w-3.5 h-3.5 text-amber-700" />
              </button>
            </div>
          )}
        </div>

        {/* Right Tab Content Area */}
        <div className="lg:col-span-9 bg-white border border-neutral-200 p-6 sm:p-10 shadow-2xs min-h-[550px] rounded-xs">

      {/* PAGE 1: DASHBOARD HUB OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Member Verification Status Banner */}
          <div className="bg-[#fcfcfb] border border-neutral-200 p-6 space-y-4 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
              <div className="flex items-center space-x-3">
                <div className={`p-2 border ${verificationEval.isVerified ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-amber-50 border-amber-200 text-amber-800'}`}>
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-neutral-900">
                    {verificationEval.isVerified ? 'Verified Member & Wearer' : 'Verification Journey Progress'}
                  </h3>
                  <p className="text-xs text-neutral-500 font-mono">
                    {verificationEval.isVerified
                      ? 'Fully verified human participant across orders and curated observations.'
                      : `Fulfilled ${verificationEval.score} of ${verificationEval.maxScore} criteria required for official badge.`}
                  </p>
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="font-mono text-2xl font-bold text-neutral-900">{verificationEval.percentage}%</span>
                <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 block">Verification Score</span>
              </div>
            </div>

            {/* Verification Steps Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-sans pt-1">
              <div className={`p-3 border flex items-center justify-between ${verificationEval.reasons.purchaseMet ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950' : 'bg-neutral-50 border-neutral-200 text-neutral-600'}`}>
                <span className="font-medium">1. Order Garment ({verificationEval.reasons.purchaseCount})</span>
                {verificationEval.reasons.purchaseMet ? <Check className="w-4 h-4 text-emerald-600 shrink-0" /> : <button onClick={() => onNavigate('shop')} className="text-[10px] font-mono underline text-black">Shop →</button>}
              </div>

              <div className={`p-3 border flex items-center justify-between ${verificationEval.reasons.reflectionMet ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950' : 'bg-neutral-50 border-neutral-200 text-neutral-600'}`}>
                <span className="font-medium">2. Field Reflection ({verificationEval.reasons.reflectionCount})</span>
                {verificationEval.reasons.reflectionMet ? <Check className="w-4 h-4 text-emerald-600 shrink-0" /> : <button onClick={() => setNewReflectionModalOpen(true)} className="text-[10px] font-mono underline text-black">Add →</button>}
              </div>

              <div className={`p-3 border flex items-center justify-between ${verificationEval.reasons.locationMet ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950' : 'bg-neutral-50 border-neutral-200 text-neutral-600'}`}>
                <span className="font-medium">3. Profile City/State</span>
                {verificationEval.reasons.locationMet ? <Check className="w-4 h-4 text-emerald-600 shrink-0" /> : <button onClick={() => switchTab('settings')} className="text-[10px] font-mono underline text-black">Edit →</button>}
              </div>

              <div className={`p-3 border flex items-center justify-between ${verificationEval.reasons.photoMet ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950' : 'bg-neutral-50 border-neutral-200 text-neutral-600'}`}>
                <span className="font-medium">4. On-Body Photo</span>
                {verificationEval.reasons.photoMet ? <Check className="w-4 h-4 text-emerald-600 shrink-0" /> : <span className="text-[10px] font-mono text-neutral-400">Optional</span>}
              </div>
            </div>
          </div>

          {/* Quick Metric Navigation Tiles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div
              onClick={() => switchTab('orders')}
              className="bg-white border border-neutral-200 p-6 shadow-xs hover:border-black transition-all cursor-pointer group space-y-3"
            >
              <div className="flex justify-between items-start">
                <div className="p-2.5 bg-neutral-100 group-hover:bg-neutral-900 group-hover:text-white transition-colors">
                  <Package className="w-5 h-5 stroke-[1.5]" />
                </div>
                <span className="font-mono text-2xl font-light text-neutral-900">
                  {userOrders.length}
                </span>
              </div>
              <div>
                <h3 className="font-serif text-base text-neutral-900 group-hover:underline">
                  Orders & Live Tracking
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Apliiq DTF print queue and USPS delivery status.
                </p>
              </div>
              <div className="pt-2 text-xs font-medium text-neutral-900 flex items-center gap-1">
                <span>Manage Orders</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            <div
              onClick={() => switchTab('wishlist')}
              className="bg-white border border-neutral-200 p-6 shadow-xs hover:border-black transition-all cursor-pointer group space-y-3"
            >
              <div className="flex justify-between items-start">
                <div className="p-2.5 bg-neutral-100 group-hover:bg-neutral-900 group-hover:text-white transition-colors">
                  <Heart className="w-5 h-5 stroke-[1.5]" />
                </div>
                <span className="font-mono text-2xl font-light text-neutral-900">
                  {user.savedGarments.length}
                </span>
              </div>
              <div>
                <h3 className="font-serif text-base text-neutral-900 group-hover:underline">
                  Saved Garments
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Bookmarked pieces and contemplation notes.
                </p>
              </div>
              <div className="pt-2 text-xs font-medium text-neutral-900 flex items-center gap-1">
                <span>View Wishlist</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            <div
              onClick={() => switchTab('reflections')}
              className="bg-white border border-neutral-200 p-6 shadow-xs hover:border-black transition-all cursor-pointer group space-y-3"
            >
              <div className="flex justify-between items-start">
                <div className="p-2.5 bg-neutral-100 group-hover:bg-neutral-900 group-hover:text-white transition-colors">
                  <MessageSquare className="w-5 h-5 stroke-[1.5]" />
                </div>
                <span className="font-mono text-2xl font-light text-neutral-900">
                  {userReflections.length}
                </span>
              </div>
              <div>
                <h3 className="font-serif text-base text-neutral-900 group-hover:underline">
                  My Field Reflections
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Personal contributions to the public archive.
                </p>
              </div>
              <div className="pt-2 text-xs font-medium text-neutral-900 flex items-center gap-1">
                <span>View Submissions</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            <div
              onClick={() => switchTab('addresses')}
              className="bg-white border border-neutral-200 p-6 shadow-xs hover:border-black transition-all cursor-pointer group space-y-3"
            >
              <div className="flex justify-between items-start">
                <div className="p-2.5 bg-neutral-100 group-hover:bg-neutral-900 group-hover:text-white transition-colors">
                  <MapPin className="w-5 h-5 stroke-[1.5]" />
                </div>
                <span className="font-mono text-2xl font-light text-neutral-900">
                  {user.addresses.length}
                </span>
              </div>
              <div>
                <h3 className="font-serif text-base text-neutral-900 group-hover:underline">
                  Shipping Addresses
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Saved delivery destinations & default address.
                </p>
              </div>
              <div className="pt-2 text-xs font-medium text-neutral-900 flex items-center gap-1">
                <span>Manage Address Book</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>

          {/* Recent Active Order Preview */}
          {userOrders.length > 0 && (
            <div className="bg-white border border-neutral-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
                    Most Recent Dispatch
                  </span>
                  <h3 className="font-serif text-xl text-neutral-900">
                    Order {userOrders[0].orderNumber}
                  </h3>
                </div>
                <Button onClick={() => switchTab('orders')} variant="outline" size="sm">
                  View All Orders ({userOrders.length})
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                <div className="md:col-span-2 space-y-3">
                  <div className="flex items-center space-x-3 text-xs">
                    <span className="font-mono text-neutral-500">Status:</span>
                    <span className="px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-300 font-mono text-[11px] uppercase">
                      {userOrders[0].status}
                    </span>
                    <span className="text-neutral-400">•</span>
                    <span className="text-neutral-600">
                      Destination: {userOrders[0].shippingAddress.city}, {userOrders[0].shippingAddress.state}
                    </span>
                  </div>

                  {/* Items Preview */}
                  <div className="space-y-2">
                    {userOrders[0].items.map((item, idx) => (
                      <div key={idx} className="flex items-center space-x-3 text-xs bg-neutral-50 p-2.5 border border-neutral-100">
                        <img src={safeSrc(item.image)} alt={item.productName} className="w-10 h-12 object-cover bg-neutral-200" />
                        <div>
                          <p className="font-medium text-neutral-900">{item.productName}</p>
                          <p className="text-[11px] text-neutral-500">
                            {item.wearType && <span className="font-mono text-neutral-700 font-medium">{item.wearType} • </span>}
                            Size: {item.size} • Color: {item.color} • Qty: {item.quantity}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-[#f5f4f0] p-4 space-y-3 border border-neutral-200 flex flex-col justify-between text-xs">
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block mb-1">
                      Carrier Details
                    </span>
                    <p className="font-medium text-neutral-900">USPS Ground Domestic</p>
                    {userOrders[0].trackingNumber && (
                      <p className="font-mono text-[11px] text-neutral-600 mt-1 break-all">
                        {userOrders[0].trackingNumber}
                      </p>
                    )}
                  </div>
                  <Button
                    onClick={() => onNavigate('track-order')}
                    variant="primary"
                    size="sm"
                    fullWidth
                    className="justify-center"
                  >
                    Open Live Tracker
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Quick Contemplation & Reflection Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Wishlist Highlight */}
            <div className="bg-white border border-neutral-200 p-6 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500">
                    Saved for Contemplation
                  </span>
                  <button
                    onClick={() => switchTab('wishlist')}
                    className="text-xs text-neutral-700 hover:text-black underline underline-offset-2"
                  >
                    View All ({user.savedGarments.length})
                  </button>
                </div>
                <h3 className="font-serif text-lg text-neutral-900 mb-3">Garments on Your Mind</h3>

                {savedProducts.length === 0 ? (
                  <p className="text-xs text-neutral-500 italic">No garments saved yet.</p>
                ) : (
                  <div className="flex items-center space-x-3 bg-neutral-50 p-3 border border-neutral-200">
                    <img
                      src={savedProducts[0].primaryImage}
                      alt={savedProducts[0].name}
                      className="w-14 h-16 object-cover bg-neutral-200 shrink-0"
                    />
                    <div className="space-y-1">
                      <p className="font-serif text-sm font-medium text-neutral-900">{savedProducts[0].name}</p>
                      <p className="text-xs text-neutral-600 italic line-clamp-1">"{savedProducts[0].tagline}"</p>
                      <p className="font-mono text-xs font-semibold text-neutral-900">${savedProducts[0].price}</p>
                    </div>
                  </div>
                )}
              </div>

              <Button onClick={() => switchTab('wishlist')} variant="outline" size="sm" className="w-full justify-center">
                Open Wishlist &amp; Saved Garments
              </Button>
            </div>

            {/* Field Reflection Highlight */}
            <div className="bg-white border border-neutral-200 p-6 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500">
                    Public Encounters
                  </span>
                  <button
                    onClick={() => switchTab('reflections')}
                    className="text-xs text-neutral-700 hover:text-black underline underline-offset-2"
                  >
                    View All ({userReflections.length})
                  </button>
                </div>
                <h3 className="font-serif text-lg text-neutral-900 mb-3">Community Contributions</h3>

                {userReflections.length === 0 ? (
                  <p className="text-xs text-neutral-500 italic">
                    You have not submitted a reflection yet. Share an observation from your daily walks.
                  </p>
                ) : (
                  <div className="bg-neutral-50 p-3 border border-neutral-200 space-y-1">
                    <p className="font-serif italic text-xs text-neutral-800 line-clamp-2">
                      "{userReflections[0].response}"
                    </p>
                    <span className="text-[10px] font-mono uppercase text-emerald-700 block pt-1">
                      ● Status: {userReflections[0].status === 'Approved' ? 'Published' : 'Under Review'}
                    </span>
                  </div>
                )}
              </div>

              <Button
                onClick={() => setNewReflectionModalOpen(true)}
                variant="outline"
                size="sm"
                className="w-full justify-center"
              >
                <Plus className="w-3.5 h-3.5 mr-1" />
                Write New Reflection
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* PAGE: MEMBER VERIFICATION ENGINE */}
      {activeTab === 'verification' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <div className="border-b border-neutral-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center space-x-2 text-xs text-neutral-500 mb-1">
                <button onClick={() => switchTab('overview')} className="hover:text-black underline underline-offset-2">
                  Dashboard
                </button>
                <span>/</span>
                <span className="font-medium text-neutral-900 font-mono">Verification Engine</span>
              </div>
              <h2 className="font-serif text-2xl font-bold text-neutral-900">
                Member Verification Engine
              </h2>
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-neutral-500">Status:</span>
              <span className={`px-2.5 py-1 text-xs font-mono font-bold border ${verificationEval.isVerified ? 'bg-emerald-50 text-emerald-950 border-emerald-300' : 'bg-amber-50 text-amber-950 border-amber-300'}`}>
                {verificationEval.isVerified ? '✓ Verified Wearer' : 'In Progress'}
              </span>
            </div>
          </div>

          {/* Full Verification Workspace */}
          <div className="bg-[#0f0f0f] text-white p-6 sm:p-8 border border-neutral-800 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-neutral-800 pb-6">
              <div className="flex items-center space-x-4">
                <div className={`p-3 border ${verificationEval.isVerified ? 'bg-emerald-900/50 border-emerald-500 text-emerald-300' : 'bg-amber-900/50 border-amber-500 text-amber-300'}`}>
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-serif text-xl font-bold text-white">
                    {verificationEval.isVerified ? 'Official Verified Wearer Badge Unlocked' : 'Verification Criteria Workspace'}
                  </h3>
                  <p className="text-xs text-neutral-400 font-mono mt-0.5">
                    {verificationEval.isVerified
                      ? 'Authentic wearer verified across POD orders, field observations, and location.'
                      : `Score: ${verificationEval.score} / ${verificationEval.maxScore} (${verificationEval.percentage}% Complete)`}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="font-mono text-3xl font-bold text-white">{verificationEval.percentage}%</span>
                <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 block">Verification Progress</span>
              </div>
            </div>

            {/* Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
              <div className={`p-4 border ${verificationEval.reasons.purchaseMet ? 'bg-emerald-950/40 border-emerald-700 text-emerald-200' : 'bg-neutral-900 border-neutral-800 text-neutral-400'}`}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold">1. Order POD Garment</span>
                  {verificationEval.reasons.purchaseMet ? <Check className="w-4 h-4 text-emerald-400" /> : <button onClick={() => onNavigate('shop')} className="text-[10px] underline text-amber-300">Shop →</button>}
                </div>
                <p className="text-[11px] text-neutral-400 font-sans">
                  Completed {verificationEval.reasons.purchaseCount} order(s). Requires at least 1 fulfilled garment order.
                </p>
              </div>

              <div className={`p-4 border ${verificationEval.reasons.reflectionMet ? 'bg-emerald-950/40 border-emerald-700 text-emerald-200' : 'bg-neutral-900 border-neutral-800 text-neutral-400'}`}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold">2. Field Reflection</span>
                  {verificationEval.reasons.reflectionMet ? <Check className="w-4 h-4 text-emerald-400" /> : <button onClick={() => setNewReflectionModalOpen(true)} className="text-[10px] underline text-amber-300">Submit →</button>}
                </div>
                <p className="text-[11px] text-neutral-400 font-sans">
                  Submitted {verificationEval.reasons.reflectionCount} reflection(s). Requires 1 approved observation.
                </p>
              </div>

              <div className={`p-4 border ${verificationEval.reasons.locationMet ? 'bg-emerald-950/40 border-emerald-700 text-emerald-200' : 'bg-neutral-900 border-neutral-800 text-neutral-400'}`}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold">3. Profile Location Tag</span>
                  {verificationEval.reasons.locationMet ? <Check className="w-4 h-4 text-emerald-400" /> : <button onClick={() => switchTab('settings')} className="text-[10px] underline text-amber-300">Update →</button>}
                </div>
                <p className="text-[11px] text-neutral-400 font-sans">
                  {user.location ? `Set to "${user.location}"` : 'Please add your City, State in Settings.'}
                </p>
              </div>

              <div className={`p-4 border ${verificationEval.reasons.photoMet ? 'bg-emerald-950/40 border-emerald-700 text-emerald-200' : 'bg-neutral-900 border-neutral-800 text-neutral-400'}`}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold">4. On-Body Photo Verification</span>
                  {verificationEval.reasons.photoMet ? <Check className="w-4 h-4 text-emerald-400" /> : <span className="text-[10px] text-neutral-500">Optional</span>}
                </div>
                <p className="text-[11px] text-neutral-400 font-sans">
                  Upload an on-body photo in the Connection Archive or Settings.
                </p>
              </div>
            </div>

            {/* Perks & Unlocked Privileges */}
            <div className="pt-4 border-t border-neutral-800 space-y-3">
              <span className="text-[10px] uppercase tracking-widest text-amber-300 font-mono font-bold block">
                Verified Wearer Privileges
              </span>
              <ul className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-sans text-neutral-300">
                <li className="bg-neutral-900 p-3 border border-neutral-800 space-y-1">
                  <span className="font-bold text-white block">1. Early Dispatch Access</span>
                  <p className="text-[11px] text-neutral-400">Receive 24-hour advance access to seasonal garment drops.</p>
                </li>
                <li className="bg-neutral-900 p-3 border border-neutral-800 space-y-1">
                  <span className="font-bold text-white block">2. Custom Label Embroidery</span>
                  <p className="text-[11px] text-neutral-400">Option to print custom interior neck tags on future orders.</p>
                </li>
                <li className="bg-neutral-900 p-3 border border-neutral-800 space-y-1">
                  <span className="font-bold text-white block">3. Archive Feature Priority</span>
                  <p className="text-[11px] text-neutral-400">Featured editorial placement in Connection Archive dispatches.</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* PAGE 2: ORDERS & POD TRACKING */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <div className="flex items-center space-x-2 text-xs text-neutral-500 mb-1">
                <button onClick={() => switchTab('overview')} className="hover:text-black underline underline-offset-2">
                  Dashboard
                </button>
                <span>/</span>
                <span className="text-neutral-900 font-medium">Orders & POD Tracking</span>
              </div>
              <h2 className="font-serif text-2xl sm:text-3xl text-neutral-900 tracking-tight">
                Order History & Live Manufacturing Status
              </h2>
              <p className="text-xs text-neutral-600 mt-1">
                Made-to-order heavyweight cotton blanks printed on demand at Apliiq's facility in Los Angeles, CA.
              </p>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => onNavigate('track-order')} variant="outline" size="sm">
                <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
                Live Tracking Portal
              </Button>
              <Button onClick={() => onNavigate('shop')} variant="primary" size="sm">
                <ShoppingBag className="w-3.5 h-3.5 mr-1.5" />
                Shop Garments
              </Button>
            </div>
          </div>

          {userOrders.length === 0 ? (
            <div className="bg-white border border-neutral-200 p-12 text-center space-y-4">
              <Package className="w-10 h-10 text-neutral-400 mx-auto stroke-[1.2]" />
              <div className="space-y-1">
                <h3 className="font-serif text-lg text-neutral-900">No Orders Found</h3>
                <p className="text-xs text-neutral-600 max-w-sm mx-auto">
                  When you place an order, its real-time Apliiq direct-to-film printing queue and USPS tracking will be listed here.
                </p>
              </div>
              <div className="pt-2">
                <Button onClick={() => onNavigate('shop')} variant="primary" size="md">
                  Explore Inaugural Collection
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {userOrders.map((order) => {
                const isDispatched = order.status === 'Shipped' || order.status === 'Delivered';
                const isInProduction = order.status === 'In Production' || isDispatched;

                return (
                  <div key={order.id} className="bg-white border border-neutral-200 shadow-xs overflow-hidden">
                    {/* Order Header Bar */}
                    <div className="bg-[#f5f4f0] p-4 sm:p-6 border-b border-neutral-200 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                      <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
                        <div>
                          <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 block">
                            Order Reference
                          </span>
                          <span className="font-mono font-bold text-neutral-900">{order.orderNumber}</span>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 block">
                            Date Placed
                          </span>
                          <span className="text-neutral-800">
                            {new Date(order.createdAt).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })}
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 block">
                            Total Investment
                          </span>
                          <span className="font-mono font-semibold text-neutral-900">
                            ${order.total.toFixed(2)}
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 block">
                            Destination
                          </span>
                          <span className="text-neutral-800">
                            {order.shippingAddress.city}, {order.shippingAddress.state}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span
                          className={`text-[11px] font-mono uppercase tracking-wider px-2.5 py-1 border ${
                            order.status === 'Delivered'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : order.status === 'Shipped'
                              ? 'bg-blue-50 text-blue-800 border-blue-300'
                              : 'bg-amber-50 text-amber-800 border-amber-300'
                          }`}
                        >
                          {order.status}
                        </span>

                        <button
                          onClick={() => copyToClipboard(order.orderNumber, order.id)}
                          className="p-1.5 text-neutral-500 hover:text-black transition-colors"
                          title="Copy Order Number"
                        >
                          {copiedOrderId === order.id ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Manufacturing Pipeline */}
                    <div className="p-4 sm:p-6 bg-neutral-50/50 border-b border-neutral-100">
                      <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block mb-3">
                        On-Demand Manufacturing & Dispatch Pipeline
                      </span>
                      <div className="grid grid-cols-4 gap-2 text-center text-[11px]">
                        <div className="space-y-1">
                          <div className="h-1.5 bg-black rounded-full" />
                          <span className="font-medium text-neutral-900 block">1. Verified</span>
                          <span className="text-[10px] text-neutral-500 hidden sm:block">DTF Specs Queued</span>
                        </div>
                        <div className="space-y-1">
                          <div className={`h-1.5 rounded-full ${isInProduction ? 'bg-black' : 'bg-neutral-200'}`} />
                          <span className={`font-medium block ${isInProduction ? 'text-neutral-900' : 'text-neutral-400'}`}>
                            2. Printing
                          </span>
                          <span className="text-[10px] text-neutral-500 hidden sm:block">Apliiq LA Facility</span>
                        </div>
                        <div className="space-y-1">
                          <div className={`h-1.5 rounded-full ${isDispatched ? 'bg-black' : 'bg-neutral-200'}`} />
                          <span className={`font-medium block ${isDispatched ? 'text-neutral-900' : 'text-neutral-400'}`}>
                            3. Dispatched
                          </span>
                          <span className="text-[10px] text-neutral-500 hidden sm:block">USPS Ground Transit</span>
                        </div>
                        <div className="space-y-1">
                          <div
                            className={`h-1.5 rounded-full ${
                              order.status === 'Delivered' ? 'bg-emerald-600' : 'bg-neutral-200'
                            }`}
                          />
                          <span
                            className={`font-medium block ${
                              order.status === 'Delivered' ? 'text-emerald-700' : 'text-neutral-400'
                            }`}
                          >
                            4. Delivered
                          </span>
                          <span className="text-[10px] text-neutral-500 hidden sm:block">Into the Field</span>
                        </div>
                      </div>
                    </div>

                    {/* Garments List */}
                    <div className="p-4 sm:p-6 space-y-4">
                      {order.items.map((item, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between gap-4 pb-4 last:pb-0 border-b last:border-b-0 border-neutral-100"
                        >
                          <div className="flex items-center space-x-4">
                            <img
                              src={item.image}
                              alt={item.productName}
                              className="w-14 h-16 object-cover bg-neutral-100 border border-neutral-200"
                            />
                            <div className="space-y-0.5">
                              <h4 className="font-serif text-sm font-medium text-neutral-900">
                                {item.productName}
                              </h4>
                              <p className="text-xs text-neutral-500">
                                {item.wearType && <span className="font-mono text-neutral-700 font-medium">{item.wearType} • </span>}
                                Size: <span className="font-medium text-neutral-800">{item.size}</span> • Color:{' '}
                                <span className="font-medium text-neutral-800">{item.color}</span> • Qty: {item.quantity}
                              </p>
                              <p className="text-[11px] text-neutral-400 font-mono">{item.wearType || 'Heavyweight 6.5oz Combed Cotton'}</p>
                            </div>
                          </div>

                          <div className="text-right space-y-1.5 shrink-0">
                            <span className="font-mono text-sm font-medium text-neutral-900 block">
                              ${item.subtotal.toFixed(2)}
                            </span>
                            {orderReflectionSubmittedKeys.includes(`${order.orderNumber}-${item.productName}-${item.size}`) ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-xs">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                <span>Reflected ✓</span>
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleOpenOrderReflection(order.orderNumber, item)}
                                className="inline-flex items-center gap-1 text-[10px] font-mono uppercase tracking-wider text-neutral-800 hover:text-black bg-white hover:bg-neutral-100 border border-neutral-300 px-2.5 py-1 transition-all cursor-pointer rounded-xs shadow-2xs"
                                title="Add Reflection & On-Body Photo for this piece"
                              >
                                <Camera className="w-3 h-3 text-neutral-800" />
                                <span>Reflect &amp; Photo</span>
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Footer Actions */}
                    <div className="bg-neutral-50 p-4 border-t border-neutral-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                      {order.trackingNumber ? (
                        <div className="flex items-center space-x-2 text-neutral-700 font-mono text-[11px]">
                          <Truck className="w-4 h-4 text-neutral-500" />
                          <span>USPS Tracking: {order.trackingNumber}</span>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2 text-neutral-500 text-[11px]">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Preparing for production (2-4 business days)</span>
                        </div>
                      )}

                      <div className="flex items-center gap-3">
                        <Button onClick={() => onNavigate('track-order')} variant="outline" size="sm">
                          Open Live Tracking View
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* PAGE 3: DEDICATED WISHLIST VIEW (SAVED GARMENTS) */}
      {activeTab === 'wishlist' && (
        <WishlistView onNavigate={onNavigate} onSwitchTab={switchTab} />
      )}

      {/* PAGE 4: MY FIELD REFLECTIONS */}
      {activeTab === 'reflections' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <div className="flex items-center space-x-2 text-xs text-neutral-500 mb-1">
                <button onClick={() => switchTab('overview')} className="hover:text-black underline underline-offset-2">
                  Dashboard
                </button>
                <span>/</span>
                <span className="text-neutral-900 font-medium">My Field Reflections</span>
              </div>
              <h2 className="font-serif text-2xl sm:text-3xl text-neutral-900 tracking-tight">
                Submissions to the Human Connection Archive
              </h2>
              <p className="text-xs text-neutral-600 mt-1">
                Observations, sidewalk encounters, and thoughts on human distance prompted by our shirts.
              </p>
            </div>
            <Button onClick={() => setNewReflectionModalOpen(true)} variant="primary" size="sm">
              <Plus className="w-3.5 h-3.5 mr-1.5" />
              Submit New Reflection
            </Button>
          </div>

          {userReflections.length === 0 ? (
            <div className="bg-white border border-neutral-200 p-12 text-center space-y-4">
              <MessageSquare className="w-10 h-10 text-neutral-400 mx-auto stroke-[1.2]" />
              <div className="space-y-1">
                <h3 className="font-serif text-lg text-neutral-900">No Reflections Submitted</h3>
                <p className="text-xs text-neutral-600 max-w-sm mx-auto">
                  Have you experienced an unexpected conversation while wearing one of our garments? We welcome your story.
                </p>
              </div>
              <div className="pt-2">
                <Button onClick={() => setNewReflectionModalOpen(true)} variant="primary" size="md">
                  Write Your First Reflection
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {userReflections.map((item) => (
                <div key={item.id} className="bg-white border border-neutral-200 p-6 shadow-xs space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-neutral-100 pb-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-serif font-medium text-neutral-900">
                        {item.productName || 'General Observation'}
                      </span>
                      <span className="text-neutral-300">•</span>
                      <span className="text-[11px] font-mono text-neutral-400">
                        {new Date(item.createdAt).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </span>
                    </div>

                    <span
                      className={`text-[10px] font-mono uppercase tracking-wider px-2.5 py-0.5 border ${
                        item.status === 'Approved'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : 'bg-amber-50 text-amber-800 border-amber-300'
                      }`}
                    >
                      {item.status === 'Approved' ? 'Published in Archive' : 'Curator Review Queue'}
                    </span>
                  </div>

                  <blockquote className="font-serif italic text-base sm:text-lg text-neutral-800 border-l-2 border-neutral-900 pl-4 py-1 leading-relaxed">
                    "{item.response}"
                  </blockquote>

                  <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-neutral-500 pt-2 border-t border-neutral-100">
                    <span>
                      Attributed to: <strong className="text-neutral-800">{item.authorName}</strong> · {item.authorLocation}
                    </span>
                    <button
                      onClick={() => onNavigate('connection')}
                      className="text-neutral-800 hover:text-black font-medium underline underline-offset-2 flex items-center gap-1"
                    >
                      <span>Explore Public Archive</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PAGE 5: SHIPPING ADDRESSES */}
      {activeTab === 'addresses' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
            <div>
              <div className="flex items-center space-x-2 text-xs text-neutral-500 mb-1">
                <button onClick={() => switchTab('overview')} className="hover:text-black underline underline-offset-2">
                  Dashboard
                </button>
                <span>/</span>
                <span className="text-neutral-900 font-medium">Shipping Address Book</span>
              </div>
              <h2 className="font-serif text-2xl sm:text-3xl text-neutral-900 tracking-tight">
                Saved Shipping Destinations
              </h2>
              <p className="text-xs text-neutral-600 mt-1">
                Maintain domestic US addresses for expedited made-to-order checkout.
              </p>
            </div>
            <Button onClick={handleOpenNewAddress} variant="primary" size="sm">
              <Plus className="w-3.5 h-3.5 mr-1.5" />
              Add Address
            </Button>
          </div>

          {user.addresses.length === 0 ? (
            <div className="bg-white border border-neutral-200 p-12 text-center space-y-4">
              <MapPin className="w-10 h-10 text-neutral-400 mx-auto stroke-[1.2]" />
              <div className="space-y-1">
                <h3 className="font-serif text-lg text-neutral-900">No Addresses Saved</h3>
                <p className="text-xs text-neutral-600 max-w-sm mx-auto">
                  Store your primary residence or studio address to expedite future orders.
                </p>
              </div>
              <div className="pt-2">
                <Button onClick={handleOpenNewAddress} variant="primary" size="md">
                  Add Shipping Address
                </Button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {user.addresses.map((addr) => (
                <div
                  key={addr.id}
                  className={`bg-white border p-6 shadow-xs flex flex-col justify-between space-y-4 relative ${
                    addr.isDefault ? 'border-neutral-900 ring-1 ring-neutral-900' : 'border-neutral-200'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono uppercase tracking-wider font-semibold text-neutral-900">
                        {addr.label}
                      </span>
                      {addr.isDefault && (
                        <span className="text-[10px] uppercase font-mono tracking-widest bg-black text-white px-2 py-0.5">
                          Default Address
                        </span>
                      )}
                    </div>

                    <div className="text-sm text-neutral-800 space-y-0.5 font-sans">
                      <p className="font-medium text-neutral-900">{addr.fullName}</p>
                      <p>{addr.street}</p>
                      {addr.apartment && <p>{addr.apartment}</p>}
                      <p>
                        {addr.city}, {addr.state} {addr.zipCode}
                      </p>
                      <p className="text-xs text-neutral-500 font-mono">United States</p>
                      {addr.phone && <p className="text-xs text-neutral-500 font-mono pt-1">{addr.phone}</p>}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-neutral-100 flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleEditAddress(addr)}
                        className="text-neutral-600 hover:text-black flex items-center gap-1 p-1 cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => setAddressToDelete(addr)}
                        className="text-neutral-400 hover:text-red-600 flex items-center gap-1 p-1 ml-2 cursor-pointer"
                        title="Delete Address"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Remove</span>
                      </button>
                    </div>

                    {!addr.isDefault && (
                      <button
                        onClick={() => setDefaultAddress(addr.id)}
                        className="text-xs text-neutral-600 hover:text-black underline underline-offset-2 cursor-pointer"
                      >
                        Set as Default
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PAGE 6: DIGITAL DIGNITY & SETTINGS */}
      {activeTab === 'settings' && (
        <div className="max-w-3xl space-y-8">
          <div className="border-b border-neutral-200 pb-4">
            <div className="flex items-center space-x-2 text-xs text-neutral-500 mb-1">
              <button onClick={() => switchTab('overview')} className="hover:text-black underline underline-offset-2">
                Dashboard
              </button>
              <span>/</span>
              <span className="text-neutral-900 font-medium">Digital Dignity & Settings</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl text-neutral-900 tracking-tight">
              Personal Profile & Data Sovereignty
            </h2>
            <p className="text-xs text-neutral-600 mt-1">
              Control your identity, communication preferences, and exercise full data export or deletion rights.
            </p>
          </div>

          {/* Profile Form */}
          <div className="bg-white border border-neutral-200 p-6 sm:p-8 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
              <h3 className="font-serif text-lg text-neutral-900">Personal Information</h3>
              {profileSavedFeedback && (
                <span className="text-xs text-emerald-700 bg-emerald-50 px-2.5 py-1 border border-emerald-200 flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  Profile Updated
                </span>
              )}
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-5">
              {/* Profile Image Management */}
              <div className="p-4 bg-neutral-50 border border-neutral-200 space-y-3">
                <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600">
                  Profile Photo & Member Avatar
                </label>
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden bg-neutral-200 border-2 border-neutral-300 shrink-0">
                    {profileAvatarUrl ? (
                      <img src={profileAvatarUrl} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-serif text-lg text-neutral-600 font-medium">
                        {getInitials(profileName || user.fullName)}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 flex-1 w-full">
                    <div className="flex flex-wrap items-center gap-2">
                      <label className="px-3 py-1.5 bg-neutral-900 text-white text-xs font-medium cursor-pointer hover:bg-black transition-colors flex items-center gap-1.5">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload From Device</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                      </label>
                      {profileAvatarUrl && (
                        <button
                          type="button"
                          onClick={() => {
                            setProfileAvatarUrl('');
                            updateProfile({ avatarUrl: undefined });
                          }}
                          className="px-2.5 py-1.5 bg-white border border-neutral-300 text-neutral-600 hover:text-red-700 text-xs transition-colors cursor-pointer"
                        >
                          Remove Photo
                        </button>
                      )}
                    </div>

                    {/* Curated Portrait Selectors */}
                    <div className="space-y-1 pt-1">
                      <span className="text-[10px] uppercase font-mono text-neutral-500 block">
                        Or Choose Curated Portrait
                      </span>
                      <div className="flex items-center gap-2">
                        {CURATED_AVATARS.map((av, idx) => (
                          <button
                            type="button"
                            key={idx}
                            onClick={() => {
                              setProfileAvatarUrl(av.url);
                              updateProfile({ avatarUrl: av.url });
                            }}
                            className={`w-7 h-7 rounded-full overflow-hidden border-2 transition-all cursor-pointer ${
                              profileAvatarUrl === av.url ? 'border-black scale-110' : 'border-transparent hover:scale-105'
                            }`}
                            title={av.label}
                          >
                            <img src={safeSrc(av.url)} alt={av.label} className="w-full h-full object-cover" />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={user.email}
                    disabled
                    className="w-full px-3 py-2 bg-neutral-100 border border-neutral-300 text-sm text-neutral-500 cursor-not-allowed font-mono text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                    Location / City
                  </label>
                  <input
                    type="text"
                    value={profileLocation}
                    onChange={(e) => setProfileLocation(e.target.value)}
                    placeholder="e.g. Chicago, IL"
                    className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                    Member Since
                  </label>
                  <input
                    type="text"
                    value={new Date(user.createdAt).toLocaleDateString('en-US', {
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                    disabled
                    className="w-full px-3 py-2 bg-neutral-100 border border-neutral-300 text-sm text-neutral-500 cursor-not-allowed font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                  Bio / Perspective
                </label>
                <textarea
                  value={profileBio}
                  onChange={(e) => setProfileBio(e.target.value)}
                  rows={2}
                  placeholder="A brief note on what brings you to Ezistential Connections..."
                  className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                />
              </div>

              <div className="pt-2">
                <Button type="submit" variant="primary" size="md">
                  Update Profile
                </Button>
              </div>
            </form>
          </div>

          {/* Communication Preferences */}
          <div className="bg-white border border-neutral-200 p-6 sm:p-8 shadow-xs space-y-6">
            <h3 className="font-serif text-lg text-neutral-900 border-b border-neutral-200 pb-4">
              Communication Preferences
            </h3>

            <div className="space-y-4 text-sm">
              <label className="flex items-start space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={user.communicationPreferences?.orderUpdatesEmail ?? true}
                  onChange={(e) =>
                    updateProfile({
                      communicationPreferences: {
                        ...user.communicationPreferences,
                        orderUpdatesEmail: e.target.checked,
                      },
                    })
                  }
                  className="accent-black w-4 h-4 mt-0.5"
                />
                <div>
                  <span className="font-medium text-neutral-900 block">Order & Dispatch Notifications</span>
                  <span className="text-xs text-neutral-500">
                    Essential transactional emails regarding DTF print status and USPS tracking.
                  </span>
                </div>
              </label>

              <label className="flex items-start space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={user.communicationPreferences?.reflectionDigestsEmail ?? true}
                  onChange={(e) =>
                    updateProfile({
                      communicationPreferences: {
                        ...user.communicationPreferences,
                        reflectionDigestsEmail: e.target.checked,
                      },
                    })
                  }
                  className="accent-black w-4 h-4 mt-0.5"
                />
                <div>
                  <span className="font-medium text-neutral-900 block">Quarterly Reflection Gazette</span>
                  <span className="text-xs text-neutral-500">
                    A curated selection of thoughts from the community archive. Max 4 per year.
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* Data Sovereignty & Export */}
          <div className="bg-neutral-50 border border-neutral-200 p-6 sm:p-8 space-y-6">
            <div className="flex items-center space-x-3">
              <ShieldCheck className="w-6 h-6 text-neutral-900" />
              <div>
                <h3 className="font-serif text-lg text-neutral-900">Digital Dignity & Data Export</h3>
                <p className="text-xs text-neutral-600">
                  Your data belongs to you. Export your complete archive or permanently purge your account at any time.
                </p>
              </div>
            </div>

            {content.enableDigitalDignityExport !== false ? (
              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <Button onClick={exportUserData} variant="outline" size="md">
                  <Download className="w-4 h-4 mr-2" />
                  Download Account Archive (JSON)
                </Button>

                <Button
                  onClick={() => setDeleteConfirmOpen(true)}
                  variant="outline"
                  size="md"
                  className="text-red-700 border-red-200 hover:bg-red-50 hover:border-red-300"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Account & Purge Data
                </Button>
              </div>
            ) : (
              <div className="p-4 bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center space-x-2">
                <Info className="w-4 h-4 text-amber-700 shrink-0" />
                <span>
                  Automated account data export is currently suspended by store administration. For data sovereignty inquiries, please reach out to {content.supportEmail || 'care@ezistential.com'}.
                </span>
              </div>
            )}
          </div>
        </div>
      )}
        </div>
      </div>

      {/* MODAL: ADD / EDIT ADDRESS */}
      <Modal
        isOpen={addressModalOpen}
        onClose={() => setAddressModalOpen(false)}
        title={editingAddressId ? 'Edit Shipping Address' : 'Add New Shipping Address'}
        subtitle="Domestic US Delivery Destination"
        maxWidth="md"
      >
        <form onSubmit={handleSaveAddress} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
                Address Label
              </label>
              <input
                type="text"
                value={addressForm.label}
                onChange={(e) => setAddressForm({ ...addressForm, label: e.target.value })}
                placeholder="e.g. Home, Studio"
                className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                required
              />
            </div>
            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={addressForm.fullName}
                onChange={(e) => setAddressForm({ ...addressForm, fullName: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
              Street Address
            </label>
            <input
              type="text"
              value={addressForm.street}
              onChange={(e) => setAddressForm({ ...addressForm, street: e.target.value })}
              placeholder="123 Main Street"
              className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
                Apt / Suite
              </label>
              <input
                type="text"
                value={addressForm.apartment}
                onChange={(e) => setAddressForm({ ...addressForm, apartment: e.target.value })}
                placeholder="Apt 4B"
                className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
                City
              </label>
              <input
                type="text"
                value={addressForm.city}
                onChange={(e) => setAddressForm({ ...addressForm, city: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                required
              />
            </div>
            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
                State & ZIP
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                <input
                  type="text"
                  value={addressForm.state}
                  onChange={(e) => setAddressForm({ ...addressForm, state: e.target.value.toUpperCase() })}
                  placeholder="IL"
                  maxLength={2}
                  className="w-full px-2 py-2 bg-white border border-neutral-300 text-sm uppercase focus:border-black focus:outline-hidden"
                  required
                />
                <input
                  type="text"
                  value={addressForm.zipCode}
                  onChange={(e) => setAddressForm({ ...addressForm, zipCode: e.target.value })}
                  placeholder="60647"
                  className="w-full px-2 py-2 bg-white border border-neutral-300 text-sm font-mono focus:border-black focus:outline-hidden"
                  required
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
              Phone Number (Optional for carrier delivery)
            </label>
            <input
              type="tel"
              value={addressForm.phone}
              onChange={(e) => setAddressForm({ ...addressForm, phone: e.target.value })}
              placeholder="(312) 555-0192"
              className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
            />
          </div>

          <div className="flex items-center space-x-2 pt-1">
            <input
              type="checkbox"
              id="isDefaultAddr"
              checked={addressForm.isDefault}
              onChange={(e) => setAddressForm({ ...addressForm, isDefault: e.target.checked })}
              className="accent-black w-4 h-4"
            />
            <label htmlFor="isDefaultAddr" className="text-xs text-neutral-700 cursor-pointer">
              Set as primary default shipping address
            </label>
          </div>

          <div className="pt-4 flex gap-3">
            <Button type="submit" variant="primary" size="md" className="flex-1 justify-center">
              {editingAddressId ? 'Save Changes' : 'Add Address'}
            </Button>
            <Button
              type="button"
              onClick={() => setAddressModalOpen(false)}
              variant="outline"
              size="md"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Modal>

      {/* MODAL: WRITE NEW REFLECTION */}
      <Modal
        isOpen={newReflectionModalOpen}
        onClose={() => setNewReflectionModalOpen(false)}
        title="Contribute a Reflection from the Field"
        subtitle="What Does This Mean To You?"
        maxWidth="lg"
      >
        <form onSubmit={handleCreateReflection} className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed">
            Share a real encounter, observation, or thought on human distance. Approved submissions become part of our permanent public archive.
          </p>

          <div>
            <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
              Associated Garment
            </label>
            <select
              value={reflectionProduct}
              onChange={(e) => setReflectionProduct(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
            >
              {products.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name} — "{p.tagline}"
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
              Your Location
            </label>
            <input
              type="text"
              value={reflectionCity}
              onChange={(e) => setReflectionCity(e.target.value)}
              placeholder="e.g. Chicago, IL"
              className="w-full px-3 py-2 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
              required
            />
          </div>

          <div>
            <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1">
              Your Reflection / Observation
            </label>
            <textarea
              value={reflectionText}
              onChange={(e) => setReflectionText(e.target.value)}
              rows={4}
              placeholder="What happened when you paused before assuming? What did a stranger say when they read your shirt?"
              className="w-full px-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden leading-relaxed"
              required
            />
          </div>

          <div className="pt-4 flex gap-3">
            <Button type="submit" variant="primary" size="md" className="flex-1 justify-center">
              Submit to Curator Queue
            </Button>
            <Button
              type="button"
              onClick={() => setNewReflectionModalOpen(false)}
              variant="outline"
              size="md"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Modal>

      {/* MODAL: DELETE CONFIRMATION REQUIRING TYPING 'DELETE' */}
      <ConfirmDeleteModal
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        title="Confirm Account Deletion"
        itemName={`${user.fullName} (${user.email})`}
        itemType="user account"
        warningMessage="Are you certain you wish to delete your Ezistential Connections account? All saved shipping addresses, contemplation wishlist items, and personal settings will be permanently wiped from the database. This action cannot be undone."
        expectedWord="DELETE"
        onConfirm={() => {
          deleteAccount();
          setDeleteConfirmOpen(false);
        }}
      />

      {/* MODAL: DELETE ADDRESS CONFIRMATION REQUIRING TYPING 'DELETE' */}
      {addressToDelete && (
        <ConfirmDeleteModal
          isOpen={Boolean(addressToDelete)}
          onClose={() => setAddressToDelete(null)}
          title="Delete Shipping Address"
          itemName={`${addressToDelete.label}: ${addressToDelete.street}, ${addressToDelete.city}, ${addressToDelete.state}`}
          itemType="saved shipping address"
          warningMessage="This address will be permanently removed from your delivery destinations."
          expectedWord="DELETE"
          onConfirm={() => {
            deleteAddress(addressToDelete.id);
            setAddressToDelete(null);
          }}
        />
      )}

      {/* MODAL: ON-BODY REFLECTION & PHOTO UPLOAD FOR ORDER ITEM */}
      {orderReflectionModalItem && (
        <Modal
          isOpen={Boolean(orderReflectionModalItem)}
          onClose={() => setOrderReflectionModalItem(null)}
          title={`Reflection on ${orderReflectionModalItem.item.productName}`}
        >
          <form onSubmit={handleSaveOrderReflection} className="space-y-5 text-left">
            {/* Garment Summary Card */}
            <div className="flex items-center space-x-3 p-3 bg-neutral-50 border border-neutral-200 rounded-xs">
              <img
                src={orderReflectionModalItem.item.image}
                alt={orderReflectionModalItem.item.productName}
                className="w-14 h-16 object-cover bg-neutral-200 rounded-xs shrink-0"
              />
              <div className="space-y-0.5 text-xs font-mono">
                <p className="font-serif font-bold text-sm text-neutral-900">{orderReflectionModalItem.item.productName}</p>
                <p className="text-neutral-600">
                  {orderReflectionModalItem.item.wearType || 'Heavyweight Garment'} · Size {orderReflectionModalItem.item.size} · {orderReflectionModalItem.item.color}
                </p>
                <p className="text-[10px] text-neutral-400">Order #{orderReflectionModalItem.orderNumber}</p>
              </div>
            </div>

            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono font-bold text-neutral-700 mb-1">
                Your Public Encounter Reflection <span className="text-neutral-400">*</span>
              </label>
              <textarea
                rows={4}
                required
                value={orderReflectionText}
                onChange={(e) => setOrderReflectionText(e.target.value)}
                placeholder="Share a moment from your day while wearing this piece... an unexpected double-take, a conversation, or a personal contemplation."
                className="w-full bg-white border border-neutral-300 p-3 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans leading-relaxed rounded-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono font-bold text-neutral-700 mb-1">
                Location of Encounter
              </label>
              <input
                type="text"
                value={orderReflectionLocation}
                onChange={(e) => setOrderReflectionLocation(e.target.value)}
                placeholder="e.g. Seattle, WA or Blue Line Train"
                className="w-full bg-white border border-neutral-300 p-2.5 text-xs text-neutral-900 focus:outline-hidden focus:border-black font-sans rounded-xs"
              />
            </div>

            {/* On-Body Image Upload */}
            <div>
              <ImageUploadCompressor
                label="On-Body Photo Attachment (Optional)"
                value={orderReflectionPhotoUrl}
                onChange={(url) => setOrderReflectionPhotoUrl(url)}
                helperText="Upload a photo wearing this garment in public space. Auto-compressed for optimal performance."
                placeholder="Paste image URL or click below to upload photo..."
              />
            </div>

            <div className="flex items-start space-x-2 pt-1">
              <input
                type="checkbox"
                id="orderReflectionPermissionCheck"
                checked={orderReflectionPermission}
                onChange={(e) => setOrderReflectionPermission(e.target.checked)}
                className="mt-0.5 accent-black cursor-pointer"
              />
              <label htmlFor="orderReflectionPermissionCheck" className="text-xs text-neutral-600 font-sans cursor-pointer">
                I grant permission to respectfully feature this reflection &amp; photo in the curated Ezistential Human Archive.
              </label>
            </div>

            <div className="pt-3 flex items-center justify-end space-x-3 border-t border-neutral-200">
              <Button type="button" variant="outline" size="md" onClick={() => setOrderReflectionModalItem(null)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="md">
                Publish Reflection
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
