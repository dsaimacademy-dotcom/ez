import React, { useState, useMemo } from 'react';
import {
  Heart,
  ShoppingBag,
  Trash2,
  ArrowRight,
  ExternalLink,
  Plus,
  Sparkles,
  Check,
  Search,
  SlidersHorizontal,
  Edit3,
  X,
  RotateCcw,
  Tag,
  ShieldCheck,
  PackageCheck
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useProducts } from '../../context/ProductContext';
import { useCart } from '../../context/CartContext';
import { Button } from '../ui/Button';
import { Product, Size, SavedGarment } from '../../types';

export interface WishlistViewProps {
  onNavigate: (view: string, param?: string) => void;
  onSwitchTab?: (tab: 'overview' | 'verification' | 'orders' | 'wishlist' | 'reflections' | 'addresses' | 'settings') => void;
}

export const WishlistView: React.FC<WishlistViewProps> = ({ onNavigate, onSwitchTab }) => {
  const { user, toggleSavedGarment, updateSavedGarment, updateProfile } = useAuth();
  const { products } = useProducts();
  const { addItem, openCart } = useCart();

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'recent' | 'price-asc' | 'price-desc' | 'name'>('recent');

  // Local selection state for size & color per product
  const [variantSelections, setVariantSelections] = useState<
    Record<string, { size: Size; color: string }>
  >({});

  // Note editing state
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');

  // Bulk confirmation states
  const [confirmMoveAll, setConfirmMoveAll] = useState(false);
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  // Transient Toast Notification
  const [toast, setToast] = useState<{
    message: string;
    type: 'success' | 'info';
    undoAction?: () => void;
  } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' = 'success', undoAction?: () => void) => {
    setToast({ message, type, undoAction });
    const timer = setTimeout(() => {
      setToast(null);
    }, 4500);
    return () => clearTimeout(timer);
  };

  // Find saved garments matched to products
  const savedGarmentsList: SavedGarment[] = user?.savedGarments || [];

  const savedProductsWithMeta = useMemo(() => {
    return savedGarmentsList
      .map((sg) => {
        const product = products.find((p) => p.id === sg.productId || p.slug === sg.productId);
        if (!product) return null;
        return {
          product,
          meta: sg,
        };
      })
      .filter((item): item is { product: Product; meta: SavedGarment } => item !== null);
  }, [savedGarmentsList, products]);

  // Filter & Sort
  const filteredItems = useMemo(() => {
    let result = [...savedProductsWithMeta];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        ({ product, meta }) =>
          product.name.toLowerCase().includes(q) ||
          product.tagline.toLowerCase().includes(q) ||
          (meta.note && meta.note.toLowerCase().includes(q))
      );
    }

    if (sortBy === 'price-asc') {
      result.sort((a, b) => a.product.price - b.product.price);
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => b.product.price - a.product.price);
    } else if (sortBy === 'name') {
      result.sort((a, b) => a.product.name.localeCompare(b.product.name));
    } else {
      // Recent (newest savedAt first)
      result.sort(
        (a, b) => new Date(b.meta.savedAt).getTime() - new Date(a.meta.savedAt).getTime()
      );
    }

    return result;
  }, [savedProductsWithMeta, searchQuery, sortBy]);

  // Get active size & color for a product
  const getSelectedSizeAndColor = (product: Product, meta: SavedGarment): { size: Size; color: string } => {
    if (variantSelections[product.id]) {
      return variantSelections[product.id];
    }
    const defaultSize = meta.preferredSize || product.availableSizes?.[0] || ('M' as Size);
    const defaultColor = meta.preferredColor || product.availableColors[0]?.name || 'Standard';
    return { size: defaultSize, color: defaultColor };
  };

  // Handler: Change Size
  const handleSizeChange = (productId: string, size: Size) => {
    setVariantSelections((prev) => ({
      ...prev,
      [productId]: {
        size,
        color: prev[productId]?.color || products.find((p) => p.id === productId)?.availableColors[0]?.name || 'Standard',
      },
    }));
    updateSavedGarment(productId, { preferredSize: size });
  };

  // Handler: Change Color
  const handleColorChange = (productId: string, color: string) => {
    setVariantSelections((prev) => ({
      ...prev,
      [productId]: {
        size: prev[productId]?.size || (products.find((p) => p.id === productId)?.availableSizes?.[0] as Size) || 'M',
        color,
      },
    }));
    updateSavedGarment(productId, { preferredColor: color });
  };

  // Move a single garment directly to Cart (and remove from Wishlist)
  const handleMoveToCart = (product: Product, meta: SavedGarment) => {
    const { size, color } = getSelectedSizeAndColor(product, meta);

    // Find matching variant
    const matchedVariant =
      product.variants.find((v) => v.size === size && v.colorName.toLowerCase() === color.toLowerCase()) ||
      product.variants.find((v) => v.size === size) ||
      product.variants[0];

    // Add to cart bag
    addItem({
      productId: product.id,
      productSlug: product.slug,
      productName: product.name,
      price: product.price,
      image: product.primaryImage,
      variantId: matchedVariant.id,
      size: size,
      color: color,
      colorHex: matchedVariant.colorHex || '#000000',
      quantity: 1,
    });

    // Remove from wishlist
    const originalGarments = [...(user?.savedGarments || [])];
    const nextSaved = originalGarments.filter((sg) => sg.productId !== product.id && sg.id !== product.id);
    updateProfile({ savedGarments: nextSaved });

    // Toast with Undo
    showToast(
      `Moved "${product.name}" (${size} / ${color}) to your Cart.`,
      'success',
      () => {
        updateProfile({ savedGarments: originalGarments });
      }
    );
  };

  // Remove a single garment from Wishlist
  const handleRemoveFromWishlist = (product: Product) => {
    const originalGarments = [...(user?.savedGarments || [])];
    const removedItem = originalGarments.find((sg) => sg.productId === product.id || sg.id === product.id);
    const nextSaved = originalGarments.filter((sg) => sg.productId !== product.id && sg.id !== product.id);
    updateProfile({ savedGarments: nextSaved });

    showToast(
      `Removed "${product.name}" from your saved garments.`,
      'info',
      removedItem
        ? () => {
            updateProfile({ savedGarments: [...nextSaved, removedItem] });
          }
        : undefined
    );
  };

  // Move ALL filtered garments to Cart (and remove all from Wishlist)
  const handleMoveAllToCart = () => {
    if (filteredItems.length === 0) return;

    const originalGarments = [...(user?.savedGarments || [])];

    filteredItems.forEach(({ product, meta }) => {
      const { size, color } = getSelectedSizeAndColor(product, meta);
      const matchedVariant =
        product.variants.find((v) => v.size === size && v.colorName.toLowerCase() === color.toLowerCase()) ||
        product.variants[0];

      addItem({
        productId: product.id,
        productSlug: product.slug,
        productName: product.name,
        price: product.price,
        image: product.primaryImage,
        variantId: matchedVariant.id,
        size: size,
        color: color,
        colorHex: matchedVariant.colorHex || '#000000',
        quantity: 1,
      });
    });

    // Remove transferred items
    const transferredIds = new Set(filteredItems.map((item) => item.product.id));
    const nextSaved = originalGarments.filter((sg) => !transferredIds.has(sg.productId) && !transferredIds.has(sg.id));
    updateProfile({ savedGarments: nextSaved });

    setConfirmMoveAll(false);
    openCart();

    showToast(
      `All ${filteredItems.length} garments moved directly to your Cart.`,
      'success',
      () => {
        updateProfile({ savedGarments: originalGarments });
      }
    );
  };

  // Clear all wishlist items
  const handleClearAll = () => {
    const originalGarments = [...(user?.savedGarments || [])];
    updateProfile({ savedGarments: [] });
    setConfirmClearAll(false);
    showToast('Wishlist archive cleared.', 'info', () => {
      updateProfile({ savedGarments: originalGarments });
    });
  };

  // Save personal note
  const handleSaveNote = (productId: string) => {
    updateSavedGarment(productId, { note: noteText.trim() });
    setEditingNoteId(null);
    setNoteText('');
    showToast('Personal reflection note saved.');
  };

  // Calculate wishlist valuation
  const totalValuation = useMemo(() => {
    return savedProductsWithMeta.reduce((sum, item) => sum + item.product.price, 0);
  }, [savedProductsWithMeta]);

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-200">
      {/* Toast Feedback Banner */}
      {toast && (
        <div className="bg-neutral-900 text-white px-4 py-3 border border-neutral-700 shadow-xl flex items-center justify-between gap-4 animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center space-x-2.5 text-xs font-mono">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{toast.message}</span>
          </div>
          <div className="flex items-center space-x-3">
            {toast.undoAction && (
              <button
                type="button"
                onClick={() => {
                  toast.undoAction?.();
                  setToast(null);
                }}
                className="text-xs font-mono uppercase tracking-wider text-neutral-300 hover:text-white underline underline-offset-4 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Undo</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setToast(null)}
              className="text-neutral-400 hover:text-white p-1 cursor-pointer"
              aria-label="Dismiss toast"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-5">
        <div>
          <div className="flex items-center space-x-2 text-xs text-neutral-500 mb-1.5">
            {onSwitchTab ? (
              <button
                type="button"
                onClick={() => onSwitchTab('overview')}
                className="hover:text-black underline underline-offset-2 cursor-pointer font-sans"
              >
                Dashboard
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onNavigate('account')}
                className="hover:text-black underline underline-offset-2 cursor-pointer font-sans"
              >
                Dashboard
              </button>
            )}
            <span>/</span>
            <span className="text-neutral-900 font-medium font-sans">Contemplation Wishlist</span>
          </div>

          <h2 className="font-serif text-2xl sm:text-3xl text-neutral-900 tracking-tight">
            Saved Garments &amp; Wishlist
          </h2>
          <p className="text-xs text-neutral-600 mt-1 max-w-2xl font-sans leading-relaxed">
            Your personal archive of garments bookmarked for philosophical reflection and future wardrobe additions. Move pieces directly to your bag when you are ready to wear the dialogue.
          </p>
        </div>

        {/* Quick Actions in Header */}
        <div className="flex items-center gap-2.5 shrink-0">
          <Button
            type="button"
            onClick={() => onNavigate('shop')}
            variant="outline"
            size="sm"
            className="text-xs font-mono uppercase tracking-wider"
          >
            <Plus className="w-3.5 h-3.5 mr-1" />
            Explore Catalog
          </Button>

          {filteredItems.length > 0 && (
            <Button
              type="button"
              onClick={() => setConfirmMoveAll(true)}
              variant="primary"
              size="sm"
              className="text-xs font-mono uppercase tracking-wider bg-black hover:bg-neutral-800 text-white"
            >
              <ShoppingBag className="w-3.5 h-3.5 mr-1.5" />
              Move All to Cart
            </Button>
          )}
        </div>
      </div>

      {/* Confirm Move All Modal / Confirmation Prompt */}
      {confirmMoveAll && (
        <div className="p-4 bg-neutral-900 text-white border border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h4 className="font-serif text-sm font-semibold">
              Move all {filteredItems.length} saved garments to your Cart?
            </h4>
            <p className="text-xs text-neutral-400 font-sans">
              These items will be placed into your garment bag with your selected sizes and colors, and removed from this wishlist view.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setConfirmMoveAll(false)}
              className="px-3 py-1.5 text-xs font-mono uppercase tracking-wider text-neutral-300 hover:text-white border border-neutral-700 hover:border-neutral-500 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <Button
              type="button"
              onClick={handleMoveAllToCart}
              variant="primary"
              size="sm"
              className="bg-white text-black hover:bg-neutral-200 text-xs font-mono uppercase tracking-wider"
            >
              Confirm &amp; Move All
            </Button>
          </div>
        </div>
      )}

      {/* Overview Stats & Filter Bar (Shown when items exist) */}
      {savedProductsWithMeta.length > 0 && (
        <div className="bg-[#fcfbf9] border border-neutral-200 p-4 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            {/* Stats Metrics (Quiet inline unboxed metadata per Frontend Constitution) */}
            <div className="flex flex-wrap items-center gap-4 text-xs font-sans text-neutral-600">
              <div className="flex items-center space-x-1.5">
                <Heart className="w-3.5 h-3.5 text-neutral-900 fill-neutral-900" />
                <span className="font-semibold text-neutral-900 font-mono">
                  {savedProductsWithMeta.length} {savedProductsWithMeta.length === 1 ? 'Garment' : 'Garments'} Saved
                </span>
              </div>
              <span aria-hidden="true" className="text-neutral-300">·</span>
              <div className="flex items-center space-x-1.5">
                <span className="text-neutral-500 font-mono uppercase text-[11px]">Total Valuation:</span>
                <span className="font-semibold text-neutral-900 font-mono">${totalValuation}</span>
              </div>
              <span aria-hidden="true" className="text-neutral-300">·</span>
              <div className="flex items-center space-x-1 text-emerald-700 font-mono text-[11px]">
                <PackageCheck className="w-3.5 h-3.5" />
                <span>Made-to-Order Ready</span>
              </div>
            </div>

            {/* Clear All Wishlist trigger */}
            <button
              type="button"
              onClick={() => setConfirmClearAll(true)}
              className="text-[11px] font-mono uppercase tracking-wider text-neutral-500 hover:text-red-700 transition-colors flex items-center gap-1 cursor-pointer self-start md:self-auto"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear Wishlist</span>
            </button>
          </div>

          {/* Confirm Clear All prompt */}
          {confirmClearAll && (
            <div className="p-3 bg-red-50 border border-red-200 flex items-center justify-between text-xs text-red-900">
              <span>Are you sure you want to remove all saved garments from your archive?</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmClearAll(false)}
                  className="px-2.5 py-1 text-xs border border-red-300 hover:bg-red-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleClearAll}
                  className="px-2.5 py-1 text-xs bg-red-700 text-white hover:bg-red-800 font-semibold cursor-pointer"
                >
                  Yes, Clear All
                </button>
              </div>
            </div>
          )}

          {/* Search & Sort Controls */}
          <div className="pt-3 border-t border-neutral-200/80 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search saved garments or notes..."
                className="w-full pl-8 pr-3 py-1.5 text-xs font-sans bg-white border border-neutral-300 focus:outline-none focus:border-black transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 p-0.5 cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
              <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-500" />
              <span className="text-xs font-mono text-neutral-500 uppercase tracking-wider text-[10px]">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="text-xs font-sans bg-white border border-neutral-300 py-1.5 px-2.5 focus:outline-none focus:border-black cursor-pointer"
              >
                <option value="recent">Recently Bookmarked</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="name">Garment Name (A-Z)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Main Grid or Empty State */}
      {filteredItems.length === 0 ? (
        <div className="bg-white border border-neutral-200 p-10 sm:p-16 text-center space-y-6">
          <div className="w-14 h-14 rounded-full bg-neutral-100 border border-neutral-200 flex items-center justify-center mx-auto text-neutral-400">
            <Heart className="w-7 h-7 stroke-[1.2]" />
          </div>

          <div className="space-y-2 max-w-md mx-auto">
            <h3 className="font-serif text-xl sm:text-2xl text-neutral-900">
              {searchQuery ? 'No matching saved garments found' : 'Your Contemplation Archive is Empty'}
            </h3>
            <p className="text-xs text-neutral-600 font-sans leading-relaxed">
              {searchQuery
                ? `No bookmarked garments matched "${searchQuery}". Try clearing your search term.`
                : 'Ezistential Connections garments are deliberate expressions of human connection. Bookmark pieces while exploring our collections to contemplate them here.'}
            </p>
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            {searchQuery ? (
              <Button type="button" onClick={() => setSearchQuery('')} variant="outline" size="sm">
                Clear Search
              </Button>
            ) : (
              <Button
                type="button"
                onClick={() => onNavigate('shop')}
                variant="primary"
                size="md"
                className="bg-black hover:bg-neutral-800 text-white font-mono text-xs uppercase tracking-wider"
              >
                Browse Garment Catalog
              </Button>
            )}
          </div>

          {/* Featured Suggestions if empty */}
          {!searchQuery && products.length > 0 && (
            <div className="mt-12 pt-10 border-t border-neutral-200/80 text-left">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] uppercase font-mono tracking-widest text-neutral-500">
                  Recommended For Your Dialogue
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate('shop')}
                  className="text-xs font-mono text-neutral-900 hover:underline cursor-pointer"
                >
                  View All &rarr;
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {products.slice(0, 3).map((p) => (
                  <div
                    key={p.id}
                    className="border border-neutral-200 bg-[#fdfdfd] p-3 flex items-center gap-3 hover:border-neutral-400 transition-colors"
                  >
                    <img
                      src={p.primaryImage}
                      alt={p.name}
                      className="w-16 h-20 object-cover bg-neutral-100 shrink-0"
                    />
                    <div className="min-w-0 space-y-1">
                      <h4 className="font-serif text-xs font-semibold text-neutral-900 truncate">
                        {p.name}
                      </h4>
                      <p className="font-mono text-xs text-neutral-800">${p.price}</p>
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => toggleSavedGarment(p.id)}
                          className="text-[10px] font-mono text-neutral-700 hover:text-black underline cursor-pointer flex items-center gap-1"
                        >
                          <Heart className="w-3 h-3 text-red-500 fill-red-500" />
                          <span>Bookmark</span>
                        </button>
                        <span>·</span>
                        <button
                          type="button"
                          onClick={() => onNavigate('product', p.id)}
                          className="text-[10px] font-mono text-neutral-500 hover:text-black cursor-pointer"
                        >
                          Examine
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Garment Cards Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map(({ product, meta }) => {
            const currentSelection = getSelectedSizeAndColor(product, meta);
            const isEditingThisNote = editingNoteId === product.id;

            return (
              <div
                key={product.id}
                className="bg-white border border-neutral-200 shadow-xs flex flex-col justify-between group hover:border-neutral-400 transition-all duration-200 relative"
              >
                <div>
                  {/* Image Container with Hover Overlay & Quick Remove */}
                  <div className="relative aspect-4/5 overflow-hidden bg-neutral-100">
                    <img
                      src={product.primaryImage}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500 cursor-pointer"
                      onClick={() => onNavigate('product', product.id)}
                    />

                    {/* Bookmark Heart Indicator & Remove Trigger */}
                    <button
                      type="button"
                      onClick={() => handleRemoveFromWishlist(product)}
                      className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/95 backdrop-blur-xs flex items-center justify-center text-red-600 hover:scale-110 hover:bg-white transition-all shadow-xs cursor-pointer group/heart"
                      title="Remove from wishlist"
                      aria-label={`Remove ${product.name} from wishlist`}
                    >
                      <Heart className="w-4 h-4 fill-red-600 text-red-600 group-hover/heart:hidden" />
                      <X className="w-4 h-4 text-neutral-700 hidden group-hover/heart:block" />
                    </button>

                    {/* Quick Examine Overlay on bottom of image */}
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 via-transparent to-transparent p-3 flex justify-between items-end opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        onClick={() => onNavigate('product', product.id)}
                        className="text-[11px] font-mono text-white hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <span>Examine Story</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                      <span className="text-[10px] font-mono text-neutral-300">
                        Saved {new Date(meta.savedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  {/* Garment Details */}
                  <div className="p-5 space-y-4">
                    {/* Header: Title & Pricing */}
                    <div>
                      <div className="flex items-center justify-between text-[10px] uppercase font-mono tracking-widest text-neutral-400 mb-1">
                        <span>Core Thesis</span>
                        <span className="text-emerald-700 font-mono font-medium">In Studio</span>
                      </div>
                      <div className="flex justify-between items-start gap-2">
                        <h3
                          onClick={() => onNavigate('product', product.id)}
                          className="font-serif text-lg text-neutral-900 hover:text-neutral-600 cursor-pointer transition-colors"
                        >
                          {product.name}
                        </h3>
                        <div className="text-right shrink-0">
                          <span className="font-mono text-base font-semibold text-neutral-900 block">
                            ${product.price}
                          </span>
                          {product.compareAtPrice && product.compareAtPrice > product.price && (
                            <span className="font-mono text-xs text-neutral-400 line-through block">
                              ${product.compareAtPrice}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Philosophical Statement Tagline */}
                    <p className="font-serif italic text-xs text-neutral-600 border-l border-neutral-300 pl-3 line-clamp-2">
                      "{product.tagline}"
                    </p>

                    {/* Size Preference Selector */}
                    {product.availableSizes && product.availableSizes.length > 0 && (
                      <div className="space-y-1.5 pt-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500">
                            Select Size:
                          </span>
                          <span className="text-[11px] font-mono font-semibold text-neutral-900">
                            {currentSelection.size}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {product.availableSizes.map((s: Size) => (
                            <button
                              key={s}
                              type="button"
                              onClick={() => handleSizeChange(product.id, s)}
                              className={`px-2 py-1 text-[11px] font-mono border transition-colors cursor-pointer ${
                                currentSelection.size === s
                                  ? 'bg-black text-white border-black font-semibold'
                                  : 'bg-white text-neutral-700 border-neutral-200 hover:border-black'
                              }`}
                            >
                              {s}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Color Preference Selector */}
                    {product.availableColors && product.availableColors.length > 1 && (
                      <div className="space-y-1.5 pt-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500">
                            Select Colorway:
                          </span>
                          <span className="text-[11px] font-mono text-neutral-700">
                            {currentSelection.color}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          {product.availableColors.map((c) => (
                            <button
                              key={c.name}
                              type="button"
                              onClick={() => handleColorChange(product.id, c.name)}
                              title={c.name}
                              className={`w-6 h-6 rounded-full border p-0.5 transition-transform cursor-pointer ${
                                currentSelection.color.toLowerCase() === c.name.toLowerCase()
                                  ? 'border-black scale-110 shadow-xs'
                                  : 'border-transparent hover:border-neutral-400'
                              }`}
                            >
                              <span
                                className="w-full h-full rounded-full block border border-neutral-300"
                                style={{ backgroundColor: c.hex }}
                              />
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Personal Reflection Note */}
                    <div className="pt-2 border-t border-neutral-100">
                      {isEditingThisNote ? (
                        <div className="space-y-2 bg-neutral-50 p-2.5 border border-neutral-300">
                          <label className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 block">
                            Contemplation Note
                          </label>
                          <textarea
                            value={noteText}
                            onChange={(e) => setNoteText(e.target.value)}
                            placeholder="Why did you bookmark this garment? (e.g. spring conference, gift for a philosopher)"
                            className="w-full text-xs font-sans p-2 bg-white border border-neutral-300 focus:outline-none focus:border-black"
                            rows={2}
                          />
                          <div className="flex justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingNoteId(null);
                                setNoteText('');
                              }}
                              className="px-2 py-1 text-[11px] font-mono text-neutral-600 hover:text-black cursor-pointer"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveNote(product.id)}
                              className="px-2.5 py-1 text-[11px] font-mono bg-black text-white hover:bg-neutral-800 cursor-pointer"
                            >
                              Save Note
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-start justify-between gap-2 group/note">
                          {meta.note ? (
                            <div className="bg-neutral-50 p-2.5 border border-neutral-200 text-xs text-neutral-700 flex-1">
                              <span className="text-[9px] uppercase font-mono tracking-wider text-neutral-400 block mb-0.5">
                                Personal Note:
                              </span>
                              <p className="italic font-sans text-neutral-800 leading-relaxed">
                                {meta.note}
                              </p>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                setEditingNoteId(product.id);
                                setNoteText(meta.note || '');
                              }}
                              className="text-[11px] font-sans text-neutral-400 hover:text-neutral-700 italic flex items-center gap-1 cursor-pointer py-1"
                            >
                              <Edit3 className="w-3 h-3" />
                              <span>Add a personal contemplation note...</span>
                            </button>
                          )}

                          {meta.note && (
                            <button
                              type="button"
                              onClick={() => {
                                setEditingNoteId(product.id);
                                setNoteText(meta.note || '');
                              }}
                              className="text-neutral-400 hover:text-black p-1 cursor-pointer shrink-0"
                              title="Edit personal note"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Card Bottom CTA Actions (Direct Move to Cart and Explicit Remove) */}
                <div className="p-5 pt-0 border-t border-neutral-100 mt-2 space-y-2">
                  <div className="flex items-center gap-2 pt-3">
                    {/* Primary Action: Move to Cart */}
                    <button
                      type="button"
                      onClick={() => handleMoveToCart(product, meta)}
                      className="flex-1 bg-black hover:bg-neutral-800 text-white py-2.5 px-3 text-xs font-mono font-medium uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs active:scale-[0.99]"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Move to Cart</span>
                    </button>

                    {/* Secondary Action: Remove */}
                    <button
                      type="button"
                      onClick={() => handleRemoveFromWishlist(product)}
                      className="p-2.5 text-neutral-500 hover:text-red-700 hover:bg-red-50 border border-neutral-300 hover:border-red-300 transition-colors cursor-pointer shrink-0"
                      title="Remove from saved garments"
                      aria-label={`Remove ${product.name} from wishlist`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Examine Link */}
                  <div className="text-center pt-1">
                    <button
                      type="button"
                      onClick={() => onNavigate('product', product.id)}
                      className="text-[11px] font-mono uppercase tracking-wider text-neutral-500 hover:text-black underline underline-offset-2 cursor-pointer transition-colors"
                    >
                      Examine Full Garment Story &rarr;
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
