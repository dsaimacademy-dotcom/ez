import React from 'react';
import { ShieldCheck, Lock, EyeOff, Server, UserCheck, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';

export interface PrivacyPolicyPageProps {
  onBackToStore: () => void;
  onNavigateToContact: () => void;
}

export const PrivacyPolicyPage: React.FC<PrivacyPolicyPageProps> = ({
  onBackToStore,
  onNavigateToContact,
}) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 space-y-12">
      {/* Header */}
      <div className="border-b border-neutral-200 pb-8 space-y-3">
        <button
          onClick={onBackToStore}
          className="text-xs uppercase tracking-wider text-neutral-500 hover:text-black flex items-center gap-1.5 cursor-pointer font-medium mb-2"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Return to Storefront</span>
        </button>
        <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
          Legal & Ethical Safeguards
        </span>
        <h1 className="font-serif text-4xl sm:text-5xl text-neutral-900 tracking-tight">
          Privacy Policy & Digital Dignity
        </h1>
        <p className="text-xs text-neutral-500 font-mono">
          Effective Date: February 2026 • Last Reviewed: Stage 6 Architecture Audit
        </p>
      </div>

      {/* Core Privacy Conviction */}
      <div className="bg-[#f5f4f0] p-6 sm:p-8 border border-neutral-300 space-y-3">
        <div className="flex items-center space-x-2 text-neutral-900 font-medium text-xs uppercase tracking-wider">
          <EyeOff className="w-4 h-4 text-neutral-700" />
          <span>Our Foundation Principle</span>
        </div>
        <p className="font-serif italic text-lg sm:text-xl text-neutral-900 leading-snug">
          "The space between us should not be surveilled, monetized, or sold to brokers."
        </p>
        <p className="text-xs text-neutral-600 leading-relaxed font-sans font-light">
          Ezistential Connections exists to encourage authentic, tactile human connection in public space. We do not operate advertising networks, behavioral tracking cookies, or data aggregation models. We collect only what is necessary to craft and deliver your garments.
        </p>
      </div>

      {/* Structured Sections */}
      <div className="space-y-10 text-xs sm:text-sm text-neutral-700 leading-relaxed font-sans font-light">
        {/* Section 1 */}
        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            1. Information We Collect
          </h2>
          <p>
            When you interact with our storefront or place an order, we collect specific information solely to execute that transaction:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-neutral-600 text-xs sm:text-sm">
            <li>
              <strong>Customer Identification & Contact:</strong> Full name and email address for order notifications, electronic receipts, and tracking dispatch confirmations.
            </li>
            <li>
              <strong>Fulfillment Address:</strong> Domestic US delivery address (street, unit, city, state, zip code) required for physical package routing.
            </li>
            <li>
              <strong>Payment Security:</strong> Card payments are securely processed through PCI-DSS Level 1 compliant tokenized payment handlers. We never store, inspect, or hold raw credit card or security CVV numbers on our servers.
            </li>
            <li>
              <strong>Community Reflections:</strong> Reflections submitted through the "What does this mean to you?" portal are collected only when you choose to share your thoughts.
            </li>
          </ul>
        </div>

        {/* Section 2 */}
        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            2. How Information Is Shared (Strict Operational Parity)
          </h2>
          <p>
            We do <strong>not</strong> sell, license, or barter your information to advertisers, marketing brokers, or data analytics firms. We share data solely with verified operational partners:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="border border-neutral-300 p-4 bg-white space-y-1.5">
              <span className="font-medium text-neutral-900 text-xs uppercase font-mono block">On-Demand Print Partner</span>
              <p className="text-xs text-neutral-600">
                Apliiq (Los Angeles, CA) receives your garment specifications (size, color, print motif) and shipping destination to produce and label your box.
              </p>
            </div>
            <div className="border border-neutral-300 p-4 bg-white space-y-1.5">
              <span className="font-medium text-neutral-900 text-xs uppercase font-mono block">Postal Carrier</span>
              <p className="text-xs text-neutral-600">
                The United States Postal Service (USPS) receives your destination address to execute domestic transit and supply door-to-door tracking status.
              </p>
            </div>
          </div>
        </div>

        {/* Section 3 */}
        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            3. Customer Reflection Submissions & Moderation
          </h2>
          <p>
            Ezistential Connections invites public reflection on human difference. When you submit a thought to our Connection archive:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-neutral-600 text-xs sm:text-sm">
            <li>Submissions remain private in our moderation queue until reviewed by our editorial team.</li>
            <li>
              We will <strong>never</strong> publish your reflection unless you explicitly check the permission checkbox giving consent.
            </li>
            <li>Your private email address is never published or visible to visitors.</li>
            <li>You can request removal of your featured quote at any time by contacting our care team.</li>
          </ul>
        </div>

        {/* Section 4 */}
        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            4. Your Rights & Data Erasure
          </h2>
          <p>
            Under US state privacy guidelines (including CCPA / CPRA), you retain the right to:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-neutral-600 text-xs sm:text-sm">
            <li>Request a full export of your personal information held in our records.</li>
            <li>Request permanent correction or deletion of your customer history.</li>
            <li>Opt out of any future marketing or brand editorial communications with a single click.</li>
          </ul>
        </div>

        {/* Section 5 */}
        <div className="space-y-3 border-t border-neutral-200 pt-6">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            5. Inquiries & Care Team Contact
          </h2>
          <p>
            For any questions, requests, or privacy concerns, reach out directly to our stewardship team at:
          </p>
          <div className="font-mono text-xs text-neutral-900 bg-white border border-neutral-300 p-4 inline-block">
            Ezistential Connections Stewardship<br />
            Email: <a href="mailto:care@ezistential.com" className="underline font-semibold">care@ezistential.com</a><br />
            Subject: Privacy Rights Inquiry
          </div>
        </div>
      </div>

      {/* Footer Navigation */}
      <div className="pt-6 border-t border-neutral-200 flex justify-between items-center text-xs">
        <Button onClick={onBackToStore} variant="outline" size="sm">
          Return to Storefront
        </Button>
        <Button onClick={onNavigateToContact} variant="ghost" size="sm">
          Send Inquiries →
        </Button>
      </div>
    </div>
  );
};
