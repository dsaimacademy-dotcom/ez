import React from 'react';
import { FileText, ShieldAlert, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { Button } from '../ui/Button';

export interface TermsOfServicePageProps {
  onBackToStore: () => void;
  onNavigateToContact: () => void;
}

export const TermsOfServicePage: React.FC<TermsOfServicePageProps> = ({
  onBackToStore,
  onNavigateToContact,
}) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 space-y-12">
      {/* Header */}
      <div className="border-b border-neutral-200 pb-8 space-y-3">
        <button
          onClick={onBackToStore}
          className="text-xs uppercase tracking-wider text-neutral-500 hover:text-black flex items-center gap-1.5 cursor-pointer font-medium mb-2"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Return to Storefront</span>
        </button>
        <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
          Operating Framework
        </span>
        <h1 className="font-serif text-4xl sm:text-5xl text-neutral-900 tracking-tight">
          Terms of Service & Garment Covenant
        </h1>
        <p className="text-xs text-neutral-500 font-mono">
          Last Updated: February 2026 • Governed by US Domestic Standards
        </p>
      </div>

      {/* Intro Note */}
      <div className="bg-[#f5f4f0] p-6 sm:p-8 border border-neutral-300 space-y-3">
        <div className="flex items-center space-x-2 text-neutral-900 font-medium text-xs uppercase tracking-wider">
          <FileText className="w-4 h-4 text-neutral-700" />
          <span>The Wearer Relationship</span>
        </div>
        <p className="font-serif italic text-lg sm:text-xl text-neutral-900 leading-snug">
          "When you purchase from Ezistential Connections, you are not simply acquiring cotton; you are carrying an inquiry into public space."
        </p>
        <p className="text-xs text-neutral-600 leading-relaxed font-sans font-light">
          These Terms set out the legal terms governing purchases, our made-to-order manufacturing process, community reflection participation, and intellectual property ownership.
        </p>
      </div>

      {/* Clauses */}
      <div className="space-y-10 text-xs sm:text-sm text-neutral-700 leading-relaxed font-sans font-light">
        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            1. Made-to-Order Fulfillment Process
          </h2>
          <p>
            To prevent excessive textile waste and landfill accumulation, our garments are manufactured on demand. When your order is placed and confirmed:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-neutral-600 text-xs sm:text-sm">
            <li>Production commences within 24 to 48 hours at our domestic partner facility in Los Angeles, California.</li>
            <li>Production spans 2 to 4 business days, followed by domestic delivery of 3 to 5 business days via USPS.</li>
            <li>Because items are printed upon order, address modifications must be requested within 2 hours of checkout submission.</li>
          </ul>
        </div>

        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            2. Intellectual Property & Brand Assets
          </h2>
          <p>
            All graphic designs, typographic compositions, the registered <strong>Zebra Z motif</strong>, the "Ezistential Connections" wordmark, product photography, editorial writings, and the Brand Manifesto are the exclusive intellectual property of Ezistential Connections.
          </p>
          <p>
            Purchasing a garment conveys physical ownership of the clothing, but does not grant rights to reproduce, commercialize, or replicate the proprietary artwork or trademarked logos.
          </p>
        </div>

        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            3. Community Reflections Code of Conduct
          </h2>
          <p>
            Visitors and customers submitting reflections through our "What does this mean to you?" portal agree to uphold thoughtful, civil human dialogue:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-neutral-600 text-xs sm:text-sm">
            <li>Submissions must be original thoughts reflecting personal observations on connection, distance, or difference.</li>
            <li>We maintain zero tolerance for hate speech, harassment, derogatory slurs, defamatory statements, or commercial advertising.</li>
            <li>Our editorial team reserves sole discretion to reject, unpublish, or delete submissions that violate these civil standards.</li>
          </ul>
        </div>

        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            4. Quality Guarantee & Exchanges
          </h2>
          <p>
            We stand firmly behind the heavyweight construction of our 6.5oz ring-spun cotton and DTF prints. As detailed in our <strong>Shipping & Returns Policy</strong>, defective items, misprints, or shipping errors are replaced or refunded within our 30-day inspection window at zero expense to the customer.
          </p>
        </div>

        <div className="space-y-3">
          <h2 className="font-serif text-xl sm:text-2xl text-neutral-900 font-normal">
            5. Governing Law & Dispute Resolution
          </h2>
          <p>
            These Terms and all commercial transactions shall be governed by and construed in accordance with the laws of the State of Illinois, without regard to conflict of law principles. Any dispute arising from these terms shall be resolved through good-faith informal consultation prior to any formal dispute venue.
          </p>
        </div>
      </div>

      {/* Footer Navigation */}
      <div className="pt-6 border-t border-neutral-200 flex justify-between items-center text-xs">
        <Button onClick={onBackToStore} variant="outline" size="sm">
          Return to Storefront
        </Button>
        <Button onClick={onNavigateToContact} variant="ghost" size="sm">
          Contact Care Team →
        </Button>
      </div>
    </div>
  );
};
