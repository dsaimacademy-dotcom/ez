import React, { useState } from 'react';
import { usePosts } from '../../context/PostContext';
import { BlogPost } from '../../types';
import { Calendar, Clock, User, ArrowRight, Tag, BookOpen, Share2, Search, Filter, ArrowLeft, Play, Pause, Bookmark, Check } from 'lucide-react';
import { Button } from '../ui/Button';

interface JournalUpdatesPageProps {
  onNavigateToShop: () => void;
  onNavigateToHome: () => void;
}

export const JournalUpdatesPage: React.FC<JournalUpdatesPageProps> = ({
  onNavigateToShop,
  onNavigateToHome,
}) => {
  const { posts } = usePosts();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activePost, setActivePost] = useState<BlogPost | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    return JSON.parse(localStorage.getItem('ec_bookmarked_essays') || '[]');
  });

  const handleToggleBookmark = (id: string) => {
    const updated = bookmarkedIds.includes(id)
      ? bookmarkedIds.filter((b) => b !== id)
      : [...bookmarkedIds, id];
    setBookmarkedIds(updated);
    localStorage.setItem('ec_bookmarked_essays', JSON.stringify(updated));
  };

  const publishedPosts = posts.filter((p) => p.isPublished !== false);

  const categories = ['All', ...Array.from(new Set(publishedPosts.map((p) => p.category)))];

  const filteredPosts = publishedPosts.filter((post) => {
    const matchesCat = selectedCategory === 'All' || post.category === selectedCategory;
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const featuredPost = publishedPosts.find((p) => p.isFeatured) || publishedPosts[0];

  return (
    <div className="min-h-screen bg-[#fcfbf9] text-neutral-900 pt-24 pb-20">
      {/* Header Banner */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="border-b border-neutral-300 pb-8 space-y-3">
          <div className="flex items-center space-x-2 text-xs font-mono uppercase tracking-widest text-neutral-500">
            <BookOpen className="w-3.5 h-3.5 text-neutral-700" />
            <span>Journal & Journal Updates</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold text-neutral-900 tracking-tight">
            Updates, Essays & Reflections
          </h1>
          <p className="text-sm sm:text-base text-neutral-600 max-w-2xl font-sans leading-relaxed">
            Quiet inquiries, garment craftsmanship, studio dispatches, and curated perspectives on the space between people.
          </p>
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-6">
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-mono transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-neutral-900 text-white font-semibold'
                    : 'bg-white border border-neutral-300 text-neutral-600 hover:border-black'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search updates..."
              className="w-full bg-white border border-neutral-300 pl-9 pr-3 py-1.5 text-xs text-neutral-900 font-sans focus:outline-hidden focus:border-black"
            />
          </div>
        </div>
      </div>

      {/* Reader Modal / View when Post is clicked */}
      {activePost ? (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-in fade-in duration-200">
          <button
            onClick={() => setActivePost(null)}
            className="inline-flex items-center space-x-2 text-xs font-mono uppercase text-neutral-600 hover:text-black transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Updates</span>
          </button>

          <div className="bg-white border border-neutral-200 p-6 sm:p-10 space-y-8 shadow-xs">
            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-xs font-mono text-neutral-500">
                <span className="px-2 py-0.5 bg-neutral-100 text-neutral-800 font-semibold uppercase text-[10px]">
                  {activePost.category}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-neutral-400" />
                  <span>{new Date(activePost.publishedAt).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</span>
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-neutral-400" />
                  <span>{activePost.readTimeMinutes} min read</span>
                </span>
              </div>

              <h1 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-extrabold text-neutral-900 leading-tight">
                {activePost.title}
              </h1>

              <div className="flex items-center justify-between border-y border-neutral-100 py-3 text-xs font-mono text-neutral-600">
                <div className="flex items-center space-x-2">
                  <User className="w-3.5 h-3.5 text-neutral-500" />
                  <span className="font-semibold text-neutral-900">{activePost.authorName}</span>
                  {activePost.authorRole && <span className="text-neutral-400">({activePost.authorRole})</span>}
                </div>
              </div>
            </div>

            {activePost.coverImage && (
              <div className="aspect-video w-full overflow-hidden bg-neutral-100 border border-neutral-200">
                <img
                  src={activePost.coverImage}
                  alt={activePost.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {/* Audio Dispatch Narration Player Bar */}
            <div className="bg-[#121212] text-white p-4 border border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 font-mono text-xs">
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => setIsPlayingAudio(!isPlayingAudio)}
                  className="p-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-full transition-all cursor-pointer shadow-sm hover:scale-105 shrink-0"
                >
                  {isPlayingAudio ? (
                    <Pause className="w-4 h-4 text-emerald-400 fill-emerald-400" />
                  ) : (
                    <Play className="w-4 h-4 text-emerald-400 fill-emerald-400 ml-0.5" />
                  )}
                </button>
                <div>
                  <span className="font-bold text-neutral-100 block text-xs">
                    {isPlayingAudio ? 'Now Playing Narration...' : 'Listen to Audio Dispatch'}
                  </span>
                  <span className="text-[10px] text-neutral-400 block font-mono">
                    Recorded Studio Dispatch • {activePost.readTimeMinutes}:30 min
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleToggleBookmark(activePost.id)}
                  className={`px-3 py-1.5 border text-xs font-mono transition-colors cursor-pointer flex items-center gap-1.5 ${
                    bookmarkedIds.includes(activePost.id)
                      ? 'bg-amber-100 text-amber-950 border-amber-300 font-bold'
                      : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border-neutral-700'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${bookmarkedIds.includes(activePost.id) ? 'fill-amber-950' : ''}`} />
                  <span>{bookmarkedIds.includes(activePost.id) ? 'Bookmarked' : 'Bookmark Essay'}</span>
                </button>
              </div>
            </div>

            <div className="prose font-serif text-neutral-800 text-base leading-relaxed space-y-6 max-w-none [&_iframe]:w-full [&_iframe]:aspect-video [&_a]:text-blue-600 [&_a]:underline [&_a]:underline-offset-2">
              {(() => {
                const formatHtmlContent = (text: string) => {
                  if (!text) return '';
                  let html = text;
                  // Automatically embed YouTube watch URLs or youtu.be links
                  html = html.replace(
                    /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/g,
                    '<div class="my-6 aspect-video w-full rounded-sm overflow-hidden shadow-md border border-neutral-300"><iframe width="100%" height="100%" src="https://www.youtube.com/embed/$1" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="w-full h-full"></iframe></div>'
                  );
                  // Automatically make raw URLs clickable if not inside tags
                  html = html.replace(
                    /(^|[^"'])(https?:\/\/[^\s<]+)/g,
                    '$1<a href="$2" target="_blank" rel="noopener noreferrer" class="text-blue-600 underline underline-offset-2 hover:text-blue-800 font-medium">$2</a>'
                  );
                  return html;
                };

                return (
                  <div
                    dangerouslySetInnerHTML={{ __html: formatHtmlContent(activePost.content) }}
                  />
                );
              })()}
            </div>

            {activePost.tags && activePost.tags.length > 0 && (
              <div className="pt-6 border-t border-neutral-100 flex flex-wrap items-center gap-2">
                <Tag className="w-3.5 h-3.5 text-neutral-400" />
                {activePost.tags.map((tag, tIdx) => (
                  <span key={tIdx} className="px-2 py-0.5 bg-neutral-100 text-neutral-600 text-[10px] font-mono">
                    #{tag}
                  </span>
                ))}
              </div>
            )}

            <div className="pt-6 border-t border-neutral-200 flex items-center justify-between">
              <Button variant="outline" size="sm" onClick={onNavigateToShop}>
                Explore Garments
              </Button>
              <Button variant="primary" size="sm" onClick={() => setActivePost(null)}>
                Close Article
              </Button>
            </div>
          </div>
        </div>
      ) : (
        /* Blog Article Grid */
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {/* Featured Post Card */}
          {featuredPost && selectedCategory === 'All' && !searchQuery && (
            <div
              onClick={() => setActivePost(featuredPost)}
              className="group bg-white border border-neutral-300 overflow-hidden grid grid-cols-1 lg:grid-cols-12 cursor-pointer hover:border-black transition-all shadow-xs"
            >
              <div className="lg:col-span-7 aspect-video lg:aspect-auto overflow-hidden bg-neutral-100 relative">
                <img
                  src={featuredPost.coverImage}
                  alt={featuredPost.title}
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                />
                <span className="absolute top-4 left-4 bg-black text-white px-2.5 py-1 text-[10px] font-mono uppercase font-bold tracking-wider">
                  Featured Dispatch
                </span>
              </div>
              <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center space-x-2 text-xs font-mono text-neutral-500">
                    <span>{featuredPost.category}</span>
                    <span>•</span>
                    <span>{featuredPost.readTimeMinutes} min read</span>
                  </div>
                  <h2 className="font-serif text-xl sm:text-2xl font-bold text-neutral-900 group-hover:underline">
                    {featuredPost.title}
                  </h2>
                  <p className="text-xs sm:text-sm text-neutral-600 font-sans leading-relaxed line-clamp-3">
                    {featuredPost.excerpt}
                  </p>
                </div>

                <div className="pt-4 border-t border-neutral-100 flex items-center justify-between text-xs font-mono text-neutral-900 font-semibold">
                  <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    <span>Read Full Update</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                  <span className="text-neutral-400 font-normal">
                    {new Date(featuredPost.publishedAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Grid of Articles */}
          {filteredPosts.length === 0 ? (
            <div className="text-center py-16 bg-white border border-neutral-200 p-8 space-y-3">
              <BookOpen className="w-8 h-8 text-neutral-400 mx-auto" />
              <h3 className="font-serif text-lg font-bold text-neutral-900">No Journal Updates Found</h3>
              <p className="text-xs text-neutral-500">Try adjusting your search query or category filter.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post) => (
                <div
                  key={post.id}
                  onClick={() => setActivePost(post)}
                  className="group bg-white border border-neutral-200 hover:border-black transition-all flex flex-col justify-between cursor-pointer shadow-xs"
                >
                  <div className="space-y-4">
                    <div className="aspect-video w-full overflow-hidden bg-neutral-100 border-b border-neutral-200">
                      <img
                        src={post.coverImage}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-5 space-y-3">
                      <div className="flex items-center justify-between text-[11px] font-mono text-neutral-500">
                        <span className="uppercase font-semibold text-neutral-800">{post.category}</span>
                        <span>{post.readTimeMinutes} min read</span>
                      </div>
                      <h3 className="font-serif text-base font-bold text-neutral-900 group-hover:underline leading-snug">
                        {post.title}
                      </h3>
                      <p className="text-xs text-neutral-600 font-sans line-clamp-3 leading-relaxed">
                        {post.excerpt}
                      </p>
                    </div>
                  </div>

                  <div className="p-5 pt-0 mt-4 flex items-center justify-between text-[11px] font-mono border-t border-neutral-100 pt-3 text-neutral-500">
                    <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
                    <span className="text-black font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      <span>Read</span>
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
