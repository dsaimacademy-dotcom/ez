import React, { useState } from 'react';
import {
  ArrowLeft,
  Mail,
  Phone,
  MapPin,
  Clock,
  Send,
  CheckCircle2,
  ShieldCheck,
  Instagram,
  Twitter,
  Youtube,
  Music,
  Bookmark,
  Share2,
  Facebook,
  Linkedin
} from 'lucide-react';
import { Button } from '../ui/Button';
import { useContent } from '../../context/ContentContext';

export interface ContactPageProps {
  onBackToStore: () => void;
  onNavigateToFaq?: () => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onBackToStore, onNavigateToFaq }) => {
  const { content } = useContent();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState<'General Inquiry' | 'Order & Transit' | 'Sizing & Blanks' | 'Editorial & Press'>('General Inquiry');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email || !message) return;
    setIsSubmitted(true);
  };

  // Only filled active socials
  const activeSocials = [
    { label: 'Instagram', url: content.instagramUrl, icon: Instagram },
    { label: 'Twitter / X', url: content.twitterUrl, icon: Twitter },
    { label: 'Spotify', url: content.spotifyUrl, icon: Music },
    { label: 'Substack', url: content.substackUrl, icon: Bookmark },
    { label: 'YouTube', url: content.youtubeUrl, icon: Youtube },
    { label: 'Facebook', url: content.facebookUrl, icon: Facebook },
    { label: 'LinkedIn', url: content.linkedinUrl, icon: Linkedin },
    { label: 'TikTok', url: content.tiktokUrl, icon: Share2 },
    { label: 'Pinterest', url: content.pinterestUrl, icon: Bookmark },
    { label: 'Discord', url: content.discordUrl, icon: Share2 },
  ].filter((s) => s.url && s.url.trim().length > 0);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 space-y-12 animate-in fade-in duration-300">
      {/* Header */}
      <div className="border-b border-neutral-200 pb-8 space-y-3">
        <button
          onClick={onBackToStore}
          className="text-xs uppercase tracking-wider text-neutral-500 hover:text-black flex items-center gap-1.5 cursor-pointer font-medium mb-2"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Return to Storefront</span>
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 block">
            Direct Studio Inquiries
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
        </div>
        <h1 className="font-serif text-4xl sm:text-5xl text-neutral-900 tracking-tight">
          {content.contactPageTitle || 'Customer Care & Studio Directory'}
        </h1>
        <p className="text-sm text-neutral-600 font-sans max-w-2xl font-light">
          {content.contactPageSubtitle || `${content.brandName} operates with thoughtful care. Whether you have questions regarding 6.5oz cotton sizing, domestic USPS tracking, or garment philosophy, our team is directly available.`}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Contact Information & Physical Studio */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#141414] text-white p-6 sm:p-8 space-y-6 border border-neutral-800">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 block mb-1">
                Design Studio & Operations
              </span>
              <h3 className="font-serif text-xl text-white">{content.legalBusinessName || content.brandName}</h3>
            </div>

            <div className="space-y-4 text-xs text-neutral-300">
              <div className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] uppercase font-mono text-neutral-400 block">Headquarters & Studio:</span>
                  <p className="leading-relaxed">
                    {content.businessAddressStreet}<br />
                    {content.businessAddressCity}, {content.businessAddressState} {content.businessAddressZip}<br />
                    {content.businessAddressCountry}
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <Phone className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] uppercase font-mono text-neutral-400 block">Customer Care Hotline:</span>
                  <p className="font-mono text-white">{content.businessPhone}</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <Clock className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] uppercase font-mono text-neutral-400 block">Operating Hours:</span>
                  <p>{content.businessHours}</p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-neutral-800 space-y-2 text-xs">
              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Departmental Directories:</span>
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-neutral-400">Customer Support:</span>
                <a href={`mailto:${content.supportEmail}`} className="text-white hover:underline">{content.supportEmail}</a>
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-neutral-400">Order Fulfillment:</span>
                <a href={`mailto:${content.ordersEmail}`} className="text-white hover:underline">{content.ordersEmail}</a>
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-neutral-400">Press & Editorial:</span>
                <a href={`mailto:${content.pressEmail}`} className="text-white hover:underline">{content.pressEmail}</a>
              </div>
            </div>

            {/* Render Filled Socials */}
            {activeSocials.length > 0 && (
              <div className="pt-4 border-t border-neutral-800 space-y-2">
                <span className="text-[10px] uppercase font-mono text-neutral-400 block">Public Channels:</span>
                <div className="flex flex-wrap items-center gap-2">
                  {activeSocials.map((soc) => {
                    const IconComp = soc.icon;
                    return (
                      <a
                        key={soc.label}
                        href={soc.url}
                        target="_blank"
                        rel="noreferrer"
                        className="px-2.5 py-1.5 bg-[#202020] hover:bg-neutral-700 text-xs font-mono text-neutral-200 hover:text-white flex items-center gap-1.5 transition-colors border border-neutral-700"
                      >
                        <IconComp className="w-3 h-3" />
                        <span>{soc.label}</span>
                      </a>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          <div className="bg-[#f5f4f0] p-6 border border-neutral-300 space-y-3">
            <div className="flex items-center space-x-2 text-xs font-mono uppercase text-neutral-700">
              <ShieldCheck className="w-4 h-4 text-neutral-800" />
              <span>Prompt Response Standard</span>
            </div>
            <p className="text-xs text-neutral-600 leading-relaxed font-sans font-light">
              All inquiries submitted during business hours are reviewed by our dedicated Chicago studio team within 24 business hours.
            </p>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 border border-neutral-200 space-y-6">
          <div className="border-b border-neutral-100 pb-4">
            <h3 className="font-serif text-2xl text-neutral-900">Send an Inquiry</h3>
            <p className="text-xs text-neutral-500 font-sans mt-1">
              Direct connection to our customer care and garment manufacturing coordinators.
            </p>
          </div>

          {isSubmitted ? (
            <div className="bg-neutral-50 border border-neutral-200 p-8 text-center space-y-4">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
              <h4 className="font-serif text-xl text-neutral-900">Inquiry Received</h4>
              <p className="text-xs text-neutral-600 max-w-md mx-auto leading-relaxed">
                Thank you for reaching out to {content.brandName}. A member of our team has received your dispatch and will respond to <strong className="text-neutral-900 font-mono">{email}</strong> shortly.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setIsSubmitted(false);
                  setFullName('');
                  setEmail('');
                  setMessage('');
                }}
              >
                Send Another Message
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1.5">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Eleanor Vance"
                    className="w-full bg-neutral-50 border border-neutral-300 px-3.5 py-2.5 text-xs text-neutral-900 placeholder-neutral-400 focus:outline-hidden focus:border-black font-sans"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1.5">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. eleanor@example.com"
                    className="w-full bg-neutral-50 border border-neutral-300 px-3.5 py-2.5 text-xs text-neutral-900 placeholder-neutral-400 focus:outline-hidden focus:border-black font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1.5">
                  Subject Category
                </label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value as any)}
                  className="w-full bg-neutral-50 border border-neutral-300 px-3.5 py-2.5 text-xs text-neutral-900 font-mono focus:outline-hidden"
                >
                  <option value="General Inquiry">General Inquiries & Brand Philosophy</option>
                  <option value="Order & Transit">Order Status & USPS Tracking Assistance</option>
                  <option value="Sizing & Blanks">6.5oz Cotton Sizing & Fit Advice</option>
                  <option value="Editorial & Press">Editorial, Collaborations & Press</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] uppercase font-mono text-neutral-600 mb-1.5">
                  Message Details *
                </label>
                <textarea
                  required
                  rows={5}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="How can we assist your contemplation or order experience today?"
                  className="w-full bg-neutral-50 border border-neutral-300 p-3.5 text-xs text-neutral-900 placeholder-neutral-400 focus:outline-hidden focus:border-black font-sans leading-relaxed"
                />
              </div>

              <Button type="submit" variant="primary" size="md" fullWidth>
                <Send className="w-3.5 h-3.5 mr-2" />
                <span>Submit Inquiry to Care Team</span>
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
