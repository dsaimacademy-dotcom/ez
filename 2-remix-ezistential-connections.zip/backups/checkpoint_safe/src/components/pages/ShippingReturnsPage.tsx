import React from 'react';
import { Truck, RefreshCw, Clock, ShieldCheck, ArrowRight, Package, AlertCircle, HelpCircle } from 'lucide-react';
import { Button } from '../ui/Button';

export interface ShippingReturnsPageProps {
  onNavigateToTrack: () => void;
  onNavigateToContact: () => void;
  onNavigateToShop: () => void;
}

export const ShippingReturnsPage: React.FC<ShippingReturnsPageProps> = ({
  onNavigateToTrack,
  onNavigateToContact,
  onNavigateToShop,
}) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 space-y-16">
      {/* Header */}
      <div className="text-center space-y-4 border-b border-neutral-200 pb-10">
        <span className="text-[11px] uppercase tracking-widest text-neutral-500 font-mono block">
          Transparent Operations
        </span>
        <h1 className="font-serif text-4xl sm:text-5xl text-neutral-900 tracking-tight">
          Shipping, Production & Returns
        </h1>
        <p className="font-serif italic text-base sm:text-lg text-neutral-600 max-w-xl mx-auto">
          "We do not mass-produce garments to sit in landfills. Every piece is crafted when requested."
        </p>
      </div>

      {/* 3 Step Timeline Ribbon */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-neutral-300 p-6 space-y-3 shadow-xs">
          <div className="flex items-center space-x-2 text-neutral-900 font-medium text-xs uppercase tracking-wider">
            <Clock className="w-4 h-4 text-neutral-700" />
            <span>1. On-Demand Production</span>
          </div>
          <div className="font-mono text-xl text-neutral-900 font-semibold">2–4 Business Days</div>
          <p className="text-xs text-neutral-600 leading-relaxed font-sans font-light">
            Each garment is pulled from heavyweight combed cotton stock and custom direct-to-film (DTF) discharge printed at our partner facility (Apliiq in Los Angeles, CA).
          </p>
        </div>

        <div className="bg-white border border-neutral-300 p-6 space-y-3 shadow-xs">
          <div className="flex items-center space-x-2 text-neutral-900 font-medium text-xs uppercase tracking-wider">
            <Truck className="w-4 h-4 text-neutral-700" />
            <span>2. Domestic Transit</span>
          </div>
          <div className="font-mono text-xl text-neutral-900 font-semibold">3–5 Business Days</div>
          <p className="text-xs text-neutral-600 leading-relaxed font-sans font-light">
            Dispatched via USPS Ground Advantage or USPS Priority Mail with end-to-door tracking sent directly to your email address.
          </p>
        </div>

        <div className="bg-white border border-neutral-300 p-6 space-y-3 shadow-xs">
          <div className="flex items-center space-x-2 text-neutral-900 font-medium text-xs uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-neutral-700" />
            <span>3. Integrity Guarantee</span>
          </div>
          <div className="font-mono text-xl text-neutral-900 font-semibold">30-Day Window</div>
          <p className="text-xs text-neutral-600 leading-relaxed font-sans font-light">
            If your garment arrives with any defect, misprint, or structural flaw, we replace or refund it immediately with zero restocking fee.
          </p>
        </div>
      </div>

      {/* Detailed Shipping Section */}
      <div className="space-y-6">
        <div className="border-b border-neutral-200 pb-3">
          <h2 className="font-serif text-2xl text-neutral-900">US Domestic Shipping Rates</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
          <div className="border border-neutral-300 p-5 bg-white space-y-2">
            <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 block">Orders Under $75</span>
            <div className="font-mono text-lg font-semibold text-neutral-900">$6.00 Flat Rate</div>
            <p className="text-neutral-600 leading-relaxed">
              Standard tracked domestic delivery via USPS Ground Advantage to any verified residential or commercial address across all 50 US States and Washington D.C.
            </p>
          </div>

          <div className="border border-neutral-300 p-5 bg-[#fbfbf9] space-y-2 border-l-4 border-l-black">
            <span className="text-[10px] uppercase font-mono tracking-wider text-emerald-700 font-semibold block">Orders $75 & Above</span>
            <div className="font-mono text-lg font-semibold text-neutral-900">Complimentary (Free)</div>
            <p className="text-neutral-600 leading-relaxed">
              Free nationwide delivery is automatically calculated at checkout when your garment bag subtotal reaches $75.00 or more.
            </p>
          </div>
        </div>

        <div className="bg-[#f5f4f0] p-4 border border-neutral-200 text-xs text-neutral-700 space-y-1">
          <div className="font-medium text-neutral-900">Notice on Geographic Guardrails:</div>
          <p className="text-neutral-600 leading-relaxed font-light">
            Our inaugural launch operates exclusively within the domestic United States. We do not currently ship internationally to prevent delayed cross-border customs or unexpected import tariffs for our wearers.
          </p>
        </div>
      </div>

      {/* Detailed Returns & Exchanges Section */}
      <div className="space-y-6">
        <div className="border-b border-neutral-200 pb-3">
          <h2 className="font-serif text-2xl text-neutral-900">30-Day Quality & Exchange Policy</h2>
        </div>

        <div className="space-y-4 text-xs text-neutral-700 leading-relaxed font-sans font-light">
          <p>
            Because Ezistential Connections prints each garment on demand rather than pulling from dusty warehouse backstock, we ask that you consult our comprehensive <strong>Size Guide</strong> prior to purchasing to minimize unnecessary shipping.
          </p>

          <div className="border border-neutral-300 bg-white p-6 space-y-4">
            <h4 className="font-serif text-base text-neutral-900 font-normal">What We Gladly Cover:</h4>
            <ul className="list-disc pl-5 space-y-1.5 text-neutral-600">
              <li>Garments arriving with print alignment errors, ink cracking, or discharge inconsistencies.</li>
              <li>Incorrect items, colors, or sizes shipped relative to your confirmed order receipt.</li>
              <li>Structural textile flaws (unraveled seams, collar imperfections, or fabric snags upon delivery).</li>
              <li>Packages demonstrably lost in transit by the carrier.</li>
            </ul>
          </div>

          <div className="border border-neutral-300 bg-white p-6 space-y-3">
            <h4 className="font-serif text-base text-neutral-900 font-normal">How to Initiate an Exchange or Replacement:</h4>
            <ol className="list-decimal pl-5 space-y-2 text-neutral-600">
              <li>
                Email our care team at <strong>care@ezistential.com</strong> with your order number (e.g. <code>EC-2026-XXXX</code>) and a quick photo of the issue.
              </li>
              <li>
                Our operations team reviews submissions within 1 business day and issues an immediate reprint order or full refund.
              </li>
              <li>
                For defective items, we never require you to pay return shipping fees.
              </li>
            </ol>
          </div>
        </div>
      </div>

      {/* Action CTA */}
      <div className="pt-8 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-4">
        <Button onClick={onNavigateToTrack} variant="primary" size="md">
          <Package className="w-4 h-4 mr-2" />
          <span>Track an Existing Order</span>
        </Button>

        <div className="flex items-center gap-3">
          <Button onClick={onNavigateToContact} variant="outline" size="md">
            <span>Contact Support</span>
          </Button>
          <Button onClick={onNavigateToShop} variant="ghost" size="md">
            <span>Explore Garments →</span>
          </Button>
        </div>
      </div>
    </div>
  );
};
