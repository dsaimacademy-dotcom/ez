import React, { useState } from 'react';
import { X, Mail, Lock, User as UserIcon, MapPin, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/Button';

export interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'signin' | 'signup' | 'forgot';
  onSuccess?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'signin',
  onSuccess,
}) => {
  const { login, signup, loginWithDemo, isLoading } = useAuth();
  const [tab, setTab] = useState<'signin' | 'signup' | 'forgot'>(initialTab);

  // Sign In Form State
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  // Sign Up Form State
  const [signUpName, setSignUpName] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpLocation, setSignUpLocation] = useState('');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([
    'Clothing as Medium',
    'Dialogue Over Assumption',
  ]);

  // Forgot Form State
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    if (!signInEmail) {
      setErrorMessage('Please provide your email address.');
      return;
    }

    const res = await login(signInEmail, signInPassword, rememberMe);
    if (res.success) {
      onClose();
      onSuccess?.();
    } else {
      setErrorMessage(res.error || 'Unable to sign in. Please verify your email.');
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    if (!signUpName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!signUpEmail.trim()) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    const res = await signup({
      fullName: signUpName,
      email: signUpEmail,
      password: signUpPassword,
      location: signUpLocation,
      reflectionInterests: selectedInterests,
    });

    if (res.success) {
      onClose();
      onSuccess?.();
    } else {
      setErrorMessage(res.error || 'Account creation failed. Please try again.');
    }
  };

  const handleDemoLogin = () => {
    loginWithDemo();
    onClose();
    onSuccess?.();
  };

  const toggleInterest = (interest: string) => {
    setSelectedInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const availableInterests = [
    'Clothing as Medium',
    'Dialogue Over Assumption',
    'The Space Between Us',
    'Public Ground Encounters',
    'Tactile Philosophy',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#0a0a0a]/80 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Card */}
      <div
        className="relative w-full max-w-lg bg-[#fbfbf9] text-[#0a0a0a] shadow-2xl border border-[#e5e5e5] p-6 sm:p-8 z-10 my-8 animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-black transition-colors focus:outline-hidden"
          aria-label="Close auth modal"
        >
          <X className="w-5 h-5 stroke-[1.5]" />
        </button>

        {/* Header Branding */}
        <div className="text-center space-y-2 mb-6">
          <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-500">
            Ezistential Connections • Account
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl text-neutral-900 tracking-tight">
            {tab === 'signin' && 'Welcome to the Threshold'}
            {tab === 'signup' && 'Create Your Account'}
            {tab === 'forgot' && 'Reset Your Password'}
          </h2>
          <p className="text-xs text-neutral-600 font-sans max-w-xs mx-auto">
            {tab === 'signin' && 'Access your order history, live Apliiq manufacturing tracking, saved garments, and personal reflections.'}
            {tab === 'signup' && 'Join an ongoing inquiry. Track made-to-order garments and contribute reflections.'}
            {tab === 'forgot' && 'Enter your email address and we will dispatch a secure recovery token.'}
          </p>
        </div>

        {/* Tab Switcher */}
        {tab !== 'forgot' && (
          <div className="flex border-b border-neutral-200 mb-6">
            <button
              onClick={() => {
                setTab('signin');
                setErrorMessage(null);
              }}
              className={`flex-1 pb-3 text-xs uppercase tracking-wider font-medium text-center transition-colors border-b-2 -mb-px ${
                tab === 'signin'
                  ? 'border-black text-neutral-900'
                  : 'border-transparent text-neutral-400 hover:text-neutral-700'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setTab('signup');
                setErrorMessage(null);
              }}
              className={`flex-1 pb-3 text-xs uppercase tracking-wider font-medium text-center transition-colors border-b-2 -mb-px ${
                tab === 'signup'
                  ? 'border-black text-neutral-900'
                  : 'border-transparent text-neutral-400 hover:text-neutral-700'
              }`}
            >
              Create Account
            </button>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-5 p-3 bg-red-50 border border-red-200 text-red-700 text-xs flex items-center justify-between">
            <span>{errorMessage}</span>
            <button onClick={() => setErrorMessage(null)} className="text-red-400 hover:text-red-700">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* TAB: SIGN IN */}
        {tab === 'signin' && (
          <form onSubmit={handleSignIn} className="space-y-4">
            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={signInEmail}
                  onChange={(e) => setSignInEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-9 pr-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                  autoComplete="email"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setTab('forgot');
                    setErrorMessage(null);
                  }}
                  className="text-[11px] text-neutral-500 hover:text-black underline underline-offset-2"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={signInPassword}
                  onChange={(e) => setSignInPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                  autoComplete="current-password"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2 pt-1">
              <input
                type="checkbox"
                id="rememberMe"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="accent-black w-4 h-4"
              />
              <label htmlFor="rememberMe" className="text-xs text-neutral-600 cursor-pointer">
                Keep me signed in on this device
              </label>
            </div>

            <div className="pt-2">
              <Button type="submit" variant="primary" size="md" className="w-full justify-center" disabled={isLoading}>
                {isLoading ? 'Signing In...' : 'Sign In'}
              </Button>
            </div>

            {/* Quick Demo Access */}
            <div className="pt-4 border-t border-neutral-200">
              <button
                type="button"
                onClick={handleDemoLogin}
                className="w-full py-2.5 px-3 bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 text-xs font-medium text-neutral-800 flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <UserIcon className="w-3.5 h-3.5 text-neutral-700" />
                <span>Sign In as Demo Member (Marcus Vance)</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB: SIGN UP */}
        {tab === 'signup' && (
          <form onSubmit={handleSignUp} className="space-y-4">
            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                Full Name
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={signUpName}
                  onChange={(e) => setSignUpName(e.target.value)}
                  placeholder="e.g. Elena Rostova"
                  className="w-full pl-9 pr-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={signUpEmail}
                  onChange={(e) => setSignUpEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-9 pr-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={signUpPassword}
                  onChange={(e) => setSignUpPassword(e.target.value)}
                  placeholder="Create a secure passphrase"
                  className="w-full pl-9 pr-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                City / Location (Optional)
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={signUpLocation}
                  onChange={(e) => setSignUpLocation(e.target.value)}
                  placeholder="e.g. Brooklyn, NY"
                  className="w-full pl-9 pr-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-2">
                Themes of Interest
              </label>
              <div className="flex flex-wrap gap-1.5">
                {availableInterests.map((interest) => {
                  const isSelected = selectedInterests.includes(interest);
                  return (
                    <button
                      type="button"
                      key={interest}
                      onClick={() => toggleInterest(interest)}
                      className={`text-[11px] px-2.5 py-1 border transition-colors ${
                        isSelected
                          ? 'bg-neutral-900 text-white border-neutral-900'
                          : 'bg-white text-neutral-600 border-neutral-300 hover:border-black'
                      }`}
                    >
                      {interest}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-3">
              <Button type="submit" variant="primary" size="md" className="w-full justify-center" disabled={isLoading}>
                {isLoading ? 'Creating Account...' : 'Join Ezistential Connections'}
              </Button>
            </div>

            <div className="flex items-center justify-center space-x-1.5 text-[11px] text-neutral-500 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
              <span>Digital Dignity: Zero advertising trackers or data sharing.</span>
            </div>
          </form>
        )}

        {/* TAB: FORGOT PASSWORD */}
        {tab === 'forgot' && (
          <div className="space-y-4">
            {forgotSent ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-2 text-center">
                <p className="text-xs font-medium">Recovery Link Dispatched</p>
                <p className="text-xs text-emerald-700">
                  If an account exists for <strong className="font-mono">{forgotEmail}</strong>, password reset instructions have been transmitted.
                </p>
                <div className="pt-2">
                  <Button
                    onClick={() => {
                      setTab('signin');
                      setForgotSent(false);
                    }}
                    variant="outline"
                    size="sm"
                  >
                    Back to Sign In
                  </Button>
                </div>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (forgotEmail) setForgotSent(true);
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-[11px] uppercase tracking-wider font-mono text-neutral-600 mb-1.5">
                    Account Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full pl-9 pr-3 py-2.5 bg-white border border-neutral-300 text-sm focus:border-black focus:outline-hidden"
                      required
                    />
                  </div>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <Button type="submit" variant="primary" size="md" className="flex-1 justify-center">
                    Send Reset Link
                  </Button>
                  <Button
                    type="button"
                    onClick={() => setTab('signin')}
                    variant="outline"
                    size="md"
                    className="justify-center"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
