import React from 'react';
import { useContent } from '../../context/ContentContext';
import { Compass } from 'lucide-react';

export interface AnnouncementBarProps {
  onOpenGuide?: () => void;
}

export const AnnouncementBar: React.FC<AnnouncementBarProps> = ({ onOpenGuide }) => {
  const { content } = useContent();

  if (!content.announcementActive) return null;

  return (
    <div className="bg-[#0a0a0a] text-[#fbfbf9] text-[11px] uppercase tracking-widest py-2 px-4 text-center font-medium border-b border-[#262626] flex items-center justify-between">
      <div className="hidden sm:block w-24" />
      <div className="flex items-center justify-center space-x-2 flex-1">
        <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#fbfbf9]/60" />
        <span>{content.announcementText}</span>
      </div>
      <div className="flex items-center">
        {onOpenGuide && content.enableTourGuide && (
          <button
            onClick={onOpenGuide}
            className="text-[10px] text-neutral-400 hover:text-white uppercase font-mono tracking-wider flex items-center gap-1 transition-colors cursor-pointer border border-[#333] hover:border-neutral-400 px-2 py-0.5 bg-[#141414]"
            title="Explore Interactive Storefront Guide"
          >
            <Compass className="w-3 h-3 text-neutral-300" />
            <span className="hidden sm:inline">Tour Guide</span>
          </button>
        )}
      </div>
    </div>
  );
};
