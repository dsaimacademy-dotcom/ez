import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Menu,
  X,
  User as UserIcon,
  Package,
  Heart,
  MessageSquare,
  MapPin,
  LogOut,
  ChevronRight,
  LayoutDashboard,
  Settings,
  Compass,
  Film,
  FileText,
  HelpCircle,
  Truck,
  ShieldCheck,
  Building2,
  Sparkles
} from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { Logo } from '../brand/Logo';
import { Drawer } from '../ui/Drawer';
import { cn } from '../../lib/utils';

export interface HeaderProps {
  currentView: string;
  onNavigate: (view: string, param?: string) => void;
  onOpenAuth?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentView, onNavigate, onOpenAuth }) => {
  const { totalCount, openCart } = useCart();
  const { user, isAuthenticated, logout } = useAuth();
  const [memberSidebarOpen, setMemberSidebarOpen] = useState(false);

  // Core Header Links (Top Bar Navigation)
  const primaryNavLinks = [
    { id: 'shop', label: 'Garments' },
    { id: 'collections', label: 'Collections' },
    { id: 'our-story', label: 'Our Story' },
    { id: 'updates', label: 'Journal' },
    { id: 'why-we-exist', label: 'Why We Exist' },
    { id: 'manifesto', label: 'Manifesto' },
  ];

  // Secondary Links for Sidebar
  const secondaryNavLinks = [
    { id: 'ecosystem', label: 'Ecosystem (Films & Audio)' },
    { id: 'connection', label: 'Connection Archive' },
    { id: 'faq', label: 'FAQ & Care' },
    { id: 'contact', label: 'Contact Studio' },
  ];

  const handleLinkClick = (viewId: string, param?: string) => {
    if (viewId === 'account' && !isAuthenticated) {
      if (onOpenAuth) {
        onOpenAuth();
      } else {
        onNavigate('account', param);
      }
      setMemberSidebarOpen(false);
      return;
    }
    onNavigate(viewId, param);
    setMemberSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getInitials = (name: string) => {
    if (!name) return 'EC';
    const parts = name.split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#fbfbf9]/95 backdrop-blur-md border-b border-[#e5e5e5] transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Left: Mobile Hamburger & Brand Logo */}
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setMemberSidebarOpen(true)}
                className="lg:hidden p-2 text-neutral-800 hover:text-black focus:outline-hidden flex items-center space-x-2 border border-transparent hover:border-neutral-200 transition-colors cursor-pointer"
                aria-label="Open member sidebar menu"
              >
                <Menu className="w-5 h-5 stroke-[1.5]" />
              </button>

              <button
                onClick={() => handleLinkClick('home')}
                className="group text-left focus:outline-hidden inline-flex items-center cursor-pointer"
              >
                <Logo variant="black" className="h-9 sm:h-11 w-auto" />
              </button>
            </div>

            {/* Desktop Top Bar Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              {primaryNavLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={cn(
                    'text-xs uppercase tracking-wider transition-colors py-1 cursor-pointer font-medium relative',
                    currentView === link.id
                      ? 'text-black font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[1.5px] after:bg-black'
                      : 'text-neutral-600 hover:text-black'
                  )}
                >
                  {link.label}
                </button>
              ))}
            </nav>

            {/* Right Utilities: Track Order, Member Account Button, Cart */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              <button
                onClick={() => handleLinkClick('track-order')}
                className="hidden xl:inline-flex text-[11px] uppercase tracking-wider text-neutral-500 hover:text-black transition-colors py-1 cursor-pointer"
              >
                Track Order
              </button>

              {/* MEMBER ACCOUNT BUTTON (SLIDES OUT SIDEBAR DRAWER) */}
              <button
                onClick={() => {
                  if (!isAuthenticated && onOpenAuth) {
                    onOpenAuth();
                  } else {
                    setMemberSidebarOpen(true);
                  }
                }}
                className="flex items-center space-x-1.5 py-1.5 px-3 text-xs uppercase tracking-wider text-neutral-800 hover:text-black bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 transition-colors cursor-pointer"
                aria-label="Member account sidebar"
              >
                {isAuthenticated && user ? (
                  <>
                    {user.avatarUrl ? (
                      <img
                        src={user.avatarUrl}
                        alt={user.fullName}
                        className="w-5 h-5 rounded-full object-cover border border-neutral-300 shrink-0"
                      />
                    ) : (
                      <div className="w-5 h-5 rounded-full bg-black text-white font-serif text-[10px] flex items-center justify-center shrink-0">
                        {getInitials(user.fullName)}
                      </div>
                    )}
                    <span className="hidden sm:inline font-mono text-[11px]">
                      {user.fullName.split(' ')[0]}
                    </span>
                  </>
                ) : (
                  <>
                    <UserIcon className="w-3.5 h-3.5 stroke-[1.5]" />
                    <span className="hidden sm:inline font-mono text-[11px]">Member</span>
                  </>
                )}
              </button>

              {/* CART BUTTON */}
              <button
                onClick={openCart}
                className="relative p-2 text-neutral-900 hover:text-black transition-colors flex items-center space-x-1.5 focus:outline-hidden group cursor-pointer"
                aria-label="View bag"
              >
                <ShoppingBag className="w-5 h-5 stroke-[1.5] group-hover:scale-105 transition-transform" />
                <span className="text-xs font-mono font-medium tracking-tight bg-neutral-900 text-white rounded-full min-w-5 h-5 px-1.5 inline-flex items-center justify-center">
                  {totalCount}
                </span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* MEMBER & BRAND SLIDE-OUT SIDEBAR DRAWER */}
      <Drawer
        isOpen={memberSidebarOpen}
        onClose={() => setMemberSidebarOpen(false)}
        position="right"
        widthClass="max-w-sm sm:max-w-md"
      >
        <div className="flex flex-col h-full overflow-y-auto divide-y divide-neutral-200">
          {/* Drawer Header / Member Status */}
          <div className="p-6 bg-[#f5f4f0] space-y-4">
            {isAuthenticated && user ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-widest bg-neutral-900 text-white px-2 py-0.5 border border-neutral-800">
                    {user.role === 'admin' ? 'Curator Admin' : 'Verified Member'}
                  </span>
                  <button
                    onClick={() => setMemberSidebarOpen(false)}
                    className="text-neutral-500 hover:text-black text-xs font-mono underline cursor-pointer"
                  >
                    Close Sidebar
                  </button>
                </div>

                <div className="flex items-center space-x-3">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.fullName}
                      className="w-12 h-12 rounded-full object-cover border border-neutral-300 shadow-sm shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-black text-white font-serif text-lg flex items-center justify-center shrink-0">
                      {getInitials(user.fullName)}
                    </div>
                  )}
                  <div className="space-y-0.5 min-w-0">
                    <h3 className="font-serif text-lg font-bold text-neutral-900 truncate">
                      {user.fullName}
                    </h3>
                    <p className="text-xs font-mono text-neutral-500 truncate">{user.email}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-500">
                    Ezistential Threshold
                  </span>
                  <button
                    onClick={() => setMemberSidebarOpen(false)}
                    className="text-neutral-500 hover:text-black text-xs font-mono underline cursor-pointer"
                  >
                    Close
                  </button>
                </div>
                <h3 className="font-serif text-xl font-bold text-neutral-900">
                  Welcome to Ezistential Connections
                </h3>
                <p className="text-xs text-neutral-600 font-sans leading-relaxed">
                  Sign in to manage your made-to-order garments, saved items, submitted reflections, and digital settings.
                </p>
                {onOpenAuth && (
                  <button
                    onClick={() => {
                      setMemberSidebarOpen(false);
                      onOpenAuth();
                    }}
                    className="w-full py-2.5 bg-black text-white hover:bg-neutral-800 text-xs font-mono uppercase tracking-wider flex items-center justify-center space-x-2 transition-colors cursor-pointer"
                  >
                    <UserIcon className="w-3.5 h-3.5" />
                    <span>Sign In or Create Account</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Wearer Circle & Account Pool Navigation (Always Visible) */}
          <div className="p-6 space-y-3 bg-white">
            <h4 className="text-[10px] uppercase font-mono tracking-widest text-neutral-500 font-bold">
              Wearer Circle & Account Pool
            </h4>

            <div className="space-y-1">
              <button
                onClick={() => handleLinkClick('account', 'overview')}
                className="w-full py-2.5 px-3 text-left text-xs font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer"
              >
                <span className="flex items-center space-x-2.5">
                  <LayoutDashboard className="w-4 h-4 text-neutral-500" />
                  <span className="font-medium">Personal Dashboard Hub</span>
                </span>
                <ChevronRight className="w-3.5 h-3.5 text-neutral-400" />
              </button>

              <button
                onClick={() => handleLinkClick('account', 'verification')}
                className="w-full py-2.5 px-3 text-left text-xs font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer bg-amber-50/50 border border-amber-200/60"
              >
                <span className="flex items-center space-x-2.5">
                  <ShieldCheck className="w-4 h-4 text-amber-700" />
                  <span className="font-medium text-amber-950">Member Verification Engine</span>
                </span>
                <ChevronRight className="w-3.5 h-3.5 text-amber-700" />
              </button>

              <button
                onClick={() => handleLinkClick('account', 'orders')}
                className="w-full py-2.5 px-3 text-left text-xs font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer"
              >
                <span className="flex items-center space-x-2.5">
                  <Package className="w-4 h-4 text-neutral-500" />
                  <span>Orders & POD Tracking</span>
                </span>
                <ChevronRight className="w-3.5 h-3.5 text-neutral-400" />
              </button>

              <button
                onClick={() => handleLinkClick('account', 'wishlist')}
                className="w-full py-2.5 px-3 text-left text-xs font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer"
              >
                <span className="flex items-center space-x-2.5">
                  <Heart className="w-4 h-4 text-neutral-500" />
                  <span>Wishlist (Saved Garments)</span>
                </span>
                {user && user.savedGarments && user.savedGarments.length > 0 && (
                  <span className="text-[10px] font-mono bg-neutral-100 text-neutral-800 px-2 py-0.5 border border-neutral-300">
                    {user.savedGarments.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => handleLinkClick('account', 'reflections')}
                className="w-full py-2.5 px-3 text-left text-xs font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer"
              >
                <span className="flex items-center space-x-2.5">
                  <MessageSquare className="w-4 h-4 text-neutral-500" />
                  <span>My Reflections</span>
                </span>
              </button>

              <button
                onClick={() => handleLinkClick('account', 'addresses')}
                className="w-full py-2.5 px-3 text-left text-xs font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer"
              >
                <span className="flex items-center space-x-2.5">
                  <MapPin className="w-4 h-4 text-neutral-500" />
                  <span>Shipping Address Book</span>
                </span>
                {user && user.addresses && user.addresses.length > 0 && (
                  <span className="text-[10px] font-mono bg-neutral-100 text-neutral-800 px-2 py-0.5 border border-neutral-300">
                    {user.addresses.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => handleLinkClick('account', 'settings')}
                className="w-full py-2.5 px-3 text-left text-xs font-sans text-neutral-800 hover:bg-neutral-100 flex items-center justify-between transition-colors rounded-xs cursor-pointer"
              >
                <span className="flex items-center space-x-2.5">
                  <Settings className="w-4 h-4 text-neutral-500" />
                  <span>Settings</span>
                </span>
              </button>
            </div>
          </div>

          {/* Admin Portal Quick Access */}
          {isAuthenticated && user && (user.role === 'admin' || user.email.includes('admin')) && (
            <div className="p-6 bg-amber-50/50 border-y border-amber-200 space-y-2">
              <span className="text-[10px] font-mono uppercase tracking-widest text-amber-800 font-bold">
                Curator Portal
              </span>
              <button
                onClick={() => handleLinkClick('admin')}
                className="w-full py-2.5 px-3 bg-black text-white hover:bg-neutral-800 text-xs font-mono uppercase tracking-wider flex items-center justify-between transition-colors cursor-pointer"
              >
                <span>Open Admin Portal</span>
                <ChevronRight className="w-3.5 h-3.5 text-amber-300" />
              </button>
            </div>
          )}

          {/* Brand & Store Navigation Shortcuts */}
          <div className="p-6 space-y-3 bg-[#fbfbf9] grow">
            <h4 className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 font-bold">
              Brand & Store
            </h4>

            <div className="space-y-1 font-sans text-xs">
              {primaryNavLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className="w-full py-2 px-3 text-left text-neutral-700 hover:text-black hover:bg-neutral-100 flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span>{link.label}</span>
                  <ChevronRight className="w-3 h-3 text-neutral-400" />
                </button>
              ))}

              {secondaryNavLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className="w-full py-2 px-3 text-left text-neutral-600 hover:text-black hover:bg-neutral-100 flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span>{link.label}</span>
                  <ChevronRight className="w-3 h-3 text-neutral-400" />
                </button>
              ))}

              <button
                onClick={() => handleLinkClick('track-order')}
                className="w-full py-2 px-3 text-left text-neutral-600 hover:text-black hover:bg-neutral-100 flex items-center justify-between transition-colors cursor-pointer border-t border-neutral-200 mt-2 pt-3"
              >
                <span className="flex items-center gap-2 font-mono">
                  <Truck className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Track My Order</span>
                </span>
                <ChevronRight className="w-3 h-3 text-neutral-400" />
              </button>
            </div>
          </div>

          {/* Drawer Footer / Sign Out */}
          {isAuthenticated && (
            <div className="p-6 bg-[#f5f4f0] shrink-0 border-t border-neutral-200">
              <button
                onClick={() => {
                  logout();
                  setMemberSidebarOpen(false);
                }}
                className="w-full py-2.5 px-3 text-left text-xs font-mono text-red-700 hover:bg-red-50 hover:text-red-900 border border-red-200 flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out of Personal Account</span>
              </button>
            </div>
          )}
        </div>
      </Drawer>
    </>
  );
};
