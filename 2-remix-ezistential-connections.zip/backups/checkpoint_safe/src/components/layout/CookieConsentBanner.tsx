import React, { useState, useEffect } from 'react';
import { ShieldCheck, X, Check, Lock, ChevronRight, Sliders } from 'lucide-react';
import { Button } from '../ui/Button';
import { useContent } from '../../context/ContentContext';

const COOKIE_CONSENT_KEY = 'ec_cookie_consent_v1';

export interface CookieConsentBannerProps {
  onNavigateToPrivacy?: () => void;
}

export const CookieConsentBanner: React.FC<CookieConsentBannerProps> = ({ onNavigateToPrivacy }) => {
  const { content } = useContent();
  const [isVisible, setIsVisible] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);

  const [analyticsConsent, setAnalyticsConsent] = useState(false);
  const [reflectionSyncConsent, setReflectionSyncConsent] = useState(true);

  useEffect(() => {
    try {
      const savedConsent = localStorage.getItem(COOKIE_CONSENT_KEY);
      if (!savedConsent && content.enableCookieConsentBanner !== false) {
        // Small delay for smooth entry
        const timer = setTimeout(() => setIsVisible(true), 800);
        return () => clearTimeout(timer);
      }
    } catch {
      // ignore
    }
  }, [content.enableCookieConsentBanner]);

  if (!isVisible || content.enableCookieConsentBanner === false) return null;

  const handleAcceptAll = () => {
    try {
      localStorage.setItem(
        COOKIE_CONSENT_KEY,
        JSON.stringify({
          essential: true,
          reflectionSync: true,
          analytics: true,
          timestamp: new Date().toISOString(),
        })
      );
    } catch {}
    setIsVisible(false);
  };

  const handleEssentialOnly = () => {
    try {
      localStorage.setItem(
        COOKIE_CONSENT_KEY,
        JSON.stringify({
          essential: true,
          reflectionSync: true,
          analytics: false,
          timestamp: new Date().toISOString(),
        })
      );
    } catch {}
    setIsVisible(false);
  };

  const handleSaveCustom = () => {
    try {
      localStorage.setItem(
        COOKIE_CONSENT_KEY,
        JSON.stringify({
          essential: true,
          reflectionSync: reflectionSyncConsent,
          analytics: analyticsConsent,
          timestamp: new Date().toISOString(),
        })
      );
    } catch {}
    setIsVisible(false);
  };

  return (
    <div className="fixed bottom-0 inset-x-0 z-50 p-3 sm:p-4 md:p-6 pointer-events-none animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="max-w-4xl mx-auto bg-[#141414] text-white border border-[#333333] shadow-2xl p-5 sm:p-6 pointer-events-auto relative">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start space-x-3.5">
            <div className="w-8 h-8 rounded-full bg-neutral-900 border border-neutral-700 flex items-center justify-center shrink-0 mt-0.5">
              <ShieldCheck className="w-4 h-4 text-neutral-300 stroke-[1.5]" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400">
                  Digital Dignity & Privacy Covenant
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              </div>
              <h3 className="font-serif text-sm sm:text-base text-white tracking-tight">
                We believe your attention and data belong to you.
              </h3>
              <p className="text-xs text-neutral-400 font-sans leading-relaxed max-w-2xl">
                Ezistential Connections uses strictly essential session integrity to preserve your garment bag, customer account, and made-to-order inquiries. We categorically reject surveillance ad networks, data brokers, and third-party tracking pixels.
              </p>
            </div>
          </div>

          <button
            onClick={handleEssentialOnly}
            className="p-1 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            aria-label="Dismiss banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Customizable Preferences Accordion */}
        {showPreferences && (
          <div className="mt-4 pt-4 border-t border-neutral-800 space-y-3 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="bg-neutral-900/80 p-3 border border-neutral-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-white">Essential Session</span>
                  <span className="text-[10px] font-mono text-neutral-400">Required</span>
                </div>
                <p className="text-[11px] text-neutral-400">
                  Preserves your garment bag, member sign-in, and made-to-order preferences.
                </p>
              </div>

              <div className="bg-neutral-900/80 p-3 border border-neutral-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-white">Community Reflections</span>
                  <input
                    type="checkbox"
                    checked={reflectionSyncConsent}
                    onChange={(e) => setReflectionSyncConsent(e.target.checked)}
                    className="accent-white cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-neutral-400">
                  Enables contributing reflections to the public Human Connection archive.
                </p>
              </div>

              <div className="bg-neutral-900/80 p-3 border border-neutral-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-white">Anonymous Telemetry</span>
                  <input
                    type="checkbox"
                    checked={analyticsConsent}
                    onChange={(e) => setAnalyticsConsent(e.target.checked)}
                    className="accent-white cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-neutral-400">
                  Aggregated performance metrics with zero cross-site tracking or profiling.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Action Controls */}
        <div className="mt-4 pt-4 border-t border-neutral-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-3 text-neutral-400">
            <button
              onClick={() => setShowPreferences(!showPreferences)}
              className="text-neutral-300 hover:text-white underline underline-offset-2 flex items-center gap-1 cursor-pointer font-medium"
            >
              <Sliders className="w-3 h-3" />
              <span>{showPreferences ? 'Hide Options' : 'Customize Preferences'}</span>
            </button>
            <span>•</span>
            {onNavigateToPrivacy && (
              <button
                onClick={onNavigateToPrivacy}
                className="text-neutral-400 hover:text-neutral-200 underline underline-offset-2 cursor-pointer"
              >
                Read Digital Dignity Policy
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {showPreferences ? (
              <Button
                onClick={handleSaveCustom}
                variant="primary"
                size="sm"
                className="bg-white text-black hover:bg-neutral-200"
              >
                Save Preferences
              </Button>
            ) : (
              <>
                <button
                  onClick={handleEssentialOnly}
                  className="px-3 py-1.5 border border-neutral-700 hover:border-neutral-500 text-neutral-300 hover:text-white transition-colors cursor-pointer text-xs font-mono uppercase tracking-wider"
                >
                  Essential Only
                </button>
                <Button
                  onClick={handleAcceptAll}
                  variant="primary"
                  size="sm"
                  className="bg-white text-black hover:bg-neutral-200"
                >
                  Accept & Continue
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
