import React, { useState } from 'react';
import {
  ArrowRight,
  Check,
  MapPin,
  Mail,
  Phone,
  Instagram,
  Twitter,
  Youtube,
  Music,
  Bookmark,
  Share2,
  Facebook,
  Linkedin
} from 'lucide-react';
import { Logo } from '../brand/Logo';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { ShapeDivider } from '../ui/ShapeDivider';
import { useContent } from '../../context/ContentContext';

export interface FooterProps {
  onNavigate: (view: string) => void;
  onOpenGuide?: () => void;
  onOpenIntWaitlist?: () => void;
  currentView?: string;
  precedingBg?: string;
}

const getPrecedingBg = (view?: string, customBg?: string): string => {
  if (customBg) return customBg;
  switch (view) {
    case 'home':
    case 'why-we-exist':
    case 'our-story':
      return '#f5f4f0';
    case 'manifesto':
    case 'shop':
    case 'collections':
    case 'product':
    case 'cart':
    case 'checkout':
    case 'order-confirmation':
    case 'faq':
    case 'contact':
    case 'shipping-returns':
    case 'privacy':
    case 'terms':
    case 'account':
    case 'updates':
    case 'ecosystem':
    case 'connection':
    default:
      return '#fbfbf9';
  }
};

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenGuide,
  onOpenIntWaitlist,
  currentView = 'home',
  precedingBg,
}) => {
  const { content } = useContent();
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const effectiveBg = getPrecedingBg(currentView, precedingBg);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setIsSubscribed(true);
    setEmail('');
  };

  const handleLink = (view: string) => {
    onNavigate(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Active filled socials only
  const activeSocials = [
    { label: 'Instagram', url: content.instagramUrl, icon: Instagram },
    { label: 'Twitter / X', url: content.twitterUrl, icon: Twitter },
    { label: 'Spotify', url: content.spotifyUrl, icon: Music },
    { label: 'Substack', url: content.substackUrl, icon: Bookmark },
    { label: 'YouTube', url: content.youtubeUrl, icon: Youtube },
    { label: 'Facebook', url: content.facebookUrl, icon: Facebook },
    { label: 'LinkedIn', url: content.linkedinUrl, icon: Linkedin },
    { label: 'TikTok', url: content.tiktokUrl, icon: Share2 },
    { label: 'Pinterest', url: content.pinterestUrl, icon: Bookmark },
    { label: 'Discord', url: content.discordUrl, icon: Share2 },
  ].filter((s) => s.url && s.url.trim().length > 0);

  return (
    <div className="w-full relative z-20 overflow-hidden" style={{ backgroundColor: effectiveBg }}>
      {/* Universal Architectural Shape Divider for Footer */}
      {content.shapeDividerEnabled !== false && (
        <div className="w-full leading-none pointer-events-none -mb-[1px] relative z-10" style={{ backgroundColor: effectiveBg }}>
          <ShapeDivider
            variant={content.shapeDividerVariant || 'editorial-notch'}
            fillColor="#0a0a0a"
            bgColor={effectiveBg}
            height={content.shapeDividerHeight || 54}
            position="bottom"
            className="w-full block"
          />
        </div>
      )}

      <footer className="w-full bg-[#0a0a0a] text-[#fbfbf9] pt-10 sm:pt-14 pb-12 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {/* Main 4-Column Footer Navigation Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-16">
            {/* Column 1: Brand Philosophy & Statement */}
            <div className="md:col-span-5 space-y-6">
              <div>
                <Logo variant="white" className="h-10 sm:h-12 w-auto" />
              </div>
              <p className="text-neutral-400 text-sm leading-relaxed max-w-md font-sans">
                {content.heroSubheadline}
              </p>
              
              <div className="pt-2 space-y-1">
                <span className="text-[11px] uppercase tracking-widest text-neutral-500 block font-mono font-bold">
                  Founding Philosophy
                </span>
                <p className="font-serif italic text-neutral-300 text-base">
                  "{content.foundingQuote}"
                </p>
              </div>
            </div>

            {/* Column 2: Quick Navigation (Explore) */}
            <div className="md:col-span-2 space-y-4">
              <h4 className="text-xs uppercase tracking-widest text-neutral-400 font-medium font-mono font-bold">
                Explore
              </h4>
              <ul className="space-y-2.5 text-xs uppercase tracking-wider text-neutral-300 font-sans">
                <li>
                  <button onClick={() => handleLink('shop')} className="hover:text-white transition-colors cursor-pointer">
                    All Garments
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('ecosystem')} className="hover:text-white transition-colors cursor-pointer">
                    Ecosystem
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('updates')} className="hover:text-white transition-colors cursor-pointer">
                    Journal
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('why-we-exist')} className="hover:text-white transition-colors cursor-pointer">
                    Why We Exist
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('our-story')} className="hover:text-white transition-colors cursor-pointer">
                    Our Story
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('manifesto')} className="hover:text-white transition-colors cursor-pointer">
                    The Manifesto
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('connection')} className="hover:text-white transition-colors cursor-pointer">
                    Connection Prompt
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 3: Practical Customer Information */}
            <div className="md:col-span-2 space-y-4">
              <h4 className="text-xs uppercase tracking-widest text-neutral-400 font-medium font-mono font-bold">
                Information
              </h4>
              <ul className="space-y-2.5 text-xs uppercase tracking-wider text-neutral-300 font-sans">
                <li>
                  <button onClick={() => handleLink('faq')} className="hover:text-white transition-colors cursor-pointer">
                    FAQ & Care
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('updates')} className="hover:text-white transition-colors cursor-pointer">
                    Journal Dispatches
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('contact')} className="hover:text-white transition-colors cursor-pointer">
                    Customer Care
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('shipping-returns')} className="hover:text-white transition-colors cursor-pointer">
                    Shipping & Returns
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('privacy')} className="hover:text-white transition-colors cursor-pointer">
                    Digital Dignity
                  </button>
                </li>
                <li>
                  <button onClick={() => handleLink('terms')} className="hover:text-white transition-colors cursor-pointer">
                    Terms & Ethics
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 4: Newsletter Subscription */}
            <div className="md:col-span-3 space-y-4">
              <h4 className="text-xs uppercase tracking-widest text-neutral-400 font-medium font-mono font-bold">
                Quiet Reflections
              </h4>
              <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                Occasional dispatches on human connection, garment releases, and community stories. No noise.
              </p>

              {isSubscribed ? (
                <div className="bg-[#1f1f1f] border border-[#262626] p-3 text-xs text-neutral-300 flex items-center space-x-2 font-sans">
                  <Check className="w-4 h-4 text-white" />
                  <span>You are on the list. Thank you for connecting.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="space-y-2">
                  <div className="relative">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email"
                      required
                      className="w-full bg-[#141414] border border-[#262626] px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-hidden focus:border-neutral-400 transition-colors font-sans"
                    />
                    <button
                      type="submit"
                      className="absolute right-1.5 top-1.5 bottom-1.5 px-2.5 bg-[#262626] text-white hover:bg-neutral-700 transition-colors flex items-center justify-center cursor-pointer"
                      aria-label="Subscribe to newsletter"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-[10px] text-neutral-500 font-sans">
                    By joining, you respect our privacy covenant. Unsubscribe anytime.
                  </p>
                </form>
              )}
            </div>
          </div>

          {/* Dedicated 3-Column Contact & Social Row */}
          <div className="pt-8 border-t border-[#262626] grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs text-neutral-400">
            {/* Column 1: Studio Address */}
            <div className="flex items-start space-x-3 bg-[#121212] p-4 border border-[#222222] rounded-xs">
              <MapPin className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-mono font-bold block">
                  Studio Address
                </span>
                <span className="text-neutral-300 block">
                  {content.businessAddressStreet ? `${content.businessAddressStreet}, ` : ''}
                  {content.businessAddressCity}, {content.businessAddressState} · {content.businessAddressCountry}
                </span>
              </div>
            </div>

            {/* Column 2: Contact (Email + Call & WhatsApp) */}
            <div className="flex items-start space-x-3 bg-[#121212] p-4 border border-[#222222] rounded-xs">
              <Mail className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-mono font-bold block">
                  Direct Contact & Care
                </span>
                <div className="space-y-1">
                  <a
                    href={`mailto:${content.supportEmail}`}
                    className="text-neutral-200 hover:text-white transition-colors underline decoration-neutral-600 underline-offset-4 block"
                  >
                    {content.supportEmail}
                  </a>
                  <div className="flex items-center space-x-2 text-[11px] text-neutral-300 pt-0.5">
                    <Phone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>
                      Call / WhatsApp:{' '}
                      <a
                        href={`https://wa.me/${(content.businessPhone || '+13125550192').replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-emerald-300 hover:text-white font-mono underline decoration-emerald-800 underline-offset-2"
                      >
                        {content.businessPhone || '+1 (312) 555-0192'}
                      </a>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Column 3: Social Channels */}
            <div className="flex items-start space-x-3 bg-[#121212] p-4 border border-[#222222] rounded-xs">
              <Share2 className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
              <div className="space-y-1.5 w-full">
                <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-mono font-bold block">
                  Social & Channels
                </span>
                {activeSocials.length > 0 ? (
                  <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                    {activeSocials.map((soc) => {
                      const IconComp = soc.icon;
                      return (
                        <a
                          key={soc.label}
                          href={soc.url}
                          target="_blank"
                          rel="noreferrer"
                          title={soc.label}
                          className="p-1.5 bg-[#1c1c1c] hover:bg-neutral-800 text-neutral-300 hover:text-white border border-[#2a2a2a] rounded-xs transition-colors cursor-pointer inline-flex items-center justify-center"
                        >
                          <IconComp className="w-3.5 h-3.5" />
                        </a>
                      );
                    })}
                  </div>
                ) : (
                  <span className="text-neutral-400 text-xs font-mono">@ezistential</span>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Credits & Policies */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 space-y-4 sm:space-y-0 font-sans">
            <div className="flex items-center space-x-4">
              <p>© {new Date().getFullYear()} {content.legalBusinessName || content.brandName}. All rights reserved.</p>
              <PWAInstallButton variant="pill" className="bg-[#141414] text-neutral-300 border-[#262626] hover:border-neutral-500 hover:text-white" />
            </div>
            <div className="flex items-center space-x-6">
              <button onClick={() => handleLink('contact')} className="hover:text-neutral-300 transition-colors cursor-pointer">
                Studio Directory
              </button>
              <button onClick={() => handleLink('privacy')} className="hover:text-neutral-300 transition-colors cursor-pointer">
                Privacy Policy
              </button>
              <button onClick={() => handleLink('terms')} className="hover:text-neutral-300 transition-colors cursor-pointer">
                Terms of Service
              </button>
              {onOpenIntWaitlist ? (
                <button
                  type="button"
                  onClick={onOpenIntWaitlist}
                  className="text-neutral-400 hover:text-white transition-colors cursor-pointer font-mono text-[11px] underline underline-offset-4"
                >
                  US Fulfillment (Global Waitlist 🌐)
                </button>
              ) : (
                <span className="text-neutral-600 font-mono">US Domestic Fulfillment</span>
              )}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
