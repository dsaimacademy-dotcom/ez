import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Product, WearType, ColorItem, DesignDraft, MasterSizeItem } from '../types';
import { PRODUCTS as DEFAULT_PRODUCTS } from '../data/products';
import { DEFAULT_WEAR_TYPES, MASTER_COLOR_LIBRARY, DEFAULT_MASTER_SIZES } from '../data/wearTypes';
import { DEFAULT_DESIGN_DRAFTS } from '../data/designs';
import { normalizeProduct } from '../lib/productNormalization';

interface ProductContextType {
  products: Product[];
  wearTypes: WearType[];
  colors: ColorItem[];
  sizes: MasterSizeItem[];
  designs: DesignDraft[];
  isLoading: boolean;
  refreshProducts: () => Promise<void>;
  updateProductPrice: (id: string, newPrice: number) => void;
  toggleProductAvailability: (id: string) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  addProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  resetProducts: () => void;
  updateWearTypes: (wearTypes: WearType[]) => void;
  addWearType: (wearType: WearType) => void;
  deleteWearType: (id: string) => void;
  updateColors: (colors: ColorItem[]) => void;
  addColor: (color: ColorItem) => void;
  deleteColor: (id: string) => void;
  updateSizes: (sizes: MasterSizeItem[]) => void;
  addSize: (size: MasterSizeItem) => void;
  updateSize: (id: string, updates: Partial<MasterSizeItem>) => void;
  deleteSize: (id: string) => void;
  updateDesigns: (designs: DesignDraft[]) => void;
  addDesign: (design: DesignDraft) => void;
  updateDesign: (id: string, updates: Partial<DesignDraft>) => void;
  deleteDesign: (id: string) => void;
  pushDesignToProduct: (designId: string, versionNumber?: number, forceNewEdition?: boolean) => Promise<Product | null>;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

const STORAGE_KEY = 'ec_products_store_v4';
const WEAR_TYPES_STORAGE_KEY = 'ec_wear_types_v2';
const COLORS_STORAGE_KEY = 'ec_colors_store_v2';
const SIZES_STORAGE_KEY = 'ec_sizes_store_v2';
const DESIGNS_STORAGE_KEY = 'ec_designs_store_v2';

export const ProductProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((p) => normalizeProduct(p));
        }
      }
      return DEFAULT_PRODUCTS.map((p) => normalizeProduct(p));
    } catch {
      return DEFAULT_PRODUCTS.map((p) => normalizeProduct(p));
    }
  });

  const [wearTypes, setWearTypes] = useState<WearType[]>(() => {
    try {
      const saved = localStorage.getItem(WEAR_TYPES_STORAGE_KEY);
      return saved ? JSON.parse(saved) : DEFAULT_WEAR_TYPES;
    } catch {
      return DEFAULT_WEAR_TYPES;
    }
  });

  const [colors, setColors] = useState<ColorItem[]>(() => {
    try {
      const saved = localStorage.getItem(COLORS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : MASTER_COLOR_LIBRARY;
    } catch {
      return MASTER_COLOR_LIBRARY;
    }
  });

  const [sizes, setSizes] = useState<MasterSizeItem[]>(() => {
    try {
      const saved = localStorage.getItem(SIZES_STORAGE_KEY);
      return saved ? JSON.parse(saved) : DEFAULT_MASTER_SIZES;
    } catch {
      return DEFAULT_MASTER_SIZES;
    }
  });

  const [designs, setDesigns] = useState<DesignDraft[]>(() => {
    try {
      const saved = localStorage.getItem(DESIGNS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : DEFAULT_DESIGN_DRAFTS;
    } catch {
      return DEFAULT_DESIGN_DRAFTS;
    }
  });

  const [isLoading, setIsLoading] = useState(false);

  // Live Server Sync (Express backend / PHP-parity REST endpoints)
  const refreshProducts = useCallback(async () => {
    try {
      setIsLoading(true);
      // Fetch Products
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.products) && data.products.length > 0) {
          const normalized = data.products.map((p: any) => normalizeProduct(p));
          setProducts(normalized);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
        }
      }

      // Fetch Wear Types
      const wtRes = await fetch('/api/wear-types');
      if (wtRes.ok) {
        const wtData = await wtRes.json();
        if (Array.isArray(wtData.wearTypes) && wtData.wearTypes.length > 0) {
          setWearTypes(wtData.wearTypes);
          localStorage.setItem(WEAR_TYPES_STORAGE_KEY, JSON.stringify(wtData.wearTypes));
        }
      }

      // Fetch Colors
      const colRes = await fetch('/api/colors');
      if (colRes.ok) {
        const colData = await colRes.json();
        if (Array.isArray(colData.colors) && colData.colors.length > 0) {
          setColors(colData.colors);
          localStorage.setItem(COLORS_STORAGE_KEY, JSON.stringify(colData.colors));
        }
      }

      // Fetch Sizes
      const szRes = await fetch('/api/sizes');
      if (szRes.ok) {
        const szData = await szRes.json();
        if (Array.isArray(szData.sizes) && szData.sizes.length > 0) {
          setSizes(szData.sizes);
          localStorage.setItem(SIZES_STORAGE_KEY, JSON.stringify(szData.sizes));
        }
      }

      // Fetch Designs
      const dsnRes = await fetch('/api/designs');
      if (dsnRes.ok) {
        const dsnData = await dsnRes.json();
        if (Array.isArray(dsnData.designs) && dsnData.designs.length > 0) {
          setDesigns(dsnData.designs);
          localStorage.setItem(DESIGNS_STORAGE_KEY, JSON.stringify(dsnData.designs));
        }
      }
    } catch (err) {
      console.warn('Live API sync offline, running in resilient cache mode:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshProducts();
  }, [refreshProducts]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
    } catch {
      // storage quota safety
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(WEAR_TYPES_STORAGE_KEY, JSON.stringify(wearTypes));
    } catch {}
  }, [wearTypes]);

  useEffect(() => {
    try {
      localStorage.setItem(COLORS_STORAGE_KEY, JSON.stringify(colors));
    } catch {}
  }, [colors]);

  useEffect(() => {
    try {
      localStorage.setItem(SIZES_STORAGE_KEY, JSON.stringify(sizes));
    } catch {}
  }, [sizes]);

  useEffect(() => {
    try {
      localStorage.setItem(DESIGNS_STORAGE_KEY, JSON.stringify(designs));
    } catch {}
  }, [designs]);

  // Product Operations
  const updateProductPrice = (id: string, newPrice: number) => {
    const validPrice = Math.max(1, newPrice);
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, price: validPrice } : p))
    );

    fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ price: validPrice }),
    }).catch((err) => console.warn('Server price update error:', err));
  };

  const toggleProductAvailability = (id: string) => {
    const current = products.find((p) => p.id === id);
    if (!current) return;
    const newStatus = !current.isAvailable;

    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isAvailable: newStatus } : p))
    );

    fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isAvailable: newStatus }),
    }).catch((err) => console.warn('Server status update error:', err));
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );

    fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    }).catch((err) => console.warn('Server product update error:', err));
  };

  const addProduct = (product: Product) => {
    setProducts((prev) => [product, ...prev]);

    fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    }).catch((err) => console.warn('Server product add error:', err));
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));

    fetch(`/api/products/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server product delete error:', err));
  };

  const resetProducts = () => {
    setProducts(DEFAULT_PRODUCTS);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_PRODUCTS));
  };

  // Wear Types Operations
  const updateWearTypes = (newWearTypes: WearType[]) => {
    setWearTypes(newWearTypes);
    localStorage.setItem(WEAR_TYPES_STORAGE_KEY, JSON.stringify(newWearTypes));

    fetch('/api/wear-types', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wearTypes: newWearTypes }),
    }).catch((err) => console.warn('Server wearTypes update error:', err));
  };

  const addWearType = (wearType: WearType) => {
    setWearTypes((prev) => [...prev, wearType]);

    fetch('/api/wear-types', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(wearType),
    }).catch((err) => console.warn('Server wearType add error:', err));
  };

  const deleteWearType = (id: string) => {
    setWearTypes((prev) => prev.filter((w) => w.id !== id));

    fetch(`/api/wear-types/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server wearType delete error:', err));
  };

  // Colors Operations
  const updateColors = (newColors: ColorItem[]) => {
    setColors(newColors);
    localStorage.setItem(COLORS_STORAGE_KEY, JSON.stringify(newColors));

    fetch('/api/colors', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ colors: newColors }),
    }).catch((err) => console.warn('Server colors update error:', err));
  };

  const addColor = (color: ColorItem) => {
    setColors((prev) => [...prev, color]);

    fetch('/api/colors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(color),
    }).catch((err) => console.warn('Server color add error:', err));
  };

  const deleteColor = (id: string) => {
    setColors((prev) => prev.filter((c) => c.id !== id && c.name.toLowerCase() !== id.toLowerCase()));

    fetch(`/api/colors/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server color delete error:', err));
  };

  // Sizes Operations
  const updateSizes = (newSizes: MasterSizeItem[]) => {
    setSizes(newSizes);
    localStorage.setItem(SIZES_STORAGE_KEY, JSON.stringify(newSizes));

    fetch('/api/sizes', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sizes: newSizes }),
    }).catch((err) => console.warn('Server sizes update error:', err));
  };

  const addSize = (size: MasterSizeItem) => {
    setSizes((prev) => [...prev, size]);

    fetch('/api/sizes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(size),
    }).catch((err) => console.warn('Server size add error:', err));
  };

  const updateSize = (id: string, updates: Partial<MasterSizeItem>) => {
    setSizes((prev) =>
      prev.map((s) => (s.id === id || s.name.toUpperCase() === id.toUpperCase() ? { ...s, ...updates } : s))
    );

    fetch(`/api/sizes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    }).catch((err) => console.warn('Server size update error:', err));
  };

  const deleteSize = (id: string) => {
    setSizes((prev) => prev.filter((s) => s.id !== id && s.name.toUpperCase() !== id.toUpperCase()));

    fetch(`/api/sizes/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server size delete error:', err));
  };

  // Design Factory Operations
  const updateDesigns = (newDesigns: DesignDraft[]) => {
    setDesigns(newDesigns);
    localStorage.setItem(DESIGNS_STORAGE_KEY, JSON.stringify(newDesigns));
  };

  const addDesign = (design: DesignDraft) => {
    setDesigns((prev) => [design, ...prev]);

    fetch('/api/designs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(design),
    }).catch((err) => console.warn('Server design add error:', err));
  };

  const updateDesign = (id: string, updates: Partial<DesignDraft>) => {
    setDesigns((prev) =>
      prev.map((d) => (d.id === id ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d))
    );

    fetch(`/api/designs/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    }).catch((err) => console.warn('Server design update error:', err));
  };

  const deleteDesign = (id: string) => {
    setDesigns((prev) => prev.filter((d) => d.id !== id));

    fetch(`/api/designs/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Server design delete error:', err));
  };

  // Push to Product Bridge
  const pushDesignToProduct = async (
    designId: string,
    versionNumber?: number,
    forceNewEdition?: boolean
  ): Promise<Product | null> => {
    try {
      const res = await fetch(`/api/designs/${designId}/push-to-product`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ versionNumber, forceNewEdition }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.product) {
          const norm = normalizeProduct(data.product, wearTypes, colors);
          if (!data.alreadyExists) {
            setProducts((prev) => [norm, ...prev.filter((p) => p.id !== norm.id)]);
          }
          setDesigns((prev) =>
            prev.map((d) => (d.id === designId ? { ...d, status: 'pushed_to_product' } : d))
          );
          return norm;
        }
      }
    } catch (err) {
      console.warn('Live push-to-product API error:', err);
    }

    // Client-side fallback if server offline
    const d = designs.find((item) => item.id === designId);
    if (!d) return null;
    const v = d.versions.find((ver) => ver.versionNumber === versionNumber) || d.versions[d.versions.length - 1];
    const targetVerNum = v?.versionNumber || Number(versionNumber) || 1;

    // Check duplicate
    if (!forceNewEdition) {
      const existing = products.find(
        (p) => p.sourceDesignId === d.id && (p.sourceDesignVersionId === v?.id || p.sourceDesignVersionNumber === targetVerNum)
      );
      if (existing) {
        return existing;
      }
    }

    const rawProd: Partial<Product> = {
      id: `prod-from-${d.id}-${Date.now()}`,
      slug: `${d.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-edition`,
      name: d.name,
      tagline: d.thesis,
      price: 48,
      collectionId: 'core-concepts',
      isFeatured: false,
      isAvailable: false,
      readinessStatus: 'draft',
      sourceDesignId: d.id,
      sourceDesignVersionId: v?.id,
      sourceDesignVersionNumber: targetVerNum,
      availableWearTypes: v?.suggestedWearTypes || ['6.5oz Heavyweight Boxy Tee'],
      availableColors: (v?.suggestedColors || ['Obsidian Black', 'Raw Ecru']).map((cn) => {
        const found = colors.find((c) => c.name.toLowerCase() === cn.toLowerCase());
        return found ? { id: found.id, name: found.name, hex: found.hex } : { id: `col-${cn.toLowerCase().replace(/[^a-z0-9]/g, '-')}`, name: cn, hex: '#0f0f0f' };
      }),
      availableSizes: v?.suggestedSizes || ['S', 'M', 'L', 'XL'],
      primaryImage: v?.artworkUrl || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85',
      galleryImages: [
        {
          url: v?.artworkUrl || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85',
          alt: `${d.name} Primary Artwork`,
          viewType: 'front',
        },
      ],
      storyA: {
        headline: d.name,
        question: 'What happens when we translate this inquiry into physical form?',
        thesis: d.thesis,
        wearerRole: 'Carrying creative inquiry into public spaces.',
      },
      storyB: {
        fabric: '100% Combed Ring-Spun Cotton',
        weight: '6.5 oz / 220 GSM Heavyweight Jersey',
        fit: 'Relaxed drop-shoulder boxy architectural silhouette',
        origin: 'Ethically crafted in Los Angeles, CA',
        printTechnique: 'Direct-to-Film (DTF) Soft-Hand Archival Pigment',
        careInstructions: [
          'Machine wash cold inside out with like colors',
          'Hang dry recommended to preserve structural drape',
          'Tumble dry low if necessary',
        ],
        productionNotes: `Generated from Design Factory Draft #${d.id} (Version ${targetVerNum})`,
        estimatedDeliveryDays: 'Production: 2–4 business days. Standard US delivery: 3–5 business days.',
      },
      variants: [],
      createdAt: new Date().toISOString(),
    };

    const newProd = normalizeProduct(rawProd, wearTypes, colors);
    setProducts((prev) => [newProd, ...prev]);
    setDesigns((prev) =>
      prev.map((item) => (item.id === designId ? { ...item, status: 'pushed_to_product' } : item))
    );
    return newProd;
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        wearTypes,
        colors,
        sizes,
        designs,
        isLoading,
        refreshProducts,
        updateProductPrice,
        toggleProductAvailability,
        updateProduct,
        addProduct,
        deleteProduct,
        resetProducts,
        updateWearTypes,
        addWearType,
        deleteWearType,
        updateColors,
        addColor,
        deleteColor,
        updateSizes,
        addSize,
        updateSize,
        deleteSize,
        updateDesigns,
        addDesign,
        updateDesign,
        deleteDesign,
        pushDesignToProduct,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

export function useProducts() {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
}
