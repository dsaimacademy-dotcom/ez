import React, { createContext, useContext, useState, useEffect } from 'react';
import { FAQItem, ShapeDividerVariant, MemberVerificationRules, HeroSlide } from '../types';
import { FAQ_DATA as DEFAULT_FAQS } from '../data/faqs';
import { DEFAULT_HERO_SLIDES } from '../data/heroSlides';
import { api } from '../lib/api';

export interface SpotlightSlide {
  id: string;
  url: string;
  subtitle: string;
  caption: string;
}

export interface SiteContent {
  memberVerificationRules?: MemberVerificationRules;
  spotlightSlides?: SpotlightSlide[];
  heroSlides?: HeroSlide[];
  // Brand & Business Profile
  brandName: string;
  brandShortName: string;
  legalBusinessName: string;
  brandTagline: string;
  brandLogoUrl: string;
  brandLogoDarkUrl: string;
  faviconUrl: string;
  pageTitleTemplate: string;
  metaDescription: string;
  
  // Physical Studio & Contact Details
  businessAddressStreet: string;
  businessAddressCity: string;
  businessAddressState: string;
  businessAddressZip: string;
  businessAddressCountry: string;
  businessPhone: string;
  supportEmail: string;
  ordersEmail: string;
  pressEmail: string;
  businessHours: string;

  // Social & Community Channels (All Platforms)
  instagramHandle: string;
  instagramUrl: string;
  twitterHandle: string;
  twitterUrl: string;
  tiktokHandle: string;
  tiktokUrl: string;
  youtubeUrl: string;
  spotifyUrl: string;
  substackUrl: string;
  pinterestUrl: string;
  facebookUrl: string;
  linkedinUrl: string;
  discordUrl: string;

  // Announcements & Hero Statements
  announcementText: string;
  announcementActive: boolean;
  announcementLinkText: string;
  heroMode?: 'carousel' | 'static';
  heroChapterNumber?: string;
  heroChapterLabel?: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroTagline: string;
  heroButtonText: string;
  heroButtonTarget?: string;
  heroSecondaryButtonText?: string;
  heroSecondaryButtonTarget?: string;
  heroShowSecondaryButton?: boolean;
  heroImageUrl: string;
  heroImageOverlayOpacity: number;
  heroOverlayColor?: string;
  heroGradientStyle?: 'soft' | 'cinematic' | 'minimal' | 'none';
  heroColorMood: 'noir-black' | 'golden-amber' | 'terracotta-sunset' | 'twilight-indigo' | 'emerald-moss' | 'natural-monochrome';
  heroEnableColorBlooms?: boolean;
  heroAutoplayIntervalMs?: number;
  
  // Brand Philosophy & Story
  manifestoExcerpt: string;
  foundingQuote: string;
  storyHeadline: string;
  storyBody: string;
  connectionPromptTitle: string;
  connectionPromptSubtitle: string;

  // Frontend & Design Controls
  selectedThemeId?: string;
  shapeDividerEnabled: boolean;
  shapeDividerVariant: ShapeDividerVariant;
  shapeDividerHeight: number;
  primaryThemeColor: string;
  enableImageZoom: boolean;

  // User Experience, Shipping & E-Commerce
  freeShippingThreshold: number;
  standardShippingRate: number;
  salesTaxRatePercent: number;
  currencyCode: string;
  currencySymbol: string;
  enableDigitalDignityExport: boolean;
  enableCookieConsentBanner: boolean;
  cookieBannerHeadline: string;
  cookieBannerDescription: string;
  enableQuickBagDrawer: boolean;
  enableReflectionModal: boolean;
  enableTourGuide: boolean;

  // ==========================================
  // GLOBAL PAYMENT GATEWAY INTEGRATIONS
  // ==========================================
  // 1. Stripe
  stripeEnabled: boolean;
  stripePublishableKey: string;
  stripeSecretKey: string;
  stripeWebhookSecret: string;
  stripeStatementDescriptor: string;
  stripeLiveMode: boolean;

  // 2. PayPal
  paypalEnabled: boolean;
  paypalClientId: string;
  paypalSecretKey: string;
  paypalWebhookId: string;
  paypalEnvironment: 'sandbox' | 'production';
  paypalPayIn4Enabled: boolean;

  // 3. Apple Pay
  applePayEnabled: boolean;
  applePayMerchantId: string;
  applePayDomainName: string;
  applePayCertStatus: 'verified' | 'pending' | 'unverified';

  // 4. Google Pay
  googlePayEnabled: boolean;
  googlePayMerchantId: string;
  googlePayGatewayMerchantId: string;
  googlePayEnvironment: 'TEST' | 'PRODUCTION';

  // 5. Klarna
  klarnaEnabled: boolean;
  klarnaClientId: string;
  klarnaClientSecret: string;
  klarnaRegion: string;

  // 6. Afterpay
  afterpayEnabled: boolean;
  afterpayMerchantId: string;
  afterpaySecretKey: string;
  afterpayRegion: string;

  // 7. Cash App Pay
  cashAppPayEnabled: boolean;
  cashAppCashtag: string;
  cashAppClientId: string;
  cashAppWebhookSecret: string;

  // 8. Shop Pay
  shopPayEnabled: boolean;
  shopPayStorefrontToken: string;
  shopPayDomain: string;

  // Print-On-Demand (POD) Production Integrations
  apliiqApiKey?: string;
  apliiqApiSecret?: string;
  apliiqStoreId?: string;
  apliiqLiveMode?: boolean;
  apliiqAutoDispatch?: boolean;
  printfulApiKey?: string;
  printfulAutoDispatch?: boolean;

  // Google Search Console & SEO Integrations
  gscVerificationMetaTag?: string;
  gscPropertyUrl?: string;
  gscSitemapStatus?: string;
  ga4TrackingId?: string;
  googleMerchantCenterFeedUrl?: string;
  gscIndexingApiKey?: string;
  gscAutoIndexingEnabled?: boolean;

  // WhatsApp CallMeBot Integration
  whatsappNotificationsEnabled?: boolean;
  whatsappPhoneNumber?: string;
  whatsappApiKey?: string;
  whatsappNotifyOnNewOrder?: boolean;
  whatsappMessageTemplate?: string;

  // Transactional Email Dispatcher (Resend, SendGrid, Postmark, SMTP)
  emailProvider?: 'resend' | 'sendgrid' | 'postmark' | 'smtp' | 'simulated';
  emailApiKey?: string;
  emailFromSenderName?: string;
  emailFromSenderEmail?: string;
  emailLiveMode?: boolean;

  // SMTP Email Server & Transactional Email Templates
  smtpEnabled?: boolean;
  smtpHost?: string;
  smtpPort?: number;
  smtpEncryption?: 'TLS' | 'SSL' | 'NONE';
  smtpUsername?: string;
  smtpPassword?: string;
  smtpFromSenderName?: string;
  smtpFromSenderEmail?: string;
  smtpSignUpSubject?: string;
  smtpSignUpTemplate?: string;
  smtpPasswordResetSubject?: string;
  smtpPasswordResetTemplate?: string;
  smtpOrderConfirmSubject?: string;
  smtpOrderConfirmTemplate?: string;
  smtpOrderStatusSubject?: string;
  smtpOrderStatusTemplate?: string;

  // Editorial Page Content CMS
  whyWeExistHeadline?: string;
  whyWeExistSubtitle?: string;
  whyWeExistBody?: string;
  manifestoTitle?: string;
  manifestoPillars?: string[];
  careDirectivesTitle?: string;
  careDirectivesNotice?: string;
  contactPageTitle?: string;
  contactPageSubtitle?: string;
  shippingReturnsHeadline?: string;
  shippingReturnsBody?: string;

  // Additional Page CMS Content
  catalogSectionTitle?: string;
  catalogSectionSubtitle?: string;
  connectionSubmitPromptTitle?: string;
  connectionSubmitPromptGuide?: string;
  connectionEmptyStateNotice?: string;
  garmentFabricNotice?: string;
  garmentFulfillmentNotice?: string;
  faqPageTitle?: string;
  faqPageSubtitle?: string;
  termsPageTitle?: string;
  termsPageBody?: string;
  privacyPageTitle?: string;
  privacyPageBody?: string;
  journalPageTitle?: string;
  journalPageSubtitle?: string;
  footerSlogan?: string;
  newsletterHeading?: string;
  newsletterSubtitle?: string;
}

interface ContentContextType {
  content: SiteContent;
  faqs: FAQItem[];
  updateContent: (updates: Partial<SiteContent>) => void;
  addFaq: (faq: Omit<FAQItem, 'id'>) => void;
  updateFaq: (id: string, updates: Partial<FAQItem>) => void;
  deleteFaq: (id: string) => void;
  resetFaqs: () => void;
  resetAllContent: () => void;
}

export const DEFAULT_CONTENT: SiteContent = {
  spotlightSlides: [
    {
      id: 'slide-1',
      url: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Diverse Age Showcase · Park Series',
      caption: 'The Distance Between Us Is Man-Made',
    },
    {
      id: 'slide-2',
      url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Editorial Campaign · 02',
      caption: 'Interrupted Typography in Public Space',
    },
    {
      id: 'slide-3',
      url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=85',
      subtitle: 'Community & Connection',
      caption: 'Inaugural Statement — Est. Nov 2008',
    },
  ],
  // Brand & Business Profile
  brandName: 'Ezistential Connections',
  brandShortName: 'Ezistential',
  legalBusinessName: 'Ezistential Connections LLC',
  brandTagline: 'The Space Between People',
  brandLogoUrl: '/ez-logo.svg',
  brandLogoDarkUrl: '/ez-logo-white.svg',
  faviconUrl: '/ez-favicon.svg',
  pageTitleTemplate: 'Ezistential Connections — Space Between People',
  metaDescription: 'Brand-led apparel exploring the space between people, human connection, identity, and difference.',
  
  // Physical Studio & Contact Details
  businessAddressStreet: '1842 N Damen Ave, Suite 3F',
  businessAddressCity: 'Chicago',
  businessAddressState: 'IL',
  businessAddressZip: '60647',
  businessAddressCountry: 'United States',
  businessPhone: '+1 (312) 555-0192',
  supportEmail: 'care@ezistential.com',
  ordersEmail: 'orders@ezistential.com',
  pressEmail: 'press@ezistential.com',
  businessHours: 'Monday – Friday: 9:00 AM – 6:00 PM CST',

  // Social & Community Channels
  instagramHandle: '@ezistential',
  instagramUrl: 'https://instagram.com/ezistential',
  twitterHandle: '@ezistential',
  twitterUrl: 'https://x.com/ezistential',
  tiktokHandle: '@ezistential',
  tiktokUrl: '',
  youtubeUrl: '',
  spotifyUrl: 'https://open.spotify.com/user/ezistential',
  substackUrl: 'https://ezistential.substack.com',
  pinterestUrl: '',
  facebookUrl: '',
  linkedinUrl: '',
  discordUrl: '',

  // Announcements & Hero
  announcementText: 'Complimentary US Domestic Shipping on Orders $75+ • On-Demand 6.5oz Heavyweight Cotton',
  announcementActive: true,
  announcementLinkText: 'Explore Garments',
  heroMode: 'carousel',
  heroSlides: DEFAULT_HERO_SLIDES,
  heroChapterNumber: '01',
  heroChapterLabel: 'The Threshold',
  heroHeadline: 'We share the same world, yet we experience each other at a distance.',
  heroSubheadline: 'Ezistential Connections examines the space between people. Our garments carry quiet questions into public space, interrupting assumptions, honoring difference, and opening the possibility of discovery.',
  heroTagline: 'The Medium Is Clothing. The Subject Is Connection.',
  heroButtonText: 'Explore Garments',
  heroButtonTarget: 'shop',
  heroSecondaryButtonText: 'Why We Exist',
  heroSecondaryButtonTarget: 'why-we-exist',
  heroShowSecondaryButton: true,
  heroImageUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=2000&q=85',
  heroImageOverlayOpacity: 0.55,
  heroOverlayColor: '#0a0a0a',
  heroGradientStyle: 'soft',
  heroColorMood: 'golden-amber',
  heroEnableColorBlooms: true,
  heroAutoplayIntervalMs: 7500,
  
  // Philosophy & Story
  manifestoExcerpt: 'Difference is not a defect to be eliminated, nor is it an excuse for division. Somewhere between you and me, there is an us worth discovering.',
  foundingQuote: 'We are not the same. That’s the point.',
  storyHeadline: 'Garments as Quiet Inquiries in Public Space',
  storyBody: 'We create tactile clothing designed to prompt dialogue, spark contemplation, and honor the nuance of human individuality without aggressive noise.',
  connectionPromptTitle: 'What does this mean to you?',
  connectionPromptSubtitle: 'Contribute your perspective to our curated Human Connection Archive.',

  // Frontend & Design
  selectedThemeId: 'editorial-noir',
  shapeDividerEnabled: true,
  shapeDividerVariant: 'editorial-notch',
  shapeDividerHeight: 64,
  primaryThemeColor: '#0a0a0a',
  enableImageZoom: true,

  // UX & E-Commerce
  freeShippingThreshold: 75,
  standardShippingRate: 6.0,
  salesTaxRatePercent: 6.5,
  currencyCode: 'USD',
  currencySymbol: '$',
  enableDigitalDignityExport: true,
  enableCookieConsentBanner: true,
  cookieBannerHeadline: 'We believe your attention and data belong to you.',
  cookieBannerDescription: 'Ezistential Connections uses strictly essential session integrity to preserve your garment bag, customer account, and made-to-order inquiries. We categorically reject surveillance ad networks, data brokers, and third-party tracking pixels.',
  enableQuickBagDrawer: true,
  enableReflectionModal: true,
  enableTourGuide: false,

  // Global Payment Gateways Configuration
  // 1. Stripe
  stripeEnabled: false,
  stripePublishableKey: '',
  stripeSecretKey: '',
  stripeWebhookSecret: '',
  stripeStatementDescriptor: 'EZISTENTIAL',
  stripeLiveMode: false,

  // 2. PayPal
  paypalEnabled: false,
  paypalClientId: '',
  paypalSecretKey: '',
  paypalWebhookId: '',
  paypalEnvironment: 'sandbox',
  paypalPayIn4Enabled: false,

  // 3. Apple Pay
  applePayEnabled: false,
  applePayMerchantId: '',
  applePayDomainName: '',
  applePayCertStatus: 'unverified',

  // 4. Google Pay
  googlePayEnabled: false,
  googlePayMerchantId: '',
  googlePayGatewayMerchantId: '',
  googlePayEnvironment: 'TEST',

  // 5. Klarna
  klarnaEnabled: false,
  klarnaClientId: '',
  klarnaClientSecret: '',
  klarnaRegion: 'US',

  // 6. Afterpay
  afterpayEnabled: false,
  afterpayMerchantId: '',
  afterpaySecretKey: '',
  afterpayRegion: 'US',

  // 7. Cash App Pay
  cashAppPayEnabled: false,
  cashAppCashtag: '',
  cashAppClientId: '',
  cashAppWebhookSecret: '',

  // 8. Shop Pay
  shopPayEnabled: false,
  shopPayStorefrontToken: '',
  shopPayDomain: '',

  // Print-On-Demand (POD) Production Integrations
  apliiqApiKey: 'apq_live_k8201948194',
  apliiqApiSecret: '',
  apliiqStoreId: 'APQ-STORE-EZISTENTIAL-01',
  apliiqLiveMode: true,
  apliiqAutoDispatch: true,
  printfulApiKey: '',
  printfulAutoDispatch: false,

  // Google Search Console & SEO Integrations
  gscVerificationMetaTag: '',
  gscPropertyUrl: 'https://ezistential.com',
  gscSitemapStatus: 'Active (https://ezistential.com/sitemap.xml)',
  ga4TrackingId: '',
  googleMerchantCenterFeedUrl: 'https://ezistential.com/api/feeds/google-merchant.xml',
  gscIndexingApiKey: '',
  gscAutoIndexingEnabled: true,

  // WhatsApp CallMeBot Integration
  whatsappNotificationsEnabled: false,
  whatsappPhoneNumber: '+13125550192',
  whatsappApiKey: '',
  whatsappNotifyOnNewOrder: true,
  whatsappMessageTemplate: '🛍️ *New Order Alert from {brand_name}!*\nOrder ID: #{order_id}\nCustomer: {customer_name}\nTotal: ${total_amount}\nItems: {items_summary}',

  // Transactional Email Service Configuration
  emailProvider: 'simulated',
  emailApiKey: '',
  emailFromSenderName: 'Ezistential Connections',
  emailFromSenderEmail: 'care@ezistential.com',
  emailLiveMode: false,

  // SMTP Email Server & Transactional Templates
  smtpEnabled: false,
  smtpHost: 'smtp.gmail.com',
  smtpPort: 587,
  smtpEncryption: 'TLS',
  smtpUsername: 'care@ezistential.com',
  smtpPassword: '',
  smtpFromSenderName: 'Ezistential Connections',
  smtpFromSenderEmail: 'care@ezistential.com',
  smtpSignUpSubject: 'Welcome to Ezistential Connections — Space Between People',
  smtpSignUpTemplate: 'Dear {customer_name},\n\nWelcome to Ezistential Connections. Your account has been initialized.\n\nExplore our connection garments at https://ezistential.com\n\nWarm regards,\nEzistential Connections Studio',
  smtpPasswordResetSubject: 'Reset Your Ezistential Connections Password',
  smtpPasswordResetTemplate: 'Hello {customer_name},\n\nWe received a request to reset your password. Click the link below to verify:\n{reset_link}\n\nIf you did not request this, please ignore this message.\n\nEzistential Care Team',
  smtpOrderConfirmSubject: 'Order Confirmation #{order_id} — Ezistential Connections',
  smtpOrderConfirmTemplate: 'Dear {customer_name},\n\nThank you for your order #{order_id} totaling ${total_amount}.\n\nItems Ordered:\n{items_summary}\n\nWe are preparing your garments for print-on-demand fulfillment.\n\nEzistential Fulfillment',
  smtpOrderStatusSubject: 'Shipment Update for Order #{order_id} — In Transit',
  smtpOrderStatusTemplate: 'Dear {customer_name},\n\nYour order #{order_id} status has been updated to: {order_status}.\n\nTracking Reference: {tracking_number}\n\nThank you for journeying with us,\nEzistential Connections',

  // Editorial Page Content CMS Defaults
  whyWeExistHeadline: 'Why We Exist',
  whyWeExistSubtitle: 'A garment is not merely fabric; it is an artifact of presence.',
  whyWeExistBody: 'In an era of hyper-connectivity, physical proximity has become increasingly rare. Ezistential Connections creates garments that act as gentle signals—prompting reflection, dialogue, and quiet recognition between individuals.',
  manifestoTitle: 'The Ezistential Manifesto',
  manifestoPillars: [
    '1. Design with intention and physical weight.',
    '2. Honor the dignity of human presence over digital distraction.',
    '3. Create clothing that serves as a bridge, not a barrier.',
    '4. Practice ethical print-on-demand zero-waste manufacturing.'
  ],
  careDirectivesTitle: 'Garment Care & Fabric Integrity Directives',
  careDirectivesNotice: 'Crafted from 6.5oz 100% combed ring-spun cotton. Wash inside out in cold water, line dry to preserve fabric density and screenprint integrity.',
  contactPageTitle: 'Studio Premises & Inquiries',
  contactPageSubtitle: 'Our Chicago studio is open for scheduled consultations, press inquiries, and care support.',
  shippingReturnsHeadline: 'Logistics, Domestic Delivery & Returns Covenant',
  shippingReturnsBody: 'All garments are printed on-demand with 3–5 business days production time. Unworn garments in original condition may be returned within 30 days of receipt.',

  // Additional Page CMS Defaults
  catalogSectionTitle: 'On-Demand Heavyweight Garments',
  catalogSectionSubtitle: 'Heavyweight 6.5oz combed cotton garments designed to provoke quiet recognition.',
  connectionSubmitPromptTitle: 'Submit an Anonymous Reflection',
  connectionSubmitPromptGuide: 'Reflections are moderated by studio stewards before publication in the Connection Archive.',
  connectionEmptyStateNotice: 'No published reflections in this category yet. Be the first to share an entry.',
  garmentFabricNotice: '100% Combed Ring-Spun Cotton, 6.5oz Heavyweight Custom Blank.',
  garmentFulfillmentNotice: 'Printed on-demand with zero-waste manufacturing. 3–5 business days fulfillment.',
  faqPageTitle: 'Frequently Asked Questions & Care Directives',
  faqPageSubtitle: 'Answers regarding garment care, custom heavyweight sizing, and domestic shipping.',
  termsPageTitle: 'Terms of Service & Usage Covenant',
  termsPageBody: 'By interacting with the Ezistential Connections digital storefront, you agree to respectful engagement.',
  privacyPageTitle: 'Digital Dignity & Privacy Covenant',
  privacyPageBody: 'We process minimal telemetry required for order logistics. No third-party tracking or data harvesting.',
  journalPageTitle: 'Journal & Studio Updates',
  journalPageSubtitle: 'Articles, design manifestos, and studio notes from Ezistential Connections.',
  footerSlogan: 'Examining the space between people through intentional apparel.',
  newsletterHeading: 'Receive Studio Dispatches',
  newsletterSubtitle: 'Occasional letters on connection, garment releases, and studio manifestos.',
};

const STORAGE_KEY_CONTENT = 'ec_cms_content_v8';
const STORAGE_KEY_FAQS = 'ec_cms_faqs_v8';

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [content, setContent] = useState<SiteContent>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CONTENT);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.faviconUrl || parsed.faviconUrl === '/favicon.ico') {
          parsed.faviconUrl = '/ez-favicon.svg';
        }
        if (!parsed.heroImageUrl) {
          parsed.heroImageUrl = DEFAULT_CONTENT.heroImageUrl;
        }
        if (parsed.heroImageOverlayOpacity === undefined) {
          parsed.heroImageOverlayOpacity = DEFAULT_CONTENT.heroImageOverlayOpacity;
        }
        if (!parsed.heroColorMood) {
          parsed.heroColorMood = DEFAULT_CONTENT.heroColorMood;
        }
        if (!parsed.heroSlides || !Array.isArray(parsed.heroSlides) || parsed.heroSlides.length === 0) {
          parsed.heroSlides = DEFAULT_HERO_SLIDES;
        }
        return { ...DEFAULT_CONTENT, ...parsed };
      }
      return DEFAULT_CONTENT;
    } catch {
      return DEFAULT_CONTENT;
    }
  });

  const [faqs, setFaqs] = useState<FAQItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FAQS);
      return saved ? JSON.parse(saved) : DEFAULT_FAQS;
    } catch {
      return DEFAULT_FAQS;
    }
  });

  // Cross-device sync from central database
  useEffect(() => {
    const syncContentFromDB = async () => {
      try {
        const serverContent = await api.getContent();
        if (serverContent && Object.keys(serverContent).length > 0) {
          setContent((prev) => ({ ...prev, ...serverContent }));
        }
      } catch (err) {
        console.warn('Central DB content sync notice:', err);
      }
    };
    syncContentFromDB();
  }, []);

  // Save content changes to localStorage & backend
  const updateContent = (updates: Partial<SiteContent>) => {
    setContent((prev) => {
      const updated = { ...prev, ...updates };
      try {
        localStorage.setItem(STORAGE_KEY_CONTENT, JSON.stringify(updated));
      } catch (err) {
        console.error('Failed to save content locally:', err);
      }
      // Persist to central server database
      api.updateContent(updated).catch(console.warn);
      return updated;
    });
  };

  const addFaq = (newFaqData: Omit<FAQItem, 'id'>) => {
    const newFaq: FAQItem = {
      ...newFaqData,
      id: `faq-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    };
    setFaqs((prev) => {
      const updated = [...prev, newFaq];
      localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(updated));
      return updated;
    });
  };

  const updateFaq = (id: string, updates: Partial<FAQItem>) => {
    setFaqs((prev) => {
      const updated = prev.map((f) => (f.id === id ? { ...f, ...updates } : f));
      localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(updated));
      return updated;
    });
  };

  const deleteFaq = (id: string) => {
    setFaqs((prev) => {
      const updated = prev.filter((f) => f.id !== id);
      localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(updated));
      return updated;
    });
  };

  const resetFaqs = () => {
    setFaqs(DEFAULT_FAQS);
    localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(DEFAULT_FAQS));
  };

  const resetAllContent = () => {
    setContent(DEFAULT_CONTENT);
    setFaqs(DEFAULT_FAQS);
    localStorage.setItem(STORAGE_KEY_CONTENT, JSON.stringify(DEFAULT_CONTENT));
    localStorage.setItem(STORAGE_KEY_FAQS, JSON.stringify(DEFAULT_FAQS));
    api.updateContent(DEFAULT_CONTENT).catch(console.warn);
  };

  // Sync browser document title, favicon, and UX/UI theme dynamically
  useEffect(() => {
    if (content.pageTitleTemplate) {
      document.title = content.pageTitleTemplate;
    }
    if (content.faviconUrl) {
      let link: HTMLLinkElement | null = document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.getElementsByTagName('head')[0].appendChild(link);
      }
      link.href = content.faviconUrl;
    }

    // Apply Live UI Theme to document root & body
    const activeTheme = content.selectedThemeId || 'editorial-noir';
    const root = document.documentElement;
    root.setAttribute('data-theme', activeTheme);
    
    // Remove previous theme classes and attach current theme class
    const themeClasses = ['theme-editorial-noir', 'theme-warm-parchment', 'theme-raw-canvas', 'theme-cyber-minimalist'];
    themeClasses.forEach((cls) => {
      document.body.classList.remove(cls);
      root.classList.remove(cls);
    });
    document.body.classList.add(`theme-${activeTheme}`);
    root.classList.add(`theme-${activeTheme}`);

    // Update CSS custom variable for theme primary accent color
    if (content.primaryThemeColor) {
      root.style.setProperty('--color-theme-primary', content.primaryThemeColor);
    }
  }, [content.pageTitleTemplate, content.faviconUrl, content.selectedThemeId, content.primaryThemeColor]);

  return (
    <ContentContext.Provider
      value={{
        content,
        faqs,
        updateContent,
        addFaq,
        updateFaq,
        deleteFaq,
        resetFaqs,
        resetAllContent,
      }}
    >
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const ctx = useContext(ContentContext);
  if (!ctx) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return ctx;
};
